import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const payrolldashboard = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default payrolldashboard;
