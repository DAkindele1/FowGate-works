import React from 'react'

const notfound = () => {
  return (
    <div>
      <p>Return to home page please</p>
    </div>
  )
}

export default notfound
