import React from 'react'
import Sidebar from '../../Components/Dashboard/Sidebar'

const settingsdasboard = () => {
  return (
    <div>
      <Sidebar />
    </div>
  )
}

export default settingsdasboard
