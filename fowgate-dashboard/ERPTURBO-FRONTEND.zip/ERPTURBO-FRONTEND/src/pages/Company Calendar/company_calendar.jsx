import React from 'react'
import Sidebar from '../../Components/Dashboard/Sidebar'

const company_calendar = () => {
  return (
    <div>
      <Sidebar />
    </div>
  )
}

export default company_calendar
