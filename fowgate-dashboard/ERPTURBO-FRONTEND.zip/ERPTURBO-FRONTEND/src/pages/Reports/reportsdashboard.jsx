import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const reportsdashboard = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default reportsdashboard;
