import React from "react";

const accountdashboard = () => {
  return <div>Account Dashboard</div>;
};

export default accountdashboard;
