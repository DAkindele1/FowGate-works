import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const messagesdashboard = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default messagesdashboard;
