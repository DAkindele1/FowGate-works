import React, { useState } from "react";
import JobBoard from "../../Components/ATS Dashboard/Job Board/components/JobBoard";

import TalentPool from "../../Components/ATS Dashboard/Talent Pool/components/TalentPool";
import RecruitmentCentral from "../../Components/ATS Dashboard/Recruitment Central/RecruitmentCentral";
import ScheduledInterviewContainer from "../../Components/ATS Dashboard/Recruitment Central/components/Interview Central/Scheduled Interview/ScheduledInterviewContainer";
import ManageAIContainer from "../../Components/ATS Dashboard/Recruitment Central/components/Interview Central/Manage AI Assessment/ManageAIContainer";
import PageHeader from "../../ui/PageHeader";
import TopPagination from "../../ui/TopPagination";

const Atsdashboard = () => {
  // const [activeTab, setActiveTab] = useState("Job Board");
  const [activeTab, setActiveTab] = useState("Recruitment Central");
    const [scheduledInterviews,setScheduledInterviews] = useState(false)
  const [manageAI, setManageAI] = useState(false)
  const [jobCode, setJobCode] = useState("");

  const tabContent =
    activeTab === "Job Board" ? (
      <JobBoard />
    ) : activeTab === "Recruitment Central" ? (
        <RecruitmentCentral 
          setScheduledInterviews={setScheduledInterviews} 
          setManageAI={setManageAI} 
          setJobCode={setJobCode} 
        />
    ) : activeTab === "Talent Pool" ? (
      <TalentPool />
    ) : "";
  
   const atsTabs = [
    { name: "Job Board" },
    { name: "Recruitment Central" },
    { name: "Talent Pool" },
  ];

  return (
    <div className="relative">
      {manageAI ? <ManageAIContainer setManageAI={setManageAI} jobCode={jobCode}/>: scheduledInterviews ? <ScheduledInterviewContainer setScheduledInterviews={ setScheduledInterviews} /> : <div className="flex">
      <main className="flex-1 ">
        <PageHeader />
          <TopPagination tabs={atsTabs} onTabChange={setActiveTab} currTab={activeTab} />

        {tabContent}
      </main>
    </div>}
    </div>
  );
};

export default Atsdashboard;
