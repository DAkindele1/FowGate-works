import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const compliancemanagementdashboard = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default compliancemanagementdashboard;
