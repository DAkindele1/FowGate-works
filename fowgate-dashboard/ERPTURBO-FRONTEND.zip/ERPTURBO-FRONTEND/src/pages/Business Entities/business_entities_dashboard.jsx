import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const business_entities_dashboard = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default business_entities_dashboard;
