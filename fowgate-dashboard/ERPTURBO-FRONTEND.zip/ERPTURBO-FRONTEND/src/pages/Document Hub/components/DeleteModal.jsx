import React from 'react';
import AddFolderIcon from '../assets/addfolder.svg'; // Reuse for consistency

const DeleteModal = ({ isOpen, onClose, onConfirm, itemType = 'item', itemName = '' }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
      <div className="w-[460px] bg-white rounded shadow-xl overflow-hidden font-[Rubik] animate-fade-in-up">

        {/* Header */}
        <div className="bg-[#1B5FC1] px-6 py-4 flex items-center gap-2">
          <img src={AddFolderIcon} alt="Delete" className="w-5 h-5" />
          <h2 className="text-white text-lg font-semibold">Delete {itemType}</h2>
        </div>

        {/* Body */}
        <div className="p-4 text-sm text-gray-700">
          Are you sure you want to delete{' '}
          <span className="font-semibold text-gray-900">{itemName}</span>?<br />
          This action cannot be undone.

          <div className="mt-6 flex justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 transition"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="px-4 py-2 text-sm font-medium bg-red-600 text-white rounded hover:bg-red-700 transition"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeleteModal;
