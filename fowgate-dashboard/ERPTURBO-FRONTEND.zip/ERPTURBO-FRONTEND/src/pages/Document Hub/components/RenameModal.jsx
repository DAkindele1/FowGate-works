import React, { useEffect, useState } from 'react';
import AddFolderIcon from '../assets/addfolder.svg'; // adjust path as needed

const RenameModal = ({ item, onClose, onRename }) => {
  const [newName, setNewName] = useState(item?.name || '');

  useEffect(() => {
    if (item?.name) {
      setNewName(item.name);
    }
  }, [item]);

  const handleSubmit = () => {
    if (newName.trim() !== '') {
      onRename(newName.trim());
    }
  };

  if (!item) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
      <div className="w-[460px] bg-white rounded shadow-xl overflow-hidden font-[Rubik] animate-fade-in-up">

        {/* Header */}
        <div className="bg-[#1B5FC1] px-6 py-4 flex items-center gap-2">
          <img src={AddFolderIcon} alt="Add" className="w-5 h-5" />
          <h2 className="text-white text-lg font-semibold">
            Rename {item?.type === 'folder' ? 'Folder' : 'File'}
          </h2>
        </div>

        {/* Body */}
        <div className="p-4">
          <label className="block text-sm text-gray-700 mb-1">
            {item?.type === 'folder' ? 'Folder' : 'File'} name
          </label>
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Enter new name"
            className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
          />

          <div className="mt-6 flex justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 transition"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              className="px-4 py-2 text-sm font-medium bg-blue-600 text-white rounded hover:bg-blue-700 transition"
            >
              Rename {item?.type === 'folder' ? 'Folder' : 'File'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RenameModal;

