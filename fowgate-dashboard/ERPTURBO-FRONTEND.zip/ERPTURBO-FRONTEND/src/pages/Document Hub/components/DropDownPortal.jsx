// src/components/DropdownPortal.jsx
import { createPortal } from 'react-dom';
import React, { useEffect, useState } from 'react';

const DropdownPortal = ({ children, position }) => {
  const [dropdownRoot, setDropdownRoot] = useState(null);

  useEffect(() => {
    let root = document.getElementById('dropdown-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'dropdown-root';
      document.body.appendChild(root);
    }
    setDropdownRoot(root);
  }, []);

  if (!dropdownRoot) return null;

  return createPortal(
    <div
      className="absolute bg-white border border-gray-200 rounded shadow-lg w-32 z-[9999]"
      style={{ top: position.top, left: position.left }}
    >
      {children}
    </div>,
    dropdownRoot
  );
};

export default DropdownPortal;
