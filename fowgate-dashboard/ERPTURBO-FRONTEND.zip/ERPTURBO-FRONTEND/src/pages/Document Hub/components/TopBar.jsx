// components/DocumentHub/TopBar.jsx

import React from 'react';
import { FiSearch, FiPlus } from 'react-icons/fi';

const TopBar = ({ currentFolderPath, onNewFolderClick }) => {
  const currentFolderName = currentFolderPath[currentFolderPath.length - 1];

  return (
    <div className="flex items-center justify-between px-4 py-2 border-b border-gray-200 bg-white">
      <h2 className="text-lg font-semibold">{currentFolderName}</h2>

      <div className="flex items-center gap-2">
        <div className="relative">
          <input
            type="text"
            placeholder="Search"
            className="pl-8 pr-2 py-1 text-sm border rounded"
            disabled
          />
          <FiSearch className="absolute left-2 top-1.5 text-gray-400" />
        </div>

        <button
          onClick={onNewFolderClick}
          className="flex items-center gap-1 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded"
        >
          <FiPlus />
          <span>New Folder</span>
        </button>
      </div>
    </div>
  );
};

export default TopBar;
