import React from 'react';
import { FiChevronRight } from 'react-icons/fi';

const Breadcrumb = ({ path, onNavigate }) => {
  const handleClick = (index) => {
    const newPath = path.slice(0, index + 1);
    onNavigate(newPath);
  };

  return (
    <nav className="flex items-center text-sm text-gray-700 space-x-1">
      {path.map((folder, index) => (
        <div key={index} className="flex items-center">
          {index > 0 && <FiChevronRight className="mx-1 text-gray-400" />}
          <button
            onClick={() => handleClick(index)}
            className={`${
              index === path.length - 1
                ? 'font-semibold text-gray-900'
                : 'text-blue-600 hover:underline'
            } truncate max-w-[120px]`}
            title={folder}
          >
            {folder}
          </button>
        </div>
      ))}
    </nav>
  );
};

export default Breadcrumb;


