import React from 'react';
import MyDriveIcon from '../assets/mydrive.svg';
import SharedIcon from '../assets/shared.svg';
import RecentIcon from '../assets/recent.svg';
import MeetingNotesIcon from '../assets/meetingnotes.svg';
import PersonalNotesIcon from '../assets/personalnotes.svg';
import { BsFolderFill } from 'react-icons/bs';

const HubSidebar = ({ fileData, currentFolderPath, setCurrentFolderPath }) => {
  const myDriveSubfolders = fileData.filter(
    (item) =>
      item.type === 'folder' &&
      item.path[0] === 'My Drive' &&
      item.path.length === 2
  );

  const handleFolderClick = (folderName) => {
    setCurrentFolderPath(['My Drive', folderName]);
  };

  return (
    <div className="w-[250px] h-[960px] bg-white border-r border-gray-200 p-4">
      <div
        onClick={() => setCurrentFolderPath(['My Drive'])}
        className={`flex items-center gap-2 p-2 rounded cursor-pointer ${
          currentFolderPath.length === 1 ? 'bg-gray-100' : ''
        }`}
      >
        <img src={MyDriveIcon} alt="My Drive" className="w-5 h-5" />
        <span className="text-sm font-medium">My Drive</span>
      </div>

      <div className="flex items-center gap-2 p-2 text-gray-400 cursor-not-allowed">
        <img src={SharedIcon} alt="Shared" className="w-5 h-5" />
        <span className="text-sm font-medium">Shared with me</span>
      </div>

      <div className="flex items-center gap-2 p-2 text-gray-400 cursor-not-allowed">
        <img src={RecentIcon} alt="Recent" className="w-5 h-5" />
        <span className="text-sm font-medium">Recent</span>
      </div>

      <div className="flex items-center gap-2 p-2 text-gray-400 cursor-not-allowed">
        <img src={MeetingNotesIcon} alt="Meeting Notes" className="w-5 h-5" />
        <span className="text-sm font-medium">Meeting Notes</span>
      </div>

      <div className="flex items-center gap-2 p-2 text-gray-400 cursor-not-allowed">
        <img src={PersonalNotesIcon} alt="Personal Notes" className="w-5 h-5" />
        <span className="text-sm font-medium">Personal Notes</span>
      </div>

      <hr className="my-4 border-gray-200" />

      <div className="px-2">
        <p className="text-xs text-gray-400 mb-1">Folders</p>
        {myDriveSubfolders.length === 0 ? (
          <p className="text-sm text-gray-400 italic">No folders yet</p>
        ) : (
          myDriveSubfolders.map((folder) => (
            <div
              key={folder.name}
              onClick={() => handleFolderClick(folder.name)}
              className={`flex items-center gap-2 p-2 rounded cursor-pointer ${
                currentFolderPath[1] === folder.name ? 'bg-gray-100' : ''
              }`}
            >
              <BsFolderFill className="text-yellow-400" />
              <span className="text-sm">{folder.name}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default HubSidebar;
