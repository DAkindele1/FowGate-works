import React, { useState, useRef, useEffect } from 'react';
import { FiMoreVertical } from 'react-icons/fi';
import { BsFolderFill, BsFileEarmark } from 'react-icons/bs';
import DropdownPortal from './DropDownPortal';

const FileTable = ({ fileData, currentFolderPath, onFolderOpen, onRename, onDelete }) => {
  const [dropdownIndex, setDropdownIndex] = useState(null);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });
  const buttonsRef = useRef([]);

  const toggleDropdown = (index) => {
    if (dropdownIndex === index) {
      setDropdownIndex(null);
      return;
    }

    const button = buttonsRef.current[index];
    const rect = button.getBoundingClientRect();
    setDropdownPosition({
      top: rect.bottom + window.scrollY,
      left: rect.left + window.scrollX,
    });

    setDropdownIndex(index);
  };

  const currentFiles = fileData.filter(
    (item) => JSON.stringify(item.path) === JSON.stringify(currentFolderPath)
  );

  return (
    <div className="bg-white rounded shadow overflow-hidden relative z-0">
      <table className="w-full text-sm text-left text-gray-700">
        <thead className="bg-gray-100 text-gray-600 uppercase">
          <tr>
            <th className="px-4 py-3">Name</th>
            <th className="px-4 py-3">Type</th>
            <th className="px-4 py-3">Created</th>
            <th className="px-4 py-3 text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentFiles.length === 0 ? (
            <tr>
              <td colSpan="4" className="px-4 py-6 text-center text-gray-500">
                No items in this folder.
              </td>
            </tr>
          ) : (
            currentFiles.map((item, index) => (
              <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                <td
                  onClick={() =>
                    item.type === 'folder' && onFolderOpen([...item.path, item.name])
                  }
                  className={`px-4 py-3 cursor-pointer flex items-center gap-2 ${
                    item.type === 'folder' ? 'font-semibold text-blue-600' : ''
                  }`}
                >
                  {item.type === 'folder' ? (
                    <BsFolderFill className="text-blue-500" />
                  ) : (
                    <BsFileEarmark />
                  )}
                  {item.name}
                </td>
                <td className="px-4 py-3 capitalize">{item.type}</td>
                <td className="px-4 py-3">
                  {new Date(item.createdAt).toLocaleDateString()}
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    ref={(el) => (buttonsRef.current[index] = el)}
                    onClick={() => toggleDropdown(index)}
                  >
                    <FiMoreVertical />
                  </button>
                  {dropdownIndex === index && (
                    <DropdownPortal position={dropdownPosition}>
                      <button
                        onClick={() => {
                          onRename?.(item);
                          setDropdownIndex(null);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-gray-100"
                      >
                        Rename
                      </button>
                      <button
                        onClick={() => {
                          onDelete?.(item);
                          setDropdownIndex(null);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-gray-100 text-red-600"
                      >
                        Delete
                      </button>
                    </DropdownPortal>
                  )}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default FileTable;

