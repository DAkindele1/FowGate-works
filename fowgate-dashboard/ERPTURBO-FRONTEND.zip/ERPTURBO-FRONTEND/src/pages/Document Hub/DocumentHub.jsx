import React, { useState } from 'react';
import HubSidebar from './components/HubSidebar';
import CreateFolderModal from './components/CreateFolderModal';
import NewFileModal from './components/NewFileModal';
import FileTable from './components/FileTable';
import Breadcrumb from './components/BreadCrumb';
import RenameModal from './components/RenameModal';

const DocumentHub = () => {
  const [fileData, setFileData] = useState([]);
  const [currentFolderPath, setCurrentFolderPath] = useState(['My Drive']);
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);
  const [showCreateFolderModal, setShowCreateFolderModal] = useState(false);
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [itemToRename, setItemToRename] = useState(null);
  const isInMyDrive = currentFolderPath[0] === 'My Drive';
  const isInsideMyDriveFolder = isInMyDrive && currentFolderPath.length > 1;

  const handleCreateFolder = (folderName) => {
    const newFolder = {
      name: folderName,
      type: 'folder',
      path: currentFolderPath,
      createdAt: new Date().toISOString(),
    };
    setFileData([...fileData, newFolder]);
    setIsCreateFolderOpen(false);
  };

  const handleCreateFile = (fileName) => {
    const newFile = {
      name: fileName,
      type: 'file',
      path: currentFolderPath,
      createdAt: new Date().toISOString(),
    };
    setFileData([...fileData, newFile]);
  };

  const handleFolderOpen = (newPath) => {
    setCurrentFolderPath(newPath);
  };

  const handleDelete = (item) => {
    const filtered = fileData.filter(
      (f) =>
        !(f.name === item.name &&
          f.type === item.type &&
          JSON.stringify(f.path) === JSON.stringify(item.path))
    );
    setFileData(filtered);
  };

  const handleRename = (item) => {
    setItemToRename(item);
    setShowRenameModal(true);
  };

  const confirmRename = (newName) => {
    const updated = fileData.map((f) => {
      if (
        f.name === itemToRename.name &&
        f.type === itemToRename.type &&
        JSON.stringify(f.path) === JSON.stringify(itemToRename.path)
      ) {
        return { ...f, name: newName };
      }
      return f;
    });
    setFileData(updated);
    setShowRenameModal(false);
    setItemToRename(null);
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <HubSidebar
        currentFolderPath={currentFolderPath}
        setCurrentFolderPath={setCurrentFolderPath}
        fileData={fileData}
      />

      <div className="flex-1 flex flex-col p-4">
        <div className="flex justify-between items-center mb-4">
          <Breadcrumb path={currentFolderPath} onNavigate={setCurrentFolderPath} />

          <div className="flex gap-2">
            {isInMyDrive && (
              <button
                onClick={() => setIsCreateFolderOpen(true)}
                className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                + New Folder
              </button>
            )}
            {isInsideMyDriveFolder && (
              <button
                onClick={() => setShowNewFileModal(true)}
                className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700"
              >
                + Upload File
              </button>
            )}
          </div>
        </div>

        <FileTable
          fileData={fileData}
          currentFolderPath={currentFolderPath}
          onFolderOpen={handleFolderOpen}
          onDelete={handleDelete}
          onRename={handleRename}
        />
      </div>

      {isCreateFolderOpen && (
        <CreateFolderModal
          isOpen={isCreateFolderOpen}
          onClose={() => setShowCreateFolderModal(false)}
          onCreate={handleCreateFolder}
        />
      )}

      {showNewFileModal && (
        <NewFileModal
          onClose={() => setShowNewFileModal(false)}
          onCreate={handleCreateFile}
        />
      )}

      {showRenameModal && (
        <RenameModal
          item={itemToRename}
          onClose={() => setShowRenameModal(false)}
          onRename={confirmRename}
        />
      )}
    </div>
  );
};

export default DocumentHub;