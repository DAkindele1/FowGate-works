import { configureStore } from '@reduxjs/toolkit';
import jobBoardReducer from './jobBoardSlice';

const store = configureStore({
    reducer: {
      jobBoard: jobBoardReducer,
  },
});

export default store;