import axios from "axios";
import toast from "react-hot-toast";

const API_BASE_URL = import.meta.env.VITE_ERP_TURBO_API_BASE_URL;

export const authUser = async (request, endpoint, data) => {


  try {
    const response = await axios({
      method: request, 
      url: `${API_BASE_URL}${endpoint}`,
      data: request === "GET" ? null : data, 
      headers: {
        "Content-Type": "application/json",
      },
    });

    return { success: true, data: response.data };
  } catch (error) {
    toast.error(error.message)
    console.error(
      error.response?.data || error.message
    );
    return {
      success: false,
      message: error.response?.data?.message || "Something went wrong",
    };
  }
};
