
import React from "react";
import WhiteButton from "./WhiteButton";

export default function FormBtns({ closeModal, step, nextStep, mode = 'create', firstBtnText, firstBtnIcon, firstBtnTextColor, secondBtnText, disabled }) {
  
  return (
    <div className="flex py-[17px] px-[24px] gap-4 border-t border-gray-300 justify-end text-[14px] h-[78px]">
      <WhiteButton text={firstBtnText ? firstBtnText : step === 5 ? "Save as Draft" : step === 6 ? "Cancel" : "Save & Close"} action={closeModal} icon={ firstBtnIcon} textColor={firstBtnTextColor} />
      {/* <button 
        className={`border border-gray-300 text-center py-[10px] px-3 rounded-sm transition cursor-pointer  flex items-center gap-1 ${firstBtnTextColor ? firstBtnTextColor : "hover:text-[#EAeaea] hover:bg-[#292929]"}` }
        onClick={closeModal}
      >
        {firstBtnIcon === "trash" && <TrashIcon size={16}/>}
        {firstBtnText? firstBtnText:step === 5 ? "Save as Draft" : step === 6 ? "Cancel" : "Save & Close"}
      </button> */}
      <button 
        onClick={disabled ? undefined : nextStep} 
        className={`bg-[#E8EFF9] text-[#1B5fc1] py-2 ${mode === "schedule"? "px-[10px] w-fit": "px-3 w-[117px]"} block rounded-sm transition ${
          disabled ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer hover:text-[#E8EFF9] hover:bg-[#1B5fc1]'
        }`}
      >
        {secondBtnText? secondBtnText:step < 5 ? "Next" : step === 6 ? "Yes, I'm sure" : mode === 'create' ? "Publish" : "Update"}
      </button>
    </div>
  );
}