import React from 'react'

export default function InfoPill({children}) {
  return (
    <div className={`px-3 py-1.5 flex items-center gap-2 bg-[#F3F2F2] text-[#292929] rounded-[40px] `}>{children}</div>
  )
}
