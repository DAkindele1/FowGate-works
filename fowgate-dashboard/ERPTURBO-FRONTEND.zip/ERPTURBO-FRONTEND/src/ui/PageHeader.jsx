import React from "react";
import { BellIcon, CaretDownIcon } from "@phosphor-icons/react";

const PageHeader = () => {
  return (
    <header className="flex items-center justify-between">
        <h2 className="text-[28px] font-medium">HCM</h2>

      <div className="flex items-center space-x-6 ">
        <button className="relative border border-gray-200 rounded-md w-[42px] h-[42px] flex items-center justify-center">
          <BellIcon size={24} className="text-gray-600" />
          <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>

        <div className="flex items-center justify-center gap-[8px] border border-gray-200 p-0.5 rounded-full h-[42px] w-[70px]">
          <img
            src="/assets/img/memoji.png"
            alt="Profile"
            className="w-[26px] h-[26px] rounded-full object-cover"
          />
          <CaretDownIcon size={20} className="text-gray-600" />
        </div>
      </div>
    </header>
  );
};

export default PageHeader;
