import React from 'react';
import { FaCheck } from 'react-icons/fa';

const CheckMarker = () => {
  return (
    <div className="w-[150px] h-[150px] mx-auto flex items-center justify-center">
      <FaCheck className="text-green-500 animate-slide-in" size={50}/>
    </div>
    
    // 
  );
};

export default CheckMarker;


