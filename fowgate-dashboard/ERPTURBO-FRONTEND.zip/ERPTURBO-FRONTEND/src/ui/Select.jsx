import React from "react";

export default function Select({ 
  label, 
  optionsArr, 
  special, 
  handleChange, 
  value = "", // Default to empty string to show placeholder
  noBorder, 
  multiple = false ,
  test,

}) {
  // Convert value to display format
  const displayValue = multiple 
    ? value 
    : (Array.isArray(value) ? value[0] || "" : value || "");

  return (
    <div className={`${test && "w-full"}`}>
      {label && <label className='block mb-2 text-[14px] '>{label}</label>}

      <div className={`px-3 w-full ${!noBorder && "border border-gray-300"} rounded-sm`}>
        <select
          multiple={multiple}
          value={displayValue}
          onChange={(e) => {
            if (multiple) {
              const selected = Array.from(e.target.selectedOptions, opt => opt.value);
              handleChange(selected);
            } else {
              handleChange(e.target.value);
            }
          }}
          className={`${special? "w-[170px] h-[40px]": "w-full h-[50px]"} outline-none bg-transparent cursor-pointer text-gray-600 text-[16px] py-1 `}
        >
          {/* Placeholder option - shows when value is empty */}
          <option value="" disabled className={`text-[14px] text-gray-700`}>
            {special || "Select"}
          </option>
          
          {/* Regular options */}
          {optionsArr.map(option => (
            <option value={option} key={option}>
              {option}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}