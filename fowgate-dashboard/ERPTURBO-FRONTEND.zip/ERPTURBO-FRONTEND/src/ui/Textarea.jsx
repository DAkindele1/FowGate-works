// src/ui/Textarea.jsx
import React from 'react';

const Textarea = ({ label, placeholder, value, handleChange, rows = 3, ...props }) => {
  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>}
      <textarea
        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder={placeholder}
        value={value}
        onChange={(e) => handleChange(e.target.value)}
        rows={rows}
        {...props}
      />
    </div>
  );
};

export default Textarea;