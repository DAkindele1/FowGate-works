import React from 'react'

export default function SmallBlueText({number}) {
  return (
    <span className='text-[#1B5FC1] text-[14px] lowercase  '>+{number} more</span>
  )
}
