import React from 'react'

export default function MainButton({text, action}) {
  return (
    <button className='rounded-[4px] py-2.5 px-3 text-white bg-[#1B5FC1] text-[14px] ' onClick={action}>{text}</button>
  )
}
