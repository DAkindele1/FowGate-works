import { TrashIcon } from '@phosphor-icons/react'
import React from 'react'

export default function WhiteButton({text, icon, textColor, action}) {
  return (
      <button className={`rounded-[4px] py-2.5 px-3 text-[#292929] border text-[14px] hover:text-[#EAeaea] hover:bg-[#292929] transition cursor-pointer  flex items-center gap-1  ${textColor ? `${textColor} border-[${textColor}]` : "hover:text-[#EAeaea] hover:bg-[#292929] border-[#eaeaea]"}`} onClick={action}>
          {icon === "trash" && <TrashIcon size={16}/>}
          {text}</button>
  )
}
