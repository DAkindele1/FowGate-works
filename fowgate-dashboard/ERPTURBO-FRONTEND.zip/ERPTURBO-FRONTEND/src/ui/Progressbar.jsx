import React from 'react'

export default function Progressbar({ step, totalSteps }) {
    const radius = 15;
    const stroke = 6;
    const normalizedRadius = radius - stroke * 0.5;
    const circumference = normalizedRadius * 2 * Math.PI;
    const progress = step / totalSteps;
    const strokeDashoffset = circumference - progress * circumference;
  
    // const isComplete = step === totalSteps;
  
    return (
      <svg height={radius * 2} width={radius * 2} className="mx-auto">
        <circle
          stroke="#e5e7eb" // Tailwind gray-200
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        <circle
          stroke={'#1B5FC1'} 
          fill="transparent"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference + ' ' + circumference}
          style={{
            strokeDashoffset,
            transition: 'stroke-dashoffset 0.3s ease, stroke 0.3s ease',
          }}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        {/* <text
          x="50%"
          y="50%"
          dominantBaseline="middle"
          textAnchor="middle"
          className={`text-sm font-semibold ${
            isComplete ? 'fill-green-600' : 'fill-gray-800'
          }`}
        >
          {isComplete ? '✓' : `${step}/${totalSteps}`}
        </text> */}
        </svg>
      );
    }


{/*
    function CircularProgressBar() {
 
     */}
