import React from 'react'
import DisplayName from '../Components/ATS Dashboard/Job Board/services/DisplayName'

export default function RoundInitials({ name , size = "24px"}) {
  return (
      <div className={`w-[${size}] h-[${size}] rounded-full flex items-center justify-center bg-[#E8EFF9] text-[#1b5fc1] font-semibold text-[10px] `}>
          <DisplayName name={name} />
    </div>
  )
}
