import React from 'react'

export default function StatusPill({ status, text }) {
    return (
        <div className={`capitalize rounded-full leading-[0.9] w-fit py-1 px-2.5 text-[12px] ${status === 'success' ? 'bg-[#EEFFF3] text-[#34A853]': status === 'warning' ? 'bg-[#FFF1DD] text-[#EB8A00]':"bg-[#FDECEB] text-[#EB4335]"}`} >{text}</div>
  )
}
