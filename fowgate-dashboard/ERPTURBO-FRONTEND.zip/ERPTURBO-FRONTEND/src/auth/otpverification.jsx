import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import LHS from "./LHS/lhs";
// import fowgatelogo from "/assets/img/fowgatelogo.png";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { authUser } from "../apis/api_auth_user";

const otpverification = () => {
  const [otp, setOtp] = useState(new Array(6).fill(""));
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const [loading, setLoading] = useState("");
  const inputRefs = useRef([]);

  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email; // Get email from state
  const fullname = location.state?.fullname; // Get email from state
  const password = location.state?.password; // Get email from state

  const [userData, setUserData] = useState({
    email: email,
    otp: otp.join(),
  });

  const [userResendData, setResendData] = useState({
    email: email,
    fullname: fullname,
    password: password,
  });

  useEffect(() => {
    setUserData((prev) => ({ ...prev, otp: otp.join("") }));
  }, [otp]);

  const handleChange = (e, index) => {
    const value = e.target.value;
    if (!isNaN(value) && value.length <= 1) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Move to next input if value is entered
      if (value !== "" && index < 5) {
        inputRefs.current[index + 1].focus();
      }
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading("Verifying OTP");

    try {
      const result = await authUser(
        "POST",
        "/api/auth/verify_signup_otp",
        userData
      );

      if (result.success) {
        toast.success(result.data.message || "OTP verified!");
        const timeout = setTimeout(() => {
          navigate("/account_dashboard");
        }, 2000);

        return () => clearTimeout(timeout);
      } else {
        toast.error(result.message); // Handle error message
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading("Verify OTP");
    }
    
  };

  const handleResend = async (e) => {
    try {
      const result = await authUser("POST", "api/auth/signup", userResendData);

      if (result.success) {
        toast.success(
          result.data.message || "User registered successfully, OTP sent!"
        );
      } else {
        toast.error(result.message); // Handle error message
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading("Sign Up");
    }
  };

  // useEffect(() => {
  //   if (shouldNavigate) {
  //     const timeout = setTimeout(() => {
  //       navigate("/account_dashboard");
  //     }, 3000);

  //     return () => clearTimeout(timeout); // Cleanup timeout
  //   }
  // }, [shouldNavigate, navigate]); // Runs when `shouldNavigate` changes

  return (
    <div className="flex flex-row max-h-100vh ">
      <LHS />
      <div className="min-h-screen flex-1 flex justify-center items-center">
        <div className="w-32 fixed top-5 right-10">
          <img src="/assets/img/fowgatelogo.png" alt="Fow gate logo" />
        </div>

        <div className="">
          <div className="">
            <div className=" max-w-md w-full p-6 ">
              <a href="#" className="text-[#1B5FC1] text-sm">
                <Link to="/signup">&larr; Back</Link>
              </a>
              <h2 className="text-3xl font-semibold mt-10">OTP Verification</h2>
              <p className="text-gray-600 text-sm mt-1">
                Enter the code sent to your email address.
              </p>

              <div className="mt-6">
                <p className="">Enter code</p>
                <div className="grid grid-cols-6 gap-2 mt-1">
                  {otp.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      value={digit}
                      placeholder="-"
                      onChange={(e) => handleChange(e, index)}
                      onKeyDown={(e) => handleKeyDown(e, index)}
                      maxLength="1"
                      className="w-full h-14 text-center text-lg font-semibold border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ))}
                </div>
              </div>

              <Link to="/create-new-password">
                <button
                  // onClick={handleSubmit}
                  className="w-full bg-[#1B5FC1]  text-white py-2 mt-10 rounded-md hover:bg-blue-700 transition cursor-pointer"
                  onClick={handleSubmit}
                >
                  {loading || "Verify OTP"}
                </button>
              </Link>

              <p
                className="text-[#1B5FC1] text-sm mt-2 cursor-pointer text-center"
                onClick={handleResend}
              >
                Resend Code
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default otpverification;
