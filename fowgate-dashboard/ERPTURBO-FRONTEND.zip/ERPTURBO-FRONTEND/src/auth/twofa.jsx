import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import LHS from "./LHS/lhs";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { authUser } from "../apis/api_auth_user";

const twofa = () => {
  const [otp, setOtp] = useState(new Array(6).fill(""));
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const [loading, setLoading] = useState("");
  const inputRefs = useRef([]);

  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email;
  const password = location.state?.password;

  const [userData, setUserData] = useState({
    email: email,
    otp: otp.join(""),
  });
  const [userResendData, setUserResendData] = useState({
    email: email,
    password: password,
  });

  // Auto-focus first input on mount
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  const handleChange = (e, index) => {
    const value = e.target.value;
    if (!isNaN(value) && value.length <= 1) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Move to next input if value is entered
      if (value !== "" && index < 5) {
        inputRefs.current[index + 1].focus();
      }

      // If we just filled the last field, submit
      if (index === 5 && value !== "") {
        // Create the complete OTP string immediately
        const completeOtp = newOtp.join("");
        setUserData(prev => ({ ...prev, otp: completeOtp }));
        
        // Submit after a small delay to ensure state is updated
        setTimeout(() => {
          handleSubmit(null, completeOtp);
        }, 50);
      }
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleSubmit = async (e, otpValue = null) => {
    if (e) e.preventDefault();
    const currentOtp = otpValue || otp.join("");
    if (currentOtp.length !== 6) return;
    if (loading === "Verifying OTP") return;

    setLoading("Verifying OTP");

    try {
      const result = await authUser(
        "POST",
        "/api/auth/verify_login_otp",
        { ...userData, otp: currentOtp }
      );

      if (result.success) {
        toast.success(result.data.message || "TwoFA verified!");
        setShouldNavigate(true);
        localStorage.setItem("userAccess", result.data.access_token);
        
        setTimeout(() => {
          navigate("/account_dashboard");
        }, 3000);
      } else {
        toast.error(result.message);
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading("Verify OTP");
    }
  };

  // Update userData when otp changes (for manual submission)
  useEffect(() => {
    setUserData(prev => ({ ...prev, otp: otp.join("") }));
  }, [otp]);

  const handleResend = async (e) => {
    try {
      const result = await authUser("POST", "api/auth/login", userResendData);

      if (result.success) {
        toast.success(result.data.message || "OTP sent!");
        setOtp(new Array(6).fill(""));
        inputRefs.current[0].focus();
      } else {
        toast.error(result.message);
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    }
  };

  return (
    <div className="flex flex-row h-screen bg-gray-50">
      {/* Left Side Component */}
      <LHS />

      {/* Right Side - OTP Verification */}
      <div className="flex-1 flex justify-center items-center">
        <div className="w-full max-w-md p-6">
          {/* Logo */}
          <div className="absolute top-5 right-10 w-32">
            <img src="/assets/img/fowgatelogo.png" alt="Company Logo" />
          </div>

          {/* Back Link */}
          <Link to="/" className="text-blue-600 text-sm hover:text-blue-800">
            &larr; Back to login
          </Link>

          {/* Header */}
          <div className="mt-5">
            <h2 className="text-2xl font-semibold text-gray-800">
              Two Factor Authentication
            </h2>
            <p className="text-gray-600 text-sm mt-1">
              Check your email for a verification code to secure your account.
            </p>
          </div>

          {/* OTP Input Fields */}
          <div className="mt-6">
            <label className="block text-gray-700 mb-1">Enter code</label>
            <div className="grid grid-cols-6 gap-3">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  ref={(el) => (inputRefs.current[index] = el)}
                  type="text"
                  value={digit}
                  placeholder="-"
                  onChange={(e) => handleChange(e, index)}
                  onKeyDown={(e) => handleKeyDown(e, index)}
                  maxLength="1"
                  className="w-full h-14 text-center text-lg font-medium border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                />
              ))}
            </div>
          </div>

          {/* Verify Button */}
          <button
            onClick={handleSubmit}
            disabled={loading === "Verifying OTP" || otp.join("").length !== 6}
            className={`w-full mt-6 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition ${
              loading === "Verifying OTP" || otp.join("").length !== 6 ? "opacity-70 cursor-not-allowed" : ""
            }`}
          >
            {loading === "Verifying OTP" ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Verifying...
              </span>
            ) : (
              "Verify OTP"
            )}
          </button>

          {/* Resend Link */}
          <p
            className="mt-4 text-center text-blue-600 text-sm hover:text-blue-800 cursor-pointer"
            onClick={handleResend}
          >
            Resend Code
          </p>
        </div>
      </div>
    </div>
  );
};

export default twofa;