import React from 'react'


const lhs = () => {
  return (
      <div
           className="bg-cover bg-center bg-no-repeat flex-1 flex justify-center relative "
           style={{ backgroundImage: `url("/assets/img/loginImg.png")` }}
         >
           <div className="absolute inset-0 bg-black opacity-50"></div>
           <div className=" pt-[25%] z-50">
             <h1 className="text-white text-4xl font-semibold pb-4">
               Powering Businesses <br /> and Organizations all <br /> over the
               world
             </h1>
             <p className="text-[#EAEAEA] text-md">
               AI Productivity and Business Workflow Solutions.
             </p>
           </div>
   
           <div className=" fixed bottom-10 left-[30px0] w-[400px] ">
             <div className="flex flex-col gap-2">
               <p className="text-[#EAEAEA] text-[16px]">Trusted by:</p>
               <div className="flex justify-center items-center gap-3 ">
                 <div className="max-w-28 flex justify-center items-center h-14 p-3  rounded-sm bg-transparent">
                   <img src="/assets/img/nestleLogo.png" alt="" />
                 </div>
   
                 <div className="max-w-28  flex justify-center items-center h-14 p-3  rounded-sm bg-transparent">
                   <img src="/assets/img/loqoLogo.png" alt="" />
                 </div>
                 <div className="max-w-28  flex justify-center items-center h-14 p-3  rounded-sm bg-transparent">
                   <img src="/assets/img/lonkingLogo.png" alt="" />
                 </div>
                 <div className="max-w-28  flex justify-center items-center h-14 p-3  rounded-sm bg-transparent">
                   <img src="/assets/img/hisenseLogo.png" alt="" />
                 </div>
               </div>
             </div>
           </div>
         </div>
  )
}

export default lhs
