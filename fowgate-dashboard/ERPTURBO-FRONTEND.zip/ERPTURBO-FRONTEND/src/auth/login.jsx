import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import LHS from "./LHS/lhs";
import { authUser } from "../apis/api_auth_user";
import { toast } from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState("");
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const navigate = useNavigate();
  const passwordInputRef = React.useRef(null);

  const [userData, setUserData] = useState({
    email: "",
    password: "",
  });

  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleSubmit(e);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (loading === "Signing In") return; // Prevent multiple submissions
    
    setLoading("Signing In");

    if (!validateEmail(userData.email)) {
      toast.error("Invalid email format!");
      setLoading("Sign In");
      return;
    }

    if (userData.password === "") {
      toast.error("Please enter a password");
      setLoading("Sign In");
      return;
    }

    try {
      const result = await authUser("POST", "/api/auth/login", userData);

      if (result.success) {
        toast.success(
          result.data.message || "User logged in successfully, OTP sent!"
        );
        setShouldNavigate(true);
      } else {
        toast.error(result.message);
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading("Sign In");
    }
  };

  useEffect(() => {
    if (shouldNavigate) {
      const timeout = setTimeout(() => {
        navigate("/twofactorauthorization", {
          state: { email: userData.email, password: userData.password },
        });
      }, 3000);

      return () => clearTimeout(timeout);
    }
  }, [shouldNavigate, navigate]);

  return (
    <div className="flex flex-row h-screen">
      <LHS />
      <div className="min-h-screen flex-1 flex justify-center items-center">
        <div className="w-32 fixed top-5 right-10">
          <img src="/assets/img/fowgatelogo.png" alt="Fowgate Logo" />
        </div>
        <div className="bg-white rounded-md w-full max-w-md p-8">
          {/* Title */}
          <h1 className="text-2xl font-bold mb-2">Welcome Back!</h1>
          <p className="text-gray-500 mb-7">
            New to Fowgate?{" "}
            <Link to="/signup" className="text-[#1B5FC1] font-medium">
              Create an account.
            </Link>
          </p>

          {/* Google Sign-in Button */}
          <button className="w-full flex items-center justify-center border border-gray-300 rounded-md py-2 mt-4 text-gray-600 hover:bg-gray-100 cursor-pointer">
            <img src="/assets/img/googleLogo.png" alt="Google" className="w-5 h-5 mr-2" />
            Google
          </button>

          {/* Divider */}
          <div className="flex items-center my-4">
            <hr className="flex-grow border-gray-300" />
            <span className="px-2 text-gray-500 text-sm">
              or sign in with
            </span>
            <hr className="flex-grow border-gray-300" />
          </div>

          {/* Email Input */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm mb-1">
              Email Address
            </label>
            <input
              type="email"
              name="email"
              onChange={handleChange}
              placeholder="abcde@gmail.com"
              value={userData.email}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
            />
          </div>

          {/* Password Input */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm mb-1">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                onChange={handleChange}
                onKeyDown={handleKeyDown}
                placeholder="Enter at least 8 characters"
                value={userData.password}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                ref={passwordInputRef}
              />
              <span
                className="absolute right-3 top-3 cursor-pointer text-gray-500"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </span>
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex justify-between items-center text-sm mb-6">
            <label className="flex items-center space-x-2">
              <input type="checkbox" className="w-4 h-4" />
              <span>Remember me</span>
            </label>
            <Link to="/forgotpassword" className="text-[#1B5FC1] font-medium">
              Forgot Password?
            </Link>
          </div>

          {/* Sign-in Button */}
          <button
            className={`w-full bg-[#1B5FC1] text-white py-2 rounded-md hover:bg-blue-700 cursor-pointer ${
              loading === "Signing In" ? "opacity-75" : ""
            }`}
            onClick={handleSubmit}
            disabled={loading === "Signing In"}
          >
            {loading === "Signing In" ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Signing In...
              </span>
            ) : (
              "Sign In"
            )}
          </button>

          {/* Footer Terms */}
          <p className="text-gray-500 text-xs mt-4">
            By signing in you accept Flowgate's{" "}
            <a href="#" className="text-blue-500">
              Terms of use
            </a>{" "}
            and acknowledge the{" "}
            <a href="#" className="text-blue-500">
              Privacy statement
            </a>{" "}
            and{" "}
            <a href="#" className="text-blue-500">
              cookie policy
            </a>
            .
          </p>
        </div>
      </div>
    </div>
  );
};

export default login;