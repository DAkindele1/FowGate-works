import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchAllJobListing, createJobListing, editJobListing, deleteJobListing } from './Components/ATS Dashboard/Job Board/services/api_job_board';

// Async thunks for API calls
export const fetchJobListings = createAsyncThunk(
    'jobBoard/fetchJobListings',
    async (_, { rejectWithValue }) => {
      try {
        const response = await fetchAllJobListing();
        return response.job_listings;
      } catch (error) {
        return rejectWithValue(error.message);
      }
    }
);

export const createJob = createAsyncThunk(
    'jobBoard/createJob',
    async (jobData, { rejectWithValue }) => {
      try {
        const response = await createJobListing(jobData);
        return response;
      } catch (error) {
        return rejectWithValue(error.message);
      }
    }
);

export const updateJob = createAsyncThunk(
    'jobBoard/updateJob',
    async ({ jobCode, jobData }, { rejectWithValue }) => {
      try {
        const response = await editJobListing(jobCode, jobData);
        return { jobCode, jobData: response };
      } catch (error) {
        return rejectWithValue(error.message);
      }
    }
);

export const deleteJob = createAsyncThunk(
    'jobBoard/deleteJob',
    async (jobCode, { rejectWithValue }) => {
      try {
        await deleteJobListing(jobCode);
        return jobCode;
      } catch (error) {
        return rejectWithValue(error.message);
      }
    }
);

const jobBoardSlice = createSlice({
    name: 'jobBoard',
    initialState: { 
      // Modal states
      openCreateModal: false,
      openEditModal: false,
    
      // Loading states
      isLoading: true,
      isCreating: false,
      isUpdating: false,
      isDeleting: false,
    
      // Data states
      jobListing: [],
      selectedJob: null,
    
      // Form states
      templateOption: "",
      searchQuery: "",
    
      // Form data for create/edit
      formData: {
        title: "",
        hiring_team: [],
        industry: "",
        salary_range: "",
        currency: "",
        required_skills: [],
        qualifications: [],
        experience: "",
        upload_resume: false,
        cover_letter: false,
        portfolio: false,
        description: "",
        questions: [],
        audience: ["public"],
        add_as_template: false,
        application_url: "",
        availability: "",
        job_type: "",
      },
    
      // UI states
      currentStep: 1,
      jobPosted: false,
    
      // Error handling
      error: null,
    
      // Pagination
      currentPage: 1,
      totalPages: 1,
      itemsPerPage: 10,
    },
    reducers: {
      // Modal actions
      toggleCreateModal: (state) => { 
        state.openCreateModal = !state.openCreateModal;
        if (state.openCreateModal) {
          state.formData = {
            title: "",
            hiring_team: [],
            industry: "",
            salary_range: "",
            currency: "",
            required_skills: [],
            qualifications: [],
            experience: "",
            upload_resume: false,
            cover_letter: false,
            portfolio: false,
            description: "",
            questions: [],
            audience: ["public"],
            add_as_template: false,
            application_url: "",
            availability: "",
            job_type: "",
          };
          state.currentStep = 1;
        }
      },
    
      toggleEditModal: (state) => { 
        state.openEditModal = !state.openEditModal;
        if (state.openEditModal && state.selectedJob) {
          state.formData = {
            ...state.selectedJob,
            hiring_team: Array.isArray(state.selectedJob.hiring_team) ? state.selectedJob.hiring_team : [],
            audience: Array.isArray(state.selectedJob.audience) ? state.selectedJob.audience : ["public"],
            required_skills: Array.isArray(state.selectedJob.required_skills) ? state.selectedJob.required_skills : [],
            questions: state.selectedJob.questions || [],
            qualifications: Array.isArray(state.selectedJob.qualifications) ? state.selectedJob.qualifications : [],
          };
          state.currentStep = 1;
        }
      },
    
      // Data actions
      setIsLoading: (state, action) => { state.isLoading = action.payload },
      setJobListing: (state, action) => { 
        // Ensure we only accept arrays, not functions
        if (Array.isArray(action.payload)) {
          state.jobListing = action.payload;
        } else {
          console.error('setJobListing expects an array, received:', typeof action.payload, action.payload);
          // Don't update the state if payload is not an array
        }
      },
      setSelectedJob: (state, action) => { state.selectedJob = action.payload },
      
      // Remove job from listing (for optimistic updates)
      removeJobFromListing: (state, action) => {
        state.jobListing = state.jobListing.filter(job => job.job_code !== action.payload);
      },
    
      // Form actions
      setTemplateOption: (state, action) => { state.templateOption = action.payload },
      setSearchQuery: (state, action) => { state.searchQuery = action.payload },
      updateFormField: (state, action) => {
        const { field, value } = action.payload;
        state.formData[field] = Array.isArray(value) ? [...value] : value;
      },
      setFormData: (state, action) => { state.formData = action.payload },
      resetFormData: (state) => {
        state.formData = {
          title: "",
          hiring_team: [],
          industry: "",
          salary_range: "",
          currency: "",
          required_skills: [],
          qualifications: [],
          experience: "",
          upload_resume: false,
          cover_letter: false,
          portfolio: false,
          description: "",
          questions: [],
          audience: ["public"],
          add_as_template: false,
          application_url: "",
          availability: "",
          job_type: "",
        };
      },
    
      // UI actions
      setCurrentStep: (state, action) => { state.currentStep = action.payload },
      nextStep: (state) => { state.currentStep += 1 },
      prevStep: (state) => { state.currentStep -= 1 },
      setJobPosted: (state, action) => { state.jobPosted = action.payload },
    
      // Error handling
      setError: (state, action) => { state.error = action.payload },
      clearError: (state) => { state.error = null },
    
      // Pagination
      setCurrentPage: (state, action) => { state.currentPage = action.payload },
      setTotalPages: (state, action) => { state.totalPages = action.payload },
    },
    extraReducers: (builder) => {
      builder
        // Fetch job listings
        .addCase(fetchJobListings.pending, (state) => {
          state.isLoading = true;
          state.error = null;
        })
        .addCase(fetchJobListings.fulfilled, (state, action) => {
          state.isLoading = false;
          state.jobListing = action.payload;
          state.totalPages = Math.ceil(action.payload.length / state.itemsPerPage);
        })
        .addCase(fetchJobListings.rejected, (state, action) => {
          state.isLoading = false;
          state.error = action.payload;
        })
      
        // Create job
        .addCase(createJob.pending, (state) => {
          state.isCreating = true;
          state.error = null;
        })
        .addCase(createJob.fulfilled, (state, action) => {
          state.isCreating = false;
          state.jobListing.push(action.payload);
          state.openCreateModal = false;
          state.jobPosted = true;
          state.currentStep = 7;
        })
        .addCase(createJob.rejected, (state, action) => {
          state.isCreating = false;
          state.error = action.payload;
        })
      
        // Update job
        .addCase(updateJob.pending, (state) => {
          state.isUpdating = true;
          state.error = null;
        })
        .addCase(updateJob.fulfilled, (state, action) => {
          state.isUpdating = false;
          const { jobCode, jobData } = action.payload;
          const index = state.jobListing.findIndex(job => job.job_code === jobCode);
          if (index !== -1) {
            state.jobListing[index] = { ...state.jobListing[index], ...jobData };
          }
          state.openEditModal = false;
          state.jobPosted = true;
          state.currentStep = 7;
        })
        .addCase(updateJob.rejected, (state, action) => {
          state.isUpdating = false;
          state.error = action.payload;
        })

        // Delete job
        .addCase(deleteJob.pending, (state) => {
          state.isDeleting = true;
          state.error = null;
        })
        .addCase(deleteJob.fulfilled, (state, action) => {
          state.isDeleting = false;
          // Remove the deleted job from the list
          state.jobListing = state.jobListing.filter(job => job.job_code !== action.payload);
        })
        .addCase(deleteJob.rejected, (state, action) => {
          state.isDeleting = false;
          state.error = action.payload;
        });
    },
});

export const { 
    toggleCreateModal, 
    toggleEditModal, 
    setIsLoading, 
    setJobListing, 
    setSelectedJob,
    removeJobFromListing,
    setTemplateOption, 
    setSearchQuery,
    updateFormField,
    setFormData,
    resetFormData,
    setCurrentStep,
    nextStep,
    prevStep,
    setJobPosted,
    setError,
    clearError,
    setCurrentPage,
    setTotalPages
} = jobBoardSlice.actions;

export default jobBoardSlice.reducer;