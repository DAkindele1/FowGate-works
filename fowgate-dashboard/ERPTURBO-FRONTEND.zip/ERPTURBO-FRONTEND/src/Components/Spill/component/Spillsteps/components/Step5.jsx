


import React, { useState } from "react";

const Step5 = ({ formData, onNext, onPrev }) => {
  const [showSpillOverview, setShowSpillOverview] = useState(false);
  const [showSpillInvestigation, setShowSpillInvestigation] = useState(false);
  const [showSupportingInfo, setShowSupportingInfo] = useState(false);
  const [showRemediationReports, setShowRemediationReports] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    onNext(formData); // Directly proceed to next step
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between h-[48px]">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Add icon" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Add New</h2>
          </div>
          <button
            onClick={onPrev}
            className="text-white hover:bg-white/20 rounded-full p-1 transition-colors duration-200"
            aria-label="Close form"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto flex-grow px-4 py-3 space-y-4 bg-transparent text-sm">
          <form onSubmit={handleFormSubmit} className="space-y-4" role="form" aria-labelledby="spill-report-title">
            <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
              <img src="/six.svg" alt="Step five" className="w-4 h-4 mr-2" />
              <span className="text-black">
                5/5 - <span className="font-bold">PREVIEW & SUBMIT</span>
              </span>
            </div>
            <hr className="border-t border-gray-300 my-3" />

            {/* Reporting Officer Details */}
            <div className="bg-white rounded-lg border  border-gray-300 overflow-hidden">
              <h3 className="bg-[#F1F1F1] px-4 py-2 text-sm font-medium text-gray-700 rounded-t-[3px]">
                Reporting Officer Details
              </h3>
              <hr className="border-gray-300" />
              <div className="px-4 py-4 text-sm space-x-2">
                {[
                  ["Name of CLO", formData?.cloName || "Kingsley Tamuno"],
                  ["OML", formData?.oml || "OML 58"],
                  ["Cluster/Host Community", formData?.communityAffected || "Rumueme Community"],
                  ["Operator", formData?.operator || "NAOC (Nigerian Agip Oil Company)"],
                  ["Date of Report", formData?.reportDate || "02 Jul, 2025 01:03 AM WAT"],
                  ["CLO Contact Number", formData?.cloContact || "+234 803 123 4567"],
                ]
                  .reduce((rows, item, index) => {
                    if (index % 2 === 0) rows.push([item]);
                    else rows[rows.length - 1].push(item);
                    return rows;
                  }, [])
                  .map((row, i) => (
                    <div key={i} className="grid grid-cols-2 gap-4">
                      {row.map(([label, value], j) => (
                        <div key={j}>
                          <p className="text-gray-500 text-[12px]">{label}</p>
                          <p className="text-black">{value || "Not provided"}</p>
                        </div>
                      ))}
                      {i < 2 && <div className="col-span-2"><hr className="border-gray-300 my-2" /></div>}
                    </div>
                  ))}
              </div>
            </div>

            {/* Spill Overview */}
            <div className="bg-white rounded-lg border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
                Spill Overview
                <div className="flex items-center gap-4">
                  <img src="/pen.svg" alt="Edit spill overview" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowSpillOverview(prev => !prev)}
                    className="focus:outline-none"
                    aria-expanded={showSpillOverview}
                    aria-label="Toggle Spill Overview"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showSpillOverview ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              <div
                className={`transition-all duration-300 ease-in-out ${
                  showSpillOverview ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
                }`}
              >
                <div className="grid grid-cols-2 gap-2 p-4 text-sm space-x-2">
                  <div>
                    <p className="text-gray-500 text-[12px]">Date of Spill</p>
                    <p className="text-black">{formData?.spillDate || "Not provided"}</p>
                  </div>
                  <div>
                        <p className="text-gray-500 text-[12px]">Time of Spill</p>
                    <p className="text-black">{formData?.spillTime || "Not provided"} </p>
                  </div>
                  <hr className="border-gray-300 col-span-2 my-2" />
                  <div>
                    <p className="text-gray-500 text-[12px]">Spill Location</p>
                    <p className="text-black">{formData?.location || "Not provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">Source</p>
                    <p className="text-black">{formData?.source || "Not provided"}</p>
                  </div>
                  <hr className="border-gray-300 col-span-2 my-2" />
                  <div>
                      <p className="text-gray-500 text-[12px]">Spill Content</p>
                    <p className="text-black">{formData?.spillType || "Not provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">Volume</p>
                    <p className="text-black">{formData?.volume ? `${formData.volume}` : "Not provided"}</p>
                  </div>
                   
                   <div>
                  <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                  <div className="space-y-1">
                    {Array.isArray(formData?.uploadedEvidence) && formData.uploadedEvidence.length > 0
                      ? formData.uploadedEvidence.map((evidence, index) => (
                          <div key={index} className="flex justify-between items-center p-2 hover:bg-gray-100 rounded">
                            <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
                            <button
                              className="text-red-500 hover:bg-red-100 rounded-full p-1 transition-colors duration-200"
                              aria-label={`Remove ${evidence?.name || `File ${index + 1}`}`}
                            >
                              X
                            </button>
                          </div>
                        ))
                      : <p className="text-black"> Not provided</p>}
                  </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Spill Investigation */}
            <div className="bg-white rounded-lg border border-gray-300">
              <h3 className="bg-[#dbe9fd] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
                Spill Investigation
                <div className="flex items-center gap-2">
                  <img src="/pen.svg" alt="Edit spill investigation" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowSpillInvestigation(prev => !prev)}
                    className="focus:outline-none"
                    aria-expanded={showSpillInvestigation}
                    aria-label="Toggle Spill Investigation"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showSpillInvestigation ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              <div
                className={`transition-all duration-300 ease-in-out ${
                  showSpillInvestigation ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
                }`}
              >
                <div className="px-4 py-4 text-sm">
                  <div className="grid grid-cols-2 gap-4 space-x-2">
                    <div>
                      <p className="text-gray-500 text-[12px]">Cause of Spill</p>
                      <p className="text-black">{formData?.causeOfSpill || "Not provided"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-[12px]">Response Time</p>
                      <p className="text-black">{formData?.responseTime || "Not provided"}</p>
                    </div>
                  </div>
                  <hr className="border-gray-300 col-span-2 my-2" />
                  <div>
                    <p className="text-gray-500 text-[12px]">Area of Impact</p>
                    <p className="text-black">{formData?.areaOfImpact || "Not provided"}</p>
                  </div>
                  <hr className="border-gray-300 col-span-2 my-2" />
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-500 text-[12px]">Receptors</p>
                      <p className="text-black">{formData?.receptors || "Not provided"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-[12px]">Risk Level</p>
                      <p className="text-orange-500 text bg-orange-200 rounded-3xl px-2 py-1 inline-block">
                        {formData?.riskLevel || "Not provided"}
                      </p>
                    </div>
                  </div>
                  <hr className="border-gray-300 col-span-2 my-2" />
                  <div>
                    <p className="text-gray-500 text-[12px]">Consequence</p>
                    <p className="text-black">{formData?.consequence || "Not provided"}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Supporting Information */}
            <div className="bg-white rounded-lg border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
                Supporting Information
                <div className="flex items-center gap-2">
                  <img src="/pen.svg" alt="Edit supporting information" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowSupportingInfo(prev => !prev)}
                    className="focus:outline-none"
                    aria-expanded={showSupportingInfo}
                    aria-label="Toggle Supporting Information"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showSupportingInfo ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              <div
                className={`transition-all duration-300 ease-in-out ${
                  showSupportingInfo ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
                }`}
              >
                <div className="px-4 py-4 text-sm ">
                  <p className="text-gray-500 text-[12px]">Witness Name</p>
                  <p className="text-black">
                    {Array.isArray(formData?.witnesses) && formData.witnesses.length > 0
                      ? formData.witnesses[0]
                      : "Not provided"}
                  </p>
                  {/* <hr className="border-gray-300 my-2" />
                  <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                  <div className="space-y-1">
                    {Array.isArray(formData?.uploadedEvidence) && formData.uploadedEvidence.length > 0
                      ? formData.uploadedEvidence.map((evidence, index) => (
                          <div key={index} className="flex justify-between items-center p-2 hover:bg-gray-100 rounded">
                            <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
                            <button
                              className="text-red-500 hover:bg-red-100 rounded-full p-1 transition-colors duration-200"
                              aria-label={`Remove ${evidence?.name || `File ${index + 1}`}`}
                            >
                              X
                            </button>
                          </div>
                        ))
                      : <p className="text-black">IMG_0887.jpg, IMG_0888.jpg, Video_034.mp4, Krakama JIV Report.pdf</p>}
                  </div> */}
                  <hr className="border-gray-300 my-2" />
                  <p className="text-gray-500 text-[12px]">Additional Notes</p>
                  <p className="text-black">{formData?.additionalNotes || "Not provided"}</p>
                </div>
              </div>
            </div>

            {/* Remediation Reports */}
            <div className="bg-white rounded-lg border border-gray-300">

              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
                Remediation Reports
                <div className="flex items-center gap-2">
                  <img src="/pen.svg" alt="Edit remediation reports" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowRemediationReports(prev => !prev)}
                    className="focus:outline-none"
                    aria-expanded={showRemediationReports}
                    aria-label="Toggle Remediation Reports"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showRemediationReports ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              <div
                className={`transition-all duration-300 ease-in-out ${
                  showRemediationReports ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
                }`}
              >
                <div className="px-4 py-4 text-sm">
                  <p className="text-gray-500 text-[12px]">Tier 1 Report</p>
                  <p className="text-black">{formData?.remediationReports?.[0] || "Not provided"}</p>
                  <hr className="border-gray-300 my-2" />
                  <p className="text-gray-500 text-[12px]">Tier 3 Report</p>
                  <p className="text-black">{formData?.remediationReports?.[1] || "Not provided"}</p>
                </div>
              </div>
            </div>
          </form>
        </div>

        {/* Footer Buttons */}
        <div className="bg-white px-4 py-3 flex justify-end space-x-2 mt-auto shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 w-full">
          <button
            onClick={onPrev}
            className="px-4 py-2 text-sm border border-gray-300 rounded-[3px] text-gray-700"
          >
            Prev
          </button>
          <button
            onClick={onNext}
            disabled={isSubmitting}
            className={`px-4 py-2 text-sm bg-[#E9F0FB] text-[#1B5FC1] rounded-[3px] ${
              isSubmitting ? "opacity-50 cursor-not-allowed" : ""
            }`}
          >
            {isSubmitting ? (
              <svg className="animate-spin h-5 w-5 mx-auto" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              </svg>
            ) : (
              "Submit"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Step5;
