



import React, { useState, useEffect } from 'react';
import { FiChevronDown } from "react-icons/fi";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";
import axios from "axios";

// Fix Leaflet marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

// MapModal Component (unchanged)
const MapModal = ({ isOpen, onClose, onSelectLocation, mapType }) => {
  const [center, setCenter] = useState([4.8430, 7.0330]);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [radius, setRadius] = useState("");

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCenter([position.coords.latitude, position.coords.longitude]);
        },
        () => {
          alert("Unable to access your location. Using default map center.");
        }
      );
    }
  }, []);

  const MapClickHandler = () => {
    useMapEvents({
      click: async (e) => {
        const { lat, lng } = e.latlng;
        setSelectedLocation([lat, lng]);

        try {
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
            {
              headers: {
                "User-Agent": "IncidentReportingApp (your-email@example.com)",
              },
            }
          );
          const address = response.data.display_name || `Lat: ${lat}, Lng: ${lng}`;
          setSelectedAddress(address);
        } catch (error) {
          console.error("Geocoding error:", error);
          setSelectedAddress(`Lat: ${lat}, Lng: ${lng}`);
          alert("Unable to retrieve address. Using coordinates instead.");
        }
      },
    });
    return null;
  };

  const handleRadiusChange = (e) => {
    const value = e.target.value;
    if (value === "" || (Number(value) > 0 && Number(value) <= 100)) {
      setRadius(value);
    }
  };

  const handleConfirm = () => {
    if (selectedLocation && selectedAddress && radius) {
      const geoJson = {
        type: "Feature",
        geometry: {
          type: "Point",
          coordinates: [selectedLocation[1], selectedLocation[0]],
        },
        properties: {
          radius: Number(radius) * 1000,
        },
      };
      const description = `${radius}km radius around ${selectedAddress}`;
      onSelectLocation({ geoJson, description });
      onClose();
    }
  };

  if (!isOpen) return null;

  const tileUrl =
    mapType === "Satellite View"
      ? "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
      : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  const attribution =
    mapType === "Satellite View"
      ? '© <a href="https://www.esri.com/">Esri</a>'
      : '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-[3px] p-4 w-[80%] h-[80%] max-w-4xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg">Select Area of Impact</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700" aria-label="Close map modal">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="mb-2 text-sm text-gray-700">
          {selectedAddress ? (
            <p>Selected: {selectedAddress}</p>
          ) : (
            <p>Click on the map to select a center point for the area</p>
          )}
        </div>
        <div className="mb-2">
          <label className="text-sm text-gray-700">
            Radius (km) <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            value={radius}
            onChange={handleRadiusChange}
            placeholder="Enter radius (1-100 km)"
            className="w-full border border-gray-300 rounded-[3px] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
            min="1"
            max="100"
            aria-label="Radius in kilometers"
          />
        </div>
        <MapContainer center={center} zoom={10} style={{ width: "100%", height: "70%" }}>
          <TileLayer url={tileUrl} attribution={attribution} />
          {selectedLocation && <Marker position={selectedLocation} />}
          <MapClickHandler />
        </MapContainer>
        <div className="flex justify-end mt-2">
          <button
            type="button"
            onClick={handleConfirm}
            className="bg-[#1B5FC1] text-white px-4 py-2 rounded-[3px]"
            disabled={!selectedLocation || !radius}
            aria-label="Confirm area selection"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};

const SpillInvestigation = ({ onSave, onChange, onPrev, formData = {}, onClose, onNext }) => {
  const [showMapDropdown, setShowMapDropdown] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [selectedMapType, setSelectedMapType] = useState(null);
  const [localAreaOfImpact, setLocalAreaOfImpact] = useState(formData.areaOfImpact || "");
  const [localResponseTime, setLocalResponseTime] = useState(formData.responseTime || "");
  const [localReceptors, setLocalReceptors] = useState(formData.receptors || "");
  const [localConsequence, setLocalConsequence] = useState(formData.consequence || "");
  const [localRiskLevel, setLocalRiskLevel] = useState(formData.riskLevel || "");

  useEffect(() => {
    setLocalAreaOfImpact(formData.areaOfImpact || "");
    setLocalResponseTime(formData.responseTime || "");
    setLocalReceptors(formData.receptors || "");
    setLocalConsequence(formData.consequence || "");
    setLocalRiskLevel(formData.riskLevel || "");
  }, [formData]);

  const handleMapSelect = (mapType) => {
    setShowMapDropdown(false);
    setSelectedMapType(mapType);
    setShowMapModal(true);
  };

  const handleAreaSelect = ({ geoJson, description }) => {
    setLocalAreaOfImpact(description);
    onChange?.({
      target: {
        name: "areaOfImpact",
        value: description,
      },
    });
    onChange?.({
      target: {
        name: "areaGeoJson",
        value: JSON.stringify(geoJson),
      },
    });
    setShowMapModal(false);
  };

  const handleInputChange = (e) => {
    const

 { name, value } = e.target;
    if (name === "areaOfImpact") {
      setLocalAreaOfImpact(value);
    } else if (name === "responseTime") {
      setLocalResponseTime(value);
    } else if (name === "receptors") {
      setLocalReceptors(value);
    } else if (name === "consequence") {
      setLocalConsequence(value);
    } else if (name === "riskLevel") {
      setLocalRiskLevel(value);
    }
    onChange?.({ target: { name, value } });
  };

  const handleIncrement = () => {
    const currentValue = Number(localResponseTime) || 0;
    const newValue = currentValue + 1;
    handleInputChange({ target: { name: "responseTime", value: newValue.toString() } });
  };

  const handleDecrement = () => {
    const currentValue = Number(localResponseTime) || 0;
    if (currentValue > 0) {
      const newValue = currentValue - 1;
      handleInputChange({ target: { name: "responseTime", value: newValue.toString() } });
    }
  };

  const handleNext = () => {
    if (onNext) {
      onNext();
    } else {
      console.warn("onNext prop is not provided");
    }
  };

  const handleSave = () => {
    console.log("handleSave called with:", {
      cause: formData.cause || "",
      responseTime: localResponseTime,
      areaOfImpact: localAreaOfImpact,
      receptors: localReceptors,
      riskLevel: localRiskLevel,
      consequence: localConsequence,
    });
    onSave?.({
      cause: formData.cause || "",
      responseTime: localResponseTime,
      areaOfImpact: localAreaOfImpact,
      receptors: localReceptors,
      riskLevel: localRiskLevel,
      consequence: localConsequence,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="add" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Report Spill</h2>
          </div>
          <button onClick={onPrev} className="text-white" aria-label="Close form">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
          <span className="w-4 h-4 flex items-center justify-center mr-4 text-xs font-bold text-blue-700">
            <img src="/two.svg" alt="one" width={20} height={20} className="ml-4" />
          </span>
          <span className="text-black">
            2/5 - <span className="font-bold">SPILL INVESTIGATION</span>
          </span>
        </div>
        <hr className="border-t border-gray-300 my-0" />

        <div className="px-4 py-3 overflow-y-auto flex-1 space-y-3">
          <div>
            <label className="text-sm text-gray-700">
              Cause of Spill
            </label>
            <select
              name="cause"
              value={formData.cause || ""}
              onChange={onChange}
              className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="">Select</option>
              <option value="pipeline">Pipeline</option>
              <option value="tank">Tank</option>
              <option value="vessel">Vessel</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="text-sm text-gray-700">
              Response Time
            </label>
            <div className="relative flex items-center">
              <div className="relative w-full">
                <input
                  type="number"
                  name="responseTime"
                  value={localResponseTime}
                  onChange={handleInputChange}
                  placeholder="Enter"
                  className="w-full border border-gray-300 rounded-[3px] px-3 py-2 pr-12 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                  min="0"
                  aria-label="Response time in hours"
                />
                <span className="absolute right-2 top-[42%] transform -translate-y-1/2 bg-gray-200 border border-gray-300 rounded-[3px] px-2 text-sm text-gray-700">
                  HRS
                </span>
              </div>
            </div>
</div>

<div>
  <label className="text-sm text-gray-700">
    Area of Impact
  </label>
  <div className="relative mt-1">
    <div className="flex items-center w-full border border-gray-300 rounded-[3px] px-3 py-2 focus-within:ring-1 focus-within:ring-blue-500 transition-all duration-150">
      <button
        type="button"
        onClick={() => setShowMapDropdown((prev) => !prev)}
        className="flex items-center text-sm text-[#1B5FC1] mr-2"
        aria-label="Select map view for area of impact"
      >
        <FiChevronDown className="mr-1" />
      </button>
      <input
        type="text"
        name="areaOfImpact"
        value={localAreaOfImpact}
        onChange={handleInputChange}
        placeholder="Type here or select on map"
        className="flex-1 bg-transparent outline-none text-sm"
      />
    </div>
    <div
      className={`absolute left-0 top-full mt-1 w-40 bg-white border border-gray-300 rounded-[3px] shadow-lg z-20 transition-all duration-200 origin-top-left transform ${
        showMapDropdown ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
      }`}
    >
      <button
        type="button"
        onClick={() => handleMapSelect("Map View")}
        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
      >
        Map View
      </button>
      <button
        type="button"
        onClick={() => handleMapSelect("Satellite View")}
        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
      >
        Satellite View
      </button>
    </div>
  </div>
</div>

<div>
  <label className="text-sm text-gray-700">
    Receptors
  </label>
  <input
    type="text"
    name="receptors"
    value={localReceptors}
    onChange={handleInputChange}
    placeholder="Type here"
    className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
  />
</div>

<div>
  <label className="text-sm text-gray-700">
    Risk Level
  </label>
  <select
    name="riskLevel"
    value={localRiskLevel}
    onChange={handleInputChange}
    className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
  >
    <option value="">Select</option>
    <option value="Low">Low</option>
    <option value="Moderate">Moderate</option>
    <option value="High">High</option>
    <option value="Severe">Severe</option>
  </select>
</div>

<div>
  <label className="text-sm text-gray-700">
    Consequence
  </label>
  <input
    type="text"
    name="consequence"
    value={localConsequence}
    onChange={handleInputChange}
    placeholder="Type here"
    className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
  />
</div>
</div>

<div className="bg-white px-4 py-3 flex justify-end space-x-2 mt-auto shadow-[0_-1px_3px_rgba(0,0,0,0.15)] w-full">
  <button onClick={onClose} className="px-4 py-2 text-sm border border-gray-300 rounded-md">
    Cancel
  </button>
  <button
    onClick={handleSave}
    className="px-4 py-2 text-sm bg-[#E8EFF9] text-[#1B5FC1] rounded-md"
  >
    Save Changes
  </button>
  {onNext && (
    <button
      onClick={handleNext}
      className="px-4 py-2 text-sm bg-[#1B5FC1] text-white rounded-md"
    >
      Next
    </button>
  )}
</div>
</div>

<MapModal
  isOpen={showMapModal}
  onClose={() => setShowMapModal(false)}
  onSelectLocation={handleAreaSelect}
  mapType={selectedMapType}
/>
</div>
);
};

export default SpillInvestigation;