



import React, { useState, useEffect } from "react";
import SpillReportTable from "../components/SpillReportTable";
import Step1Overview from "../../Spillsteps/components/Step1Overview";
import Step2Details from "../../Spillsteps/components/Step2Details";
import Step3 from "../../Spillsteps/components/Step3";
import Step4 from "../../Spillsteps/components/Step4";
import Step5 from "../../Spillsteps/components/Step5";
import ConfirmationPage from "../../Spillsteps/components/ConfirmationPage";
import SuccessPage from "../../Spillsteps/components/SuccessPage";

function SpillReportingDashboard() {
  const [activeTab] = useState("spill");
  const [spills, setSpills] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    date: "",
    time: "",
    cause: "",
    spillType: "",
    volume: "",
    location: "",
    riskLevel: "",
    attachment: null,
    reportDate: new Date().toISOString(),
  });
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [pendingReport, setPendingReport] = useState(null);
  const [filterType, setFilterType] = useState("All");
  const [filterMonth, setFilterMonth] = useState("All");
  const [spillTypes, setSpillTypes] = useState(["Oil", "Chemical", "Gas"]);
  const [currentPage, setCurrentPage] = useState(1); // Added for pagination
  const pageSize = 10; // Define page size

  useEffect(() => {
    // Simulated local "default options"
    setSpillTypes(["Oil", "Chemical", "Gas", "Waste"]);
  }, []);

  const handleAddNew = () => {
    setShowForm(true);
    setCurrentStep(1);
    setFormData({
      date: "",
      time: "",
      cause: "",
      spillType: "",
      volume: "",
      location: "",
      riskLevel: "",
      attachment: null,
      reportDate: new Date().toISOString(),
    });
  };

  const nextStep = (data) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setCurrentStep((prev) => prev + 1);
  };

  const prevStep = () => setCurrentStep((prev) => prev - 1);

  const handleSubmit = () => {
    setShowConfirmation(true);
    setPendingReport({ ...formData });
  };

  const handleConfirm = () => {
    setShowConfirmation(false);

    const newSpill = {
      ...pendingReport,
      id: `SPILL${Date.now()}`,
      status: "Unresolved",
      dateReported: `${pendingReport.date} ${pendingReport.time}`,
    };

    // Simulate API delay
    setTimeout(() => {
      setSpills((prev) => [...prev, newSpill]);
      setShowSuccess(true); // Show SuccessPage immediately
      // Delay closing the form and resetting step to after SuccessPage is viewed
    }, 1000);
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    setShowForm(false); // Close form only after success is acknowledged
    setCurrentStep(1);   // Reset step only after success is acknowledged
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setCurrentStep(1);
  };

  const uniqueMonths = [
    ...new Set(
      spills.map((spill) => {
        const dateStr = spill.reportDate || spill.date;
        const date = new Date(dateStr);
        return date.toLocaleString("default", { month: "short", year: "numeric" });
      })
    ),
  ];

  const filteredSpills = spills.filter((spill) => {
    const matchesType = filterType === "All" || spill.spillType === filterType;
    const dateStr = spill.reportDate || spill.date;
    const spillDate = new Date(dateStr);
    const monthYear = spillDate.toLocaleString("default", {
      month: "short",
      year: "numeric",
    });
    const matchesMonth = filterMonth === "All" || monthYear === filterMonth;
    return matchesType && matchesMonth;
  });

  // Pagination logic
  const totalFiltered = filteredSpills.length;
  const totalPages = Math.ceil(totalFiltered / pageSize);
  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, totalFiltered);
  const paginatedSpills = filteredSpills.slice(start - 1, end);

  // Gmail-style pagination logic (modified to remove "1" completely)
  const getPageNumbers = () => {
    const pageNumbers = [];
    const delta = 1; // Number of pages to show on each side of current page
    let left = Math.max(currentPage - delta, 2); // Start from 2 to skip 1
    let right = Math.min(currentPage + delta, totalPages);

    // Only show ellipsis and higher pages if there are more than 1 page
    if (left > 2 && totalPages > 1) {
      pageNumbers.push("...");
    }

    // Add the current range of pages, skipping 1
    for (let i = left; i <= right; i++) {
      pageNumbers.push(i);
    }

    // Show the last page if not in range and more than 1 page exists
    if (right < totalPages - 1) {
      pageNumbers.push("...");
    }
    if (right < totalPages && totalPages > 1) {
      pageNumbers.push(totalPages);
    }

    return pageNumbers;
  };

  return (
    <div>
      {activeTab === "spill" && (
        <div className="pt-3">
          <div className="bg-white p-4 rounded-md mb-4 border border-gray-200">
            <div className="mb-6 flex justify-between items-center flex-wrap gap-4">
              <div className="flex items-center space-x-4">
                <h2 className="text-xl font-semibold text-gray-900">Report History</h2>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search title, name..."
                    className="w-64 h-9 pr-10 pl-2 border border-gray-100 rounded-[8px] focus:outline-none font-light text-[16px] focus:ring-1 focus:ring-blue-500"
                  />
                  <img
                    src="/search.svg"
                    alt="search"
                    width={16}
                    height={16}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-600 mr-1">
                  {totalFiltered === 0 ? "0–0" : `${start}–${end}`} of {totalFiltered}
                </span>
                {/* Gmail-style Pagination */}
                <div className="flex items-center gap-1">
                  <button
                    className="text-gray-600 hover:text-black px-1 disabled:text-gray-300"
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                    </svg>
                  </button>

                  {getPageNumbers().map((page, index) => (
                    <React.Fragment key={index}>
                      {page === "..." ? (
                        <span className="text-gray-400 mx-1">...</span>
                      ) : (
                        <button
                          className={`px-2 py-1 rounded ${currentPage === page ? "bg-[#1B5FC1] text-white" : "text-gray-600 hover:bg-gray-200"}`}
                          onClick={() => setCurrentPage(page)}
                        >
                          {page}
                        </button>
                      )}
                    </React.Fragment>
                  ))}

                  <button
                    className="text-gray-600 hover:text-black px-1 disabled:text-gray-300"
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage((prev) => prev + 1)}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>

                <select
                  className="border border-gray-200 rounded px-2 py-2 text-sm"
                  value={filterType}
                  onChange={(e) => {
                    setFilterType(e.target.value);
                    setCurrentPage(1); // Reset to first page on filter change
                  }}
                >
                  <option value="All">All Types</option>
                  {spillTypes.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                <select
                  className="border border-gray-200 rounded px-2 py-2 text-sm"
                  value={filterMonth}
                  onChange={(e) => {
                    setFilterMonth(e.target.value);
                    setCurrentPage(1); // Reset to first page on filter change
                  }}
                >
                  <option value="All">All Dates</option>
                  {uniqueMonths.map((monthYear) => (
                    <option key={monthYear} value={monthYear}>{monthYear}</option>
                  ))}
                </select>
                <button
                  type="button"
                  className="bg-[#1B5FC1] hover:bg-blue-700 text-white text-sm h-9 px-3 flex items-center rounded-[8px]"
                  onClick={handleAddNew}
                >
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                  Add New
                </button>
              </div>
            </div>

            <p className="text-[16px]">
              Total No of Spill: <span className="font-bold">{totalFiltered}</span>
            </p>

            {showForm ? (
              <div>
                {currentStep === 1 && (
                  <Step1Overview
                    formData={formData}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        [e.target.name]: e.target.value,
                      }))
                    }
                    onNext={nextStep}
                    onClose={handleCloseForm}
                  />
                )}
                {currentStep === 2 && <Step2Details formData={formData} onNext={nextStep} onPrev={prevStep} />}
                {currentStep === 3 && <Step3 formData={formData} onNext={nextStep} onPrev={prevStep} />}
                {currentStep === 4 && <Step4 formData={formData} onNext={nextStep} onPrev={prevStep} />}
                {currentStep === 5 && (
                  <Step5 onNext={handleSubmit} onPrev={prevStep} formData={formData} />
                )}
                {showConfirmation && (
                  <ConfirmationPage
                    onClose={() => setShowConfirmation(false)}
                    onConfirm={handleConfirm}
                    data={pendingReport}
                  />
                )}
                {showSuccess && (
                  <SuccessPage
                    message="Spill report submitted successfully"
                    onClose={handleSuccessClose}
                  />
                )}
              </div>
            ) : filteredSpills.length > 0 ? ( 
              <SpillReportTable incidents={paginatedSpills} onStatusUpdate={() => setSpills([...spills])} />
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-gray-500">
                <img src="/book.svg" alt="empty" width={150} height={40} />
                <p className="font-medium text-[20px] text-[#292929]">No spill report</p>
                <p className="text-sm text-[#707070]">Use the "Add New" button</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default SpillReportingDashboard;