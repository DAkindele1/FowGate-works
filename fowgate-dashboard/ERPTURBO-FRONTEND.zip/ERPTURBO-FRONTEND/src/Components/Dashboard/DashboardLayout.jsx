import React from "react";
import { Outlet, NavLink } from "react-router-dom";
import Sidebar from "./Sidebar";

const DashboardLayout = () => {
  return (
    <div className="flex gap-[15px] p-1 h-screen overflow-hidden border border-blue-900">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 px-6 h-full overflow-auto">
        <Outlet />
      </main>
    </div>
  );
};

export default DashboardLayout;
