// FileUpload.jsx
import React, { useRef } from "react";
import toast from "react-hot-toast";

const FileUpload = ({ attachments, onChange }) => {
  const fileInputRef = useRef(null);

  const maxSize = 5 * 1024 * 1024; // 5MB
  const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/gif",
    "video/mp4",
    "video/mpeg",
    "audio/mpeg",
    "audio/wav",
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ];

  const validateFile = (file) => {
    if (!file) return false;
    if (file.size > maxSize) {
      toast.error(`${file.name} exceeds 5MB limit.`);
      return false;
    }
    if (!allowedTypes.includes(file.type)) {
      toast.error(`${file.name} has an invalid file type.`);
      return false;
    }
    return true;
  };

  const handleFiles = (fileList) => {
    const validFiles = Array.from(fileList).filter((file) => validateFile(file));
    if (validFiles.length) {
      onChange?.({ target: { name: "attachments", value: validFiles } });
    }
  };

  const handleInputChange = (e) => {
    const file = e.target.files;
    handleFiles(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files;
    handleFiles(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  return (
    <div
      className="mt-0 flex justify-center px-6 pt-5 pb-6 border-2 border-[#1B5FC1] border-dashed rounded-[3px] bg-blue-50"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <div className="space-y-1 text-center">
        <img src="/upload.svg" alt="upload" className="mx-auto h-12 w-12" />
        <div className="flex text-sm text-gray-600 justify-center">
          <span className="mr-1 font-bold">Drag and drop file or</span>
          <a
            href="#"
            className="text-blue-600 underline font-bold"
            onClick={(e) => {
              e.preventDefault();
              fileInputRef.current.click();
            }}
          >
            Browse
          </a>
        </div>
        <p className="text-xs text-gray-500">Max 5MB – Images, Video, Audio, Documents</p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept="image/*,video/*,audio/*,application/pdf,.doc,.docx"
          onChange={handleInputChange}
          multiple
        />
        {attachments?.length > 0 && (
          <ul className="text-xs text-gray-600 mt-2 space-y-1">
            {attachments.map((file, index) => (
              <li key={index}>• {file.name}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default FileUpload;