import React, { useEffect, useRef, useState } from "react";

const SelectDropdown = ({ name, value, onChange, options, label, required }) => {
  return (
    <div className="relative">
      {label && (
        <label className="text-sm text-gray-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <select
        name={name}
        value={value || ""}
        onChange={onChange}
        className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm mt-1 appearance-none bg-no-repeat bg-[length:16px] bg-[right_0.75rem_center] pr-8"
        style={{ backgroundImage: `url('/arrow.svg')` }}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SelectDropdown;