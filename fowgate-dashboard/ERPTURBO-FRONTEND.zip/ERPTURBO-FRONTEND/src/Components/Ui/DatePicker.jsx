import React, { useRef } from "react";

const DatePicker = ({ value, onChange, label, required }) => {
  const dateInputRef = useRef(null);

  const handleIconClick = () => {
    dateInputRef.current?.showPicker();
  };

  const handleDateChange = (e) => {
    const newDate = e.target.value;
    onChange?.({ target: { name: "date", value: newDate } });
  };

  const formatDate = (isoString) => {
    if (!isoString) return "";
    const [year, month, day] = isoString.split("-");
    return `${day}/${month}/${year}`;
  };

  return (
    <div>
      {label && (
        <label className="text-sm text-gray-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <div className="relative w-full mt-1">
        <input
          ref={dateInputRef}
          type="date"
          value={value}
          onChange={handleDateChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        <div className="flex items-center justify-between w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-900 bg-white relative pointer-events-none">
          <span className="truncate pointer-events-none">
            {value ? formatDate(value) : "dd/mm/yyyy"}
          </span>
          <img
            src="/calendar.svg"
            alt="calendar"
            className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 cursor-pointer pointer-events-auto hover:scale-110 transition"
            onClick={handleIconClick}
          />
        </div>
      </div>
    </div>
  );
};

export default DatePicker;