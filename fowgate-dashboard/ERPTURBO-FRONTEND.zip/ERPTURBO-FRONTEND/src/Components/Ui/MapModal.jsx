import React, { useEffect, useState } from "react";
import axios from "axios";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix Leaflet marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const MapModal = ({ isOpen, onClose, onSelectLocation, mapType }) => {
  const [center, setCenter] = useState([4.8430, 7.0330]); // Default: Port Harcourt, Rumudara
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedAddress, setSelectedAddress] = useState(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCenter([position.coords.latitude, position.coords.longitude]);
        },
        () => {
          alert("Unable to access your location. Using default map center.");
        }
      );
    }
  }, []);

  const MapClickHandler = () => {
    useMapEvents({
      click: async (e) => {
        const { lat, lng } = e.latlng;
        setSelectedLocation([lat, lng]);

        try {
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
            {
              headers: {
                "User-Agent": "IncidentReportingApp (nackycynthia@gmail.com)",
              },
            }
          );
          const address = response.data.display_name || `Lat: ${lat}, Lng: ${lng}`;
          setSelectedAddress(address);
        } catch (error) {
          console.error("Geocoding error:", error);
          setSelectedAddress(`Lat: ${lat}, Lng: ${lng}`);
          alert("Unable to retrieve address. Using coordinates instead.");
        }
      },
    });
    return null;
  };

  const handleConfirm = () => {
    if (selectedLocation && selectedAddress) {
      onSelectLocation({
        lat: selectedLocation[0],
        lng: selectedLocation[1],
        address: selectedAddress,
      });
    }
    onClose();
  };

  if (!isOpen) return null;

  const tileUrl =
    mapType === "Satellite View"
      ? "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
      : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  const attribution =
    mapType === "Satellite View"
      ? '© <a href="https://www.esri.com/">Esri</a>'
      : '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-[3px] p-4 w-[80%] h-[80%] max-w-4xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg">Select Spill Location</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="mb-2 text-sm text-gray-700">
          {selectedAddress ? (
            <p>Selected: {selectedAddress}</p>
          ) : (
            <p>Click on the map to select a location</p>
          )}
        </div>
        <MapContainer
          center={center}
          zoom={10}
          style={{ width: "100%", height: "80%" }}
        >
          <TileLayer url={tileUrl} attribution={attribution} />
          {selectedLocation && <Marker position={selectedLocation} />}
          <MapClickHandler />
        </MapContainer>
        <div className="flex justify-end -mt-2">
          <button
            type="button"
            onClick={handleConfirm}
            className="bg-[#1B5FC1] text-white px-4 py-2 rounded-[3px]"
            disabled={!selectedLocation}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};

export default MapModal;