import React from 'react'

export default function DisplayName({name, fontSize}) {
  const formattedName = (() => {
    const words = name.trim().split(/\s+/);
    return words.length === 1 ? name.trim() : words.map(w => w[0]).join('');
  })();

  return <div className={`${fontSize? fontSize : ""}`}>{formattedName}</div>;
}

  