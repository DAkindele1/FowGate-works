import React, { useState} from "react";
import CreateJobForm from "./CreateForm/CreateJobForm";
import { fetchAllJobListing } from "../services/api_job_board";
import JobTable from "./JobTable";
import Spinner from "../../../../ui/Spinner";
import Select from "../../../../ui/Select";
import EmptyTable from "../../../../ui/EmptyTable";
import { CalendarDotsIcon } from "@phosphor-icons/react";
import { useQuery } from "@tanstack/react-query";
import MainButton from "../../../../ui/MainButton";


export default function JobBoard() {
  const [openCreateModal, setOpenCreateJob] = useState(false)
  const [openEditModal, setOpenEditJob] = useState(false)
  const [templateOption, setTemplateOption] = useState("")
  const [selectedJob, setSelectedJob] = useState(null); 

  const { data, isLoading, error } = useQuery({
    queryKey: ['job-listing'],
    queryFn: ()=>fetchAllJobListing(),
  })
 
  
  return <div className="border border-gray-300 px-[20px] rounded-xl min-h-[80vh]">

    {/* Header */}
              <div className="my-[20px]">
                <div className="flex items-center justify-between w-full">
                  <div className="flex gap-[24px] items-center ">
                    <h1 className="text-[20px] font-medium text-[#292929]">
                      Job Listing
                    </h1>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search here"
                        className="h-[42px] py-[8px] px-[12px] border border-gray-300 rounded-sm w-64 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                      
                      <img
                        src="/assets/img/ats-search.png"
                        alt="Search Icon"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 "
                      />
                    </div>
                  </div>
    
                  <div className="flex items-center gap-[20px]  h-[40px] w-[322px] justify-end">
                    <div className="flex items-center gap-[8px]">
            <p className="text-[#707070] text-[12px]">Filter by:</p>
            <div className="border border-gray-300 rounded-sm flex items-center gap-2 h-[40px] w-[123px] py-[10px]">
              <Select optionsArr={["Job Title"]} noBorder={true} value={templateOption} handleChange={setTemplateOption} test={true}/>
            </div>
           
                    </div>
    
          {/* Create Job Button */}
          <MainButton 
                      text="Create Job" 
                      action={()=>setOpenCreateJob(true)} />
                    {/* <button
            onClick={() => {
              
                      }}
                      className="w-[110px] flex items-center justify-center py-[10px] bg-[#1B5FC1] text-white rounded-sm hover:bg-blue-500 transition cursor-pointer text-[14px]"
                    >
                      Create Job
                    </button> */}
                  </div>
                </div>
    </div>
    
      <div className="w-full  ">
    {/* Table Headers */}    
      <div className="grid grid-cols-[250px_128px_250px_140px_1.8fr_0.4fr] items-center  bg-[#E8EFF9]  rounded-tr-lg rounded-tl-lg">
        {["Title", "Candidates", "Hiring Team", "Post Status", "Post Audience", "Action"].map(tab => <div key={tab} className="py-[9px] px-[12px] text-[14px] font-medium text-[#292929]">{tab}</div>)}
      </div>
      

      {/* Table Body */}
      <div >

        {/* Conditional rendering based on loading state, error state and job listing */}

        {isLoading && <Spinner />}

        {error && <p>Error: {error.message}</p>}

        {data?.job_listings && (
          data.job_listings.length === 0 ?
            (<EmptyTable info="No job listing" instruction='Use the "Create Job" button.' />
             ) :
            (<JobTable jobs={data.job_listings} setSelectedJob={setSelectedJob} setIsEdit={setOpenEditJob}/>)
        )} 
        
        </div> 
      </div>
     
    
    {openCreateModal && <CreateJobForm handleClose={ ()=> setOpenCreateJob(false)} mode={"create"}  />}
    {openEditModal && (
  <CreateJobForm 
  handleClose={() => setOpenEditJob(false)} 
    mode="edit" 
        jobData={selectedJob}
        
  />
)}
  </div>;
}

