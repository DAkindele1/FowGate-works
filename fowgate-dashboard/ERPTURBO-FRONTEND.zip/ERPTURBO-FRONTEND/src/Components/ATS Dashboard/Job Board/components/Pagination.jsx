import { CaretLeftIcon, CaretRightIcon } from '@phosphor-icons/react';
import React, {useState} from 'react'

import { FaAngleLeft } from "react-icons/fa6";
import { FaAngleRight } from "react-icons/fa6";

export default function Pagination() {
    const [currPage, setCurrPage] = useState(1)
  return (
    <div className="ml-auto w-fit mt-4 flex items-center gap-2 font-medium">
            <button className={` w-8 h-8 flex items-center justify-center rounded-sm bg-[#EAEAEA] ${currPage <= 1 ? "cursor-not-allowed" : "cursor-pointer"}`} aria-disabled><CaretLeftIcon size={24} color='#9D9D9D' /></button>
            <span className="border w-8 h-8 flex items-center justify-center rounded-sm text-[#1B5FC1] border-[#1B5FC1]">1</span>
            <span className="border border-[#EAEAEA]  w-8 h-8 flex items-center justify-center rounded-sm text-[#212B36]">2</span>
            <span className="border border-[#EAEAEA]  w-8 h-8 flex items-center justify-center rounded-sm text-[#212B36]">...</span>
            <span className="border border-[#EAEAEA]  w-8 h-8 flex items-center justify-center rounded-sm text-[#212B36]">5</span>
            <button className="cursor-pointer w-8 h-8 flex items-center justify-center rounded-sm bg-[#EAEAEA]"><CaretRightIcon size={24} color='#1B5FC1'/></button>
        </div>
  )
}
