import React from 'react'
import JobTableRow from './JobTableRow';
import BottomPagination from '../../../../ui/BottomPagination';


const JobTable = ({ jobs, setIsEdit, setSelectedJob, setJobs }) => {
  
    
    return (<>
      {jobs.map((job) => <JobTableRow key={job._id} job={job} setIsEdit={setIsEdit} setSelectedJob={setSelectedJob} setJobs={setJobs} />   
      )}
        {jobs.length>=10 && <BottomPagination />}
    </>
    );
};
  

  
  export default JobTable;