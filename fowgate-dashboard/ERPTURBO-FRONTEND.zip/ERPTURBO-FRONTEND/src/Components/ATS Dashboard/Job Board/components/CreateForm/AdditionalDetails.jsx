import React from 'react'
import Toggle from '../../../../../ui/Toggle'

export default function AdditionalDetails({heading, body, handleToggle, value}) {
  return (
    <div className="pt-6 pb-2 border-b border-gray-300 flex items-center justify-between">
                  <div>
              <p className="text-black text-[16px]">{ heading}</p>
              <p className=" text-gray-600 text-[14px]">{body}</p>
                  </div>
          <Toggle handleToggle={ handleToggle} value={value} />
                </div>
  )
}
