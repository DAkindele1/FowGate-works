
import React, { useState } from "react";
import { HiDotsVertical } from "react-icons/hi";
import JobActionsModal from "./JobActionsModal";
import toast from "react-hot-toast";
import { deleteJobListing } from "../services/api_job_board";
import DisplayName from "../services/DisplayName";
import SuccessModal from "../../../../ui/SuccessModal";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import SmallBlueText from "../../../../ui/SmallBlueText";
import RoundInitials from "../../../../ui/RoundInitials";
import StatusPill from "../../../../ui/StatusPill";

const JobTableRow = ({ job, setIsEdit, setSelectedJob }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
  const [confirmModal, setConfirmModal] = useState(false)
  const [successModal, setSuccessModal] = useState(false)
    

  const queryClient = useQueryClient();

  const { mutate } = useMutation({
    mutationFn: deleteJobListing,
    onSuccess: () => {
      setConfirmModal(false);
        setIsModalOpen(false);
        setSuccessModal(true);
      
    },
    onError: (error) => {
      toast.error(error.message || "Operation failed");
    }
  })
    
      const handleDotsClick = (e) => {
        e.stopPropagation()
        setAnchorEl(e.currentTarget);
        setIsModalOpen(true)
    
  };


  
  
  const handleEdit = () => {
    setSelectedJob(job); // Set the selected job
    setIsEdit(true); // Open the edit modal
  };


  const handleDelete = (jobCode) => {
    mutate(jobCode)
  };
         
      const statusColors = {
        published: "bg-[#EEFFF3] text-[#34A853]",
        cancelled: "bg-[#FDECEB] text-[#EB4335]",
        pending: "bg-[#FFF1DD] text-[#EB8A00]",
  };
  console.log(job.status, "job status in row");
        return (<>  <div className="grid grid-cols-[250px_128px_250px_140px_1.8fr_0.4fr] border-b border-gray-300 text-[#292929] text-[14px] font-normal items-center  py-[12px]">
            <div className="truncate capitalize  px-[12px]">{ job.title}</div>
            <div className=" px-[12px]">{job.no_of_candidates}</div>

                {/* Hiring Team */}
          <div className="flex items-center px-[12px]">
            {job.hiring_team.length > 1 && job.hiring_team.slice(0, 4).map((el, i) => <div key={el.value} className={`${el.value.trim().split(/\s+/).length !== 1 && "text-[#1b5fc1] font-medium rounded-full flex items-center justify-center bg-white p-[.7px]"} ${i !== 0 && `${"-ml-[5px]"}`} `}>
              <RoundInitials name={el.value}/>
            </div>)}

            {job.hiring_team.length === 1 && <div className="flex items-center gap-2">
              <RoundInitials name={ job.hiring_team[0].value}/>
              <p>{job.hiring_team[0].value}</p></div>}
            
          {job.hiring_team.length > 4 && (
            <span className="ml-[4px]">
              +{job.hiring_team.length - 4} more
            </span>
                )}
          </div>
          
          <div className="ml-1">
            <StatusPill status={job.status === "published" ? "success" : job.status === "cancelled" ? "error" : "warning"} text={`${job.status === "pending" ? "draft" : job.status}`}/>
          </div>
          
            <div className='capitalize px-[12px] '> {job.audience[0]} {job.audience.length>1? <SmallBlueText number={job.audience.length-1}/>: ""}</div>
            <button className='cursor-pointer flex items-center' onClick={handleDotsClick}><HiDotsVertical /></button>
          {isModalOpen &&
             <JobActionsModal
             jobTitle={job.title}
             jobCode={job.job_code}
             isOpen={isModalOpen}
             onDelete={handleDelete}
             onEdit={handleEdit} 
             anchorEl={anchorEl}
             onClose={() => setIsModalOpen(false)}
             confirmModal={confirmModal}
             showConfirmedModal={()=>setConfirmModal(true)}
             showSuccessModal={()=>setSuccessModal(true)}
             closeConfirmedModal={()=>setConfirmModal(false)}
           />
          }
        </div>
          
          {successModal && 
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
              <div className={`bg-white rounded-sm relative shadow-xl animate-fadeIn w-[528px] h-[442px]`}>
                <SuccessModal actionMode={"delete"} closeModal={() => {
                  setSuccessModal(false);
        toast.success("Job listing deleted successfully");                  
      queryClient.invalidateQueries({ queryKey: ['job-listing'] });
                  }} />
              </div></div>}
          
          
        
        </>)
    
};

export default JobTableRow;
