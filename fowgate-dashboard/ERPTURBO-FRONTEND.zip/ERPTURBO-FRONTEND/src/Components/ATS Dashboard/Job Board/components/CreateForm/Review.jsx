import React from 'react'
import Select from '../../../../../ui/Select'
import { useState } from 'react'
import { CaretDownIcon, PlusIcon, XIcon } from '@phosphor-icons/react';
import DisplayName from '../../services/DisplayName';

export default function Review({ setStep, jobTitle, jobOverview, industry, salaryCurrency, salaryRange, requiredSkills, resume, coverLetter, hiringTeam, questions }) {
    const [isOpen, setIsOpen] = useState(true);
    const toggleDropdown = () => setIsOpen(!isOpen);

  const [advertSites, setAdvertSites] = useState(["LinkedIn", "Jobberman", "Remote.io", "Indeed", "MyJobMag", "Upwork", "AngelList", "Glassdoor"])

  const [safeAdvertSites, setSafeAdvertSites] =useState([]);

  const removeItem = (item)=>{
    setAdvertSites([...advertSites, item])
    setSafeAdvertSites(safeAdvertSites.filter(el => el !== item))
  }
  const addItem = (item) => {
    setSafeAdvertSites([...safeAdvertSites, item])
    setAdvertSites(advertSites.filter(el => el !== item))
    setIsOpen(true)
  }
   
  
  
  
  return (
    <div className='flex flex-col gap-[20px] pb-2'>
      <div className=" gap-2 flex flex-col ">
      <p className="font-normal text-[16px]  ">Advertise Posting</p>
        <div className="border border-gray-300 rounded-[6px]  w-full p-[12px] flex justify-between items-start">
          <div className='w-[400px] flex flex-wrap gap-1.5'>
          {safeAdvertSites && safeAdvertSites.map((item, index) => (
            <span
              key={index}
              className="flex items-center bg-[#E8EFF9] text-[#1B5fc1] rounded-full px-3 py-1 text-sm "
            >
              {item}
              <button onClick={() => removeItem(item)} className="ml-2  hover:text-red-600 cursor-pointer">
                <XIcon size={16} />
              </button>
            </span>
          ))}
          </div>
          <button
                      
                      onClick={toggleDropdown}
                    >
          <CaretDownIcon className="text-gray-400" size={16}/></button>
        </div>
        
       { isOpen && <div className="mt-2 border border-gray-200 rounded-[6px]">
            <div className="flex gap-3 flex-wrap  p-[16px] ">
              { advertSites.map((item, index) => (
                <button
                  key={index}
                  onClick={() => addItem(item)}
                  className="text-sm text-left bg-white cursor-pointer border border-gray-200  w-fit rounded-full px-2 py-1 hover:bg-gray-200 flex items-center gap-2"
                >
                  {item}
                  <PlusIcon size={16}/>
                </button>
              ))}
            </div>
          </div>}
      </div>

   {/* Job Details */}
   <div className="bg-[#F2F7FF] p-3 rounded-sm">
     <div className="bg-white rounded-[8px] p-4 flex flex-col gap-2 ">

     <div className="flex items-center justify-between border-b py-4 h-[54px] border-b-gray-300">
       <h1 className='font-medium text-[16px] text-[#292929]'>Job Details</h1>
       <p className='text-[#1B5fc1] text-[14px] font-normal cursor-pointer' onClick={()=>setStep(1)}>Edit</p>
     </div>
     <div className="grid grid-cols-2 py-3 border-b border-b-gray-300 h-[70px]">
         <div className=" h-[46px] flex flex-col gap-1">
           <p className='text-[#707070] text-[14px] font-normal'>Job Title</p>
           <p className='text-[#292929] text-[16px] font-normal truncate'>{jobTitle|| " - "}</p>
       </div>
            <div className="h-[46px]  flex flex-col gap-1">
              <p className='text-[#707070] text-[14px] font-normal'>Job Code</p>
              <p className='text-[#292929] text-[16px] font-normal'>UDX-2025-06</p>
            </div>
     </div>
     <div className="border-b py-3 border-b-gray-300  h-[70px] flex flex-col gap-1">
       <h1 className='text-[#707070] text-[14px] font-normal'>Industry</h1>
       <p className='text-[#292929] text-[16px] font-normal'>{industry|| " - "}</p>
          </div>
          <div className="grid grid-cols-2 py-3 border-b border-b-gray-300 h-[70px]">
         <div className=" h-[46px] flex flex-col gap-1">
           <p className='text-[#707070] text-[14px] font-normal'>Salary Currency</p>
           <p className='text-[#292929] text-[16px] font-normal truncate'>{salaryCurrency|| " Nigerian Naira (NGN) "}</p>
       </div>
            <div className="h-[46px]  flex flex-col gap-1">
              <p className='text-[#707070] text-[14px] font-normal'>Salary Range</p>
              <p className='text-[#292929] text-[16px] font-normal'>{salaryRange|| " - "}/month</p>
            </div>
     </div>
       <div className="border-b py-4 border-b-gray-300">
       <h1 className='text-[#707070] text-[14px] font-normal'>Required skills</h1>
            <p className='text-[#292929] text-[16px] font-normal'>
              {requiredSkills.length < 4 ? requiredSkills.join(', ') : requiredSkills.slice(0, 3).join(', ')}
              {requiredSkills.length > 4 && <span> +{ requiredSkills.length - 3 } more</span>}
            </p>
       </div>
     </div>
   </div>

   {/* Job Description */}
   <div className="bg-[#F2F7FF] p-3 rounded-sm ">
     <div className="bg-white rounded-[8px] p-4 flex flex-col gap-2 ">

    
     <div className="flex items-center justify-between border-b py-4 h-[54px] border-b-gray-300">
       <h1 className='font-medium text-[16px] text-[#292929]'>Job Description</h1>
       <p className='text-[#1B5fc1] text-[14px] font-normal cursor-pointer' onClick={()=>setStep(1)}>Edit</p>
          </div>
          <div className="border-b py-4 border-b-gray-300">
       <h1 className='text-[#707070] text-[14px] font-normal'>Job Overview</h1>
       <p className='text-[#292929] text-[16px] font-normal'>{jobOverview ? jobOverview : " - "}</p>
          </div>     
     </div>
   </div>

      {/* Additional Details */}
      <div className="bg-[#F2F7FF] p-3 rounded-sm ">
     <div className="bg-white rounded-[8px] p-4 flex flex-col gap-2 ">    
     <div className="flex items-center justify-between border-b py-4 h-[54px] border-b-gray-300">
       <h1 className='font-medium text-[16px] text-[#292929]'>Additional Details</h1>
       <p className='text-[#1B5fc1] text-[14px] font-normal cursor-pointer' onClick={()=>setStep(2)}>Edit</p>
          </div>
          <div className="border-b py-4 border-b-gray-300  flex items-center justify-between text-[16px] text-[#292929]">
          <h2 className='font-normal'>Upload Resume</h2>
          <p className="font-medium">{resume?"Yes":"No"}</p>
          </div>
          
          <div className="border-b py-4 border-b-gray-300 flex items-center justify-between text-[16px] text-[#292929]">
         <h2 className='font-normal '>Attach Cover Letter</h2>
         <p className="font-medium ">{coverLetter?"Yes":"No"}</p>       
       </div>
     
     </div>
   </div>

      {/* Questions */}
      <div className="bg-[#F2F7FF] p-3 rounded-sm ">
     <div className="bg-white rounded-[8px] p-4 flex flex-col gap-2 ">    
     <div className="flex items-center justify-between border-b py-4 h-[54px] border-b-gray-300">
       <h1 className='font-medium text-[16px] text-[#292929]'>Questions</h1>
       <p className='text-[#1B5fc1] text-[14px] font-normal cursor-pointer' onClick={()=>setStep(3)}>Edit</p>
          </div>
          {questions.map((el, i) => {
            return <div key={i} className="border-b py-3 border-b-gray-300  flex flex-col gap-2 text-[16px] text-[#292929]">
             
              <h1 className='font-normal text-xl text-[#292929]'>{el.question}</h1>
             {el.options && <ol className={`list-inside ${el.type === "dropdown"? "list-[upper-alpha]":"list-disc"} text-[14px] text-[#707070] flex flex-col gap-2`}>
               {el.options.map((el, i) => <li key={i}>{el.option}</li>)}
         </ol>}
            </div>
          })}
  
        
         </div>
      </div>
      
      {/* Hiring Team */}
      {hiringTeam.length>0 && <div className="bg-[#F2F7FF] p-3 rounded-sm ">
     <div className="bg-white rounded-[8px] p-4 flex flex-col gap-2 ">    
     <div className="flex items-center justify-between border-b py-4 h-[54px] border-b-gray-300">
       <h1 className='font-medium text-[16px] text-[#292929]'>Hiring Team</h1>
       <p className='text-[#1B5fc1] text-[14px] font-normal cursor-pointer' onClick={()=>setStep(4)}>Edit</p>
          </div>
          <div className="flex flex-col gap-3">
            {hiringTeam.map((el, i) => <div key={i} className={`h-[27px] flex item-center gap-2`}>
              <div className='p-[1px] rounded-full bg-[#E8EFF9]'><div className="text-[#1b5fc1] font-medium rounded-full h-[24px] w-[24px] flex items-center justify-center  ">

<DisplayName name={el.value} />
</div></div>
              
              <div className='font-light text-[16px]'>{el.value}</div>
            </div>)}
          </div>
          
     
     </div>
   </div>}
    </div>
  )
}

