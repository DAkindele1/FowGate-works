import React, { useState } from 'react';
import { FaRegTrashAlt } from 'react-icons/fa';
import Input from '../../../../../ui/Input';
import Select from '../../../../../ui/Select';
import { PlusIcon } from '@phosphor-icons/react';
import Toggle from '../../../../../ui/Toggle';
import { CaretDownIcon, CaretUpIcon } from '@phosphor-icons/react/dist/ssr';
import toast from 'react-hot-toast';

const QUESTION_TYPES = {
  MULTIPLE_CHOICE: "multiple_choice",
  DROPDOWN: "dropdown",
  SHORT_ANSWER: "short_answer",
  LONG_ANSWER: "long_answer"
};

const typeDisplayMap = {
  [QUESTION_TYPES.MULTIPLE_CHOICE]: "Multiple Choice",
  [QUESTION_TYPES.DROPDOWN]: "Dropdown",
  [QUESTION_TYPES.SHORT_ANSWER]: "Short Answer",
  [QUESTION_TYPES.LONG_ANSWER]: "Long Answer"
};

const Questionnaire = ({ questions, setQuestions }) => {
  const [openIndex, setOpenIndex] = useState(null);
  const [saveTemplate, setSaveTemplate] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState({
    type: QUESTION_TYPES.MULTIPLE_CHOICE,
    question: "",
    options: [
      { option: "", is_selected: false },
      { option: "", is_selected: false }
    ],
    answer: ""
  });

  const resetForm = () => {
    setCurrentQuestion({
      type: QUESTION_TYPES.MULTIPLE_CHOICE,
      question: "",
      options: [
        { option: "", is_selected: false },
        { option: "", is_selected: false }
      ],
      answer: ""
    });
  };

  const toggleDropdown = (index) => {
    if (openIndex === index) {
      setOpenIndex(null);
      resetForm();
    } else {
      setOpenIndex(index);
      const q = questions[index];
      setCurrentQuestion({
        type: q.type,
        question: q.question,
        options: q.options || [],
        answer: q.answer || ""
      });
    }
  };

  const deleteQuestion = (index) => {
    const updatedQuestions = questions.filter((_, i) => i !== index);
    setQuestions(updatedQuestions);
    if (openIndex === index) {
      setOpenIndex(null);
      resetForm();
    }
  };

  const handleTypeChange = (displayType) => {
    const typeMap = {
      "Multiple Choice": QUESTION_TYPES.MULTIPLE_CHOICE,
      "Dropdown": QUESTION_TYPES.DROPDOWN,
      "Short Answer": QUESTION_TYPES.SHORT_ANSWER,
      "Long Answer": QUESTION_TYPES.LONG_ANSWER
    };
    
    const newType = typeMap[displayType] || QUESTION_TYPES.MULTIPLE_CHOICE;
    
    setCurrentQuestion(prev => ({
      ...prev,
      type: newType,
      options: ["multiple_choice", "dropdown"].includes(newType) 
        ? prev.options 
        : [],
      answer: ["short_answer", "long_answer"].includes(newType)
        ? prev.answer
        : ""
    }));
  };

  const addQuestion = () => {
    if (!currentQuestion.question.trim()) {
      toast.error("Please enter a question");
      return;
    }

    if (["multiple_choice", "dropdown"].includes(currentQuestion.type)) {
      const hasEmptyOptions = currentQuestion.options.some(opt => !opt.option.trim());
      if (hasEmptyOptions) {
        toast.error("Please fill all option fields");
        return;
      }
      if (currentQuestion.options.length < 2) {
        toast.error("Please add at least 2 options");
        return;
      }
    }

    const newQuestion = {
      type: currentQuestion.type,
      question: currentQuestion.question.trim(),
      ...(["multiple_choice", "dropdown"].includes(currentQuestion.type) 
        ? { 
            options: currentQuestion.options.map(opt => ({
              option: opt.option.trim(),
              is_selected: opt.is_selected
            }))
          }
        : {
            answer: currentQuestion.answer.trim()
          })
    };

    if (openIndex !== null) {
      const updatedQuestions = [...questions];
      updatedQuestions[openIndex] = newQuestion;
      setQuestions(updatedQuestions);
    } else {
      setQuestions([...questions, newQuestion]);
    }

    resetForm();
    setOpenIndex(null);
  };

  const toggleOptionSelection = (index) => {
    const newOptions = [...currentQuestion.options];
    if (currentQuestion.type === QUESTION_TYPES.DROPDOWN) {
      newOptions.forEach(opt => opt.is_selected = false);
    }
    newOptions[index].is_selected = !newOptions[index].is_selected;
    setCurrentQuestion({
      ...currentQuestion,
      options: newOptions
    });
  };

  const addOption = () => {
    setCurrentQuestion({
      ...currentQuestion,
      options: [...currentQuestion.options, { option: "", is_selected: false }]
    });
  };

  const removeOption = (index) => {
    const newOptions = [...currentQuestion.options];
    newOptions.splice(index, 1);
    setCurrentQuestion({
      ...currentQuestion,
      options: newOptions
    });
  };

  const isOptionsQuestion = ["multiple_choice", "dropdown"].includes(currentQuestion.type);

  return (
    <div className="w-full py-3">
      {/* Existing Questions List */}
      {questions.map((q, index) => (
        <div key={index} className="border border-gray-300 rounded-md mb-4 cursor-pointer hover:bg-gray-50 transition">
          <div className="flex justify-between items-center p-4" onClick={() => toggleDropdown(index)}>
            <span className="text-gray-800 font-normal w-[90%] h-fit break-words whitespace-normal">
              {q.question || `Question ${index + 1}`}
              <span className="text-gray-500 text-sm ml-2">
                ({typeDisplayMap[q.type]})
              </span>
            </span>
            <div className="flex items-center space-x-3">
              {openIndex !== index ? (
                <CaretDownIcon className="text-gray-400" size={16} />
              ) : (
                <CaretUpIcon className="text-gray-400" size={16} />
              )}
              <button 
                onClick={(e) => { 
                  e.stopPropagation(); 
                  deleteQuestion(index); 
                }}
                className="text-red-500 hover:text-red-700"
              >
                <FaRegTrashAlt size={14} />
              </button>
            </div>
          </div>

          {/* Question Editor */}
          {openIndex === index && (
            <div className="px-4 pb-4">
              <Input 
                label="Question" 
                overview={true}
                placeholder="Enter question text" 
                value={currentQuestion.question} 
                handleChange={(val) => setCurrentQuestion({
                  ...currentQuestion, 
                  question: val
                })} 
              />
              
              <Select 
                label="Field Type" 
                optionsArr={Object.values(typeDisplayMap)} 
                handleChange={handleTypeChange}
                value={typeDisplayMap[currentQuestion.type]}
              />

              {isOptionsQuestion && (
                <div className="mt-4">
                  <div className="flex item-center  mb-2 justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Options {currentQuestion.type === QUESTION_TYPES.DROPDOWN ? 
                      "(Select one)" : "(Select multiple)"}
                  </label>
                  <button
                    onClick={addOption}
                    className="text-sm text-[#1b5fc1] flex items-center"
                  >
                    <PlusIcon size={16} className="mr-1" />
                    Add Option
                  </button>
                 </div>
                  {currentQuestion.options.map((opt, optIndex) => (
                    <div key={optIndex} className="flex items-center mb-2">
                      <input
                        type={currentQuestion.type === QUESTION_TYPES.MULTIPLE_CHOICE ? 
                          "checkbox" : "radio"}
                        checked={opt.is_selected}
                        onChange={() => toggleOptionSelection(optIndex)}
                        className="mr-2"
                      />
                      <div className="border w-full">
                      <Input
                        value={opt.option}
                        overview={true}
                        handleChange={(val) => {
                          const newOptions = [...currentQuestion.options];
                          newOptions[optIndex].option = val;
                          setCurrentQuestion({
                            ...currentQuestion, 
                            options: newOptions
                          });
                        }}
                        placeholder={`Option ${optIndex + 1}`}
                        noLabel
                      />
                      </div>
                      
                      {currentQuestion.options.length > 1 && (
                        <button 
                          onClick={() => removeOption(optIndex)}
                          className="ml-2 text-red-500 hover:text-red-700"
                        >
                          <FaRegTrashAlt size={14} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={addQuestion}
                className="mt-4 w-full border border-[#1b5fc1] text-[#1b5fc1] py-2 px-4 rounded-md cursor-pointer"
              >
                {openIndex !== null ? "Update Question" : "Add Question"}
              </button>
            </div>
          )}
        </div>
      ))}

      {/* Add New Question Form */}
      {openIndex === null && (
        <div>
          <div className="border border-gray-300 rounded-md mb-4 p-4">
          <div className="w-full"><Input 
            label="Question" 
            overview={true}
            placeholder="Enter question text" 
            value={currentQuestion.question} 
            handleChange={(val) => setCurrentQuestion({
              ...currentQuestion, 
              question: val
            })} 
          /></div>
          
          <Select 
            label="Field Type" 
            optionsArr={Object.values(typeDisplayMap)} 
            handleChange={handleTypeChange}
            value={typeDisplayMap[currentQuestion.type]}
          />

          {isOptionsQuestion && (
            <div className="mt-4">
              <div className="flex item-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700 ">
                Options {currentQuestion.type === QUESTION_TYPES.DROPDOWN ? 
                  "(Select one)" : "(Select multiple)"}
              </label>
              <button
                onClick={addOption}
                className="text-sm text-[#1b5fc1] flex items-center"
              >
                <PlusIcon size={16} className="mr-1" />
                Add Option
              </button>
              </div>
              {currentQuestion.options.map((opt, optIndex) => (
                <div key={optIndex} className="flex items-center mb-2">
                  <input
                    type={currentQuestion.type === QUESTION_TYPES.MULTIPLE_CHOICE ? 
                      "checkbox" : "radio"}
                    checked={opt.is_selected}
                    onChange={() => toggleOptionSelection(optIndex)}
                    className="mr-2"
                  />
                  <div className="w-full">
                  <Input
                    value={opt.option}
                    question={true}
                    overview={true}
                    handleChange={(val) => {
                      const newOptions = [...currentQuestion.options];
                      newOptions[optIndex].option = val;
                      setCurrentQuestion({
                        ...currentQuestion, 
                        options: newOptions
                      });
                    }}
                    placeholder={`Option ${optIndex + 1}`}
                    noLabel
                  />
                  </div>
                  {currentQuestion.options.length > 1 && (
                    <button 
                      onClick={() => removeOption(optIndex)}
                      className="ml-2 text-red-500 hover:text-red-700"
                    >
                      <FaRegTrashAlt size={14} />
                    </button>
                  )}
                </div>
              ))}
              
            </div>
          )}                 </div>
          <button
          onClick={addQuestion}
          className="mt-2 w-full  border border-[#1b5fc1] text-[#1b5fc1] py-2 px-4 rounded-md cursor-pointer"
        >
          Add Question
        </button>
        </div>
      )}

      {/* Save Template Toggle */}
      <div className='font-normal flex items-center gap-1 mt-5'>
        <Toggle 
          value={saveTemplate} 
          handleToggle={() => {
            setSaveTemplate(!saveTemplate)
          }} 
        />
        <p>Save form as Template</p>
      </div>
    </div>
  );
};

export default Questionnaire;