import React, { useEffect, useRef } from 'react';
import { HiOutlineTrash } from "react-icons/hi2";
import { MdOutlineCancel } from "react-icons/md";
import { GoPencil } from "react-icons/go";
import { FiFileText } from "react-icons/fi";
import Modal from '../../../../ui/Modal';
const JobActionsModal = ({ jobCode, isOpen, anchorEl, onClose, showConfirmedModal, onEdit, closeConfirmedModal, confirmModal, onDelete, jobTitle}) => {

  const modalRef = useRef(null);
  

   // Close modal when clicking outside
   useEffect(() => {
    const handleClickOutside = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target) && e.target !== anchorEl) {
        onClose();
      }
    };
    if (isOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, anchorEl, onClose]);


  // Calculate position relative to the dots button
  const anchorRect = anchorEl.getBoundingClientRect();  

  return (
    <>
      
    {!confirmModal && <div
      ref={modalRef}
      className="absolute bg-white shadow-lg rounded-md p-2 z-50 border border-gray-100"
      style={{
        top: `${anchorRect.bottom + 4}px`, 
        right: "30px",
        minWidth: '160px',
      }}
    >
      <ul className="space-y-1 text-[#292929] text-[14px]">
        <li>
          <button className="w-full flex items-center cursor-pointer gap-2 p-2 hover:bg-gray-50 rounded">
            <FiFileText/>
            <span>View Application</span>
          </button>
        </li>
        <li>
          <button className="w-full flex items-center cursor-pointer gap-2 p-2 hover:bg-gray-50 rounded" onClick={onEdit}>
            <GoPencil/>
            <span>Edit Application</span>
          </button>
        </li>
        <li>
          <button className="w-full flex items-center cursor-pointer gap-2 p-2 hover:bg-gray-50 rounded" onClick={onClose}>
            <MdOutlineCancel/>
            <span>Unpublish Application</span>
          </button>
        </li>
        <li>
          <button
              className="w-full flex items-center cursor-pointer gap-2 p-2 hover:bg-red-50 text-[#EB4335]"
              onClick={showConfirmedModal}
          >
            <HiOutlineTrash color='#eb4335'/>
            <span>Delete Application</span>
          </button>
        </li>
      </ul>
      </div>}
      {confirmModal && <Modal contW={"w-[450px]"} headerIcon={"trash"} headTitle={"Delete Job"} headBgColor={"bg-[#eb4335]"} contH={"h-[230px]"}><p className="border-b border-gray-200 py-[20px] px-[24px] text-[16px] font-light">Are you sure you want to delete this Job post <span className="font-normal">"{jobTitle}"</span> ? This action cannot be undone. </p>
      <div className="flex py-2 px-3 gap-6 border-t border-gray-300 justify-end"><button onClick={() => onDelete(jobCode)} className='text-[#292929]  py-2 px-10 block rounded-sm cursor-pointer hover:border hover:border-gray-200'>Yes, I'm sure</button>
              <button className='text-center py-2 px-5 text-[#EB4335] bg-[#FDECEB] rounded-sm block transition cursor-pointer hover:text-[#FDECEB] hover:bg-[#EB4335]' onClick={closeConfirmedModal}>Cancel</button>
              
              </div>
      </Modal>}
    </>
  );
};

export default JobActionsModal;