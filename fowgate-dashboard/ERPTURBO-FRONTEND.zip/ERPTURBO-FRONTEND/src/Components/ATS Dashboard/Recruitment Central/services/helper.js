function getInitials(candidateName) {
    return candidateName.split(" ").map(word=>word[0]).join("").toUpperCase()
}

function formatDate(dateString) {
    const options = { day: 'numeric', month: 'short', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-UK', options);
  }
  


export { getInitials, formatDate };