import React from 'react';
import Pagination from './Pagination';
import HiredTableRow from './HiredTableRow';


const HiredTable = ({ candidates, setIsEdit, setSelectedJob }) => {
    
    return (<>
      {candidates.map((candidate, i) => <HiredTableRow key={i} candidate={candidate} setIsEdit={setIsEdit} setSelectedJob={setSelectedJob} />   
      )}
        {candidates.length>=10 && <Pagination/>}
    </>
    );
};
  

  
export default HiredTable;