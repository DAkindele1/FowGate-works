export const candidatesData = [
  {
    id: 1,
    name: "Samuel Adeyemi",
    position: "Software Engineer",
    role: "UI/UX Designer",
    location: "Lagos, Nigeria",
    match: "75% Good Match",
    experience: "3 Years",
    phone: "+234-810-589-4695",
    availability: "Full-Time",
    applicationDate: "27 Nov, 2024",
    about:
      "A passionate UI/UX designer dedicated to creating intuitive and visually engaging digital experiences. I'm known for creating interfaces that delight users, solve problems, and simplify ideas into seamless, accessible designs that delight users. From wireframes to prototypes, my focus is on crafting interfaces that are not only functional but also inspiring. Let's make design work for people!",
    skills: [
      "Product Design",
      "Wireframing",
      "UI/UX Design",
      "Usability Studies",
      "Prototyping",
      "Design System",
      "Motion Design",
      "Illustration",
      "Documentation",
    ],
    resume: {
      name: "Samuel_Adeyemi_Resume.pdf",
      size: "280KB",
    },
    answers: [
      {
        question: "How did you hear about this job?",
        answer: "LinkedIn",
      },
      {
        question: "What is your favorite design tool and why?",
        answer: "Figma, because it's versatile and great for collaboration.",
      },
      {
        question: "Describe a challenging design project you worked on",
        answer:
          "I worked on redesigning a complex e-commerce platform. I started by conducting user interviews, created personas, and used iterative prototyping to refine the design until it met user needs and business goals. Developing a design system for a client with inconsistent branding. I analyzed their existing assets, proposed cohesive guidelines, and ensured team adoption through workshops. A last-minute UI overhaul required before a product launch. I prioritized key screens, focused on simplicity, and collaborated closely with developers to meet the deadline.",
      },
      {
        question: "What is your favorite design tool and why?",
        answer: "Figma, because it's versatile and great for collaboration.",
      },
      {
        question: "What is your favorite design tool and why?",
        answer: "Figma, because it's versatile and great for collaboration.",
      },
    ],
    avatar: "/placeholder.svg?height=40&width=40",
    status: "ALL CANDIDATES",
    honors: "BSc in Computer Science",
    interviewDate: "3 Nov, 2024",
    interviewTime: "9:00 PM",
    portfolio: "Samuel Adeyemi Portfolio",
  },
  {
    id: 2,
    name: "Ahmed Bello",
    position: "Software Engineer",
    role: "Frontend Developer",
    location: "Abuja, Nigeria",
    match: "65% Good Match",
    experience: "4 Years",
    phone: "+234-703-456-7890",
    availability: "Full-Time",
    applicationDate: "25 Nov, 2024",
    about:
      "Frontend developer with a passion for creating responsive, accessible, and performant web applications. I specialize in React, Next.js, and modern JavaScript frameworks. I believe in writing clean, maintainable code and creating user experiences that are both beautiful and functional.",
    skills: [
      "React",
      "Next.js",
      "TypeScript",
      "JavaScript",
      "CSS/SCSS",
      "Responsive Design",
      "Performance Optimization",
      "Accessibility",
      "Testing",
    ],
    resume: {
      name: "Ahmed_Bello_Resume.pdf",
      size: "310KB",
    },
    answers: [
      {
        question: "How did you hear about this job?",
        answer: "Twitter",
      },
      {
        question: "What is your favorite frontend framework and why?",
        answer:
          "React, because of its component-based architecture and the vibrant ecosystem.",
      },
      {
        question: "Describe a challenging project you worked on",
        answer:
          "I built a real-time dashboard for a fintech application that needed to handle large amounts of data while maintaining performance. I implemented virtualization and optimized rendering to ensure smooth user experience.",
      },
    ],
    avatar: "/placeholder.svg?height=40&width=40",
    status: "ALL CANDIDATES",
    honors: "BSc in Computer Science",
    interviewDate: "3 Nov, 2024",
    interviewTime: "9:00 PM",
  },
  {
    id: 3,
    name: "Grace Nwosu",
    position: "Software Engineer",
    role: "Backend Developer",
    location: "Port Harcourt, Nigeria",
    match: "55% Satisfactory",
    experience: "2 Years",
    phone: "+234-815-123-4567",
    availability: "Contract",
    applicationDate: "22 Nov, 2024",
    about:
      "Backend developer with experience in building scalable APIs and microservices. I'm proficient in Node.js, Express, and database design. I enjoy solving complex problems and optimizing system performance. My goal is to build robust backend systems that power exceptional user experiences.",
    skills: [
      "Node.js",
      "Express",
      "MongoDB",
      "PostgreSQL",
      "API Design",
      "Microservices",
      "Docker",
      "AWS",
      "Testing",
    ],
    resume: {
      name: "Grace_Nwosu_Resume.pdf",
      size: "295KB",
    },
    answers: [
      {
        question: "How did you hear about this job?",
        answer: "Company website",
      },
      {
        question: "What is your preferred backend technology and why?",
        answer:
          "Node.js, because of its non-blocking I/O model and the ability to use JavaScript across the stack.",
      },
      {
        question: "Describe a challenging project you worked on",
        answer:
          "I designed and implemented a payment processing system that needed to handle thousands of transactions per minute while ensuring data consistency and security.",
      },
    ],
    avatar: "/placeholder.svg?height=40&width=40",
    status: "ALL CANDIDATES",
    honors: "BSc in Computer Science",
    interviewDate: "3 Nov, 2024",
    interviewTime: "9:00 PM",
  },
  {
    id: 4,
    name: "Jane Smith",
    position: "Software Engineer",
    role: "Full Stack Developer",
    location: "Accra, Ghana",
    match: "45% Mismatch",
    experience: "5 Years",
    phone: "+233-24-123-4567",
    availability: "Remote",
    applicationDate: "20 Nov, 2024",
    about:
      "Full stack developer with expertise in both frontend and backend technologies. I enjoy building complete solutions from database design to user interfaces. I'm passionate about creating scalable, maintainable applications that solve real-world problems.",
    skills: [
      "JavaScript",
      "TypeScript",
      "React",
      "Node.js",
      "Python",
      "Django",
      "SQL",
      "NoSQL",
      "DevOps",
    ],
    resume: {
      name: "Jane_Smith_Resume.pdf",
      size: "320KB",
    },
    answers: [
      {
        question: "How did you hear about this job?",
        answer: "Referral from a colleague",
      },
      {
        question: "What is your approach to full stack development?",
        answer:
          "I believe in choosing the right tool for the job and maintaining a balance between frontend and backend concerns. I focus on creating cohesive systems where both sides work together seamlessly.",
      },
      {
        question: "Describe a challenging project you worked on",
        answer:
          "I built an e-learning platform that needed to handle video streaming, user authentication, payment processing, and content management. I designed a modular architecture that allowed for easy scaling and maintenance.",
      },
    ],
    avatar: "/placeholder.svg?height=40&width=40",
    status: "ALL CANDIDATES",
    honors: "BSc in Computer Science",
    interviewDate: "3 Nov, 2024",
    interviewTime: "9:00 PM",
  },
  {
    id: 5,
    name: "Daniel Okafor",
    position: "Software Engineer",
    role: "UI/UX Designer",
    location: "Lagos, Nigeria",
    match: "70% Good Match",
    experience: "3 Years",
    phone: "+234-810-123-4567",
    availability: "Full-Time",
    applicationDate: "26 Nov, 2024",
    about:
      "UI/UX designer with a passion for creating beautiful and functional interfaces. I focus on user-centered design and creating experiences that are both intuitive and delightful.",
    skills: [
      "UI/UX Design",
      "Wireframing",
      "Prototyping",
      "User Research",
      "Figma",
      "Adobe XD",
      "Sketch",
      "Design Systems",
    ],
    resume: {
      name: "Daniel_Okafor_Resume.pdf",
      size: "290KB",
    },
    answers: [
      {
        question: "How did you hear about this job?",
        answer: "LinkedIn",
      },
      {
        question: "What is your favorite design tool and why?",
        answer:
          "Figma, because of its collaborative features and powerful prototyping capabilities.",
      },
      {
        question: "Describe a challenging design project you worked on",
        answer:
          "I redesigned a complex financial app that had poor user engagement. By conducting user research and iterative testing, I was able to create a more intuitive interface that increased user engagement by 40%.",
      },
    ],
    avatar: "/placeholder.svg?height=40&width=40",
    status: "ALL CANDIDATES",
    honors: "BSc in Computer Science",
    interviewDate: "3 Nov, 2024",
    interviewTime: "9:00 PM",
  },
  {
    id: 6,
    name: "Linda Eze",
    position: "Software Engineer",
    role: "UI/UX Designer",
    location: "Lagos, Nigeria",
    match: "80% Good Match",
    experience: "4 Years",
    phone: "+234-812-345-6789",
    availability: "Full-Time",
    applicationDate: "28 Nov, 2024",
    about:
      "UI/UX designer with a background in psychology. I combine my understanding of human behavior with design principles to create interfaces that are not only beautiful but also intuitive and user-friendly.",
    skills: [
      "UI/UX Design",
      "User Research",
      "Wireframing",
      "Prototyping",
      "Usability Testing",
      "Design Systems",
      "Figma",
      "Adobe Creative Suite",
    ],
    resume: {
      name: "Linda_Eze_Resume.pdf",
      size: "300KB",
    },
    answers: [
      {
        question: "How did you hear about this job?",
        answer: "Company website",
      },
      {
        question: "What is your favorite design tool and why?",
        answer:
          "Figma, because it allows for seamless collaboration and has a great community of plugins and resources.",
      },
      {
        question: "Describe a challenging design project you worked on",
        answer:
          "I worked on redesigning a healthcare app that needed to be accessible to users of all ages and abilities. I conducted extensive user research and testing to ensure the design was inclusive and easy to use for everyone.",
      },
    ],
    avatar: "/placeholder.svg?height=40&width=40",
    status: "ALL CANDIDATES",
    honors: "BSc in Computer Science",
    interviewDate: "3 Nov, 2024",
    interviewTime: "9:00 PM",
  },
];
