import React, { useState, useRef, useEffect } from 'react'
import {CheckCircleIcon, DotsThreeVerticalIcon,  DownloadSimpleIcon,  LinkIcon,  StarIcon} from '@phosphor-icons/react'
import { formatDate } from '../services/helper';
import Answer from './Selected Candidate Details/Answer';
import Application from './Selected Candidate Details/Application';
import SelectedCandidateAction from './Selected Candidate Details/SelectedCandidateAction';
import { hiringAPI, shortlistApplication } from '../services/api_recruitment_central';
import toast from 'react-hot-toast';
import EmptyList from '../../../../ui/EmptyTable';
import Notes from './Selected Candidate Details/Notes';
import CandidateAnalysis from './Selected Candidate Details/CandidateAnalysis';
import InterviewAssessment from './Selected Candidate Details/InterviewAssessmentTab';
import InfoPill from '../../../../ui/InfoPill';
import Percentage from '../../../../ui/Percentage';

export default function CandidateDetails({ selectedCandidate, onFavoriteToggle, onTalentToggle, onShortlistToggle, mainTab, candidatesData, currentTab}) {
  
  const [activeTab, setActiveTab] = useState("Application");
    const [showActionMenu, setShowActionMenu] = useState(false);
  const actionMenuRef = useRef();


  


  useEffect(() => {
    const handleClickOutside = (event) => {
      if (actionMenuRef.current && !actionMenuRef.current.contains(event.target)) {
        // Check if the click was on the dots button
        const dotsButton = document.querySelector('.dots-button');
        if (!dotsButton || !dotsButton.contains(event.target)) {
          setShowActionMenu(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const existCandidate = candidatesData.some(item => item._id === selectedCandidate._id) ? selectedCandidate : candidatesData[0]
  
  

  useEffect(() => {
    currentTab === "INTERVIEW CENTRAL" && mainTab !== "talentPool"  ? setActiveTab("Interview Assessment") : setActiveTab("Application")
  }, [currentTab, existCandidate, mainTab])
  
  const handleShortlist = async (applicationCode, check) => {
    const mode = check ? "unshortlist" : "shortlist"
    
    try {
      await shortlistApplication(applicationCode, mode);
      toast.success(`Candidate ${mode === "shortlist" ? "shortlisted" : "removed from shortlist"}`);
      onShortlistToggle(applicationCode, check);  
    } catch (err) {
      toast.error(err.message);
    }
  }; 

  
  const handleHiring = async (applicationCode)=>{
    try {
      await hiringAPI(applicationCode, "hire");
      toast.success(`Candidate hired`);
    } catch (err) {
      toast.error(err.message);
    }
  }

  return (
    candidatesData.length === 0 ?
      
      // EMPTY DISPLAY
      <EmptyList>{mainTab === "talentPool" ? <div>
      <p className='font-bold text-black'>No Candidate in Talent Pool</p>
      <p className='font-light text-sm'>Shortlist or Mark a candidate as Favourite to appear here</p>
    </div> : currentTab === "SHORTLISTED" ? <p className='font-bold text-black'>No Shortlisted Candidate </p> : currentTab === "ALL CANDIDATES" ? <p className='font-bold text-black'>No Candidate Found</p> : ""}</EmptyList> :
      
      // MAIN DISPLAY
    <div className="w-2/3 bg-white rounded-lg border border-gray-300  px-4 relative">
    {/* Candidate Header */}
    <div className=" py-1.5 flex items-center justify-between">
      <div className="flex items-center">
        <div className="text-[#1b5fc1] font-medium rounded-full h-[45px] w-[45px] flex items-center justify-center bg-[#E8EFF9] mr-3">
          <span className= "flex items-center justify-center">
          {existCandidate.firstname[0]+existCandidate.lastname[0]}
          </span>
        </div>
        <div>
          <h3 className="font-medium text-[20px] text-gray-900 capitalize flex gap-1">
                                        <div>{existCandidate.firstname} </div>
                                        <div>{existCandidate.lastname}</div>
                                        
                                        
                                    </h3>
          <div className="text-sm text-gray-500 flex gap-1 pt-0.5">
            <img
              src="/assets/img/location.png"
              alt="location icon"
              className="w-4 h-4"
            />
            <p>{existCandidate.location}</p>
          </div>
        </div>
      </div>
      <div className="flex items-center space-x-2">
      <div className="cursor-pointer" onClick={() => handleShortlist(existCandidate.application_code, existCandidate.is_shortlisted)}>
  {!existCandidate.is_shortlisted ? (
   <div className="px-3 py-0.5 border border-gray-200 rounded-md flex items-center gap-1 h-[30px]
   hover:bg-gray-50 hover:border-gray-300 hover:shadow-xs
   active:bg-gray-100 active:scale-[0.98]
   transition-all duration-150 ease-in-out cursor-pointer">
<img 
src="/assets/img/shortlist-icon.png" 
alt="shortlist icon" 
className="hover:scale-105 transition-transform duration-150"
/>
<span className="text-[14px] text-[#292929] font-light hover:text-[#1a1a1a]">
Shortlist
</span>
</div>
  ) : (
    <div className="text-[#EB8A00] bg-[#FFF1DD] text-[14px] flex h-[30px] items-center gap-2 px-1.5 py-1 rounded-sm
               hover:bg-[#FFE5C2] hover:text-[#D97F00] hover:shadow-sm hover:scale-[1.02] 
               transition-all duration-200 ease-in-out cursor-pointer">
  <CheckCircleIcon className="hover:scale-110 transition-transform duration-200" /> 
  <p>Shortlisted</p>
</div>
  )}
</div>
        <button 
  className="p-1 rounded-md border border-gray-200"
  onClick={() => onFavoriteToggle(existCandidate.application_code, existCandidate.is_favorite)}
>
  <StarIcon 
    size={20}
    color={existCandidate.is_favorite ? "#EB8A00" : undefined}
    weight={existCandidate.is_favorite ? "fill" : "light"}
  />
</button>
          <div className="relative" ref={actionMenuRef}>
      <button
        className="dots-button p-1.5 hover:bg-gray-100 rounded-md cursor-pointer"
        onClick={() => setShowActionMenu(!showActionMenu)}
      >
        <DotsThreeVerticalIcon weight="bold" />
      </button>

      {showActionMenu && (
        <SelectedCandidateAction 
          candidateData={existCandidate} 
                setShowActionMenu={setShowActionMenu}
                  onFavoriteToggle={onFavoriteToggle}
                  onTalentToggle={onTalentToggle}
        />
      )}
    </div>
       
      </div>
    </div>

    <div className=" my-5 flex items-center gap-6">
      {/* MATCH */}
      <InfoPill>
        <div className="rounded-full flex items-center justify-center">
          <img
            src="/assets/img/user-check-01.png"
            alt="User Check Icon"
            className="w-4 h-4 "
          />
        </div>
            <div className="text-[14px] font-normal">
              <Percentage number={existCandidate.match} />
              Exam Score
        </div>
      </InfoPill>

      {/* BRIEFCASE */}
      <InfoPill>
        <div className="rounded-full flex items-center justify-center">
          <img
            src="/assets/img/briefcase-01.png"
            alt="Brief Case Icon"
            className="w-4 h-4 "
          />
        </div>
        <div>
          <p className="text-[14px] font-normal">
            {existCandidate.experience ? existCandidate.experience : '— year'}
          </p>
        </div>
      </InfoPill>

      {/* PHONE */}
      <InfoPill>
        <div className="rounded-full flex items-center justify-center">
          <img src="/assets/img/phone.png" alt="Phone Icon" className="w-4 h-4 " />
        </div>
        <div>
          <p className=" text-[14px] font-normal">
            {existCandidate.phone_num}
          </p>
        </div>
      </InfoPill>
    </div>

        {currentTab === "INTERVIEW CENTRAL" && mainTab !== "talentPool" ? <div className='h-[83px] flex items-center gap-6'>

          {/* RESUME */}
          <div className='w-full h-full flex flex-col justify-between cursor-pointer'>
            <p className="font-medium text-[16px]">Resume</p>
                          <div className="flex items-center border rounded-[5px] p-2 h-[53px] gap-2 border-[#707070]">
                            <div className="flex items-center justify-center">
                              <img src="/assets/img/pdf.png" alt="PDF Icon" className='h-[32px] w-[32px] '/>
                            </div>
              <div>
                <p className='text-[#292929] text-[14px]'>{existCandidate.firstname} {existCandidate.lastname}_Resume.pdf</p>
                <p className="text-xs text-[#707070]">{"No size"}</p>
                            </div>
                          </div>
          </div>

          {/* PORTFOLIO */}
          <div className='w-full h-full flex flex-col justify-between '>
            <p className="font-medium text-[16px]">Portfolio</p>
                          <div className="flex items-center border rounded-[5px] p-2 h-[53px] gap-2 border-[#707070]">
                            <div className="h-8 w-8 flex items-center justify-center text-[#292929]"><LinkIcon size={20}/></div>
              <a className=' text-[14px] underline ' href='#'>{existCandidate.firstname} {existCandidate.lastname} Portfolio</a>
                          </div>
          </div>
    </div>:<div className="flex justify-between items-center border border-gray-200 rounded-md">
      <div className="p-4">
        <p className="text-[14px] text-[#707070] font-normal">Role</p>
        <p className="font-normal text-[14px] text-[#292929]">
          {existCandidate.role}
        </p>
      </div>
      <div className="p-4">
        <p className="text-[14px] text-[#707070] font-normal">
          Availability
        </p>
        <p className="font-normal text-[14px] text-[#292929]">
          {existCandidate.availability? existCandidate.availability: '—'}
        </p>
      </div>
      <div className="p-4">
        <p className="text-[14px] text-[#707070] font-normal">
          Application Date
        </p>
        <p className="font-normal text-[14px] text-[#292929]">
            {formatDate(existCandidate.created_at)}
        </p>
      </div>
    </div>}

        {currentTab === "INTERVIEW CENTRAL" && mainTab !== "talentPool"  ? <div className='mt-5 flex flex-col gap-5'>
          <div className="flex border-b border-gray-200 mb-4 space-x-6">
        <button
          className={` w-fit pb-2 cursor-pointer ${
            activeTab === "Interview Assessment"
              ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
              : "text-[#707070] font-light text-[16px] hover:text-gray-700"
          }`}
          onClick={() => setActiveTab("Interview Assessment")}
        >
          1V1 Interview Assessment
        </button>
        <button
          className={` w-fit pb-2 cursor-pointer ${
            activeTab === "candAnalysis"
              ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
              : "text-[#707070] font-light text-[16px] hover:text-gray-700"
          }`}
          onClick={() => setActiveTab("candAnalysis")}
        >
          Candidate Analysis
        </button>
        <button
          className={` w-fit pb-2 cursor-pointer ${
            activeTab === "Notes"
              ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
              : "text-[#707070] font-light text-[16px] hover:text-gray-700"
          }`}
          onClick={() => setActiveTab("Notes")}
        >
          Notes
        </button>
      </div>
    </div>: <div className="p-4 mt-4">
      <div className="flex border-b border-gray-200 mb-4 space-x-6">
        <button
          className={` w-fit pb-2 cursor-pointer ${
            activeTab === "Application"
              ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
              : "text-[#707070] font-light text-[16px] hover:text-gray-700"
          }`}
          onClick={() => setActiveTab("Application")}
        >
          Application
        </button>
        <button
          className={` w-fit pb-2 cursor-pointer ${
            activeTab === "Answers"
              ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
              : "text-[#707070] font-light text-[16px] hover:text-gray-700"
          }`}
          onClick={() => setActiveTab("Answers")}
        >
          Answers
        </button>
      </div>

            
        </div>}
        
        <div className="mb-[78px] px-5">
        {activeTab === "Application" ? (
        <Application candidateData={existCandidate}/>
      ) : activeTab === "Answers" ? (
        <Answer candidateData={existCandidate}/>
      ) : activeTab === "candAnalysis" ? (
        <CandidateAnalysis candidateData={existCandidate}/>
      ) : activeTab === "Interview Assessment" ? (
        <InterviewAssessment candidateData={existCandidate}/>
        ) : <Notes />}
      </div>
        
        {currentTab === "INTERVIEW CENTRAL" && mainTab !== "talentPool"  &&  <div className=" absolute bg-white h-[78px] w-fit bottom-0 right-2 flex items-center justify-end"><button className={"w-[140px] h-[44px] px-3 py-2.5 bg-[#E8EFF9] text-[#1B5FC1] text-[14px] "} onClick={()=> handleHiring(existCandidate.application_code, "hire")}>Hire Candidate</button></div> }
  </div>
  )
}
