import React, { useState, useEffect } from "react";
import {
  Modal,
  Box,
  Typography,
  TextField,
  IconButton,
  Select,
  MenuItem,
  InputAdornment,
  Fab,
  Switch,
  CircularProgress,
  Button,
  Chip,
} from "@mui/material";
import {
  X,
  Search,
  ChevronDown,
  ArrowLeft,
  ChevronUp,
  Trash2,
  Plus,
  Edit,
  AlertCircle,
} from "lucide-react";

import createJobIcon from "../../../assets/img/create-job-icon.png";
import sparkleIcon from "../../../assets/img/sparkle.png";

// Update the component props to accept a job for editing and an isEditing flag
function CreateJobModal({
  isOpen,
  onClose,
  jobToEdit = null,
  isEditing = false,
}) {
  const [currentStep, setCurrentStep] = useState(1);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPlatformDropdown, setShowPlatformDropdown] = useState(false);

  // Available advertising platforms
  const availablePlatforms = [
    "LinkedIn",
    "Jobberman",
    "Remote.io",
    "MyJobMag",
    "Company Website",
    "Indeed",
    "Glassdoor",
  ];

  // Add error handling for API responses
  const [apiError, setApiError] = useState(null);

  // Initialize formData with default values or values from jobToEdit if provided
  const [formData, setFormData] = useState({
    jobTitle: "",
    jobCode: "",
    industry: "",
    availability: "",
    jobType: "",
    salaryCurrency: "",
    description: "",
    salaryRange: "",
    requireResume: true,
    requireCoverLetter: true,
    requirePortfolio: true,
    hiringTeam: [],
    audience: ["public", "internal", "check"], //assume public audience
    requiredSkills: [],
    qualifications: [],
    experience: "",
    addAsTemplate: false,
    advertisePlatforms: [], // Changed from advertisePlatform to advertisePlatforms (array)
    companyCode: "COM_202", // Add default company code
  });

  // Update the questions state to include placeholder for text inputs
  const [questions, setQuestions] = useState([
    {
      id: 1,
      question: "What's your years of experience?",
      expanded: false,
      type: "dropdown",
      placeholder: "",
      options: [
        { option: "0-1 years", is_selected: false },
        { option: "2-4 years", is_selected: false },
        { option: "5+ years", is_selected: false },
      ],
      answer: "",
      isRequired: false,
    },
  ]);

  // Available team members
  const [availableTeamMembers, setAvailableTeamMembers] = useState([
    { id: "1", name: "Olanrewaju Joshua", type: "name" },
    {
      id: "2",
      name: "michaeljohnson@gmail.com",
      type: "email",
      email: "michaeljohnson@gmail.com",
    },
    { id: "3", name: "Ava Carter", type: "name" },
    { id: "4", name: "Human Resources", type: "department" },
    { id: "5", name: "Finance", type: "department" },
    { id: "6", name: "Marketing", type: "department" },
    { id: "7", name: "Operations", type: "department" },
    { id: "8", name: "Information Technology", type: "department" },
    { id: "9", name: "Product Development", type: "department" },
    { id: "10", name: "Research and Development", type: "department" },
    { id: "11", name: "Legal", type: "department" },
  ]);

  // Selected team members
  const [selectedTeamMembers, setSelectedTeamMembers] = useState([]);

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedQuestion, setSelectedQuestion] = useState(null);

  // Effect to populate form data when editing a job
  useEffect(() => {
    if (isEditing && jobToEdit) {

      // Map the job data to our form structure
      setFormData({
        jobTitle: jobToEdit.title || "",
        jobCode: jobToEdit.job_code || "",
        industry: jobToEdit.industry || "",
        availability: jobToEdit.availability || "",
        jobType: jobToEdit.job_type || "",
        salaryCurrency: jobToEdit.currency || "",
        description: jobToEdit.description || "",
        salaryRange: jobToEdit.salary_range || "",
        requireResume:
          jobToEdit.upload_resume !== undefined
            ? jobToEdit.upload_resume
            : true,
        requireCoverLetter:
          jobToEdit.cover_letter !== undefined ? jobToEdit.cover_letter : true,
        requirePortfolio:
          jobToEdit.portfolio !== undefined ? jobToEdit.portfolio : true,
        audience: jobToEdit.audience || ["public"],
        requiredSkills: jobToEdit.required_skills || [],
        qualifications: jobToEdit.qualifications || [],
        experience: jobToEdit.experience || "",
        addAsTemplate: jobToEdit.add_as_template || false,
        advertisePlatforms: jobToEdit.advertise_platforms || [],
        companyCode: jobToEdit.company_code || "COM_202",
      });

      // Set questions if available
      if (jobToEdit.questions && jobToEdit.questions.length > 0) {
        setQuestions(
          jobToEdit.questions.map((q, index) => ({
            id: index + 1,
            question: q.question || "",
            expanded: false,
            type: q.type || "dropdown",
            placeholder: "",
            options: Array.isArray(q.options) ? q.options : [],
            answer: q.answer || "",
            isRequired: q.is_required || false,
          }))
        );
      } else {
        // Set default question if no questions are available
        setQuestions([
          {
            id: 1,
            question: "What's your years of experience?",
            expanded: false,
            type: "dropdown",
            placeholder: "",
            options: [
              { option: "0-1 years", is_selected: false },
              { option: "2-4 years", is_selected: false },
              { option: "5+ years", is_selected: false },
            ],
            answer: "",
            isRequired: false,
          },
        ]);
      }

      // Set hiring team if available
      if (jobToEdit.hiring_team && jobToEdit.hiring_team.length > 0) {
        // Map hiring team to the format expected by the component
        const mappedTeam = jobToEdit.hiring_team.map((member, index) => ({
          id: `edit-${index}`,
          name: member.value || "",
          type: member.type || "name",
          email: member.type === "email" ? member.value : undefined,
        }));
        setSelectedTeamMembers(mappedTeam);
      } else {
        setSelectedTeamMembers([]);
      }
    }
  }, [isEditing, jobToEdit]);

  const handleNext = () => {
    setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleToggleChange = (field) => (event) => {
    setFormData({
      ...formData,
      [field]: event.target.checked,
    });
  };

  // Update the toggleQuestionExpand function to toggle expansion without hiding other questions
  const toggleQuestionExpand = (id) => {
    setQuestions(
      questions.map((q) => ({
        ...q,
        expanded: q.id === id ? !q.expanded : q.expanded,
      }))
    );
  };

  const handleDeleteQuestion = (id) => {
    setQuestions(questions.filter((q) => q.id !== id));
  };

  // Update the handleQuestionChange function to handle type changes and ensure options are properly initialized
  const handleQuestionChange = (id, field, value) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === id) {
          // If changing question type, ensure proper options structure
          if (field === "type") {
            const needsOptions = ["dropdown", "mult", "check"];
            const updatedQuestion = { ...q, [field]: value };

            // Initialize options if switching to a type that needs them
            if (
              needsOptions.includes(value) &&
              (!q.options || q.options.length === 0)
            ) {
              updatedQuestion.options = [
                { option: "Option 1", is_selected: false },
                { option: "Option 2", is_selected: false },
              ];
            }

            return updatedQuestion;
          }
          return { ...q, [field]: value };
        }
        return q;
      })
    );

    if (selectedQuestion && selectedQuestion.id === id) {
      if (field === "type") {
        const needsOptions = ["dropdown", "mult", "check"];
        const updatedSelectedQuestion = { ...selectedQuestion, [field]: value };

        // Initialize options if switching to a type that needs them
        if (
          needsOptions.includes(value) &&
          (!selectedQuestion.options || selectedQuestion.options.length === 0)
        ) {
          updatedSelectedQuestion.options = [
            { option: "Option 1", is_selected: false },
            { option: "Option 2", is_selected: false },
          ];
        }

        setSelectedQuestion(updatedSelectedQuestion);
      } else {
        setSelectedQuestion({ ...selectedQuestion, [field]: value });
      }
    }
  };

  const handleOptionChange = (questionId, optionIndex, value) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === questionId) {
          const newOptions = [...q.options];
          newOptions[optionIndex] = {
            ...newOptions[optionIndex],
            option: value,
          };
          return { ...q, options: newOptions };
        }
        return q;
      })
    );
  };

  const handleAddOption = (questionId) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === questionId) {
          return {
            ...q,
            options: [...q.options, { option: "", is_selected: false }],
          };
        }
        return q;
      })
    );
  };

  const handleDeleteOption = (questionId, optionIndex) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === questionId) {
          const newOptions = q.options.filter(
            (_, index) => index !== optionIndex
          );
          return { ...q, options: newOptions };
        }
        return q;
      })
    );
  };

  // Update the handleAddQuestion function to set appropriate default options based on question type
  const handleAddQuestion = () => {
    const newId = Math.max(...questions.map((q) => q.id), 0) + 1;
    const newQuestion = {
      id: newId,
      question: `Question ${newId}`,
      expanded: true,
      type: "dropdown",
      placeholder: "",
      options: [
        { option: "Option 1", is_selected: false },
        { option: "Option 2", is_selected: false },
      ],
      answer: "",
      isRequired: false,
    };
    setQuestions([...questions, newQuestion]);
  };

  const toggleTeamMember = (member) => {
    const isSelected = selectedTeamMembers.some((m) => m.id === member.id);

    if (isSelected) {
      setSelectedTeamMembers(
        selectedTeamMembers.filter((m) => m.id !== member.id)
      );
    } else {
      setSelectedTeamMembers([...selectedTeamMembers, member]);
    }
  };

  // Handle platform selection
  const handlePlatformSelect = (platform) => {
    if (!formData.advertisePlatforms.includes(platform)) {
      setFormData({
        ...formData,
        advertisePlatforms: [...formData.advertisePlatforms, platform],
      });
    }
    setShowPlatformDropdown(false);
  };

  // Handle platform deletion
  const handleDeletePlatform = (platform) => {
    setFormData({
      ...formData,
      advertisePlatforms: formData.advertisePlatforms.filter(
        (p) => p !== platform
      ),
    });
  };

  // Fixed: Added proper filtering of team members
  const filteredTeamMembers = availableTeamMembers.filter(
    (member) =>
      member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (member.email &&
        member.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Update the preparePayload function to fix the validation errors
  const preparePayload = () => {
    // Replace the existing mapTeamMemberType function with this corrected version
    const mapTeamMemberType = (member) => {
      if (member.email) {
        return "email";
      } else if (member.type === "department") {
        return "department";
      } else {
        return "name";
      }
    };

    const mapQuestionType = (type) => {
      switch (type) {
        case "text":
          return "short";
        case "dropdown":
          return "dropdown";
        default:
          return type;
      }
    };

    return {
      title: formData.jobTitle || "",
      description: formData.description || "",
      hiring_team: selectedTeamMembers.map((member) => ({
        type: mapTeamMemberType(member),
        value: member.name,
      })),
      audience: formData.audience || [],
      job_code: formData.jobCode || "",
      industry: formData.industry || "",
      currency: formData.salaryCurrency || "",
      salary_range: formData.salaryRange || "",
      upload_resume: formData.requireResume,
      cover_letter: formData.requireCoverLetter,
      questions: questions.map((q) => ({
        type: mapQuestionType(q.type),
        question: q.question,
        options: q.options.map((opt) => ({
          option: opt.option,
          is_selected: opt.is_selected || false,
        })),
        answer: q.answer || "",
        is_required: q.isRequired || false,
      })),
      required_skills: Array.isArray(formData.requiredSkills)
        ? formData.requiredSkills
        : formData.requiredSkills
            .split(",")
            .map((s) => s.trim())
            .filter((s) => s),
      qualifications: formData.qualifications || [],
      experience: formData.experience || "",
      add_as_template: formData.addAsTemplate,
      company_code: formData.companyCode, // Add company_code to the payload
      advertise_platforms: formData.advertisePlatforms || [],
    };
  };

  const handlePublish = () => {
    setShowConfirmModal(true);
  };

  const handleConfirmPublish = async () => {
    setIsSubmitting(true);
    setApiError(null);

    // Ensure we're using the original job_code and company_code when editing
    const jobCode =
      isEditing && jobToEdit ? jobToEdit.job_code : formData.jobCode;
    const companyCode =
      isEditing && jobToEdit ? jobToEdit.company_code : formData.companyCode;

    // Create the payload with the original job_code and company_code
    const payload = preparePayload();

    // If editing, ensure the payload uses the original job_code and company_code
    if (isEditing && jobToEdit) {
      payload.job_code = jobToEdit.job_code;
      payload.company_code = jobToEdit.company_code;
    }


    const token = localStorage.getItem("userAccess");

    try {
      // Use different endpoint and method based on whether we're editing or creating
      const endpoint = isEditing
        ? `https://erpturbo-backend.onrender.com/api/ats/job_board/edit_job_listing?job_code=${jobCode}&company_code=${companyCode}`
        : "https://erpturbo-backend.onrender.com/api/ats/job_board/create_job_listing";

      const method = isEditing ? "PUT" : "POST";


      const response = await fetch(endpoint, {
        method: method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok) {
        setShowConfirmModal(false);
        setShowSuccessModal(true);
      } else {
        console.error(
          `Failed to ${isEditing ? "update" : "publish"} job:`,
          data
        );
        setApiError(data);
      }
    } catch (error) {
      console.error(
        `Error ${isEditing ? "updating" : "publishing"} job:`,
        error
      );
      setApiError({
        message: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuestionRequiredToggle = (questionId) => (event) => {
    setQuestions(
      questions.map((q) =>
        q.id === questionId ? { ...q, isRequired: event.target.checked } : q
      )
    );
  };

  const handleSaveAsDraft = () => {
    const payload = preparePayload();
    // Here you would send the payload to your API endpoint with draft status
    onClose();
  };

  const handleCloseSuccessModal = () => {
    setShowSuccessModal(false);
    onClose();
  };

  const getStepTitle = () => {
    switch (currentStep) {
      case 1:
        return "JOB OPENING";
      case 2:
        return "ADDITIONAL DETAILS";
      case 3:
        return "QUESTIONNAIRE";
      case 4:
        return "INVITE HIRING TEAM";
      case 5:
        return "PREVIEW & PUBLISH";
      default:
        return "";
    }
  };

  // Add a function to handle qualifications input
  const handleQualificationsChange = (e) => {
    setFormData({
      ...formData,
      qualifications: e.target.value
        .split(",")
        .map((qual) => qual.trim())
        .filter(Boolean),
    });
  };

  return (
    <>
      {/* Main Modal */}
      <Modal
        open={isOpen && !showConfirmModal && !showSuccessModal}
        onClose={onClose}
        sx={{ backdropFilter: "blur(4px)" }}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100%",
            height: "95%",
            maxWidth: "500px",
            bgcolor: "background.paper",
            borderRadius: 2,
            overflow: "hidden",
            maxHeight: "90vh",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* Modal Header */}
          <Box
            sx={{
              bgcolor: "#1B5FC1",
              color: "white",
              px: 2,
              py: 3,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              position: "relative",
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              {/* CALENDAR ICON */}
              <img
                src={"/assets/img/create-job-icon.png"}
                alt="Create Job Icon"
              />

              <Typography variant="h6" component="h2">
                {isEditing ? "Edit Job" : "Create Job"}
              </Typography>
            </Box>
            <IconButton onClick={onClose} sx={{ color: "white" }}>
              <X size={20} />
            </IconButton>
          </Box>

          {/* Progress Indicator */}
          <Box
            sx={{
              px: 2,
              py: 1.5,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid #e0e0e0",
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <CircularProgress
                  variant="determinate"
                  value={(currentStep / 5) * 100}
                  size={17}
                  thickness={8}
                  sx={{
                    color: "#1B5FC1",
                  }}
                />
              </Box>

              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                {currentStep > 1 && (
                  <IconButton
                    onClick={handleBack}
                    sx={{
                      color: "#1976d2",
                      p: 0.5,
                      mr: 0.5,
                    }}
                  >
                    <ArrowLeft size={16} />
                  </IconButton>
                )}
                <Typography variant="body2" sx={{ fontWeight: "medium" }}>
                  {" "}
                  {currentStep} / 5 - {getStepTitle()}
                </Typography>
              </Box>
            </Box>

            {(currentStep === 1 || currentStep === 3) && (
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 0.5,
                  cursor: "pointer",
                }}
              >
                <Typography variant="body2" color="text.secondary">
                  Choose from Template
                </Typography>
                <ChevronDown size={16} color="#666" />
              </Box>
            )}
          </Box>

          {/* Form Content - with fixed height to ensure footer stays at bottom */}
          <Box sx={{ p: 3, overflowY: "auto", flex: 1 }}>
            {currentStep === 1 ? (
              <form>
                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Job Title
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="Search title"
                    variant="outlined"
                    size="small"
                    value={formData.jobTitle}
                    onChange={(e) =>
                      setFormData({ ...formData, jobTitle: e.target.value })
                    }
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <Search size={16} color="#999" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Company Code
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="Enter company code"
                    variant="outlined"
                    size="small"
                    value={formData.companyCode}
                    onChange={(e) =>
                      setFormData({ ...formData, companyCode: e.target.value })
                    }
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Job Code
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="Enter job code"
                    variant="outlined"
                    size="small"
                    value={formData.jobCode}
                    onChange={(e) =>
                      setFormData({ ...formData, jobCode: e.target.value })
                    }
                    disabled={isEditing} // Disable job code editing when editing a job
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Industry
                  </Typography>
                  <Select
                    fullWidth
                    displayEmpty
                    size="small"
                    value={formData.industry}
                    onChange={(e) =>
                      setFormData({ ...formData, industry: e.target.value })
                    }
                    renderValue={(selected) => {
                      if (!selected) {
                        return (
                          <Typography color="text.secondary">Select</Typography>
                        );
                      }
                      return selected;
                    }}
                    IconComponent={() => <ChevronDown size={16} color="#666" />}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                      "& .MuiSelect-select": {
                        display: "flex",
                        alignItems: "center",
                      },
                      "& .MuiSvgIcon-root": {
                        right: 8,
                        position: "absolute",
                      },
                    }}
                  >
                    <MenuItem value="Advertising">Advertising</MenuItem>
                    <MenuItem value="E-commerce">E-commerce</MenuItem>
                    <MenuItem value="Education">Education</MenuItem>
                    <MenuItem value="Finance">Finance</MenuItem>
                    <MenuItem value="Healthcare">Healthcare</MenuItem>
                    <MenuItem value="Software Development">
                      Software Development
                    </MenuItem>
                  </Select>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Availability
                  </Typography>
                  <Select
                    fullWidth
                    displayEmpty
                    size="small"
                    value={formData.availability}
                    onChange={(e) =>
                      setFormData({ ...formData, availability: e.target.value })
                    }
                    renderValue={(selected) => {
                      if (!selected) {
                        return (
                          <Typography color="text.secondary">Select</Typography>
                        );
                      }
                      return selected;
                    }}
                    IconComponent={() => <ChevronDown size={16} color="#666" />}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                      "& .MuiSelect-select": {
                        display: "flex",
                        alignItems: "center",
                      },
                      "& .MuiSvgIcon-root": {
                        right: 8,
                        position: "absolute",
                      },
                    }}
                  >
                    <MenuItem value="Full-time">Full-time</MenuItem>
                    <MenuItem value="Part-time">Part-time</MenuItem>
                    <MenuItem value="Contract">Contract</MenuItem>
                  </Select>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Job Type
                  </Typography>
                  <Select
                    fullWidth
                    displayEmpty
                    size="small"
                    value={formData.jobType}
                    onChange={(e) =>
                      setFormData({ ...formData, jobType: e.target.value })
                    }
                    renderValue={(selected) => {
                      if (!selected) {
                        return (
                          <Typography color="text.secondary">Select</Typography>
                        );
                      }
                      return selected;
                    }}
                    IconComponent={() => <ChevronDown size={16} color="#666" />}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                      "& .MuiSelect-select": {
                        display: "flex",
                        alignItems: "center",
                      },
                      "& .MuiSvgIcon-root": {
                        right: 8,
                        position: "absolute",
                      },
                    }}
                  >
                    <MenuItem value="Remote">Remote</MenuItem>
                    <MenuItem value="Hybrid">Hybrid</MenuItem>
                    <MenuItem value="Onsite">Onsite</MenuItem>
                  </Select>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Salary Currency
                  </Typography>
                  <Select
                    fullWidth
                    displayEmpty
                    size="small"
                    value={formData.salaryCurrency}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        salaryCurrency: e.target.value,
                      })
                    }
                    renderValue={(selected) => {
                      if (!selected) {
                        return (
                          <Typography color="text.secondary">Select</Typography>
                        );
                      }
                      return selected;
                    }}
                    IconComponent={() => <ChevronDown size={16} color="#666" />}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                      "& .MuiSelect-select": {
                        display: "flex",
                        alignItems: "center",
                      },
                      "& .MuiSvgIcon-root": {
                        right: 8,
                        position: "absolute",
                      },
                    }}
                  >
                    <MenuItem value="AUD">AUD (Australian Dollar)</MenuItem>
                    <MenuItem value="BRL">BRL (Brazilian Real)</MenuItem>
                    <MenuItem value="CAD">CAD (Canadian Dollar)</MenuItem>
                    <MenuItem value="EUR">EUR (Euro)</MenuItem>
                    <MenuItem value="GBP">GBP (British Pound)</MenuItem>
                    <MenuItem value="NGN">Nigerian Naira (NGN)</MenuItem>
                  </Select>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Salary Range
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="e.g. 400,000 - 600,000/month"
                    variant="outlined"
                    size="small"
                    value={formData.salaryRange}
                    onChange={(e) =>
                      setFormData({ ...formData, salaryRange: e.target.value })
                    }
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Required Skills
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="e.g. Wireframing, Prototyping, Figma, Visual design"
                    variant="outlined"
                    size="small"
                    value={
                      Array.isArray(formData.requiredSkills)
                        ? formData.requiredSkills.join(", ")
                        : formData.requiredSkills
                    }
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        requiredSkills: e.target.value
                          .split(",")
                          .map((skill) => skill.trim()),
                      })
                    }
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Job Description
                  </Typography>
                  <TextField
                    fullWidth
                    multiline
                    rows={4}
                    placeholder="Enter job description"
                    variant="outlined"
                    size="small"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Experience Required
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="e.g. 2+ years of experience in UI/UX design"
                    variant="outlined"
                    size="small"
                    value={formData.experience}
                    onChange={(e) =>
                      setFormData({ ...formData, experience: e.target.value })
                    }
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5, fontWeight: "medium" }}
                  >
                    Qualifications
                  </Typography>
                  <TextField
                    fullWidth
                    placeholder="e.g. Bachelor's degree in Computer Science, 3+ years of experience"
                    variant="outlined"
                    size="small"
                    value={
                      Array.isArray(formData.qualifications)
                        ? formData.qualifications.join(", ")
                        : formData.qualifications
                    }
                    onChange={handleQualificationsChange}
                    sx={{
                      "& .MuiOutlinedInput-root": {
                        borderRadius: 1,
                      },
                    }}
                  />
                </Box>
              </form>
            ) : currentStep === 2 ? (
              <form>
                <Box sx={{ mb: 3 }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      mb: 0.5,
                    }}
                  >
                    <Typography variant="body1" fontWeight="medium">
                      Upload Resume
                    </Typography>
                    <Switch
                      checked={formData.requireResume}
                      onChange={handleToggleChange("requireResume")}
                      color="primary"
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Toggle on to require resume uploads
                  </Typography>
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      mb: 0.5,
                    }}
                  >
                    <Typography variant="body1" fontWeight="medium">
                      Attach Cover Letter
                    </Typography>
                    <Switch
                      checked={formData.requireCoverLetter}
                      onChange={handleToggleChange("requireCoverLetter")}
                      color="primary"
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Toggle on to require cover letter attachment
                  </Typography>
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      mb: 0.5,
                    }}
                  >
                    <Typography variant="body1" fontWeight="medium">
                      Attach Portfolio
                    </Typography>
                    <Switch
                      checked={formData.requirePortfolio}
                      onChange={handleToggleChange("requirePortfolio")}
                      color="primary"
                    />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Toggle on to require cover letter attachment
                  </Typography>
                </Box>
              </form>
            ) : currentStep === 3 ? (
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {questions.map((question) => (
                  <Box
                    key={question.id}
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      border: "1px solid #e0e0e0",
                      borderRadius: 1,
                      overflow: "hidden",
                    }}
                  >
                    {/* Question header - always visible */}
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        p: 2,
                        backgroundColor: question.expanded
                          ? "#f5f8ff"
                          : "transparent",
                      }}
                    >
                      <Typography variant="body1" fontWeight="medium">
                        {question.question}
                      </Typography>
                      <Box sx={{ display: "flex", gap: 1 }}>
                        <IconButton
                          size="small"
                          onClick={() => toggleQuestionExpand(question.id)}
                        >
                          {question.expanded ? (
                            <ChevronUp size={18} />
                          ) : (
                            <ChevronDown size={18} />
                          )}
                        </IconButton>
                        <IconButton
                          size="small"
                          sx={{ color: "red" }}
                          onClick={() => handleDeleteQuestion(question.id)}
                        >
                          <Trash2 size={18} />
                        </IconButton>
                      </Box>
                    </Box>

                    {/* Expanded question editor */}
                    {question.expanded && (
                      <Box
                        sx={{
                          p: 2,
                          borderTop: "1px solid #e0e0e0",
                          backgroundColor: "#f9f9f9",
                        }}
                      >
                        <Box sx={{ mt: 1 }}>
                          <Typography variant="body2" sx={{ mb: 0.5 }}>
                            Question
                          </Typography>
                          <TextField
                            fullWidth
                            variant="outlined"
                            size="small"
                            value={question.question}
                            onChange={(e) =>
                              handleQuestionChange(
                                question.id,
                                "question",
                                e.target.value
                              )
                            }
                            sx={{
                              "& .MuiOutlinedInput-root": {
                                borderRadius: 1,
                              },
                            }}
                          />
                        </Box>

                        <Box sx={{ mt: 2 }}>
                          <Typography variant="body2" sx={{ mb: 0.5 }}>
                            Field Type
                          </Typography>
                          <Select
                            fullWidth
                            size="small"
                            value={question.type}
                            onChange={(e) =>
                              handleQuestionChange(
                                question.id,
                                "type",
                                e.target.value
                              )
                            }
                            IconComponent={() => (
                              <ChevronDown size={16} color="#666" />
                            )}
                            sx={{
                              "& .MuiOutlinedInput-root": {
                                borderRadius: 1,
                              },
                            }}
                          >
                            <MenuItem value="mult">Multiple Choice</MenuItem>
                            <MenuItem value="short">Short Answer</MenuItem>
                            <MenuItem value="paragraph">Paragraph</MenuItem>
                            <MenuItem value="check">Checkbox</MenuItem>
                            <MenuItem value="dropdown">Dropdown</MenuItem>
                          </Select>
                        </Box>

                        {/* Short Answer Input */}
                        {question.type === "short" && (
                          <Box sx={{ mt: 2 }}>
                            <Typography variant="body2" sx={{ mb: 0.5 }}>
                              Answer
                            </Typography>
                            <TextField
                              fullWidth
                              variant="outlined"
                              size="small"
                              placeholder="Type here..."
                              disabled
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  borderRadius: 1,
                                },
                              }}
                            />
                          </Box>
                        )}

                        {/* Paragraph Input */}
                        {question.type === "paragraph" && (
                          <Box sx={{ mt: 2 }}>
                            <Typography variant="body2" sx={{ mb: 0.5 }}>
                              Answer
                            </Typography>
                            <TextField
                              fullWidth
                              variant="outlined"
                              size="small"
                              multiline
                              rows={4}
                              placeholder="Type here..."
                              disabled
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  borderRadius: 1,
                                },
                              }}
                            />
                          </Box>
                        )}

                        {/* Multiple Choice Options */}
                        {question.type === "mult" && (
                          <Box sx={{ mt: 2 }}>
                            {question.options.map((option, index) => (
                              <Box
                                key={index}
                                sx={{
                                  display: "flex",
                                  gap: 1,
                                  mb: 1,
                                  alignItems: "center",
                                }}
                              >
                                <Typography
                                  variant="body2"
                                  sx={{ minWidth: 60 }}
                                >
                                  {`Option ${index + 1}`}
                                </Typography>
                                <TextField
                                  fullWidth
                                  variant="outlined"
                                  size="small"
                                  value={option.option}
                                  onChange={(e) =>
                                    handleOptionChange(
                                      question.id,
                                      index,
                                      e.target.value
                                    )
                                  }
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 1,
                                    },
                                  }}
                                />
                                <IconButton
                                  size="small"
                                  onClick={() =>
                                    handleDeleteOption(question.id, index)
                                  }
                                  sx={{ color: "#666" }}
                                >
                                  <X size={16} />
                                </IconButton>
                              </Box>
                            ))}

                            <Box
                              sx={{
                                mt: 2,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                              }}
                            >
                              <div className="flex gap-1 items-center">
                                <Switch
                                  checked={question.isRequired || false}
                                  onChange={handleQuestionRequiredToggle(
                                    question.id
                                  )}
                                  color="primary"
                                />
                                <p className="text-sm">
                                  Make this field compulsory
                                </p>
                              </div>

                              <Button
                                variant="text"
                                startIcon={<Plus size={16} />}
                                onClick={() => handleAddOption(question.id)}
                                sx={{
                                  borderColor: "#1B5FC1",
                                  color: "#1B5FC1",
                                  textTransform: "none",
                                  borderRadius: 1,
                                  py: 0.5,
                                }}
                              >
                                Add Option
                              </Button>
                            </Box>
                          </Box>
                        )}

                        {/* Checkbox Options */}
                        {question.type === "check" && (
                          <Box sx={{ mt: 2 }}>
                            {question.options.map((option, index) => (
                              <Box
                                key={index}
                                sx={{
                                  display: "flex",
                                  gap: 1,
                                  mb: 1,
                                  alignItems: "center",
                                }}
                              >
                                <Typography
                                  variant="body2"
                                  sx={{ minWidth: 60 }}
                                >
                                  {`Option ${index + 1}`}
                                </Typography>
                                <TextField
                                  fullWidth
                                  variant="outlined"
                                  size="small"
                                  value={option.option}
                                  onChange={(e) =>
                                    handleOptionChange(
                                      question.id,
                                      index,
                                      e.target.value
                                    )
                                  }
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 1,
                                    },
                                  }}
                                />
                                <IconButton
                                  size="small"
                                  onClick={() =>
                                    handleDeleteOption(question.id, index)
                                  }
                                  sx={{ color: "#666" }}
                                >
                                  <X size={16} />
                                </IconButton>
                              </Box>
                            ))}

                            <Box
                              sx={{
                                mt: 2,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                              }}
                            >
                              <div className="flex gap-1 items-center">
                                <Switch
                                  checked={question.isRequired || false}
                                  onChange={handleQuestionRequiredToggle(
                                    question.id
                                  )}
                                  color="primary"
                                />
                                <p className="text-sm">
                                  Make this field compulsory
                                </p>
                              </div>

                              <Button
                                variant="text"
                                startIcon={<Plus size={16} />}
                                onClick={() => handleAddOption(question.id)}
                                sx={{
                                  borderColor: "#1B5FC1",
                                  color: "#1B5FC1",
                                  textTransform: "none",
                                  borderRadius: 1,
                                  py: 0.5,
                                }}
                              >
                                Add Option
                              </Button>
                            </Box>
                          </Box>
                        )}

                        {/* Dropdown Options */}
                        {question.type === "dropdown" && (
                          <Box sx={{ mt: 2 }}>
                            {question.options.map((option, index) => (
                              <Box
                                key={index}
                                sx={{
                                  display: "flex",
                                  gap: 1,
                                  mb: 1,
                                  alignItems: "center",
                                }}
                              >
                                <Typography
                                  variant="body2"
                                  sx={{ minWidth: 60 }}
                                >
                                  {`Option ${index + 1}`}
                                </Typography>
                                <TextField
                                  fullWidth
                                  variant="outlined"
                                  size="small"
                                  value={option.option}
                                  onChange={(e) =>
                                    handleOptionChange(
                                      question.id,
                                      index,
                                      e.target.value
                                    )
                                  }
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 1,
                                    },
                                  }}
                                />
                                <IconButton
                                  size="small"
                                  onClick={() =>
                                    handleDeleteOption(question.id, index)
                                  }
                                  sx={{ color: "#666" }}
                                >
                                  <X size={16} />
                                </IconButton>
                              </Box>
                            ))}

                            <Box
                              sx={{
                                mt: 2,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                              }}
                            >
                              <div className="flex gap-1 items-center">
                                <Switch
                                  checked={question.isRequired || false}
                                  onChange={handleQuestionRequiredToggle(
                                    question.id
                                  )}
                                  color="primary"
                                />
                                <p className="text-sm">
                                  Make this field compulsory
                                </p>
                              </div>

                              <Button
                                variant="text"
                                startIcon={<Plus size={16} />}
                                onClick={() => handleAddOption(question.id)}
                                sx={{
                                  borderColor: "#1B5FC1",
                                  color: "#1B5FC1",
                                  textTransform: "none",
                                  borderRadius: 1,
                                  py: 0.5,
                                }}
                              >
                                Add Option
                              </Button>
                            </Box>
                          </Box>
                        )}
                      </Box>
                    )}
                  </Box>
                ))}

                <Box sx={{ mt: 2, display: "flex", justifyContent: "center" }}>
                  <Button
                    variant="outlined"
                    startIcon={<Plus size={16} />}
                    onClick={handleAddQuestion}
                    sx={{
                      borderColor: "#1B5FC1",
                      color: "#1B5FC1",
                      textTransform: "none",
                      borderRadius: 1,
                      width: "100%",
                    }}
                  >
                    Add Question
                  </Button>
                </Box>
              </Box>
            ) : currentStep === 4 ? (
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <Typography variant="body1" fontWeight="medium" sx={{ mb: 1 }}>
                  Select Hiring Team
                </Typography>

                <TextField
                  fullWidth
                  placeholder="Search name or department"
                  variant="outlined"
                  size="small"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <ChevronDown size={16} color="#666" />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: 1,
                    },
                    mb: 2,
                  }}
                />

                {/* Grid layout for team members */}
                <Box
                  sx={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "10px",
                  }}
                >
                  {filteredTeamMembers.map((member) => {
                    const isSelected = selectedTeamMembers.some(
                      (m) => m.id === member.id
                    );
                    return (
                      <Box
                        key={member.id}
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          py: 0.5,
                          px: 1,
                          borderRadius: "20px",
                          backgroundColor: isSelected ? "#E8EFF9" : "#f0f0f0",
                          cursor: "pointer",
                          border: "1px solid #e0e0e0",
                          textWrap: "nowrap",
                        }}
                        onClick={() => toggleTeamMember(member)}
                      >
                        <Typography
                          variant="body2"
                          sx={{
                            color: isSelected ? "#1B5FC1" : "black",
                            fontWeight: isSelected ? "medium" : "normal",
                            fontSize: "15px",
                          }}
                        >
                          {member.name}
                        </Typography>
                        <IconButton
                          size="small"
                          sx={{
                            color: isSelected ? "#1B5FC1" : "#666",
                            p: 0.5,
                          }}
                        >
                          {isSelected ? <X size={14} /> : <Plus size={14} />}
                        </IconButton>
                      </Box>
                    );
                  })}
                </Box>
              </Box>
            ) : currentStep === 5 ? (
              <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
                <Box>
                  <Typography
                    variant="body1"
                    fontWeight="medium"
                    sx={{ mb: 1 }}
                  >
                    Advertise Posting
                  </Typography>
                  <Box sx={{ position: "relative" }}>
                    <Box
                      sx={{
                        border: "1px solid #e0e0e0",
                        borderRadius: 1,
                        p: 2,
                        minHeight: "50px",
                        display: "flex",
                        flexWrap: "wrap",
                        gap: 1,
                      }}
                    >
                      {formData.advertisePlatforms.map((platform) => (
                        <Chip
                          key={platform}
                          label={platform}
                          onDelete={() => handleDeletePlatform(platform)}
                          sx={{
                            backgroundColor: "#E8EFF9",
                            color: "#1B5FC1",
                            "& .MuiChip-deleteIcon": {
                              color: "#1B5FC1",
                            },
                          }}
                        />
                      ))}
                      <Box
                        onClick={() =>
                          setShowPlatformDropdown(!showPlatformDropdown)
                        }
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          cursor: "pointer",
                          ml: formData.advertisePlatforms.length > 0 ? 1 : 0,
                        }}
                      >
                        <ChevronDown size={16} color="#666" />
                      </Box>
                    </Box>
                    {showPlatformDropdown && (
                      <Box
                        sx={{
                          position: "absolute",
                          top: "100%",
                          left: 0,
                          width: "100%",
                          maxHeight: "200px",
                          overflowY: "auto",
                          backgroundColor: "white",
                          border: "1px solid #e0e0e0",
                          borderRadius: 1,
                          zIndex: 10,
                          mt: 0.5,
                          boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                        }}
                      >
                        {availablePlatforms
                          .filter(
                            (platform) =>
                              !formData.advertisePlatforms.includes(platform)
                          )
                          .map((platform) => (
                            <Box
                              key={platform}
                              onClick={() => handlePlatformSelect(platform)}
                              sx={{
                                p: 1.5,
                                cursor: "pointer",
                                "&:hover": {
                                  backgroundColor: "#f5f5f5",
                                },
                              }}
                            >
                              {platform}
                            </Box>
                          ))}
                      </Box>
                    )}
                  </Box>
                </Box>

                <Box
                  sx={{
                    bgcolor: "#f9f9f9",
                    p: 3,
                    borderRadius: 1,
                    border: "1px solid #e0e0e0",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      mb: 2,
                    }}
                  >
                    <Typography variant="body1" fontWeight="medium">
                      Job Details
                    </Typography>
                    <Button
                      startIcon={<Edit size={16} />}
                      sx={{
                        color: "#1B5FC1",
                        textTransform: "none",
                        p: 0,
                      }}
                      onClick={() => setCurrentStep(1)}
                    >
                      Edit
                    </Button>
                  </Box>

                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr",
                      gap: 2,
                    }}
                  >
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Job Title
                      </Typography>
                      <Typography variant="body2">
                        {formData.jobTitle || "null"}
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Job Code
                      </Typography>
                      <Typography variant="body2">
                        {formData.jobCode || "null"}
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Industry
                      </Typography>
                      <Typography variant="body2">
                        {formData.industry || "null"}
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Salary Currency
                      </Typography>
                      <Typography variant="body2">
                        {formData.salaryCurrency || "null"}
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Salary Range
                      </Typography>
                      <Typography variant="body2">
                        {formData.salaryRange || "null"}
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Required Skills
                      </Typography>
                      <Typography variant="body2">
                        {formData.requiredSkills.length > 0
                          ? formData.requiredSkills.join(", ") + " + more"
                          : "null"}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            ) : null}
          </Box>

          {/* Footer - fixed at bottom */}
          <Box
            sx={{
              px: 3,
              py: 2,
              bgcolor: "#f5f5f5",
              display: "flex",
              justifyContent: "end",
              gap: "15px",
              borderTop: "1px solid #e0e0e0",
            }}
          >
            {currentStep < 5 ? (
              <>
                <button
                  variant="outlined"
                  onClick={onClose}
                  className="border border-gray-400 rounded-sm px-3 py-3"
                >
                  Save & Close
                </button>
                <button
                  onClick={handleNext}
                  className="bg-[#E8EFF9] rounded-sm px-3 py-3"
                >
                  Next
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={handleSaveAsDraft}
                  className="border border-gray-400 rounded-sm px-3 py-3"
                >
                  Save as Draft
                </button>
                <button
                  onClick={handlePublish}
                  className="bg-[#1B5FC1] text-white rounded-sm px-3 py-3"
                >
                  {isEditing ? "Update" : "Publish"}
                </button>
              </>
            )}
          </Box>

          {/* Floating Action Button */}
          <Fab
            color="#1B5FC1"
            sx={{
              position: "fixed",
              bottom: 80,
              right: 32,
              zIndex: 9999,
              bgcolor: "#1B5FC1",
            }}
          >
            <img
              src={sparkleIcon || "/placeholder.svg"}
              alt="AI sparkle Icon"
            />
          </Fab>
        </Box>
      </Modal>

      {/* Confirmation Modal */}
      <Modal
        open={showConfirmModal}
        onClose={() => setShowConfirmModal(false)}
        sx={{ backdropFilter: "blur(4px)" }}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100%",
            maxWidth: "400px",
            bgcolor: "background.paper",
            borderRadius: 2,
            boxShadow: 24,
            p: 4,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
            <AlertCircle size={24} color="#1B5FC1" />
            <Typography
              variant="h6"
              component="h2"
              sx={{ ml: 1, fontWeight: "bold" }}
            >
              Confirm Action
            </Typography>
            <IconButton
              onClick={() => setShowConfirmModal(false)}
              sx={{ ml: "auto", color: "#666" }}
            >
              <X size={20} />
            </IconButton>
          </Box>

          <Typography variant="body1" sx={{ mb: 3 }}>
            {isEditing
              ? "Are you sure you want to update this job posting? This will modify the live listing."
              : "Are you sure you want to publish this job posting? Once live, changes cannot be undone."}
          </Typography>

          {apiError && (
            <Box
              sx={{
                mb: 3,
                p: 2,
                bgcolor: "#FFF4F4",
                borderRadius: 1,
                border: "1px solid #FFD6D6",
              }}
            >
              <Typography variant="body2" color="error" fontWeight="medium">
                {apiError.message || "Error submitting form"}
              </Typography>
              {apiError.errors && (
                <ul style={{ margin: "8px 0 0 20px", padding: 0 }}>
                  {Object.entries(apiError.errors).map(([field, message]) => (
                    <li key={field}>
                      <Typography variant="body2" color="error">
                        {field}: {message}
                      </Typography>
                    </li>
                  ))}
                </ul>
              )}
            </Box>
          )}

          <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 2 }}>
            <Button
              variant="outlined"
              onClick={() => setShowConfirmModal(false)}
              sx={{
                borderColor: "#e0e0e0",
                color: "#666",
                textTransform: "none",
                borderRadius: 1,
                px: 3,
              }}
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={handleConfirmPublish}
              disabled={isSubmitting}
              sx={{
                bgcolor: "#1B5FC1",
                color: "white",
                textTransform: "none",
                borderRadius: 1,
                px: 3,
                "&:hover": {
                  bgcolor: "#164a9c",
                },
              }}
            >
              {isSubmitting
                ? "Processing..."
                : isEditing
                ? "Yes, Update"
                : "Yes, I'm sure"}
            </Button>
          </Box>
        </Box>
      </Modal>

      {/* Success Modal */}
      <Modal
        open={showSuccessModal}
        onClose={handleCloseSuccessModal}
        sx={{ backdropFilter: "blur(4px)" }}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100%",
            maxWidth: "400px",
            bgcolor: "background.paper",
            borderRadius: 2,
            boxShadow: 24,
            p: 4,
            textAlign: "center",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              mb: 3,
            }}
          >
            <CircularProgress
              variant="determinate"
              value={100}
              size={40}
              thickness={5}
              sx={{ color: "#4CAF50", mb: 2 }}
            />
            <Typography variant="h5" component="h2" sx={{ fontWeight: "bold" }}>
              {isEditing ? "Job Updated!" : "Job Published!"}
            </Typography>
          </Box>

          <Typography variant="body1" sx={{ mb: 4 }}>
            {isEditing
              ? "Your job listing has been successfully updated."
              : "Your listing is now live. Check your dashboard to track applications."}
          </Typography>

          <Button
            fullWidth
            variant="contained"
            onClick={handleCloseSuccessModal}
            sx={{
              bgcolor: "#1B5FC1",
              color: "white",
              textTransform: "none",
              borderRadius: 1,
              py: 1.5,
              "&:hover": {
                bgcolor: "#164a9c",
              },
            }}
          >
            Okay
          </Button>
        </Box>
      </Modal>
    </>
  );
}
export default CreateJobModal;
