import { CaretDownIcon, CaretUpIcon } from '@phosphor-icons/react';
import React, { useState } from 'react';

export default function InterviewAssessRow({ children, totalMark, setTotalMark, title, isOpen, onToggle }) {
    const [selectedMarks, setSelectedMarks] = useState(Array(children.length).fill(null));

    const handleMark = (num, childIndex) => {
        const newSelectedMarks = [...selectedMarks];
        newSelectedMarks[childIndex] = num; // Update selection for this child
        setSelectedMarks(newSelectedMarks);

        // Calculate total: sum of selections divided by 2
        const sum = newSelectedMarks.reduce((total, mark) => total + (mark || 0), 0);
        setTotalMark(sum / 2);
    };

    return (
        <div className='text-[#292929]'>
            <div className="py-[13px] bg-[#F3F2F2] px-3 flex items-center justify-between rounded-md">
                <div className="font-medium text-[16px]">{title}</div>
                <div className="w-[161px] h-[25px] flex items-center gap-3">
                    <div className="gap-2 flex items-center">
                        <p className="text-[12px] w">Score Earned</p>
                        <p className='px-3 py-1 rounded-[4px] bg-[#1B5FC1] text-white text-[12px]'>
                            {totalMark === 0 ? "-" : totalMark.toFixed(1)}
                        </p>
                    </div>
                    <button className='cursor-pointer' onClick={onToggle}>
                        {isOpen ? <CaretUpIcon size={20} /> : <CaretDownIcon size={20} />}
                    </button>
                </div>
            </div>

            {isOpen && (
                <div>
                    {children.map((child, childIndex) => (
                        <div className="flex items-center justify-between px-3 h-[72px] border-b border-b-gray-300" key={childIndex}>
                            <p className='h-5 text-[14px]'>{child.props.children}</p>
                            <div className="flex gap-4 h-[43px] w-[344px]">
                                {[10, 9, 8, 7, 6, 5, 4, 3, 2, 1].map((el, i) => {
                                    const isSelected = selectedMarks[childIndex] === el;
                                    return (
                                        <div className='w-5 h-full flex items-center flex-col gap-1.5' key={i}>
                                            <div 
                                                className={`${isSelected ? "bg-[#1B5FC1]" : ""} w-5 h-5 rounded-full cursor-pointer hover:bg-gray-300 border border-gray-200`} 
                                                onClick={() => handleMark(el, childIndex)}
                                            ></div>
                                            <p className='text-[12px]'>{el}</p>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}