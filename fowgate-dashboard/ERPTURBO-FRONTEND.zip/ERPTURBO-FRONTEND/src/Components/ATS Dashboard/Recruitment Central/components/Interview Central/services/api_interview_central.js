import toast from "react-hot-toast";

const token = localStorage.getItem("userAccess")

const API_BASE_URL = import.meta.env.VITE_ERP_TURBO_API_BASE_URL

const createScheduledInterview = async (payload) => {
  console.log("Payload for creating interview:", payload);
  
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/apply/schedule_interview`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      }
    );
    const data = await response.json();

    if (response.status === 401 && data.auth_url) {
      window.location.href = data.auth_url;
      return; // Stop further execution
    }

    if (!response.ok) {
      throw new Error(data.message || "Failed to create interview");
    }
    return data;
  } catch (error) {
    console.error("Failed to create interview:", error);
    throw error;
  }
};
const createAssessmentQuestions = async (payload) => {
  console.log("Payload for creating assessment question:", payload);
  
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/job_board/ai_assessment/add_question`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      }
    );
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Failed to create interview");
    }
    toast.success("Assessment Question Created Successfully");
    console.log("Assessment Question Created Successfully:", data);
    return data;
  } catch (error) {
    console.error("Failed to create interview:", error);
    throw error;
  }
};

const getAllInterviews = async (month, day = "") => {
  
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/apply/get_interviews?company_code=${"COM_101"}&month=${month}&day=${day}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const data = await response.json();
  
    if (!response.ok) {
      throw new Error(data.message)
    }
    return data
      
  } catch (error) {
    console.error("Failed to fetch interviews:", error);
  } finally {
    // setLoading(false);
  }
}

const getAIAssessmentQuestions = async (job_code) => {
  console.log("job_code:", job_code);
  
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/job_board/ai_assessment/get_questions?job_code=${job_code}`,
      // `${API_BASE_URL}/api/hcm/ats/job_board/ai_assessment/get_questions?job_code=${job_code}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const data = await response.json();
  
    if (!response.ok) {
      throw new Error(data.message)
    }
    return data
      
  } catch (error) {
    console.error("Failed to fetch AI assessment Question:", error);
  } finally {
    // setLoading(false);
  }
}

const editScheduledInterview = async (payload) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/apply/edit_interview_details`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      }
    );
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Failed to update interview");
    }
    return data;
  } catch (error) {
    console.error("Failed to update interview:", error);
    throw error;
  }
};

const editAssessmentQuestion = async (payload) => {
  console.log("Payload for editing assessment question:",payload);
  
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/job_board/ai_assessment/edit_question`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      }
    );
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message);
    }
    toast.success("Assessment Question Updated Successfully");
    return data;
  } catch (error) {
    console.error("Failed to update assessment question:", error);
    throw error;
  }
};

const deleteAnInterview = async ( meeting_code ) => {
  
    try {
           const response = await fetch(
          `${API_BASE_URL}/api/hcm/ats/apply/delete_interview?meeting_code=${meeting_code}`,
          {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const data = await response.json();
  
        if (!response.ok) {
          throw new Error(data.message)
      }  
      toast.success("Interview Deleted");
      return data
      } catch (error) {
        console.error("Failed to fetch interviews:", error);
      }
}

const deleteAnAssessmentQuestion = async ( payload ) => {
  
  console.log("Payload for deleting assessment question:", payload);
  
    try {
           const response = await fetch(
          `${API_BASE_URL}/api/hcm/ats/job_board/ai_assessment/delete_question`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify(payload)
          }
        );
        const data = await response.json();
  
        if (!response.ok) {
          throw new Error(data.message)
      }  
      toast.success("Assessment Question Deleted");
      return data
      } catch (error) {
        console.error("Failed to delete assessment Question:", error);
      }
}






export{createScheduledInterview, createAssessmentQuestions, getAllInterviews, getAIAssessmentQuestions, editScheduledInterview, editAssessmentQuestion, deleteAnInterview, deleteAnAssessmentQuestion}