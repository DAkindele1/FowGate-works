import React from 'react'

export default function Notes() {
  return (
    <div>Notes</div>
  )
}
