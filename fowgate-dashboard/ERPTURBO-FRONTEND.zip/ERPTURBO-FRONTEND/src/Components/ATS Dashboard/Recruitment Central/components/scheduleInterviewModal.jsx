import React, { useState } from "react";
import { Calendar, ChevronDown, X } from "lucide-react";

const ScheduleInterviewModal = ({
  isOpen,
  onClose,
  candidateName,
  candidateRole,
  onSubmit,
}) => {
  const [interviewDetails, setInterviewDetails] = useState({
    title: `${candidateRole} Interview`,
    date: "02 December, 2024",
    startTime: "7:15 PM",
    endTime: "9:00 PM",
    location: "Virtual Meeting",
    platform: "Google Meet",
    link: "",
  });

  const handleSubmit = () => {
    // Generate a random meeting link if not provided
    if (!interviewDetails.link) {
      setInterviewDetails({
        ...interviewDetails,
        link: `https://meet.google.com/${Math.random()
          .toString(36)
          .substring(2, 8)}-${Math.random()
          .toString(36)
          .substring(2, 5)}-${Math.random().toString(36).substring(2, 5)}`,
      });
    }
    onSubmit(interviewDetails);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-md">
        <div className="bg-blue-600 text-white p-4 flex items-center justify-between rounded-t-lg">
          <div className="flex items-center">
            <Calendar className="mr-2" size={20} />
            <h2 className="text-lg font-semibold">Schedule Interview</h2>
          </div>
          <button onClick={onClose} className="text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">
              Meeting Title
            </label>
            <input
              type="text"
              className="w-full p-2 border border-gray-300 rounded"
              placeholder="Enter Title"
              value={interviewDetails.title}
              onChange={(e) =>
                setInterviewDetails({
                  ...interviewDetails,
                  title: e.target.value,
                })
              }
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">Date</label>
            <div className="relative">
              <input
                type="text"
                className="w-full p-2 border border-gray-300 rounded"
                placeholder="Select Date"
                value={interviewDetails.date}
                onChange={(e) =>
                  setInterviewDetails({
                    ...interviewDetails,
                    date: e.target.value,
                  })
                }
              />
              <Calendar
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={18}
              />
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">
              Select Time
            </label>
            <div className="flex space-x-4">
              <div className="flex-1">
                <div className="flex items-center justify-between border border-gray-300 rounded p-2">
                  <span className="text-sm text-gray-500">From</span>
                  <div className="flex items-center">
                    <span>{interviewDetails.startTime}</span>
                    <ChevronDown size={16} className="ml-1 text-gray-500" />
                  </div>
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between border border-gray-300 rounded p-2">
                  <span className="text-sm text-gray-500">To</span>
                  <div className="flex items-center">
                    <span>{interviewDetails.endTime}</span>
                    <ChevronDown size={16} className="ml-1 text-gray-500" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">
              Meeting Location
            </label>
            <div className="relative">
              <input
                type="text"
                className="w-full p-2 border border-gray-300 rounded"
                value={interviewDetails.location}
                readOnly
              />
              <ChevronDown
                size={16}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              />
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">
              Select Meeting Platform
            </label>
            <div className="flex space-x-2">
              <button
                className={`p-2 border rounded flex items-center justify-center ${
                  interviewDetails.platform === "Google Meet"
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-300"
                }`}
                onClick={() =>
                  setInterviewDetails({
                    ...interviewDetails,
                    platform: "Google Meet",
                  })
                }
              >
                <span className="text-sm">Google Meet</span>
              </button>
              <button
                className={`p-2 border rounded flex items-center justify-center ${
                  interviewDetails.platform === "Zoom"
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-300"
                }`}
                onClick={() =>
                  setInterviewDetails({ ...interviewDetails, platform: "Zoom" })
                }
              >
                <span className="text-sm">Zoom</span>
              </button>
              <button
                className={`p-2 border rounded flex items-center justify-center ${
                  interviewDetails.platform === "Microsoft Teams"
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-300"
                }`}
                onClick={() =>
                  setInterviewDetails({
                    ...interviewDetails,
                    platform: "Microsoft Teams",
                  })
                }
              >
                <span className="text-sm">Microsoft Teams</span>
              </button>
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">
              Meeting Link
            </label>
            <div className="relative">
              <input
                type="text"
                className="w-full p-2 border border-gray-300 rounded"
                placeholder="https://meet.google.com/abc-xyz-pqr"
                value={interviewDetails.link}
                onChange={(e) =>
                  setInterviewDetails({
                    ...interviewDetails,
                    link: e.target.value,
                  })
                }
              />
              {interviewDetails.link ? (
                <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-600 text-sm">
                  Copy
                </button>
              ) : (
                <button
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-600 text-sm"
                  onClick={() =>
                    setInterviewDetails({
                      ...interviewDetails,
                      link: `https://meet.google.com/${Math.random()
                        .toString(36)
                        .substring(2, 8)}-${Math.random()
                        .toString(36)
                        .substring(2, 5)}-${Math.random()
                        .toString(36)
                        .substring(2, 5)}`,
                    })
                  }
                >
                  Generate Link
                </button>
              )}
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">
              Invite Hiring Team
            </label>
            <div className="relative">
              <input
                type="text"
                className="w-full p-2 border border-gray-300 rounded"
                placeholder="Search name or department"
              />
              <ChevronDown
                size={16}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 mt-6">
            <button
              className="px-4 py-2 border border-gray-300 rounded text-gray-700"
              onClick={onClose}
            >
              Cancel
            </button>
            <button
              className="px-4 py-2 bg-blue-600 text-white rounded"
              onClick={handleSubmit}
            >
              Schedule Interview
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScheduleInterviewModal;
