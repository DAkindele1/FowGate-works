import React from 'react'
import { CaretDownIcon, StarIcon } from '@phosphor-icons/react';
import Select from '../../../../ui/Select';

export default function RecruitmentList({ selectedCandidate, handleCandidateSelect, candidatesData, mainTab, currentTab}) {
  const existCandidate = candidatesData.some(item => item._id === selectedCandidate._id) ? selectedCandidate : candidatesData[0]
  

  return (
   
    candidatesData.length === 0 ? null :  <div className={` w-[340px] bg-white rounded-lg border border-gray-200 max-h-[1200px] overflow-y-auto`}>
      {currentTab === "INTERVIEW CENTRAL"? <div className="p-4 border-b border-gray-200">
        <div className="mb-3 flex items-center">
            <div className="relative border px-3 py-2 w-[197px] h-[42px] rounded-[8px] text-[#292929] font-medium text-[20px] flex items-center">
              <select className="w-full focus:outline-none">
                <option>Audit Manager</option>
                <option>Software Engineer</option>
                <option>UI/UX Designer</option>
              </select>
            </div>
          </div>

          <div className="relative">
            <input
              type="text"
              placeholder="Search name, skill..."
              className="w-full pl-2 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-[14px] font-light"
            />

            <img
              src="/assets/img/ats-search.png"
              alt="search icon"
              className="absolute right-3 top-1/2 transform -translate-y-1/2"
            />
          </div>
          
        </div>:
      <div className="m-[16px] mb-[13px] flex flex-col gap-[16px] h-fit">
        {/* Search and filter section (unchanged) */ }
        <div className="relative border border-gray-200 rounded-[4px]  h-[38px] py-[8px] px-[12px]">
          <input
            type="text"
            placeholder="Search name, skill..."
            className="w-full h-full rounded-md focus:outline-none text-[14px] font-light"
          />
          <img
            src="/assets/img/ats-search.png"
            alt="search icon"
            className="absolute right-3 top-1/2 transform -translate-y-1/2"
          />
        </div>
        {mainTab !== "talentPool" && <div className="flex items-center  w-[211px] h-[28px]">
          <span className="text-[12px] font-light text-[#707070]">
            Filter by status:
          </span>
          <div className="relative w-[120px] h-[28px] p-1 flex items-center gap-1.5">
            {/* <Select optionsArr={"Satisfactory"}/> */}
            <select className=" rounded-md appearance-none focus:outline-none">
              <option>Satisfactory</option>
            </select>
            <CaretDownIcon size={18}/>
          </div>
        </div>}
      </div>}

      {/* Candidate list */}
      <div className="flex flex-col gap-3 ">
        {candidatesData.map((candidateData) => (
          <div 
            key={candidateData._id}
            className={`px-4 py-2 flex  gap-2 hover:bg-gray-50 cursor-pointer ${
              candidateData._id === existCandidate._id ? "bg-[#ECF4FF]" : ""
            }`}
            onClick={() => handleCandidateSelect(candidateData)}
          >
            <div className="text-[#1b5fc1] font-medium rounded-full h-[48px] w-[48px] flex items-center justify-center mr-1">
          <span className= {` h-[48px] w-[48px] rounded-full  flex items-center justify-center ${
              candidateData._id === existCandidate._id ? "bg-white" : "bg-[#E8EFF9]"
            }`}>
          {candidateData.firstname[0]+candidateData.lastname[0]}
          </span>
        </div>
            
            <div className="flex flex-col gap-0.5">
              <h3 className="font-medium text-[16px] text-gray-900 capitalize flex items-center gap-1">
                {candidateData.firstname} {candidateData.lastname}
                {candidateData.is_favorite && (
    <StarIcon 
      size={15} 
      color="#EB8A00" 
      weight="fill" 
      className="ml-1 transition-opacity duration-200"
    />
  )}
              </h3>
              <p className="text-sm font-light text-gray-500 capitalize">
                {candidateData.industry}
              </p>
              <p className={`text-xs flex items-center gap-2.5 justify-center w-fit px-[8px] py-[2px] rounded-full text-[#292929]`}>
                <span className={`${
                  candidateData.match > 70 ? "text-[#34A853]" : 
                  candidateData.match > 50 ? "text-[#1B5FC1]" : "text-[#EB4335]"
                }`}>
                  {candidateData.match ? candidateData.match+"%" : '—'}
                </span>
                <span>
                  Exam Score
                
                </span>
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}