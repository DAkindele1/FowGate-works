import React, { useState } from "react";
import {
  Search,
  Star,
  MoreVertical,
  Download,
  Calendar,
  ChevronDown,
} from "lucide-react";
import { candidatesData } from "./candidatesData";

const InterviewCentral = () => {
  const [candidates, setCandidates] = useState(candidatesData);
  const [selectedCandidate, setSelectedCandidate] = useState(candidatesData[0]);
  const [showActionMenu, setShowActionMenu] = useState(false);
  const [activeTab, setActiveTab] = useState("Interview Assessment");
  const [currentTab, setCurrentTab] = useState("ALL CANDIDATES");
  const [loading, setLoading] = useState(false);
  const [interviewTab, setInterviewTab] = useState("Interview Assessment");

  const handleShortlist = () => {
    const updatedCandidates = candidates.map((candidate) =>
      candidate.id === selectedCandidate.id
        ? { ...candidate, status: "SHORTLISTED" }
        : candidate
    );

    setCandidates(updatedCandidates);
    setSelectedCandidate({ ...selectedCandidate, status: "SHORTLISTED" });
  };

  const filteredCandidates = candidates.filter(
    (candidate) =>
      currentTab === "ALL CANDIDATES" || candidate.status === currentTab
  );

  return (
    <div className="flex flex-1 space-x-4 px-6">
      {/* Left Column - Candidate List */}
      <div className="w-1/3 bg-white rounded-lg border border-gray-200">
        <div className="p-4 border-b border-gray-200">
        <div className="mb-3 flex items-center">
            <div className="relative border px-3 py-2 w-[197px] h-[42px] rounded-[8px] text-[#292929] font-medium text-[20px] flex items-center">
              <select className="w-full">
                <option>Audit Manager</option>
              </select>
            </div>
          </div>

          <div className="relative">
            <input
              type="text"
              placeholder="Search name, skill..."
              className="w-full pl-2 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-[14px] font-light"
            />

            <img
              src="/assets/img/ats-search.png"
              alt="search icon"
              className="absolute right-3 top-1/2 transform -translate-y-1/2"
            />
          </div>
          
        </div>

        <div className="divide-y divide-gray-100 border w-[340px] flex flex-col gap-3 ">
          {loading ? (
            <div className="p-4 text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <p className="mt-2 text-gray-600">Loading candidates...</p>
            </div>
          ) : filteredCandidates.length > 0 ? (
            filteredCandidates.map((candidate) => (
              <div
                key={candidate.id}
                className={`p-4 flex items-center hover:bg-gray-50 cursor-pointer ${
                  candidate.id === selectedCandidate.id ? "bg-blue-50" : ""
                }`}
                onClick={() => handleCandidateSelect(candidate)}
              >
                <img
                  src={candidate.avatar || "/placeholder.svg"}
                  alt={candidate.name}
                  className="w-10 h-10 rounded-full object-cover mr-3"
                />
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">
                    {candidate.name}
                  </h3>
                  <p className="text-sm text-gray-500">{candidate.position}</p>
                  <p
                    className={`text-xs mt-1 w-fit p-[8px] rounded-full ${
                      candidate.match?.includes("Good")
                        ? "text-green-600"
                        : candidate.match?.includes("Satisfactory")
                        ? "text-orange-600"
                        : "text-red-600"
                    } ${
                      candidate.id === selectedCandidate.id
                        ? "bg-white"
                        : "bg-[#F1F1F1]"
                    }`}
                  >
                    {candidate.match}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-gray-500">
              No candidates found
            </div>
          )}
        </div>
      </div>

      {/* Right Column - Candidate Details */}
      <div className="w-2/3 bg-white rounded-lg border border-gray-200 relative ">
        {/* Candidate Header */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
              <span className="text-lg font-bold text-yellow-800">
                {selectedCandidate.name.charAt(0)}
              </span>
            </div>
            <div>
              <h2 className="text-lg font-semibold">
                {selectedCandidate.name}
              </h2>
              <div className="text-sm text-gray-500 flex gap-1">
                <img src="/assets/img/location.png" alt="location icon" className="w-4 h-4" />
                <p>{selectedCandidate.location}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="px-3 py-1.5 border border-gray-200 rounded-md hover:bg-gray-50 flex items-center gap-1">
              <img src="/assets/img/shortlist-icon.png" alt="shortlist icon" />
              <button
                className="flex items-center text-[14px] text-[#292929] font-light"
                onClick={handleShortlist}
              >
                <span>Shortlist</span>
              </button>
            </div>
            <button className="p-1.5 hover:bg-gray-100 rounded-md">
              <Star className="h-5 w-5 text-gray-400" />
            </button>
            <div className="relative">
              <button
                className="p-1.5 hover:bg-gray-100 rounded-md"
                onClick={() => setShowActionMenu(!showActionMenu)}
              >
                <MoreVertical className="h-5 w-5 text-gray-400" />
              </button>

              {showActionMenu && (
                <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200">
                  <div className="py-1">
                    <button
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={handleScheduleInterview}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-2 text-gray-500"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                      </svg>
                      Schedule A Call
                    </button>
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <Star className="h-4 w-4 mr-2 text-gray-500" />
                      Mark As Favorite
                    </button>
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-2 text-gray-500"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
                      </svg>
                      Add To Talent Pool
                    </button>
                    <button className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-2 text-red-500"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                          clipRule="evenodd"
                        />
                      </svg>
                      Delete Candidate
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 pt-2 flex items-center gap-4 ">
          {/* MATCH */}
          <div className="flex items-center bg-[#F3F2F2] w-fit rounded-full gap-1 px-[12px] py-[10px]">
            <div className="rounded-full flex items-center justify-center mr-2">
              <img src="/assets/img/user-check-01.png" alt="User Check Icon" className="w-4 h-4 " />
            </div>
            <div>
              <p className="text-[14px] font-normal text-green-600">
                {selectedCandidate.match}
              </p>
            </div>
          </div>

          {/* BRIEFCASE */}
          <div className="flex items-center bg-[#F3F2F2] w-fit rounded-full gap-1 px-[12px] py-[10px]">
            <div className="rounded-full flex items-center justify-center mr-2">
              <img src="/assets/img/briefcase-01.png" alt="Brief Case Icon" className="w-4 h-4 " />
            </div>
            <div>
              <p className="text-[14px] font-normal">
                {selectedCandidate.experience}
              </p>
            </div>
          </div>

          {/* PHONE */}
          <div className="flex items-center bg-[#F3F2F2] w-fit rounded-full gap-1 px-[12px] py-[10px]">
            <div className="rounded-full flex items-center justify-center mr-2">
              <img src="/assets/img/phone.png" alt="Phone Icon" className="w-4 h-4 " />
            </div>
            <div>
              <p className=" text-[14px] font-normal">
                {selectedCandidate.phone}
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center border border-gray-200 mx-5 rounded-md">
          <div className="p-4">
            <p className="text-[14px] text-[#707070] font-normal">Honors</p>
            <p className="font-normal text-[14px] text-[#292929]">
              {selectedCandidate.role}
            </p>
          </div>
          <div className="p-4">
            <p className="text-[14px] text-[#707070] font-normal">
              Availability
            </p>
            <p className="font-normal text-[14px] text-[#292929]">
              {selectedCandidate.availability}
            </p>
          </div>
          <div className="p-4">
            <p className="text-[14px] text-[#707070] font-normal">
              Application Date
            </p>
            <p className="font-normal text-[14px] text-[#292929]">
              27 Nov, 2024
            </p>
          </div>
        </div>

        <div className="p-4 mt-4">
          <div className="flex border-b border-gray-200 mb-4 space-x-6">
            <button
              className={` w-fit pb-2 ${
                activeTab === "Interview Assessment"
                  ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
                  : "text-[#707070] font-light text-[16px] hover:text-gray-700"
              }`}
              onClick={() => setActiveTab("Interview Assessment")}
            >
              Interview Assessment
            </button>
            <button
              className={` w-fit pb-2 ${
                activeTab === "Notes"
                  ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
                  : "text-[#707070] font-light text-[16px] hover:text-gray-700"
              }`}
              onClick={() => setActiveTab("Notes")}
            >
              Notes
            </button>
            <button
              className={` w-fit pb-2 ${
                activeTab === "Candidate Analysis"
                  ? "text-[#1B5FC1] border-b-4 border-[#1B5FC1] font-normal text-[16px]"
                  : "text-[#707070] font-light text-[16px] hover:text-gray-700"
              }`}
              onClick={() => setActiveTab("Candidate Analysis")}
            >
              Candidate Analysis
            </button>
          </div>

          {activeTab === "Interview Assessment" ? (
            <>
              <div className="flex items-center justify-between mt-6">
                <div className="w-[45%]">
                  <h3 className="font-medium mb-3 text-[#292929] text-[16px]">
                    Resume
                  </h3>
                  <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
                    <div className="flex items-center">
                      <div className="w-8 h-10 flex items-center justify-center rounded mr-3">
                        <img src="/assets/img/pdf.png" alt="PDF Icon" />
                      </div>
                      <div>
                        <p className="font-normal text-[14px]">
                          {selectedCandidate.resume.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {selectedCandidate.resume.size}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                {/* PORTFOLIO */}
                <div className="w-[45%]">
                  <h3 className="font-medium mb-3 text-[#292929] text-[16px]">
                    Portfolio
                  </h3>
                  <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
                    <div className="flex items-center">
                      <div className="w-8 h-10 flex items-center justify-center rounded mr-3">
                        <img src="/assets/img/link-icon.png" alt="Link Icon" />
                      </div>
                      <div className="font-normal text-[14px]">
                        <a className="font-medium text-sm underline">
                          {selectedCandidate.resume.name}
                        </a>
                        <p className="text-xs text-gray-500">
                          {selectedCandidate.resume.size}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="font-medium mb-3 text-[#292929] text-[16px]">
                  Top Skills
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedCandidate.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-6 py-3 bg-gray-100 text-[#292929] text-[14px] font-normal rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-between items-center text-[#1B5FC1]">
                <h3 className="font-medium mb-3 text-[#292929] text-[16px]">
                  Interview Assessment
                </h3>
                <p className="text-[14px] text-[#1B5FC1] font-medium leading-relaxed">
                  <span className="text-2xl">{`+ `}</span> Add Section
                </p>
              </div>

              {/* INTERVIEW ASSESSMENT SECTIONS WRAP */}
              <div className="my-2">
                {/* FIRST SECTION */}
                <div>
                  <div className="flex items-center justify-between bg-[#E8EFF9] p-3 rounded-md">
                    <h3 className="text-[16px] font-medium text-[#1B5FC1]">
                      Candidate's courtesy
                    </h3>

                    <div className="flex items-center gap-2">
                      <span className="text-[12px] font-normal text-[#292929]">
                        Score Earned:{" "}
                      </span>
                      <button className="py-2 px-4 text-white bg-[#1B5FC1] rounded-md">
                        1
                      </button>
                      <img src="/assets/img/vertical-dots.png" alt="Vertical dot icon" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between my-2 border-b border-gray-200 py-1.5">
                    <p className="text-[14px] font-normal text-[#292929]">
                      Proper Introduction
                    </p>

                    <div className="flex gap-4">
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                    </div>
                  </div>
                  <div className="flex items-center justify-between my-2 border-b border-gray-200 py-1.5">
                    <p className="text-[14px] font-normal text-[#292929]">
                      Positive First Impression
                    </p>

                    <div className="flex gap-4">
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                    </div>
                  </div>
                </div>

                {/* SECOND SECTION */}
                <div>
                  <div className="flex items-center justify-between bg-[#E8EFF9] p-3 rounded-md">
                    <h3 className="text-[16px] font-medium text-[#1B5FC1]">
                      Candidate's Appearance
                    </h3>

                    <div className="flex items-center gap-2">
                      <span className="text-[12px] font-normal text-[#292929]">
                        Score Earned:{" "}
                      </span>
                      <button className="py-2 px-4 text-white bg-[#1B5FC1] rounded-md">
                        1
                      </button>
                      <img src="/assets/img/vertical-dots.png" alt="Vertical dot icon" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between my-2 border-b border-gray-200 py-1.5">
                    <p className="text-[14px] font-normal text-[#292929]">
                      Proper Introduction
                    </p>

                    <div className="flex gap-4">
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                    </div>
                  </div>
                  <div className="flex items-center justify-between my-2 border-b border-gray-200 py-1.5">
                    <p className="text-[14px] font-normal text-[#292929]">
                      Positive First Impression
                    </p>

                    <div className="flex gap-4">
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                      <label className="flex flex-col space-y-3">
                        <input
                          type="radio"
                          name="rating"
                          value="10"
                          className="w-4 h-4 border border-red-600 focus:ring-red-500"
                        />
                        <span className="font-normal text-[12px] text-[#707070]">
                          10
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : activeTab === "Notes" ? (
            "notes"
          ) : (
            <div className="space-y-4 mt-4">
              {selectedCandidate.answers &&
                selectedCandidate.answers.map((item, index) => (
                  <div key={index} className="p-4 rounded-r">
                    <div className="flex items-center mb-2">
                      <div className="w-5 h-5 rounded-full flex items-center justify-center mr-2">
                        <img src="/assets/img/green-check.png" alt="Green check icon" />
                      </div>
                      <h4 className="font-medium">{item.question}</h4>
                    </div>
                    <p className="text-sm text-gray-900 bg-gray-50 p-4 rounded-md ml-7">
                      {item.answer}
                    </p>
                  </div>
                ))}
            </div>
          )}
        </div>
        <div className="absolute w-full flex items-center justify-end bottom-0  border-t border-gray-200 p-4">
          <button className="bg-[#E8EFF9] text-[14px] font-normal text-[#1B5FC1] py-2 px-3 rounded-md">
            {" "}
            Hire Candidate
          </button>
        </div>
      </div>
    </div>
  );
};

export default InterviewCentral;
