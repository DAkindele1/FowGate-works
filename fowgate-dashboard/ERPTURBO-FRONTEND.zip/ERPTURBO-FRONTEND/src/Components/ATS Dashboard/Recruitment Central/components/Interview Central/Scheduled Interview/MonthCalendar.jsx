import React, { useEffect, useState } from 'react';
import { getAllInterviews } from '../services/api_interview_central';
import Spinner from '../../../../../../ui/Spinner';
import InterviewDetailsModal from './InterviewDetailsModal';

export default function MonthCalendar({ refreshFlag, setSelectedDayMeeting, monthName, setTotalMeetings, interviewMonth, year, setFilterBy, setInterviewDay, showInterviewDetailsModal, setShowInterviewDetailsModal, selectedInterview, setSelectedInterview, onInterviewDeleted, interviews, setInterviews }) {
    const [isLoading, setIsLoading] = useState(false);
    const [calendarDays, setCalendarDays] = useState([]);

    const monthMap = {
        'Jan.': 0, 'Feb.': 1, 'Mar.': 2, 'Apr.': 3,
        'May': 4, 'Jun.': 5, 'Jul.': 6, 'Aug.': 7,
        'Sep.': 8, 'Oct.': 9, 'Nov.': 10, 'Dec.': 11
    };

    const monthAbbr = {
        0: 'JAN', 1: 'FEB', 2: 'MAR', 3: 'APR',
        4: 'MAY', 5: 'JUN', 6: 'JUL', 7: 'AUG',
        8: 'SEP', 9: 'OCT', 10: 'NOV', 11: 'DEC'
    };

    const dayAbbr = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

    // Then modify your getMeetingsForDay function:
const getMeetingsForDay = (dayInfo) => {
    return interviews.filter(meeting => {
      const meetingDate = new Date(meeting.date);
      return (
        meetingDate.getDate() === dayInfo.day &&
        meetingDate.getMonth() === dayInfo.month && 
        meetingDate.getFullYear() === dayInfo.year
      );
    });
  };

    useEffect(() => {
        const fetchInterviews = async () => {
          setIsLoading(true);
          try {
            const data = await getAllInterviews(interviewMonth);
            setInterviews(data.meetings);
            setTotalMeetings(data.meetings.length);
            generateCalendarDays();
          } catch (error) {
            console.error("Error fetching interviews:", error);
          } finally {
            setIsLoading(false);
          }
        };
      
        fetchInterviews();
      }, [interviewMonth, refreshFlag]);

    useEffect(() => {
        generateCalendarDays();
    }, [interviews, monthName, year, refreshFlag]);

    

    const generateCalendarDays = () => {
        const currentMonth = monthMap[monthName];
        const firstDayOfMonth = new Date(year, currentMonth, 1).getDay(); // 0 = Sunday
        const daysInMonth = new Date(year, currentMonth + 1, 0).getDate();
        const daysInPrevMonth = new Date(year, currentMonth, 0).getDate();

        // Calculate days from previous month to show
        const prevMonthDays = [];
        for (let i = firstDayOfMonth - 1; i >= 0; i--) {
            prevMonthDays.push({
                day: daysInPrevMonth - i,
                month: currentMonth - 1,
                year: currentMonth === 0 ? year - 1 : year,
                isCurrentMonth: false
            });
        }

        // Current month days
        const currentMonthDays = [];
        for (let i = 1; i <= daysInMonth; i++) {
            currentMonthDays.push({
                day: i,
                month: currentMonth,
                year,
                isCurrentMonth: true
            });
        }

        // Calculate days from next month to show
        const totalCells = 42; // 6 weeks
        const nextMonthDaysCount = totalCells - (prevMonthDays.length + daysInMonth);
        const nextMonthDays = [];
        for (let i = 1; i <= nextMonthDaysCount; i++) {
            nextMonthDays.push({
                day: i,
                month: currentMonth + 1,
                year: currentMonth === 11 ? year + 1 : year,
                isCurrentMonth: false
            });
        }

        setCalendarDays([...prevMonthDays, ...currentMonthDays, ...nextMonthDays]);
    };

    const handleDayClick = (dayInfo, selectedDayMeeting) => {
        if (!dayInfo.isCurrentMonth) return;
        setSelectedDayMeeting(selectedDayMeeting);
        setFilterBy("day");
        setInterviewDay(dayInfo.day);
    };

    // const getMeetingsForDay = (dayInfo) => {
    //     return interviews.filter(meeting => {
    //         const meetingDate = new Date(meeting.date);
    //         return (
    //             meetingDate.getDate() === dayInfo.day &&
    //             meetingDate.getMonth() === dayInfo.month &&
    //             meetingDate.getFullYear() === dayInfo.year
    //         );
    //     });
    // };

    const truncateTitle = (title, maxLength = 15) => {
        return title.length > maxLength ? `${title.substring(0, maxLength)}...` : title;
    };

    const formatTime = (timeString) => {
        if (!timeString) return '';
        
        const timeWithoutSeconds = timeString.split(':').slice(0, 2).join(':');
        const [hours] = timeWithoutSeconds.split(':').map(Number);
        
        const period = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours % 12 || 12;
        
        return `${displayHours}${period}`;
    };

    const handleInterviewClick = (meeting, e) => {
        e.stopPropagation();
        setShowInterviewDetailsModal(true);
        setSelectedInterview(meeting);
    };

    const formatDateDisplay = (dayInfo) => {
        const date = new Date(dayInfo.year, dayInfo.month, dayInfo.day);
        const dayOfWeek = dayAbbr[date.getDay()];
        return `${dayInfo.day} ${monthAbbr[dayInfo.month]}, ${dayOfWeek}`;
    };

  

    return (
        <div className='w-full h-full flex flex-wrap'>
            {isLoading ? (
                <div className="w-full flex justify-center h-full items-center">
                    <Spinner />
                </div>
            ) : (
                calendarDays.map((dayInfo, index) => {
                    const dayMeetings = getMeetingsForDay(dayInfo);
                    const hasMeetings = dayMeetings.length > 0;
                    const showSeeMore = dayMeetings.length > 2;

                    return (
                        <div
                            key={index}
                            className={`
                                w-[calc(100%/7)]
                                h-[150px] /* Fixed height for all cells */
                                border-r border-r-gray-300 border-b border-b-gray-300 
                                box-border
                                p-2 ${dayInfo.isCurrentMonth ? 'cursor-pointer bg-white' : 'bg-gray-100 cursor-not-allowed'} hover:scale-105
                                transition duration-200 ease-in-out hover:bg-gray-50
                                flex flex-col
                                overflow-hidden
                            `}
                            onClick={() => dayInfo.isCurrentMonth && handleDayClick(dayInfo, dayMeetings)}
                        >
                            <div className='flex flex-col items-center gap-1.5 m-3'>
                            <p className={`text-[14px] ${dayInfo.isCurrentMonth ? 'text-[#707070]' : 'text-gray-800'}`}>
                                {formatDateDisplay(dayInfo)}
                            </p>
                            <div className="w-full h-full overflow-y-auto">
    {hasMeetings ? (
        <div className="flex flex-col gap-1">
            {dayMeetings.slice(0, 2).map((meeting, i) => (
                <div 
                    key={i} 
                    className="gap-1 flex items-center bg-[#EFF1FB] px-2 h-[29px] rounded-full max-w-full" 
                    onClick={(e) => handleInterviewClick(meeting, e)}
                >
                    <span className="h-[6px] w-[6px] rounded-full bg-[#1B5FC1] flex-shrink-0"></span>
                    <span className="text-[12px] whitespace-nowrap overflow-hidden text-ellipsis min-w-0">
                        <span className='font-light text-[#707070]'>
                            {formatTime(meeting.start_time)}
                        </span> {truncateTitle(meeting.title)}
                    </span>
                </div>
            ))}
            {showSeeMore && (
                <div className="text-[12px] text-[#1B5FC1] text-center">See more</div>
            )}
        </div>
    ) : null}
</div>
                           </div>
                        </div>
                    );
                })
            )}
            <InterviewDetailsModal
                showInterviewDetailsModal={showInterviewDetailsModal}
                setShowInterviewDetailsModal={setShowInterviewDetailsModal}
                selectedInterview={selectedInterview}
                onInterviewDeleted={onInterviewDeleted} 
            />
        </div>
    );
}