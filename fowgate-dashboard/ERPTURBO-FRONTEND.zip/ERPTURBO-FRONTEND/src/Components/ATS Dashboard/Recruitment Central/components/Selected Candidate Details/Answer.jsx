import React from 'react'

export default function Answer({candidateData}) {
  return (
    <div className="space-y-4 mt-4">
          {candidateData.answers &&
            candidateData.answers.map((item, index) => (
              <div key={index} className="py-2 border-b border-gray-300">
                <div className="flex items-center mb-2">
                  <div className="w-5 h-5 rounded-full flex items-center justify-center mr-2">
                    <img src="/assets/img/green-check.png" alt="Green check icon" />
                  </div>
                  <h4 className="font-medium">{item.question}</h4>
                </div>
                <p className="text-sm text-gray-900 bg-gray-50 px-4 py-2 rounded-md ml-7">
                  {item.answer ? item.answer : item.is_selected ? "Yes": item.is_selected === false ? "No" : item.options&& item.options.map(option => option.is_selected && `${option.option}`)}
                  
                </p>
              </div>
            ))}
        </div>
  )
}
