import React from 'react'
import RecruitmentCentralReuse from './components/RecruitmentCentralReuse'

export default function RecruitmentCentral({setScheduledInterviews, setManageAI, setJobCode}) {
  return (
      <RecruitmentCentralReuse 
        mainTab={'main'} 
        setScheduledInterviews={setScheduledInterviews} 
        setManageAI={setManageAI} 
        setJobCode={setJobCode}
      />
  )
}
