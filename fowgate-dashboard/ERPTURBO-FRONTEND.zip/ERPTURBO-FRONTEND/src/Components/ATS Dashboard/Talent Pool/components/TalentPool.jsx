import React from 'react'
import RecruitmentCentralReuse from '../../Recruitment Central/components/RecruitmentCentralReuse'

export default function TalentPool() {
  return (
    <RecruitmentCentralReuse  mainTab={"talentPool"} />
  )
}
