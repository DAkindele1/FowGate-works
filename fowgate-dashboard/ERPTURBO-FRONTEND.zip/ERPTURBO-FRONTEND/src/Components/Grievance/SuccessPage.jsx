

import React from "react";
import { motion as Motion } from "framer-motion";
import { CheckFatIcon } from "@phosphor-icons/react";

const SuccessPage = ({ formData, closeModal }) => {
  return (
    <div className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white w-full max-w-md p-6 text-center rounded-lg shadow-lg relative">
        <div className="flex justify-center mb-6 w-20 h-20 mx-auto">
          <Motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{
              type: "spring",
              stiffness: 260,
              damping: 20,
            }}
            className="flex items-center justify-center w-full h-full rounded-full bg-green-500"
          >
            <Motion.div
              initial={{ scale: 0.5, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{
                delay: 0.2,
                duration: 0.5,
                ease: "easeOut",
              }}
            >
              <CheckFatIcon weight="fill" className="text-white" size={70} />
            </Motion.div>
          </Motion.div>
        </div>

        <h2 className="text-[22px] font-bold text-gray-900 mb-2">Report Updated!</h2>
        <p className="text-gray-600 mb-2 text-sm">
          The incident report
          <span className="font-semibold text-gray-900"> ({formData.id || "Pending ID"})</span>
          has been updated.
        </p>
        <button
          onClick={closeModal}
          className="bg-[#1B5FC1] text-white mt-6 w-full py-3 rounded-lg hover:bg-blue-700 transition duration-300"
        >
          Okay
        </button>
      </div>
    </div>
  );
};

export default SuccessPage;
