


import React, { useState, useEffect, useRef } from "react";
import { FiChevronDown } from "react-icons/fi"; // Import FiChevronDown

// onThread: function(grievance) => void, opens the thread popup for this grievance
function GrievanceGridCard({ grievance, index, onView, onEdit, onDelete, onThread, formData, handleChange }) {
  const [openDropdown, setOpenDropdown] = useState(false);
  const [isEditing, setIsEditing] = useState(false); // Add edit mode state
  const dropdownRef = useRef(null);
  const [urgencyLevels] = useState(["Low", "Medium", "High"]); // Define urgencyLevels locally, same as GrievanceStep1

  const formattedDate = new Date(grievance.grieviance_date || new Date()).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short", 
    year: "numeric",
  });

  const statusStyles = {
    Resolved: "bg-[#EBF6EE] text-[#34A853]",
    Unresolved: "bg-[#FDECEB] text-[#EB4335]",
    "In Progress": "bg-[#FDF3E6] text-[#EB8A00]",
    Pending: "bg-[#FDF3E6] text-[#EB8A00] ",
    "": "bg-[#FDECEB] text-[#EB4335]",
  };

  // Local image paths from public folder
  const urgencyIcons = {
    Low: "/low.svg",
    Medium: "/mid.svg",
    High: "/high.svg",
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpenDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDropdown = () => setOpenDropdown(!openDropdown);

  // Handle edit button click
  const handleEditClick = () => {
    setIsEditing(true);
    onEdit?.(grievance);
  };

  // Handle saving the edit
  const handleSave = () => {
    setIsEditing(false);
    // Additional save logic can be added here, e.g., calling an API
  };

  return (
    <div className="border border-gray-200 bg-white  rounded-xl">
      {/* Card Header */}
      <div className="bg-gray-200 p-2 flex justify-between items-center relative py-3">
        <span className="text-sm font-semibold text-[#292929] truncate max-w-[260px]">
          {grievance.grieviance_code} - {grievance.title}
        </span>
        <div className="relative" ref={dropdownRef}>
          <svg
            className="w-4 h-4 text-gray-500 cursor-pointer"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            onClick={toggleDropdown}
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v.01M12 12v.01M12 18v.01" />
          </svg>
          {openDropdown && (
            <div className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded shadow-lg z-10">
              <button
                className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                onClick={() => {
                  onView?.(grievance);
                  setOpenDropdown(false);
                }}
              >
                <img src="/file.svg" alt="View" className="w-4 h-4 mr-2" />
                View Report
              </button>
              <button
                className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                onClick={() => {
                  onEdit?.(grievance);
                  setOpenDropdown(false);
                }}
              >
                <img src="/pen.svg" alt="Edit" className="w-4 h-4 mr-2" />
                Edit Report
              </button>
              <button
                className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                onClick={() => {
                  if (onThread) onThread(grievance);
                  setOpenDropdown(false);
                }}
              >
                <img src="/chat.svg" alt="Thread" className="w-4 h-4 mr-2" />
                Thread [{Array.isArray(grievance.thread) && grievance.thread.length > 0
                  ? grievance.thread.length
                  : (Array.isArray(grievance.comments) ? grievance.comments.length : 0)}]
              </button>
              <button
                className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                onClick={() => {
                  onDelete?.(grievance);
                  setOpenDropdown(false);
                }}
              >
                <img src="/del.svg" alt="Delete" className="w-4 h-4 mr-2" />
                Delete Report
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 space-y-2">
        <div className="flex justify-between text-xs text-[#707070]">
          <span>Complainant:</span>
          <span>Date Submitted:</span>
        </div>
        <div className="flex justify-between items-center text-xs -mt-2">
          <div className="flex items-center space-x-2">
            <img
              src={grievance.avatar || grievance.image || " placeholder"}
              alt={grievance.complainant}
              className="h-6 w-6 rounded-full object-cover"
            />
            <span>{grievance.complainant || "N/A"}</span>
          </div>
          <span className="text-[#292929]">{formattedDate}</span>
        </div>
        <hr className="border-[#EAEAEA]" />
        <div className="py-2 -pt-1">
        <div className="flex justify-between text-xs text-[#707070] ">
          <span>Grievance Type:</span>
          <span>Urgency Level:</span>
        </div>
        <div className="flex justify-between items-center text-xs">

          <span className=" text-gray-[#292929]">
            {grievance.grievanceType || grievance.type}
          </span>
          {isEditing ? (
            <div className="relative">
              <select
                name="urgencyLevel"
                value={formData.urgencyLevel || grievance.urgency || ""}
                onChange={handleChange}
                className="w-full border border-gray-300 rounded-[6px] px-3 py-2 appearance-none pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">Select</option>
                {urgencyLevels.map((level) => (
                  <option key={level} value={level}>
                    {level}
                  </option>
                ))}
              </select>
              <FiChevronDown className="absolute right-3 top-3 text-gray-500 pointer-events-none" />
            </div>
          ) : (
            <span className=" text-gray-[#292929] flex items-center space-x-1">
              <img
                src={`/${(grievance.urgency || "Medium").toLowerCase()}.svg`}
                alt={grievance.urgency || "Medium"}
                className="w-4 h-4"
              />
              <span>{grievance.urgency || "Medium"}</span>
            </span>
          )}
        </div>
        </div>

        {/* <div className="text-xs text-gray-700">
          Attachments: {grievance.attachments?.length || grievance.attachments }
        </div>
        <div className="flex justify-end">
          <div
            className={`inline-flex items-center  text-xs font-medium  px-1.5 py-0.5 rounded-full text-[12px] bg-[#FDECEB] text-[#EB4335] ${statusStyles[grievance.status || "Unresolved"]
              }`}
          >
            {grievance.status || "Unresolved"}
            <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div> */}  
 <hr className="border-[#EAEAEA]" />
<div className="flex items-center justify-between py-2 -pb-2">
  <div className="text-xs text-gray-[#707070]">
    Attachments: {grievance.attachments?.length || grievance.attachments}
  </div>
  <div className="flex justify-end">
    <div
      className={`inline-flex items-center justify-center text-xs  px-1.5 py-1 rounded-full text-[12px] bg-[#FDECEB] text-[#EB4335] ${statusStyles[grievance.status || "Unresolved"]}`}
    >
      {grievance.status }
      <svg className="w-3 h-3 " fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
      </svg>
    </div>
  </div>
</div>
        
        {isEditing && (
          <div className="flex justify-end space-x-2">
            <button
              className="px-3 py-1 bg-blue-500 text-white rounded text-xs hover:bg-blue-600"
              onClick={handleSave}
            >
              Save
            </button>
            <button
              className="px-3 py-1 bg-gray-300 text-gray-700 rounded text-xs hover:bg-gray-400"
              onClick={() => setIsEditing(false)}
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default GrievanceGridCard;