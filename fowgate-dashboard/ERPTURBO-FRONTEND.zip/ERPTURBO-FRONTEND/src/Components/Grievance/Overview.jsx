


import React, { useState } from "react";

const Overview = ({ grievance, closeModal }) => {
  const [showGrievanceInfo, setShowGrievanceInfo] = useState(true);
  const [showLocationInfo, setShowLocationInfo] = useState(true);
  const [showSupportingInfo, setShowSupportingInfo] = useState(true);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-[500px] h-[575px]  bg-white overflow-hidden flex flex-col ">
        {/* Header */} 
         <div className="bg-[#1B5FC1] h-[80px] px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
            <h2 className="text-white text-lg font-semibold">Add New</h2>
          </div>
          <button onClick={closeModal} className="text-white text-2xl font-bold focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto px-4 py-5 flex-grow bg-transparent">
          {/* Reporting Officer Details */}
          <div className="bg-white rounded-lg border border-gray-300 overflow-hidden">
            <h3 className="bg-[#F1F1F1] px-6 py-2 text-sm font-medium rounded-t-lg">
              Reporting Officer Details
            </h3>
            <hr className="border-gray-300" />
            <div className="px-6 py-4 text-sm space-y-4">
              {[
                ["Name of CLO", grievance.cloName || "Not Provided"],
                ["OML", grievance.oml || "Not Provided"],
                ["Cluster/Host Community", grievance.hostCommunity || "Not Provided"],
                ["Company", grievance.company || "Not Provided"],
                ["Date of Report", grievance.grievanceDate || "Not Provided"],
                ["CLO Contact Number", grievance.cloPhone || "Not Provided"],
              ]
                .reduce((rows, item, index) => {
                  if (index % 2 === 0) rows.push([item]);
                  else rows[rows.length - 1].push(item);
                  return rows;
                }, [])
                .map((row, i) => (
                  <div key={i} className="grid grid-cols-2 gap-4">
                    {row.map(([label, value], j) => (
                      <div key={j}>
                        <p className="text-gray-500 text-[12px]">{label}</p>
                        <p className="text-black">{value}</p>
                      </div>
                    ))}
                    {i < 2 && <div className="col-span-2"><hr className="border-gray-300 mt-2" /></div>}
                  </div>
                ))}
            </div>
          </div>

          {/* Grievance Information */}
          <div className="bg-white rounded-lg relative border border-gray-300 mt-4">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Grievance Information
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowGrievanceInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showGrievanceInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showGrievanceInfo && (
              <div className="grid grid-cols-2 gap-4 p-4 text-sm">
                <div>
                  <p className="text-gray-500 text-[12px]">Grievance Title</p>
                  <p className="text-black">{grievance.grievanceTitle || grievance.title || "Not Provided"}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-[12px]">Urgency Level</p>
                  <p className="text-black flex items-center">
                    {grievance.urgencyLevel || grievance.urgency || "Not Provided"}
                    {(grievance.urgencyLevel === "High" || grievance.urgency === "High") && (
                      <span className="ml-1 text-red-500 text-xs">!!</span>
                    )}
                  </p>
                </div>
                <hr className="border-gray-300 col-span-2" />
                <div className="col-span-2">
                  <p className="text-gray-500 text-[12px]">Grievance Type</p>
                  <p className="text-black">{grievance.grievanceType || grievance.type || "Not Provided"}</p>
                </div>
                <hr className="border-gray-300 col-span-2" />
                <div className="col-span-2">
                  <p className="text-gray-500 text-[12px]">Description</p>
                  <p className="text-black">{grievance.description || "Not Provided"}</p>
                </div>
                <hr className="border-gray-300 col-span-2" />
                
                
              </div>
            )}
          </div>

          {/* Location Details */}
          <div className="bg-white rounded-lg relative border border-gray-300 mt-4">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Location Details
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowLocationInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showLocationInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showLocationInfo && (
              <div className="px-4 py-4 text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-500 text-[12px]">State</p>
                    <p className="text-black">{grievance.state || "Not Provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">LGA</p>
                    <p className="text-black">{grievance.lga || "Not Provided"}</p>
                  </div>
                  <hr className="border-gray-300 col-span-2" />
                  <div className="col-span-2">
                    <p className="text-gray-500 text-[12px]">Community/Area</p>
                    <p className="text-black">{grievance.community || "Not Provided"}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Supporting Information */}
          <div className="bg-white rounded-lg relative border border-gray-300 mt-4">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Supporting Information
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowSupportingInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showSupportingInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showSupportingInfo && (
              <div className="px-4 py-4 text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-500 text-[12px]">Complainant</p>
                    <p className="text-black">
                      {grievance.complainant || grievance.complainantName || grievance.grievanceTitle || grievance.title || "Not Provided"}
                    </p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                    <p className="text-black">
                      {Array.isArray(grievance.attachments) && grievance.attachments.length > 0
                        ? grievance.attachments.map(a => a.name || a.filename).join(", ")
                        : (grievance.attachment && (grievance.attachment.name || grievance.attachment.filename))
                          || grievance.attachmentName
                          || "Not Provided"}
                    </p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-500 text-[12px]">Signature</p>
                    {grievance.signature ? (
                      <img
                        src={grievance.signature}
                        alt="Signature"
                        className="h-10 object-contain"
                      />
                    ) : (
                      <p className="text-black">Not Provided</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            onClick={closeModal}
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default Overview;