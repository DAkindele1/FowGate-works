
import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { FiChevronDown } from "react-icons/fi";

function FilterModal({ onClose, types, statuses, severities, applyFilters, clearFilters, current }) {
  const [type, setType] = useState(current.filterType || "All");
  const [status, setStatus] = useState(current.filterStatus || "All");
  const [severity, setSeverity] = useState(current.filterSeverity || "All");

  console.log("FilterModal initial state:", { type, status, severity, current });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-md shadow-lg p-6">
        <h2 className="text-lg font-medium mb-4">Filter by</h2>

        <div className="mb-4">
          <label className="block font-medium">Type</label>
          <div className="flex justify-between items-center">
            <select
              value={type}
              onChange={(e) => {
                console.log("Type filter changed to:", e.target.value);
                setType(e.target.value);
              }}
              className="w-full border rounded px-2 py-1"
            >
              <option value="All">All</option>
              {types.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
            <button
              onClick={() => {
                console.log("Clearing type filter");
                setType("All");
              }}
              className="text-blue-600"
            >
              Clear
            </button>
          </div>
        </div>

        <div className="mb-4">
          <label className="block font-medium">Status</label>
          <div className="flex justify-between items-center">
            <select
              value={status}
              onChange={(e) => {
                console.log("Status filter changed to:", e.target.value);
                setStatus(e.target.value);
              }}
              className="w-full border rounded px-2 py-1"
            >
              <option value="All">All</option>
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <button
              onClick={() => {
                console.log("Clearing status filter");
                setStatus("All");
              }}
              className="text-blue-600"
            >
              Clear
            </button>
          </div>
        </div>

        <div className="mb-4">
          <label className="block font-medium">Severity</label>
          <div className="flex justify-between items-center">
            <select
              value={severity}
              onChange={(e) => {
                console.log("Severity filter changed to:", e.target.value);
                setSeverity(e.target.value);
              }}
              className="w-full border rounded px-2 py-1"
            >
              <option value="All">All</option>
              {severities.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <button
              onClick={() => {
                console.log("Clearing severity filter");
                setSeverity("All");
              }}
              className="text-blue-600"
            >
              Clear
            </button>
          </div>
        </div>

        <div className="flex justify-between mt-6">
          <button
            onClick={() => {
              console.log("Resetting all filters from FilterModal");
              clearFilters();
              onClose();
            }}
            className="text-gray-600"
          >
            Reset
          </button>
          <button
            onClick={() => {
              console.log("Applying filters from FilterModal:", { type, status, severity });
              applyFilters({ type, status, severity });
              onClose();
            }}
            className="bg-blue-600 text-white px-4 py-1 rounded"
          >
            Apply Now
          </button>
        </div>
      </div>
    </div>
  );
}

function GrievanceFilter({
  grievances,
  grievanceTypes,
  statusOptions,
  severityOptions,
  onFilteredGrievances,
  currentPage,
  setCurrentPage,
  pageSize,
}) {
  if (typeof onFilteredGrievances !== "function") {
    console.error("onFilteredGrievances is not a function:", onFilteredGrievances);
    throw new Error("onFilteredGrievances must be a function");
  }

  const [filterType, setFilterType] = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");
  const [filterSeverity, setFilterSeverity] = useState("All");
  const [filterMonth, setFilterMonth] = useState("All");
  const [showFilter, setShowFilter] = useState(false);

  useEffect(() => {
    console.log("Filter state updated:", { filterType, filterStatus, filterSeverity, filterMonth });
  }, [filterType, filterStatus, filterSeverity, filterMonth]);

  const applyFilters = ({ type, status, severity }) => {
    console.log("applyFilters called with:", { type, status, severity });
    setFilterType(type || "All");
    setFilterStatus(status || "All");
    setFilterSeverity(severity || "All");
    setCurrentPage(1);
    console.log("Filter states updated:", {
      filterType: type || "All",
      filterStatus: status || "All",
      filterSeverity: severity || "All",
      currentPage: 1,
    });
  };

  const clearFilters = () => {
    console.log("clearFilters called");
    setFilterType("All");
    setFilterStatus("All");
    setFilterSeverity("All");
    setFilterMonth("All");
    setCurrentPage(1);
    console.log("All filters cleared:", {
      filterType: "All",
      filterStatus: "All",
      filterSeverity: "All",
      filterMonth: "All",
      currentPage: 1,
    });
  };

  const uniqueMonths = [
    ...new Set(
      grievances.map((grievance) => {
        const dateStr = grievance.reportDate || grievance.grievanceDate || new Date().toISOString();
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) {
          console.warn("Invalid date for grievance:", { id: grievance.id, dateStr });
          return null;
        }
        return date.toLocaleString("default", { month: "short", year: "numeric" });
      }).filter(Boolean)
    ),
  ].sort((a, b) => new Date(`1 ${b}`) - new Date(`1 ${a}`));

  const filteredGrievances = grievances.filter((grievance) => {
    console.log("Filtering grievance:", { id: grievance.id, grievance });
    const matchesType =
      filterType === "All" ||
      (grievance.grievanceType || "").toLowerCase() === filterType.toLowerCase();
    const matchesStatus =
      filterStatus === "All" ||
      (grievance.status || "").toLowerCase() === filterStatus.toLowerCase();
    const matchesSeverity =
      filterSeverity === "All" ||
      (grievance.urgencyLevel || "").toLowerCase() === filterSeverity.toLowerCase();
    const matchesMonth =
      filterMonth === "All" ||
      (grievance.reportDate || grievance.grievanceDate) &&
      new Date(grievance.reportDate || grievance.grievanceDate).toLocaleString("default", {
        month: "short",
        year: "numeric",
      }) === filterMonth;
    const result = matchesType && matchesStatus && matchesSeverity && matchesMonth;
    console.log("Filter result for grievance:", {
      id: grievance.id,
      matchesType,
      matchesStatus,
      matchesSeverity,
      matchesMonth,
      included: result,
    });
    return result;
  });

  useEffect(() => {
    const totalFiltered = filteredGrievances.length;
    const totalPages = Math.ceil(totalFiltered / pageSize);
    const start = (currentPage - 1) * pageSize + 1;
    const end = Math.min(start + pageSize - 1, totalFiltered);
    const paginatedGrievances = filteredGrievances.slice(start - 1, end);
    onFilteredGrievances({
      filteredGrievances: paginatedGrievances,
      totalFiltered,
      totalPages,
      start,
      end,
    });
  }, [filteredGrievances, currentPage, pageSize, onFilteredGrievances]);

  return (
    <>
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => {
            console.log("Opening filter modal");
            setShowFilter(true);
          }}
          className="border border-gray-200 rounded px-1.5 py-1 text-xs"
        >
          Filter
        </button>
        <select
          className="border border-gray-200 rounded px-1.5 py-1 text-xs"
          value={filterMonth}
          onChange={(e) => {
            console.log("Month filter changed to:", e.target.value);
            setFilterMonth(e.target.value);
            setCurrentPage(1);
          }}
        >
          <option value="All">All Months</option>
          {uniqueMonths.map((monthYear) => (
            <option key={monthYear} value={monthYear}>
              {monthYear}
            </option>
          ))}
        </select>
      </div>
      <div className="text-sm text-gray-600 mt-2">
        Active Filters: Type: {filterType}, Status: {filterStatus}, Severity: {filterSeverity}, Month: {filterMonth}
      </div>
      {showFilter && (
        <FilterModal
          onClose={() => {
            console.log("Closing filter modal");
            setShowFilter(false);
          }}
          types={grievanceTypes}
          statuses={statusOptions}
          severities={severityOptions}
          current={{ filterType, filterStatus, filterSeverity }}
          applyFilters={applyFilters}
          clearFilters={clearFilters}
        />
      )}
    </>
  );
}

GrievanceFilter.propTypes = {
  grievances: PropTypes.array.isRequired,
  grievanceTypes: PropTypes.arrayOf(PropTypes.string).isRequired,
  statusOptions: PropTypes.arrayOf(PropTypes.string).isRequired,
  severityOptions: PropTypes.arrayOf(PropTypes.string).isRequired,
  onFilteredGrievances: PropTypes.func.isRequired,
  currentPage: PropTypes.number.isRequired,
  setCurrentPage: PropTypes.func.isRequired,
  pageSize: PropTypes.number.isRequired,
};

export default GrievanceFilter;
