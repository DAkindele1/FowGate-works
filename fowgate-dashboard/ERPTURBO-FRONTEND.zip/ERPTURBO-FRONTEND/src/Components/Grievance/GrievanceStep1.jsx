


import React, { useState, useRef } from "react";
import { FiChevronDown } from "react-icons/fi";
import toast from "react-hot-toast";

const GRIEVANCE_TYPES = ["Infrastructure", "Health & Sanitation", "Environment", "Safety","Utilities (Water, Electricity)","other"];
const URGENCY_LEVELS = ["Low", "Medium", "High"];

function GrievanceStep1({ formData = {}, onChange, onNext, onClose }) {
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  const fileInputRef = useRef(null);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.title?.trim()) newErrors.title = "Title is required.";
    if (!formData.grievanceType) newErrors.grievanceType = "Grievance type is required.";
    if (!formData.description?.trim()) newErrors.description = "Description is required.";
    if (!formData.urgencyLevel) newErrors.urgencyLevel = "Urgency level is required.";
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    onChange(name, value);
    setErrors((prev) => ({ ...prev, [name]: "" }));
    setApiError(null);
  };

  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      onChange("attachment", file); // ✅ persist file to formData
      if (file.type.startsWith("image/")) {
        setPreviewImage(URL.createObjectURL(file));
      } else {
        setPreviewImage(null);
      }
    }
  };

  const handleNext = (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);
    onNext(); // ✅ no file passed, it's already in formData
    setLoading(false);
  };

  return (
    <div className="  flex items-center   justify-center backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Add icon" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Add New Grievance</h2>
          </div>
          <button onClick={onClose} className="text-white" aria-label="Close form">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="px-4 py-3 overflow-y-auto flex-1">
          <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
            <img src="/one.svg" alt="Step 1" width={20} height={20} className="mr-2" />
            <span className="text-black">
              1/4 - <span className="font-bold">GRIEVANCE INFORMATION</span>
            </span>
          </div>
          <hr className="border-t border-gray-300 my-3" />

          {loading && (
            <div className="flex justify-center mb-4">
              <svg className="w-6 h-6 animate-spin text-blue-500" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
            </div>
          )}
          {apiError && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded mb-4 text-sm">
              {apiError}
            </div>
          )}

          <div className="space-y-4 text-sm">
            {/* File Upload */}
            
            {/* Title */}
            <div>
              <label htmlFor="title" className="block text-sm text-gray-700 mb-1">
                Grievance Title
              </label>
              <input
                id="title"
                type="text"
                name="title"
                value={(formData.title || "").replace(/\b\w/g, c => c.toUpperCase())}
                onChange={handleChange}
                placeholder="Enter title"
                className={`w-full border ${errors.title ? "border-red-500" : "border-gray-300"} rounded-[6px] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                disabled={loading}
              />
              {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
            </div>

            {/* Grievance Type */}
            <div>
              <label htmlFor="grievanceType" className="block text-sm text-gray-700 mb-1">
                Grievance Type
              </label>
              <div className="relative">
                <select
                  id="grievanceType"
                  name="grievanceType"
                  value={formData.grievanceType || ""}
                  onChange={handleChange}
                  className={`w-full border ${errors.grievanceType ? "border-red-500" : "border-gray-300"} rounded-[6px] px-3 py-2 appearance-none pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                  disabled={loading}
                >
                  <option value="">Select</option>
                  {GRIEVANCE_TYPES.map((type) => (
                    <option key={type} value={type}>
                      {type.replace(/\b\w/g, c => c.toUpperCase())}
                    </option>
                  ))}
                </select>
                <FiChevronDown className="absolute right-3 top-3 text-gray-500 pointer-events-none" />
              </div>
              {errors.grievanceType && <p className="text-red-500 text-xs mt-1">{errors.grievanceType}</p>}
            </div>

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description || ""}
                onChange={handleChange}
                placeholder="Type here"
                className={`w-full border ${errors.description ? "border-red-500" : "border-gray-300"} rounded-[6px] px-3 py-2 text-sm h-24 resize-none focus:outline-none focus:ring-1 focus:ring-blue-500`}
                disabled={loading}
              />
              {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
            </div>

            {/* Urgency Level */}
            <div>
              <label htmlFor="urgencyLevel" className="block text-sm text-gray-700 mb-1">
                Urgency Level
              </label>
              <div className="relative">
                <select
                  id="urgencyLevel"
                  name="urgencyLevel"
                  value={formData.urgencyLevel || ""}
                  onChange={handleChange}
                  className={`w-full border ${errors.urgencyLevel ? "border-red-500" : "border-gray-300"} rounded-[6px] px-3 py-2 appearance-none pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                  disabled={loading}
                >
                  <option value="">Select</option>
                  {URGENCY_LEVELS.map((level) => (
                    <option key={level} value={level}>
                      {level}
                    </option>
                  ))}
                </select>
                <FiChevronDown className="absolute right-3 top-3 text-gray-500 pointer-events-none" />
              </div>
              {errors.urgencyLevel && <p className="text-red-500 text-xs mt-1">{errors.urgencyLevel}</p>}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            type="button"
            onClick={onClose}
            className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
            disabled={loading}
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
            disabled={loading}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export default GrievanceStep1;