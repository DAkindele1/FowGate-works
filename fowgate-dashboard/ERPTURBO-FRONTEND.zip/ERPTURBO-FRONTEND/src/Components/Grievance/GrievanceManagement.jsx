

import React, { useState, useEffect, useMemo } from "react";
import { FiChevronDown, FiGrid, FiList, FiFilter } from "react-icons/fi";
import toast from "react-hot-toast";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { format } from "date-fns";

import GrievanceStep1 from "./GrievanceStep1";
import GrievanceStep2 from "./GrievanceStep2";
import GrievanceStep3 from "./GrievanceStep3";
import GrievanceStep4 from "./GrievanceStep4";
import GrievanceTable from "./GrievanceTable";
import ConfirmationModal from "./ConfirmationModal";
import SuccessModal from "./SuccessModal";
import FilterModal from "./FilterModal";

function GrievanceManagement() {
  const [activeTab, setActiveTab] = useState("grievance");
  const [grievances, setGrievances] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState(null);
  const [referenceId, setReferenceId] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [formData, setFormData] = useState({});
  const [stepFormData, setStepFormData] = useState({});
  const [viewMode, setViewMode] = useState("list");
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [filters, setFilters] = useState({
    type: "",
    status: "",
    severity: "",
    monthYear: "",
  });

  const pageSize = 10;
  const token = localStorage.getItem("userAccess");

  if (!token || token === "undefined") {
    console.error("Missing or invalid token");
    toast.error("Please log in to continue");
    throw new Error("Missing token");
  }

  const grievanceTypes = ["Infrastructure", "Health & Sanitation", "Environment", "Safety","Utilities (Water, Electricity)","other"];
  const statuses = ["In Progress", "Resolved", "Unresolved", "Pending"];
  const severities = ["Low", "Medium", "High"];

  const fetchGrievances = async () => {
    console.log("Fetching grievances");
    try {
      const response = await fetch(
        "https://erpturbo-backend.onrender.com/api/oml/grieviance_management/get_grieviances",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({}),
        }
      );

      const data = await response.json();
      console.log("Fetch grievances response:", data.grieviances);

      if (!response.ok) {
        toast.error(data.message || "Failed to fetch grievances");
        throw new Error(data.message || "Server error");
      }

      // Normalize data
      const normalizedGrievances = data.grieviances.map((grievance) => ({
        ...grievance,
        type: grievance.type
          ? grievance.type.charAt(0).toUpperCase() + grievance.type.slice(1).toLowerCase()
          : grievance.type || "",
        status: grievance.status
          ? grievance.status.charAt(0).toUpperCase() + grievance.status.slice(1).toLowerCase()
          : grievance.status || "",
        urgency: grievance.urgency
          ? grievance.urgency.charAt(0).toUpperCase() + grievance.urgency.slice(1).toLowerCase()
          : grievance.urgency || "",
      }));
      setGrievances(normalizedGrievances);
    } catch (err) {
      setApiError(err.message || "Failed to connect to the server. Please check your network or try again later.");
      toast.error(err.message || "Failed to fetch grievances");
    }
  };

  const handleAddNew = () => {
    setStep(1);
    setShowForm(true);
    setFormData({});
    setStepFormData({});
    setApiError(null);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setStep(1);
    setFormData({});
    setStepFormData({});
    setReferenceId("");
    setApiError(null);
  };

  const handleNextStep = (data) => {
    if (data instanceof FormData) {
      setStepFormData((prev) => ({ ...prev, [`step${step}`]: data }));
      const info = data.get("info");
      if (info) {
        try {
          const parsedInfo = JSON.parse(info);
          setFormData((prev) => ({ ...prev, ...parsedInfo }));
        } catch (err) {
          console.error(`Error parsing FormData info for step ${step}:`, err);
        }
      }
    } else {
      setFormData((prev) => ({ ...prev, ...data }));
      setStepFormData((prev) => ({ ...prev, [`step${step}`]: data }));
    }
    setStep((prev) => prev + 1);
    setApiError(null);
  };

  const handlePreviousStep = () => {
    setStep((prev) => prev - 1);
    setApiError(null);
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    setApiError(null);

    const data = {
      title: formData.title || "",
      type: formData.grievanceType || "",
      description: formData.description || "",
      urgency: formData.urgencyLevel || "Medium",
      state: formData.state || "",
      lga: formData.lga || "",
      community_area: {
        name: formData.hostCommunity || "Nil",
        longitude: formData.longitude || 6.542764649554391,
        latitude: formData.latitude || 3.313045713444352,
      },
      signature: true,
      grieviance_date: formData.grievanceDate || "",
    };

    const formDataObj = new FormData();
    formDataObj.append("data", JSON.stringify(data));
    formData.attachments?.forEach((file, index) => {
      formDataObj.append(`files[${index}]`, file);
    });

    try {
      const response = await fetch(
        "https://erpturbo-backend.onrender.com/api/oml/grieviance_management/create_grieviance",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formDataObj,
        }
      );

      const result = await response.json();
      console.log("Create grievance response:", result);

      if (!response.ok) {
        throw new Error(
          result?.message || `Server error: ${response.status} - ${JSON.stringify(result.errors || result)}`
        );
      }

      toast.success(result.message || "Grievance submitted successfully");

      const grievanceId = result.data?.id || `GRV-${Date.now()}`;
      setReferenceId(grievanceId);

      setGrievances((prev) => [
        ...prev,
        {
          id: grievanceId,
          title: formData.title || "",
          type: formData.grievanceType || "",
          description: formData.description || "",
          urgency: formData.urgencyLevel || "Medium",
          state: formData.state || "",
          lga: formData.lga || "",
          complainant: formData.complainant || "",
          hostCommunity: formData.hostCommunity || "",
          company: formData.company || "",
          grieviance_date: formData.grievanceDate || "",
          status: result.data?.status || "In Progress",
          reportDate: formData.grievanceDate || "",
          oml: formData.oml || "",
        },
      ]);

      setStep(6);
      try {
        await fetchGrievances();
      } catch (refreshErr) {
        console.error("Failed to refresh grievances after create:", refreshErr);
        toast.warn("Grievance created, but failed to refresh list.");
      }
    } catch (err) {
      console.error("Create grievance error:", err);
      setApiError(err.message || "Submission failed. Please try again.");
      toast.error(err.message || "Failed to submit grievance");
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdate = (updatedGrievance) => {
    setGrievances((prev) =>
      prev.map((grievance) =>
        grievance.id === updatedGrievance.id ? { ...grievance, ...updatedGrievance } : grievance
      )
    );
    console.log("Updated grievance:", updatedGrievance);
    fetchGrievances().catch((err) => {
      console.error("Failed to refresh grievances after update:", err);
      toast.warn("Grievance updated, but failed to refresh list.");
    });
  };

  const handleDelete = (id) => {
    setGrievances((prev) => prev.filter((g) => g.id !== id));
    fetchGrievances().catch((err) => {
      console.error("Failed to refresh grievances after delete:", err);
      toast.warn("Grievance deleted, but failed to refresh list.");
    });
  };

  useEffect(() => {
    console.log("Fetching grievances on mount");
    fetchGrievances();
  }, []);

  const handleOpenFilterModal = () => {
    setIsFilterModalOpen(true);
  };

  const handleCloseFilterModal = () => {
    setIsFilterModalOpen(false);
  };

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleClearFilter = (key) => {
    setFilters((prev) => ({ ...prev, [key]: "" }));
    setCurrentPage(1);
  };

  const handleResetFilters = () => {
    setFilters({ type: "", status: "", severity: "" });
    setCurrentPage(1);
  };

  const handleApplyFilters = () => {
    console.log("Applying filters:", filters);
    setIsFilterModalOpen(false);
    setCurrentPage(1);
  };

  const filteredGrievances = useMemo(() => {
    return grievances.filter((grievance) => {
      const matchesType =
        !filters.type ||
        (grievance.type &&
          filters.type.toLowerCase() === String(grievance.type).toLowerCase());
      const matchesStatus =
        !filters.status ||
        (grievance.status &&
          filters.status.toLowerCase() === String(grievance.status).toLowerCase());
      const matchesMonthYear =
  !filters.monthYear ||
  (grievance.grieviance_date &&
    grievance.grieviance_date.startsWith(filters.monthYear));

      const matchesSeverity =
        !filters.severity ||
        (grievance.urgency &&
          filters.severity.toLowerCase() === String(grievance.urgency).toLowerCase());
      return matchesType && matchesStatus && matchesSeverity && matchesMonthYear;

    });
  }, [grievances, filters]);

  const resolvedCount = filteredGrievances.filter((g) => g.status?.toLowerCase() === "resolved").length;
  const inProgressCount = filteredGrievances.filter((g) => g.status?.toLowerCase() === "in progress").length;
  const unresolvedCount = filteredGrievances.filter(
    (g) => g.status?.toLowerCase() !== "resolved" && g.status?.toLowerCase() !== "in progress"
  ).length;

  const totalFiltered = filteredGrievances.length;
  const totalPages = Math.ceil(totalFiltered / pageSize);
  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, totalFiltered);
  const paginatedGrievances = filteredGrievances.slice(start - 1, end);

  return (
    <div>
      <div className="flex justify-between items-center py-3 bg-white">
        <h1 className="text-lg font-medium text-[#292929]">Grievance Management</h1>
        <div className="flex items-center space-x-3">
          <img src="/facenotif.svg" alt="chat" width={20} height={32} />
          <img src="/notif.svg" alt="notification" width={20} height={32} />
          <div className="flex items-center border border-gray-100 rounded-full p-[1px]">
            <img src="/memoji.svg" alt="profile" width={16} height={32} className="mr-1" />
            <FiChevronDown className="w-3 h-3 text-gray-600" />
          </div>
        </div>
      </div>
      <hr className="-mt-1 border-gray-200" />

      <div className="pt-6">
        <div className="bg-white p-3 rounded-md mb-3 border border-gray-200">
          {apiError && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded mb-4 text-sm">
              {apiError}
            </div>
          )}
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-4 flex-wrap">
              <h2 className="text-lg font-semibold text-gray-900">Record History</h2>
              <div className="relative ml-4">
                <input
                  type="text"
                  placeholder="Search title, name..."
                  className="w-48 h-8 pr-8 pl-2 border border-gray-100 rounded-[6px] focus:outline-none font-light text-sm focus:ring-1 focus:ring-blue-500"
                />
                <img
                  src="/search.svg"
                  alt="search"
                  width={14}
                  height={14}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                />
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap ml-auto">
              <div className="flex items-center gap-1">
                <span className="text-xs text-gray-600">
                  {totalFiltered === 0 ? "0–0" : `${start}–${end}`} of {totalFiltered}
                </span>
                <button
                  className="text-gray-600 hover:text-black px-0.5"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                >
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <button
                  className="text-gray-600 hover:text-black px-0.5"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((prev) => prev + 1)}
                >
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              <div className="flex items-center gap-1 bg-[#E6F0FD] rounded-[6px] p-0.5 transition-all duration-300">
                <button
                  onClick={() => setViewMode("list")}
                  className={`p-1.5 rounded-md transition-all duration-300 ${viewMode === "list" ? "bg-[#1B5FC1] text-white" : "bg-[#E6F0FD] text-[#1B5FC1]"}`}
                >
                  <FiList className="w-3 h-3" />
                </button>
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-1.5 rounded-md transition-all duration-300 ${viewMode === "grid" ? "bg-[#1B5FC1] text-white" : "bg-[#E6F0FD] text-[#1B5FC1]"}`}
                >
                  <FiGrid className="w-3 h-3" />
                </button>
              </div>
              <button
                onClick={handleOpenFilterModal}
                className=" border-gray-300 border text-black p-1.5 rounded-[6px] flex items-center gap-1 text-xs hover:bg-[#d3e3fd]"
              >
                 Filter
                <FiFilter className="w-3 h-3" />
               
              </button>
              
   <div className="relative w-20">
  <DatePicker
    selected={filters.monthYear ? new Date(filters.monthYear + "-01") : null}
    onChange={(date) => {
      if (date) {
        const formatted = format(date, "yyyy-MM");
        setFilters((prev) => ({ ...prev, monthYear: formatted }));
        setCurrentPage(1);
      }
    }}
    dateFormat="MMMM yyyy"
    showMonthYearPicker
    placeholderText="Jan, 2025"
    className="border-gray-300 border text-xs text-black w-full px-2 py-1.5 pr-6 rounded-[6px] hover:bg-[#d3e3fd] cursor-pointer"
  />
  <img
    src="/arrow.svg"
    alt="arrow"
    className="absolute right-2 top-1/2 transform -translate-y-1/2 w-3 h-3 pointer-events-none"
  />
</div>



              <button
                type="button"
                className="bg-[#1B5FC1] hover:bg-blue-700 text-white text-xs h-8 px-2 flex items-center rounded-[6px]"
                onClick={handleAddNew}
              >
                <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                    clipRule="evenodd"
                  />
                </svg>
                Add New
              </button>
            </div>
          </div>

          <p className="text-sm mt-3 flex flex-wrap items-center space-x-4">
            <span>
              Total No of Grievance: <span>{totalFiltered}</span>
            </span>
            <span>
              Resolved: <span className="font-bold text-[#34A853]">{resolvedCount}</span>
            </span>
            <span>
              In Progress: <span className="font-bold text-[#EB8A00]">{inProgressCount}</span>
            </span>
            <span>
              Unresolved: <span className="font-bold text-[#EB4335]">{unresolvedCount}</span>
            </span>
          </p>

          <GrievanceTable
            grievances={paginatedGrievances}
            viewMode={viewMode}
            onDelete={handleDelete}
            onUpdate={handleUpdate}
            fetchGrievances={fetchGrievances}
          />

          {!filteredGrievances.length && !showForm && (
            <div className="flex flex-col items-center justify-center py-[10%] text-gray-500">
              <img src="/book.svg" alt="empty" width={150} height={40} />
              <p className="font-medium text-[20px] text-[#292929]">No grievance record</p>
              <p className="text-xs text-[#707070]">Use the "Add New" button</p>
            </div>
          )}
          {showForm && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
              <div className="bg-white w-full max-w-md rounded-md shadow-lg overflow-hidden">
                {step === 1 && (
                  <GrievanceStep1
                    formData={formData}
                    onChange={(name, value) => setFormData((prev) => ({ ...prev, [name]: value }))}
                    onNext={handleNextStep}
                    onClose={handleCloseForm}
                  />
                )}
                {step === 2 && (
                  <GrievanceStep2
                    formData={formData}
                    onChange={(name, value) => setFormData((prev) => ({ ...prev, [name]: value }))}
                    onNext={handleNextStep}
                    onBack={handlePreviousStep}
                    onClose={handleCloseForm}
                  />
                )}
                {step === 3 && (
                  <GrievanceStep3
                    formData={formData}
                    onChange={(data) => setFormData((prev) => ({ ...prev, ...data }))}
                    onNext={handleNextStep}
                    onBack={handlePreviousStep}
                    onClose={handleCloseForm}
                  />
                )}
                {step === 4 && (
                  <GrievanceStep4
                    formData={formData}
                    onChange={(data) => setFormData((prev) => ({ ...prev, ...data }))}
                    onNext={handleNextStep}
                    onBack={handlePreviousStep}
                    onClose={handleCloseForm}
                  />
                )}
                {step === 5 && (
                  <ConfirmationModal
                    onConfirm={handleSubmit}
                    onCancel={() => setStep(4)}
                    onClose={handleCloseForm}
                    data={formData}
                  />
                )}
                {step === 6 && (
                  <SuccessModal
                    referenceId={referenceId}
                    onClose={handleCloseForm}
                  />
                )}
                {isLoading && (
                  <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-60">
                    <svg
                      className="w-6 h-6 animate-spin text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                  </div>
                )}
              </div>
            </div>
          )}
          {/* {isFilterModalOpen && (

            <FilterModal
              onClose={handleCloseFilterModal}
              types={grievanceTypes}
              statuses={statuses}
              severities={severities}
              current={filters}
              onChange={handleFilterChange}
              onClear={handleClearFilter}
              onReset={handleResetFilters}
              onApply={handleApplyFilters}
            />
          )} */}


          {isFilterModalOpen && (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <FilterModal
      onClose={handleCloseFilterModal}
      types={grievanceTypes}
      statuses={statuses}
      severities={severities}
      current={filters}
      onChange={handleFilterChange}
      onClear={handleClearFilter}
      onReset={handleResetFilters}
      onApply={handleApplyFilters}
    />
  </div>
)}

        </div>
      </div>
    </div>
  );
}

export default GrievanceManagement;