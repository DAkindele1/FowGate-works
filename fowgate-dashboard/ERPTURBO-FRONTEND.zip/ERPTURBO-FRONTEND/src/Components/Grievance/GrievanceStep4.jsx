

import React, { useState } from "react";
import toast from "react-hot-toast";

const GrievanceStep4 = ({ formData, onChange, onNext, onBack, onClose }) => {
  const [showGrievanceInfo, setShowGrievanceInfo] = useState(false);
  const [showLocationInfo, setShowLocationInfo] = useState(false);
  const [showSupportingInfo, setShowSupportingInfo] = useState(false);
  const [loading, setLoading] = useState(false);

  // No validation function — all fields optional now

  const handleNext = () => {
    setLoading(true);
    // No validation errors to clear
    onNext(); // Proceed with submission
    setLoading(false);
  };
 
  return (
    <div className="flex items-center   justify-center backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-[#1B5FC1] h-[80px] px-6 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
            <h2 className="text-white text-lg font-semibold">Add New </h2>
          </div>
          <button onClick={onClose} className="text-white text-2xl font-bold focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto px-4 py-5 flex-grow bg-transparent">
          {loading && (
            <div className="flex justify-center mb-4">
              <svg className="w-6 h-6 animate-spin text-blue-500" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
            </div>
          )}

          {/* Step Indicator */}
          <div className="flex items-center text-gray-500 mb-6">
            <img src="/four.svg" alt="step" className="w-4 h-4 mr-2" />
            <span className="text-black">
              4/4 - <span className="font-bold">PREVIEW & SUBMIT</span>
            </span>
          </div>
          <hr className="border-t border-gray-100 my-3" />

          {/* Reporting Officer Details */}
          <div className="bg-white rounded-lg border border-gray-300 overflow-hidden">
            <h3 className="bg-[#F1F1F1] px-6 py-2 text-sm font-medium rounded-t-lg">
              Reporting Officer Details
            </h3>
            <hr className="border-gray-300" />
            <div className="px-6 py-4 text-sm space-y-4">
              {[
                ["Name of CLO", formData.cloName || "Not Provided"],
                ["OML", formData.oml || "Not Provided"],
                ["Cluster/Host Community", formData.hostCommunity || "Not Provided"],
                ["Company", formData.company || "Not Provided"],
                ["Date of Report", formData.grievanceDate || "Not Provided"],
                ["CLO Contact Number", formData.cloPhone || "Not Provided"],
              ]
                .reduce((rows, item, index) => {
                  if (index % 2 === 0) rows.push([item]);
                  else rows[rows.length - 1].push(item);
                  return rows;
                }, [])
                .map((row, i) => (
                  <div key={i} className="grid grid-cols-2 gap-4">
                    {row.map(([label, value], j) => (
                      <div key={j}>
                        <p className="text-gray-500 text-[12px]">{label}</p>
                        <p className="text-black">{value}</p>
                      </div>
                    ))}
                    {i < 2 && <div className="col-span-2"><hr className="border-gray-300 mt-2" /></div>}
                  </div>
                ))}
            </div>
          </div>

          {/* Grievance Information */}
          <div className="bg-white rounded-lg relative border border-gray-300 mt-4">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Grievance Information
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowGrievanceInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showGrievanceInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showGrievanceInfo && (
              <div className="grid grid-cols-2 gap-4 p-4 text-sm">
                <div>
                  <p className="text-gray-500 text-[12px]">Grievance Title</p>
                  <p className="text-black">{formData.grievanceTitle || "Not Provided"}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-[12px]">Urgency Level</p>
                  <p className="text-black flex items-center">
                    {formData.urgencyLevel || "Not Provided"}
                    {formData.urgencyLevel === "High" && (
                      <span className="ml-1 text-red-500 text-xs">!!</span>
                    )}
                  </p>
                </div>
                <hr className="border-gray-300 col-span-2" />
                <div className="col-span-2">
                  <p className="text-gray-500 text-[12px]">Grievance Type</p>
                  <p className="text-black">{formData.grievanceType || "Not Provided"}</p>
                </div>
                <hr className="border-gray-300 col-span-2" />
                <div className="col-span-2">
                  <p className="text-gray-500 text-[12px]">Description</p>
                  <p className="text-black">{formData.description || "Not Provided"}</p>
                </div>
              </div>
            )}
          </div>

          {/* Location Details */}
          <div className="bg-white rounded-lg relative border border-gray-300 mt-4">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Location Details
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowLocationInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showLocationInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showLocationInfo && (
              <div className="px-4 py-4 text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-500 text-[12px]">State</p>
                    <p className="text-black">{formData.state || "Not Provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">LGA</p>
                    <p className="text-black">{formData.lga || "Not Provided"}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-500 text-[12px]">Community/Area</p>
                    <p className="text-black">{formData.community || "Not Provided"}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Supporting Information */}
          <div className="bg-white rounded-lg relative border border-gray-300 mt-4">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Supporting Information
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowSupportingInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showSupportingInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showSupportingInfo && (
              <div className="px-4 py-4 text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-500 text-[12px]">Complainant</p>
                    <p className="text-black">{formData.complainant || "Not Provided"}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                    <div className="text-black">
                      {Array.isArray(formData.attachment) && formData.attachment.length > 0 ? (
                        <ul className="list-disc pl-4">
                          {formData.attachment.map((file, idx) => (
                            <li key={idx}>{file.name || file.filename || (typeof file === 'string' ? file : 'File')}</li>
                          ))}
                        </ul>
                      ) : formData.attachment && (formData.attachment.name || formData.attachment.filename) ? (
                        <span>{formData.attachment.name || formData.attachment.filename}</span>
                      ) : (
                        <span>Not Provided</span>
                      )}
                    </div>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-500 text-[12px]">Signature</p>
                    {formData.signature ? (
                      <img
                        src={formData.signature}
                        alt="Signature"
                        className="h-10 object-contain"
                      />
                    ) : (
                      <p className="text-black">Not Provided</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            type="button"
            onClick={onBack}
            className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
            disabled={loading}
          >
            Prev
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
            disabled={loading}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default GrievanceStep4;