

import React, { useState, useRef, useEffect } from "react";
import toast from "react-hot-toast";

const FileUpload = ({ attachments, onChange }) => {
  const fileInputRef = useRef(null);

  const maxSize = 5 * 1024 * 1024;
  const allowedTypes = [
    "image/jpeg", "image/png", "image/gif", "video/mp4", "video/mpeg",
    "audio/mpeg", "audio/wav", "application/pdf", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ];

  const validateFile = (file) => {
    if (!file) return false;
    if (file.size > maxSize) {
      toast.error(`${file.name} exceeds 5MB limit.`);
      return false;
    }
    if (!allowedTypes.includes(file.type)) {
      toast.error(`${file.name} has an invalid file type.`);
      return false;
    }
    return true;
  };

  const handleFiles = (fileList) => {
    const validFiles = Array.from(fileList).filter((file) => validateFile(file));
    console.log(validFiles)
    if (validFiles.length) {
      onChange?.({ target: { name: "attachments", value: validFiles } });
    }
  };

  const handleInputChange = (e) => {
    const file = e.target.files;
    handleFiles(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files;
    handleFiles(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  useEffect(() => {
    console.log(attachments);
  }, (attachments))

  return (
    <div
      className="mt-0 flex justify-center px-6 pt-5 pb-6 border-2 border-[#1B5FC1] border-dashed rounded-[3px] bg-blue-50"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <div className="space-y-1 text-center">
        <img src="/upload.svg" alt="upload" className="mx-auto h-12 w-12" />
        <div className="flex text-sm text-gray-600 justify-center">
          <span className="mr-1 font-bold">Drag and drop file or</span>
          <a
            href="#"
            className="text-blue-600 underline font-bold"
            onClick={(e) => {
              e.preventDefault();
              fileInputRef.current.click();
            }}
          >
            Browse
          </a>
        </div>
        <p className="text-xs text-gray-500">Max 5MB – Images, Video, Audio, Documents</p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept="image/*,video/*,audio/*,application/pdf,.doc,.docx"
          onChange={handleInputChange}
          multiple
        />
        {attachments?.length > 0 && (
          <ul className="text-xs text-gray-600 mt-2 space-y-1">
            {attachments.map((file, index) => (
              <li key={index}>• {file.name}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

function GrievanceStep3({ formData = {}, onChange, onNext, onBack, onClose }) {
  const [localFormData, setLocalFormData] = useState({
    complainant: formData.complainant || "",
    cloName: formData.cloName || "",
    oml: formData.oml || "",
    hostCommunity: formData.hostCommunity || "",
    company: formData.company || "",
    cloPhone: formData.cloPhone || "",
    grievanceDate: formData.grievanceDate || "",
    signature: formData.signature || "",
    attachment: formData.attachment || [],
  });
  const [errors, setErrors] = useState({});

  // Static list of complainants
  const complainants = [
    { id: "1", name: "Alfred Beckett" },
    { id: "2", name: "Jane Doe" },
    { id: "3", name: "John Smith" },
  ];

  // Validation function
  const validateForm = () => {
    const newErrors = {};
    if (!localFormData.complainant) newErrors.complainant = "Complainant is required.";
    if (!localFormData.cloName) newErrors.cloName = "CLO Name is required.";
    if (!localFormData.oml) newErrors.oml = "OML is required.";
    if (!localFormData.hostCommunity) newErrors.hostCommunity = "Host Community is required.";
    if (!localFormData.company) newErrors.company = "Company is required.";
    if (!localFormData.cloPhone) newErrors.cloPhone = "CLO Phone Number is required.";
    if (!localFormData.grievanceDate) newErrors.grievanceDate = "Grievance Date is required.";
    //if (!localFormData.signature) newErrors.signature = "Signature is required.";
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLocalFormData((prev) => {
      const newState = { ...prev, [name]: value };
      console.log("localFormData updated:", newState);
      return newState;
    });
    // onChange({ target: { name, value } });
    onChange(localFormData);
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const handleFileChange = ({ target: { name, value } }) => {
    setLocalFormData((prev) => {
      console.log(name, " : ", value)
      const newState = { ...prev, [name]: value };
      console.log("localFormData updated with files:", newState);
      return newState;
    });
    // onChange({ target: { name, value } });
    onChange(localFormData);
    setErrors((prev) => ({ ...prev, attachment: "" }));
  };

  const handleNext = () => {
    // const validationErrors = validateForm();
    // if (Object.keys(validationErrors).length > 0) {
    //   setErrors(validationErrors);
    //   toast.error("Please fill in all required fields.");
    //   return;
    // }
    console.log("Next button clicked, passing localFormData:", localFormData);
    onNext(localFormData);
  };

  return (
    <div className="flex items-center   justify-center backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="add" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Add New</h2>
          </div>
          <button onClick={onClose} className="text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="px-4 py-3 overflow-y-auto flex-1">
          <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
            <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
              <img src="/four.svg" alt="one" width={20} height={20} />
            </span>
            <span className="text-black">
              3/4 - <span className="font-bold">PROJECT STAKEHOLDERS</span>
            </span>
          </div>
          <hr className="border-t border-gray-300 my-3" />

          <div className="space-y-4 text-sm">
            {/* Complainant */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Complainant</label>
              <div className="relative mt-1">
                <select
                  name="complainant"
                  value={localFormData.complainant}
                  onChange={handleChange}
                  className={`w-full border ${errors.complainant ? "border-red-500" : "border-gray-300"
                    } rounded-[6px] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                >
                  <option value="">Select Complainant</option>
                  {complainants.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
                {/* <svg
                  className="absolute right-3 top-2.5 text-gray-500 pointer-events-none"
                  width="20"
                  height="20"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg> */}
                {errors.complainant && (
                  <p className="text-red-500 text-xs mt-1">{errors.complainant}</p>
                )}
              </div>
            </div>

            {/* Attachment */}
            <div>
              
              <label className="block text-sm text-gray-700 mb-1">Required Attachment</label>
              <FileUpload
                attachments={localFormData.attachment || []}
                onChange={handleFileChange}
              />
              {/* {errors.attachment && <p className="text-red-500 text-xs mt-1">{errors.attachment}</p>} */}
            </div>

            <div className="flex gap-4 w-full">
  {/* Grievance Date with calendar.svg as the only clickable icon */}
  
  {/* Signature with Inline Append Button */}
  <div className="w-1/2">  

    <label className="block text-sm text-gray-700 mb-1">Signature</label>
    <div className="relative">
      <input
        type="text"
        name="signature"
        value={localFormData.signature}
        onChange={handleChange}
        className={`w-full border ${
          errors.signature ? "border-red-500" : "border-gray-300"
        } rounded-[3px] px-3 py-2 pr-[130px] text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
      />
      <button
        type="button"
        onClick={() =>
          setLocalFormData((prev) => ({
            ...prev,
            signature: prev.signature || "Signed by CLO",
          }))
        }
        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-[16px] text-blue-500  px-3 py-1 rounded-[4px] transition"
      >
        + Append Signature
      </button>
    </div>
    {errors.signature && (
      <p className="text-red-500 text-xs mt-1">{errors.signature}</p>
    )}
  </div>
  <div className="w-1/2">
    <label className="block text-sm text-gray-700 mb-1">Grievance Date</label>
    <div className="relative w-full">
      {/* Hidden input for triggering calendar */}
      <input
        ref={(el) => (window.__grievanceDateInput = el)}
        type="date"
        name="grievanceDate"
        value={localFormData.grievanceDate}
        onChange={handleChange}
        className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
      />
      {/* Styled read-only box */}
      <div className="w-full border border-gray-300 rounded-[6px] px-3 py-2 text-sm text-gray-900 bg-white flex items-center justify-between">
        <span>
          {localFormData.grievanceDate
            ? new Date(localFormData.grievanceDate).toLocaleDateString()
            : "dd/mm/yyyy"}
        </span>
        <img
          src="/calendar.svg"
          alt="calendar"
          className="w-4 h-4 cursor-pointer"
          onClick={() => window.__grievanceDateInput?.showPicker()}
        />
      </div>
    </div>
    {errors.grievanceDate && (
      <p className="text-red-500 text-xs mt-1">{errors.grievanceDate}</p>
    )}
  </div>

</div>

          </div>
        </div>

        {/* Footer */}
        <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            type="button"
            onClick={onBack}
            className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
          >
            Prev
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export default GrievanceStep3;
