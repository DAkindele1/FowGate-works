// import React, { useState, useRef } from "react";
// import Picker from "emoji-picker-react"; // npm install emoji-picker-react

// function ThreadPopup({ isOpen, onClose, grievance, commentCount, comments = [], onAddComment }) {

//   const [newComment, setNewComment] = useState("");
//   const [showEmojiPicker, setShowEmojiPicker] = useState(false);
//   const fileInputRef = useRef(null);

//   if (!isOpen || !grievance) return null;

//   const handleEmojiClick = (emojiData) => {
//     setNewComment((prev) => prev + emojiData.emoji);
//     setShowEmojiPicker(false);
//   };

//   const handleFileClick = () => {
//     fileInputRef.current.click();
//   };

//   const handleFileChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       setNewComment((prev) => prev + ` [Attached: ${file.name}]`);
//     }
//   };

//   const handleAddComment = () => {
//     if (newComment.trim()) {
//       onAddComment(newComment); // Call the callback with the new comment
//       setNewComment(""); // Clear the input
//     }
//   };

//   return (
//     <div
//       className={`fixed top-0 right-0 h-full w-[420px] bg-white z-50 shadow-lg border-l border-gray-200 transition-transform duration-300 ease-in-out ${
//         isOpen ? "translate-x-0" : "translate-x-full"
//       }`}
//     >
//       {/* Header */}
//       <div className="flex justify-between items-center px-6 py-4 border-b border-gray-200">
//         <h2 className="text-xl font-semibold">Thread ({commentCount})</h2>
//       </div>

//       {/* Chat Box */}
//       <div className="px-6 py-4 border-b border-gray-200">
//         <div className="flex space-x-3">
//           <img src="/avatar-default.svg" className="w-10 h-10 rounded-full" alt="User avatar" />
//           <div className="flex-1 relative">
//             <textarea
//               value={newComment}
//               onChange={(e) => setNewComment(e.target.value)}
//               maxLength={500}
//               placeholder="Type your comment here…."
//               rows={4}
//               className="w-full p-3 pr-20 border rounded-md text-sm resize-none focus:outline-none focus:ring-1 focus:ring-blue-500"
//             />
//             {/* Icons inside text area (absolute) */}
//             <div className="absolute bottom-2 left-3 flex space-x-2">
//               <img
//                 src="/emoji-icon.svg"
//                 alt="emoji"
//                 onClick={() => setShowEmojiPicker(!showEmojiPicker)}
//                 className="w-5 h-5 cursor-pointer opacity-70 hover:opacity-100"
//               />
//               <img
//                 src="/mention-icon.svg"
//                 alt="@mention"
//                 onClick={() => alert("@ Mention triggered")}
//                 className="w-5 h-5 cursor-pointer opacity-70 hover:opacity-100"
//               />
//               <img
//                 src="/attachment-icon.svg"
//                 alt="attach"
//                 onClick={handleFileClick}
//                 className="w-5 h-5 cursor-pointer opacity-70 hover:opacity-100"
//               />
//               <input
//                 type="file"
//                 ref={fileInputRef}
//                 className="hidden"
//                 onChange={handleFileChange}
//               />
//             </div>
//             {/* Character count inside textarea bottom-right */}
//             <span className="absolute bottom-2 right-3 text-[11px] text-gray-400">
//               {newComment.length}/500
//             </span>
//           </div>
//         </div>

//         {/* Emoji Picker (optional) */}
//         {showEmojiPicker && (
//           <div className="relative z-10 mt-2">
//             <Picker onEmojiClick={handleEmojiClick} width={300} />
//           </div>
//         )}

//         {/* Add Comment Button (outside box) */}
//         <button
//           className="mt-4 bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700 float-right"
//           onClick={handleAddComment}
//         >
//           Add Comment
//         </button>
//         <div className="clear-both" />
//       </div>

//       {/* Tabs */}
//       <div className="flex items-center space-x-6 px-6 py-3 border-b border-gray-200 text-sm">
//         <div className="text-blue-600 font-medium border-b-2 border-blue-600 pb-1">
//           Comments ({commentCount})
//         </div>
//         <div className="text-gray-400">Activity (0)</div>
//       </div>

//       {/* Comments Section */}
//       {/* <div className="px-6 py-4 space-y-6 max-h-[calc(100vh-350px)] overflow-y-auto">
//         {grievance.comments?.length > 0 ? (
//           grievance.comments.map((comment, idx) => (
//             <div key={idx}>
//               <div className="flex space-x-3 items-start">
//                 <img
//                   src={comment.avatar || "/avatar-default.svg"}
//                   alt="avatar"
//                   className="w-8 h-8 rounded-full"
//                 />
//                 <div className="flex-1">
//                   <div className="flex justify-between items-center">
//                     <span className="font-semibold text-sm text-[#0047B0]">
//                       {comment.author || "CLO’s Name"}
//                     </span>
//                     <span className="text-[11px] text-gray-500">
//                       {comment.date || "11 Dec, 2024, 4:17 PM"}
//                     </span>
//                   </div>
//                   <p className="text-sm mt-1 text-gray-700">{comment.text}</p>
//                 </div>
//               </div>
//             </div>
//           ))
//         ) : (
//           <p className="text-sm text-gray-500">No comments yet.</p>
//         )}
//       </div> */}

//       {/* Comments Section */}
// <div className="px-6 py-4 space-y-6 max-h-[calc(100vh-350px)] overflow-y-auto">
//   {comments.length > 0 ? (
//     comments.map((comment, idx) => (
//       <div key={idx}>
//         <div className="flex space-x-3 items-start">
//           <img
//             src={comment.avatar || "/avatar-default.svg"}
//             alt="avatar"
//             className="w-8 h-8 rounded-full"
//           />
//           <div className="flex-1">
//             <div className="flex justify-between items-center">
//               <span className="font-semibold text-sm text-[#0047B0]">
//                 {comment.employee_code || "User"}
//               </span>
//               <span className="text-[11px] text-gray-500">
//                 {new Date(comment.created_at).toLocaleString() || "—"}
//               </span>
//             </div>
//             <p className="text-sm mt-1 text-gray-700">{comment.message}</p>
//           </div>
//         </div>
//       </div>
//     ))
//   ) : (
//     <p className="text-sm text-gray-500">No comments yet.</p>
//   )}
// </div>


//       {/* Bottom Close Button */}
//       <div className="border-t p-4 flex justify-end">
//         <button
//           onClick={onClose}
//           className="bg-gray-100 px-4 py-2 rounded text-sm text-blue-600 hover:bg-gray-200"
//         >
//           Close
//         </button>
//       </div>
//     </div>
//   );
// }

// export default ThreadPopup;












import React, { useState, useRef } from "react";
import Picker from "emoji-picker-react"; // npm install emoji-picker-react


function ThreadPopup({ isOpen, onClose, grievance, thread = [], commentCount, onAddComment }) {
  const [newComment, setNewComment] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [optimisticComments, setOptimisticComments] = useState([]);
  const fileInputRef = useRef(null);

  React.useEffect(() => {
    // Reset optimistic comments when grievance or thread changes or popup closes
    setOptimisticComments([]);
  }, [grievance, thread, isOpen]);

  if (!isOpen || !grievance) return null;

  const handleEmojiClick = (emojiData) => {
    setNewComment((prev) => prev + emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setNewComment((prev) => prev + ` [Attached: ${file.name}]`);
    }
  };

  const handleAddComment = (/* no event */) => {
    if (newComment.trim()) {
      // Optimistically add comment
      setOptimisticComments((prev) => [
        ...prev,
        {
          author: "You",
          date: new Date().toLocaleString(),
          text: newComment,
          avatar: "/avatar-default.svg",
          optimistic: true,
        },
      ]);
      onAddComment(newComment); // Call the callback with the new comment
      setNewComment(""); // Clear the input
    }
  };

  return (
    <div
      className={`fixed top-0 right-0 h-full w-[420px] bg-white z-50 shadow-lg border-l border-gray-200 transition-transform duration-300 ease-in-out flex flex-col ${
        isOpen ? "translate-x-0" : "translate-x-full"
      }`}
    >
      {/* Header */}
      <div className="flex justify-between items-center px-6 py-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold">Thread ({commentCount})</h2>
      </div>

      {/* Chat Box */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex space-x-3">
          <img src="/avatar-default.svg" className="w-10 h-10 rounded-full" alt="User avatar" />
          <div className="flex-1 relative">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              maxLength={500}
              placeholder="Type your comment here…."
              rows={4}
              className="w-full p-3 pr-20 border rounded-md text-sm resize-none focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            {/* Icons inside text area (absolute) */}
            <div className="absolute bottom-2 left-3 flex space-x-2">
              <img
                src="/emoji-icon.svg"
                alt="emoji"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="w-5 h-5 cursor-pointer opacity-70 hover:opacity-100"
              />
              <img
                src="/mention-icon.svg"
                alt="@mention"
                onClick={() => alert("@ Mention triggered")}
                className="w-5 h-5 cursor-pointer opacity-70 hover:opacity-100"
              />
              <img
                src="/attachment-icon.svg"
                alt="attach"
                onClick={handleFileClick}
                className="w-5 h-5 cursor-pointer opacity-70 hover:opacity-100"
              />
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileChange}
              />
            </div>
            {/* Character count inside textarea bottom-right */}
            <span className="absolute bottom-2 right-3 text-[11px] text-gray-400">
              {newComment.length}/500
            </span>
          </div>
        </div>

        {/* Emoji Picker (optional) */}
        {showEmojiPicker && (
          <div className="relative z-10 mt-2">
            <Picker onEmojiClick={handleEmojiClick} width={300} />
          </div>
        )}

        {/* Add Comment Button (outside box) */}
        <button
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700 float-right"
          onClick={handleAddComment}
        >
          Add Comment
        </button>
        <div className="clear-both" />
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-6 px-6 py-3 border-b border-gray-200 text-sm">
        <div className="text-blue-600 font-medium border-b-2 border-blue-600 pb-1">
          Comments ({commentCount})
        </div>
        <div className="text-gray-400">Activity (0)</div>
      </div>
  
      {/* Comments Section */}
      <div className="px-6 py-4 space-y-6 max-h-[calc(100vh-350px)] overflow-y-auto flex-1">
        {(thread.length > 0 || optimisticComments.length > 0) ? (
          [...thread, ...optimisticComments].reverse().map((comment, idx) => (
            <div key={idx}>
              <div className="flex space-x-3 items-start">
                <img
                  src={comment.avatar || "/avatar-default.svg"}
                  alt="avatar"
                  className="w-8 h-8 rounded-full"
                />
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-sm text-[#0047B0]">
                      {comment.author || comment.employee_code || "CLO’s Name"}
                    </span>
                    <span className="text-[11px] text-gray-500">
                      {comment.date || (comment.created_at ? new Date(comment.created_at).toLocaleString() : "—")}
                    </span>
                  </div>
                  <p className="text-sm mt-1 text-gray-700">{comment.text || comment.message}</p>
                  {comment.optimistic && (
                    <span className="text-xs text-gray-400 italic">Sending…</span>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-sm text-gray-500">No comments yet.</p>
        )}
      </div>

      {/* Bottom Close Button */}
      <div className="relative flex justify-end shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full ">
        <button
          onClick={onClose}
          className="bg-gray-100 px-4 py-2 rounded text-sm text-blue-600 hover:bg-gray-200"
        >
          Close
        </button>
      </div>
    </div>
  );
}

export default ThreadPopup;