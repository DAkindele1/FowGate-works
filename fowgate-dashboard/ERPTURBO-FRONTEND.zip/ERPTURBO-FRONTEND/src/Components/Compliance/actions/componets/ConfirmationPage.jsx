



import React from "react";

const ConfirmationPage = ({ onClose, onConfirm }) => {
  return (
    <div className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white w-full max-w-md rounded shadow-md">
        <div className="bg-[#1B5FC1] px-6 py-7 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/help.svg" alt="Info Icon" className="w-5 h-5" />
            <h3 className="text-white font-semibold text-[17px]">Confirm Action</h3>
          </div>
          <button onClick={onClose} className="text-white hover:text-gray-200">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="px-6 pt-6 pb-8 text-left text-gray-700 text-[13px] leading-relaxed">
          You're about to submit this incident report. Please ensure all
          <span className="block ml-[2px]">information is accurate and supporting files are attached.</span>
        </div>

        <div className="flex justify-end space-x-4 px-6 pb-6">
          <button
            onClick={onClose}
            className="text-gray-800 text-[15px] px-4 py-2 rounded-[4px] hover:bg-gray-100"
          >
            Close
          </button>
          <button
            onClick={onConfirm}
            className="bg-[#EAF1FD] text-[#1B5FC1] font-medium px-5 py-2 rounded-[6px] hover:bg-[#d5e6fc]"
          >
            Yes, I am
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationPage;