

// import React from 'react';
// import jsPDF from 'jspdf';
// import { FiDownload } from 'react-icons/fi';

// const PdfExportModal = ({ isOpen, onClose, incident }) => {
//   if (!isOpen) return null;

//   const handleDownload = () => {
//     const doc = new jsPDF();

//     const payload = {
//       type: Array.isArray(incident?.incidentType) ? incident.incidentType : [],
//       date: incident?.date || "Not specified",
//       time: incident?.time || "Not specified",
//       community_affected: incident?.communityAffected || "Not specified",
//       people_involved: Array.isArray(incident?.peopleInvolved) ? incident.peopleInvolved : [],
//       stakeholder_role: incident?.stakeholderRole || "",
//       number_of_people_involved: incident?.numberOfPeopleInvolved || 0,
//       actions_taken: Array.isArray(incident?.actionsTaken) ? incident.actionsTaken : [],
//       clo_response: incident?.cloResponse || "",
//       witnesses: Array.isArray(incident?.witnesses) ? incident.witnesses : [],
//       additional_notes: incident?.additionalNotes || "",
//       submitted_to: incident?.submittedTo || "",
//       follow_up_actions: Array.isArray(incident?.followUpActions) ? incident.followUpActions : [],
//       signature: true,
//       report_date: incident?.reportDate || ""
//     };

//     doc.setFontSize(12);
//     doc.text("Reporting Officer Details", 10, 10);
//     doc.text(`Name of CLO: ${incident?.cloName || "N/A"}`, 10, 20);
//     doc.text(`OML: ${incident?.oml || "N/A"}`, 10, 30);
//     doc.text(`Cluster/Host Community: ${incident?.community || "N/A"}`, 10, 40);
//     doc.text(`Company: ${incident?.company || "N/A"}`, 10, 50);
//     doc.text(`Date of Report: ${payload.report_date}`, 10, 60);
//     doc.text(`CLO Contact Number: ${incident?.cloPhone || "N/A"}`, 10, 70);

//     doc.text("Incident Overview", 10, 85);
//     doc.text(`Date of Incident: ${payload.date}`, 10, 95);
//     doc.text(`Time of Incident: ${payload.time}`, 10, 105);
//     doc.text(`Location: ${incident?.location || "N/A"}`, 10, 115);
//     doc.text(`Community Affected: ${payload.community_affected}`, 10, 125);

//     doc.text("Incident Type(s):", 10, 135);
//     let y = 145;

//     payload.type.forEach((type) => {
//       doc.text(`- ${type}`, 10, y);
//       y += 10;
//     });

//     doc.text("Stakeholder Role:", 10, y);
//     doc.text(payload.stakeholder_role || "None", 60, y);
//     y += 10;

//     doc.text(`# of People Involved: ${payload.number_of_people_involved}`, 10, y);
//     y += 10;

//     if (payload.people_involved.length) {
//       doc.text("People Involved:", 10, y);
//       payload.people_involved.forEach((p) => {
//         y += 10;
//         doc.text(`- ${p}`, 10, y);
//       });
//       y += 10;
//     }

//     if (payload.actions_taken.length) {
//       doc.text("Actions Taken:", 10, y);
//       payload.actions_taken.forEach((a) => {
//         y += 10;
//         doc.text(`- ${a}`, 10, y);
//       });
//       y += 10;
//     }

//     if (payload.clo_response) {
//       doc.text("CLO Response:", 10, y);
//       y += 10;
//       doc.text(payload.clo_response, 10, y);
//       y += 10;
//     }

//     if (payload.witnesses.length) {
//       doc.text("Witnesses:", 10, y);
//       payload.witnesses.forEach((w) => {
//         y += 10;
//         doc.text(`- ${w}`, 10, y);
//       });
//       y += 10;
//     }

//     if (payload.additional_notes) {
//       doc.text("Additional Notes:", 10, y);
//       y += 10;
//       doc.text(payload.additional_notes, 10, y);
//       y += 10;
//     }

//     if (payload.submitted_to) {
//       doc.text("Submitted To:", 10, y);
//       y += 10;
//       doc.text(payload.submitted_to, 10, y);
//     }

//     doc.save("incident_report.pdf");
//   };

//   return (
//    <div className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50" onClick={onClose}>
//       <div
//         className="bg-white w-full max-w-md rounded-[3px] shadow-lg overflow-y-auto max-h-[90vh] border"
//         onClick={(e) => e.stopPropagation()}
//       >
//         {/* Header */}
//         <div className="flex items-center justify-between bg-[#1B5FC1] text-white h-[80px] px-6">
//           <div className="flex items-center space-x-2">
//             <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
//             <h2 className="text-white text-lg font-semibold">Incident Overview</h2>
//           </div>
//           <button onClick={onClose} className="text-white text-xl font-bold">&times;</button>
//         </div>

//         {/* Content */}
//         <div className="px-6 py-4 text-sm text-gray-800 space-y-6">
//           {/* Officer Details */}
//           <div>
//             <div className="bg-[#dbe9fd] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
//               Reporting Officer Details
//             </div>
//             <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700">
//               <div>
//                 <p className="text-xs text-gray-500">Name of CLO</p>
//                 <p>{incident?.cloName || "Kingsley Tamuno"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">OML</p>
//                 <p>{incident?.oml || "OML 58"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Cluster/Host Community</p>
//                 <p>{incident?.community || "Rumueme Community"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Company</p>
//                 <p>{incident?.company || "NAOC (Nigerian Agip Oil Company)"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Date of Report</p>
//                 <p>{incident?.reportDate || "N?A"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">CLO Contact Number</p>
//                 <p>{incident?.cloPhone || "N/A"}</p>
//               </div>
//             </div>
//           </div>

//           {/* Incident Overview */}
//           <div>
//             <div className="bg-[#dbe9fd] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
//               Incident Overview
//             </div>
//             <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700">
//               <div>
//                 <p className="text-xs text-gray-500">Date of Incident</p>
//                 <p>{incident?.dateOfIncident || "N/A"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Time of Incident</p>
//                 <p>{incident?.timeOfIncident || "3:45 PM"}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Location</p>
//                 <p>{incident?.communityAffected || "Near Rumuokoro Pipeline Station..."}</p>
//               </div>
//               <div>
//                 <p className="text-xs text-gray-500">Community Affected</p>
//                 <p>{incident?.communityAffected || "Rumueme Community"}</p>
//               </div>
//               <div className="col-span-2">
//                 <p className="text-xs text-gray-500 mb-1">Incident Type</p>
//                 {/* <div className="flex flex-wrap gap-2">
//                   {Array.isArray(incident?.incidentType) && incident.incidentType.length ? (
//                     incident.incidentType.map((type, idx) => (
//                       <span
//                         key={idx}
//                         className="bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full"
//                       >
//                         {type}
//                       </span>
//                     ))
//                   ) : (
//                     <>
//                       <span className="bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full">Community Protest/Demonstration</span>
//                       <span className="bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full">Access Restriction/Site Shutdown</span>
//                       <span className="bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full">Security Breach or Threat</span>
//                     </>
//                   )}
//                 </div> */}

// <div>
//   <label className="block text-sm text-gray-700 mb-1">Incident Type</label>
//   <div className=" bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full">
//     <span className={`truncate ${!incident?.incidentType ? 'text-gray-400 italic' : 'text-gray-900'}`}>
//       {incident?.incidentType || 'No incident type provided'}
//     </span>
//   </div>
// </div>

                
//               </div>
//             </div>
//           </div>
//                       {/* Parties Involved */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#dbe9fd] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Parties Involved
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowPartiesInvolved((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showPartiesInvolved ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showPartiesInvolved && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Names or Groups Involved</p>
//                   <div className="flex flex-wrap gap-2 mb-2">
//                     {Array.isArray(formData?.peopleInvolved) && formData.peopleInvolved.length > 0 ? (
//                       formData.peopleInvolved.map((person, index) => (
//                         <p key={index} className="text-black">
//                           {person}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <p className="text-gray-500 text-[12px]">Stakeholder Role</p>
//                   <div className="flex flex-wrap gap-2 mb-2">
//                     {Array.isArray(formData?.stakeholderRole) && formData.stakeholderRole.length > 0 ? (
//                       formData.stakeholderRole.map((role, index) => (
//                         <p key={index} className="text-black">
//                           {role}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">{formData?.stakeholderRole || "Not provided"}</p>
//                     )}
//                   </div>
//                   <p className="text-gray-500 text-[12px]">Number of People Involved</p>
//                   <p className="text-black">{formData?.numberOfPeopleInvolved || "Not provided"}</p>
//                 </div>
//               )}
//             </div>

//             {/* Action Taken */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#dbe9fd] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Action Taken
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowActionTaken((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showActionTaken ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showActionTaken && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Immediate Action Taken</p>
//                   <div className="space-y-2">
//                     {Array.isArray(formData?.actionsTaken) && formData.actionsTaken.length > 0 ? (
//                       formData.actionsTaken.map((action, index) => (
//                         <p key={index} className="text-black">
//                           {action}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Details of CLO's Response</p>
//                   <p className="text-black">{formData?.cloResponse || "Not provided"}</p>
//                 </div>
//               )}
//             </div>

//             {/* Supporting Information */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#dbe9fd] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Supporting Information
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowSupportingInfo((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showSupportingInfo ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showSupportingInfo && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Witness Name</p>
//                   <p className="text-black">
//                     {Array.isArray(formData?.witnesses) && formData.witnesses.length > 0
//                       ? formData.witnesses.join(", ")
//                       : "Not provided"}
//                   </p>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
//                   <div className="space-y-1">
//                     {Array.isArray(formData?.uploadedEvidence) && formData.uploadedEvidence.length > 0 ? (
//                       formData.uploadedEvidence.map((evidence, index) => (
//                         <div key={index} className="flex justify-between items-center">
//                           <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
//                           <button className="text-red-500">X</button>
//                         </div>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Additional Notes</p>
//                   <p className="text-black">{formData?.additionalNotes || "Not provided"}</p>
//                 </div>
//               )}
//             </div>

//             {/* Escalation & Follow-Up */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#dbe9fd] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Escalation & Follow-Up
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowEscalationFollowUp((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showEscalationFollowUp ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showEscalationFollowUp && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Report Submitted To</p>
//                   <div className="flex flex-wrap gap-2 mb-2">
//                     {Array.isArray(formData?.submittedTo) && formData.submittedTo.length > 0 ? (
//                       formData.submittedTo.map((recipient, index) => (
//                         <p key={index} className="text-black">
//                           {recipient}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">{formData?.submittedTo || "Not provided"}</p>
//                     )}
//                   </div>
//                   <p className="text-gray-500 text-[12px]">Follow-Up Actions Recommended</p>
//                   <div className="space-y-1">
//                     {Array.isArray(formData?.followUpActions) && formData.followUpActions.length > 0 ? (
//                       formData.followUpActions.map((action, index) => (
//                         <p key={index} className="text-black">
//                           {action}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <div className="flex items-center mt-4">
//                     <div className="flex-1">
//                       <p className="text-gray-500 text-[12px]">Signature</p>
//                       <div className="flex items-center space-x-2">
//                         <img
//                           src={formData?.signature || "/signature-placeholder.png"}
//                           alt="Signature"
//                           className="w-20 h-auto"
//                         />
//                         <img src="/pen.svg" alt="Edit Signature" className="w-4 h-4" />
//                       </div>
//                     </div>
//                     <div className="ml-4">
//                       <p className="text-gray-500 text-[12px]">Date</p>
//                       <p className="text-black">
//                         {formData?.reportDate || "Not provided"}
//                         <img src="/calendar.svg" alt="Calendar" className="w-4 h-4 inline ml-1" />
//                       </p>
//                     </div>
//                   </div>
//                   <p className="text-black mt-2">{formData?.cloName || "Not provided"}</p>
//                 </div>
//               )}
//             </div>
//         </div>

//         {/* Footer */}
//         <div className="flex justify-end items-center px-6 py-4 bg-gray-50 rounded-b-lg space-x-2">
//           <button
//             onClick={handleDownload}
//             className="flex items-center gap-2 px-4 py-2 text-sm bg-white border border-gray-300 rounded hover:bg-gray-100"
//           >
//             <FiDownload className="text-gray-600" />
//             Download as PDF
//           </button>
//           <button
//             onClick={onClose}
//             className="px-4 py-2 text-sm bg-[#1C64F2] text-white rounded hover:bg-[#155cd1]"
//           >
//             Close
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PdfExportModal;















import React, { useState } from 'react';
import jsPDF from 'jspdf';
import { FiDownload } from 'react-icons/fi';

const PdfExportModal = ({ isOpen, onClose, incident }) => {
  // Initialize state for collapsible sections
  const [showPartiesInvolved, setShowPartiesInvolved] = useState(true);
  const [showActionTaken, setShowActionTaken] = useState(true);
  const [showSupportingInfo, setShowSupportingInfo] = useState(true);
  const [showEscalationFollowUp, setShowEscalationFollowUp] = useState(true);

  // Initialize formData state, defaulting to incident props or fallback values
  const [formData] = useState({
    cloName: incident?.cloName || 'Kingsley Tamuno',
    oml: incident?.oml || 'OML 58',
    community: incident?.community || 'Rumueme Community',
    company: incident?.company || 'NAOC (Nigerian Agip Oil Company)',
    reportDate: incident?.reportDate || 'N/A',
    cloPhone: incident?.cloPhone || 'N/A',
    date: incident?.date || 'Not specified',
    time: incident?.time || '3:45 PM',
    location: incident?.location || 'Near Rumuokoro Pipeline Station',
    communityAffected: incident?.communityAffected || 'Rumueme Community',
    incidentType: incident?.incidentType || 'No incident type provided',
    peopleInvolved: Array.isArray(incident?.peopleInvolved) ? incident.peopleInvolved : [],
    stakeholderRole: incident?.stakeholderRole || 'Not provided',
    numberOfPeopleInvolved: incident?.numberOfPeopleInvolved || 0,
    actionsTaken: Array.isArray(incident?.actionsTaken) ? incident.actionsTaken : [],
    cloResponse: incident?.cloResponse || 'Not provided',
    witnesses: Array.isArray(incident?.witnesses) ? incident.witnesses : [],
    additionalNotes: incident?.additionalNotes || 'Not provided',
    submittedTo: incident?.submittedTo || 'Not provided',
    followUpActions: Array.isArray(incident?.followUpActions) ? incident.followUpActions : [],
    signature: incident?.signature || '/signature-placeholder.png',
    uploadedEvidence: incident?.uploadedEvidence || [],
  });

  if (!isOpen) return null;

  const handleDownload = () => {
    const doc = new jsPDF();

    const payload = {
      type: Array.isArray(incident?.incidentType) ? incident.incidentType : [],
      date: incident?.date || 'Not specified',
      time: incident?.time || 'Not specified',
      community_affected: incident?.communityAffected || 'Not specified',
      people_involved: Array.isArray(incident?.peopleInvolved) ? incident.peopleInvolved : [],
      stakeholder_role: incident?.stakeholderRole || '',
      number_of_people_involved: incident?.numberOfPeopleInvolved || 0, // Fixed syntax error
      actions_taken: Array.isArray(incident?.actionsTaken) ? incident.actionsTaken : [],
      clo_response: incident?.cloResponse || '',
      witnesses: Array.isArray(incident?.witnesses) ? incident.witnesses : [],
      additional_notes: incident?.additionalNotes || '',
      submitted_to: incident?.submittedTo || '',
      follow_up_actions: Array.isArray(incident?.followUpActions) ? incident.followUpActions : [],
      signature: true,
      report_date: incident?.reportDate || '',
    };

    doc.setFontSize(12);
    doc.text('Reporting Officer Details', 10, 10);
    doc.text(`Name of CLO: ${incident?.cloName || 'N/A'}`, 10, 20);
    doc.text(`OML: ${incident?.oml || 'N/A'}`, 10, 30);
    doc.text(`Cluster/Host Community: ${incident?.community || 'N/A'}`, 10, 40);
    doc.text(`Company: ${incident?.company || 'N/A'}`, 10, 50);
    doc.text(`Date of Report: ${payload.report_date}`, 10, 60);
    doc.text(`CLO Contact Number: ${incident?.cloPhone || 'N/A'}`, 10, 70);

    doc.text('Incident Overview', 10, 85);
    doc.text(`Date of Incident: ${payload.date}`, 10, 95);
    doc.text(`Time of Incident: ${payload.time}`, 10, 105);
    doc.text(`Location: ${incident?.location || 'N/A'}`, 10, 115);
    doc.text(`Community Affected: ${payload.community_affected}`, 10, 125);

    doc.text('Incident Type(s):', 10, 135);
    let y = 145;

    payload.type.forEach((type) => {
      doc.text(`- ${type}`, 10, y);
      y += 10;
    });

    doc.text('Stakeholder Role:', 10, y);
    doc.text(payload.stakeholder_role || 'None', 60, y);
    y += 10;

    doc.text(`# of People Involved: ${payload.number_of_people_involved}`, 10, y);
    y += 10;

    if (payload.people_involved.length) {
      doc.text('People Involved:', 10, y);
      payload.people_involved.forEach((p) => {
        y += 10;
        doc.text(`- ${p}`, 10, y);
      });
      y += 10;
    }

    if (payload.actions_taken.length) {
      doc.text('Actions Taken:', 10, y);
      payload.actions_taken.forEach((a) => {
        y += 10;
        doc.text(`- ${a}`, 10, y);
      });
      y += 10;
    }

    if (payload.clo_response) {
      doc.text('CLO Response:', 10, y);
      y += 10;
      doc.text(payload.clo_response, 10, y);
      y += 10;
    }

    if (payload.witnesses.length) {
      doc.text('Witnesses:', 10, y);
      payload.witnesses.forEach((w) => {
        y += 10;
        doc.text(`- ${w}`, 10, y);
      });
      y += 10;
    }

    if (payload.additional_notes) {
      doc.text('Additional Notes:', 10, y);
      y += 10;
      doc.text(payload.additional_notes, 10, y);
      y += 10;
    }

    if (payload.submitted_to) {
      doc.text('Submitted To:', 10, y);
      y += 10;
      doc.text(payload.submitted_to, 10, y);
    }

    doc.save('incident_report.pdf');
  };

  return (
    <div
      className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-md rounded-[3px] shadow-lg flex flex-col max-h-[90vh] border"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between bg-[#1B5FC1] text-white h-[80px] px-6 shrink-0">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
            <h2 className="text-white text-lg font-semibold">Incident Overview</h2>
          </div>
          <button onClick={onClose} className="text-white text-xl font-bold">×</button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4 text-sm text-gray-800 space-y-6">
          {/* Officer Details */}
          <div>
            <div className="bg-[#F1F1F1] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
              Reporting Officer Details
            </div>
            <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700">
              <div>
                <p className="text-xs text-gray-500">Name of CLO</p>
                <p>{formData.cloName}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">OML</p>
                <p>{formData.oml}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Cluster/Host Community</p>
                <p>{formData.community}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Company</p>
                <p>{formData.company}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Date of Report</p>
                <p>{formData.reportDate}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">CLO Contact Number</p>
                <p>{formData.cloPhone}</p>
              </div>
            </div>
          </div>

          {/* Incident Overview */}
          <div>
            <div className="bg-[#F1F1F1] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
              Incident Overview
            </div>
            <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700">
              <div>
                <p className="text-xs text-gray-500">Date of Incident</p>
                <p>{formData.date}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Time of Incident</p>
                <p>{formData.time}</p>
              </div>
              <div>

                <p className="text-xs text-gray-500">Location</p>
                <p>{formData.location}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Community Affected</p>
                <p>{formData.communityAffected}</p>
              </div>
              <div className="col-span-2">
                <label className="block text-sm text-gray-700 mb-1">Incident Type</label>
                <div className="bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full">
                  <span
                    className={`truncate ${
                      !formData.incidentType ? 'text-gray-400 italic' : 'text-gray-900'
                    }`}
                  >
                    {Array.isArray(formData.incidentType)
                      ? formData.incidentType.join(', ')
                      : formData.incidentType}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Parties Involved */}
          <div className="bg-white rounded-lg relative border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Parties Involved
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowPartiesInvolved((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showPartiesInvolved ? 'rotate-180' : 'rotate-0'
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showPartiesInvolved && (
              <div className="px-4 py-4 text-sm">
                <p className="text-gray-500 text-[12px]">Names or Groups Involved</p>
                <div className="flex flex-wrap gap-2 mb-2">
                  {formData.peopleInvolved.length > 0 ? (
                    formData.peopleInvolved.map((person, index) => (
                      <p key={index} className="text-black">
                        {person}
                      </p>
                    ))
                  ) : (
                    <p className="text-black">Not provided</p>
                  )}
                </div>
                <p className="text-gray-500 text-[12px]">Stakeholder Role</p>
                <div className="flex flex-wrap gap-2 mb-2">
                  <p className="text-black">{formData.stakeholderRole}</p>
                </div>
                <p className="text-gray-500 text-[12px]">Number of People Involved</p>
                <p className="text-black">{formData.numberOfPeopleInvolved}</p>
              </div>
            )}
          </div>

          {/* Action Taken */}
          <div className="bg-white rounded-lg relative border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Action Taken
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowActionTaken((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showActionTaken ? 'rotate-180' : 'rotate-0'
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showActionTaken && (
              <div className="px-4 py-4 text-sm">
                <p className="text-gray-500 text-[12px]">Immediate Action Taken</p>
                <div className="space-y-2">
                  {formData.actionsTaken.length > 0 ? (
                    formData.actionsTaken.map((action, index) => (
                      <p key={index} className="text-black">
                        {action}
                      </p>
                    ))
                  ) : (
                    <p className="text-black">Not provided</p>
                  )}
                </div>
                <hr className="border-gray-300 my-2" />
                <p className="text-gray-500 text-[12px]">Details of CLO's Response</p>
                <p className="text-black">{formData.cloResponse}</p>
              </div>
            )}
          </div>

          {/* Supporting Information */}
          <div className="bg-white rounded-lg relative border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Supporting Information
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowSupportingInfo((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showSupportingInfo ? 'rotate-180' : 'rotate-0'
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showSupportingInfo && (
              <div className="px-4 py-4 text-sm">
                <p className="text-gray-500 text-[12px]">Witness Name</p>
                <p className="text-black">
                  {formData.witnesses.length > 0 ? formData.witnesses.join(', ') : 'Not provided'}
                </p>
                <hr className="border-gray-300 my-2" />
                <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                <div className="space-y-1">
                  {formData.uploadedEvidence && formData.uploadedEvidence.length > 0 ? (
                    formData.uploadedEvidence.map((evidence, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
                        <button className="text-red-500">X</button>
                      </div>
                    ))
                  ) : (
                    <p className="text-black">Not provided</p>
                  )}
                </div>
                <hr className="border-gray-300 my-2" />
                <p className="text-gray-500 text-[12px]">Additional Notes</p>
                <p className="text-black">{formData.additionalNotes}</p>
              </div>
            )}
          </div>

          {/* Escalation & Follow-Up */}
          <div className="bg-white rounded-lg relative border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
              Escalation & Follow-Up
              <div className="flex items-center space-x-2">
                <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowEscalationFollowUp((prev) => !prev)}
                  className="focus:outline-none"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showEscalationFollowUp ? 'rotate-180' : 'rotate-0'
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            {showEscalationFollowUp && (
              <div className="px-4 py-4 text-sm">
                <p className="text-gray-500 text-[12px]">Report Submitted To</p>
                <div className="flex flex-wrap gap-2 mb-2">
                  <p className="text-black">{formData.submittedTo}</p>
                </div>
                <p className="text-gray-500 text-[12px]">Follow-Up Actions Recommended</p>
                <div className="space-y-1">
                  {formData.followUpActions.length > 0 ? (
                    formData.followUpActions.map((action, index) => (
                      <p key={index} className="text-black">
                        {action}
                      </p>
                    ))
                  ) : (
                    <p className="text-black">Not provided</p>
                  )}
                </div>
                <div className="flex items-center mt-4">
                  <div className="flex-1">
                    <p className="text-gray-500 text-[12px]">Signature</p>
                    <div className="flex items-center space-x-2">
                      <img src={formData.signature} alt="Signature" className="w-20 h-auto" />
                      <img src="/pen.svg" alt="Edit Signature" className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-gray-500 text-[12px]">Date</p>
                    <p className="text-black">
                      {formData.reportDate}
                      <img src="/calendar.svg" alt="Calendar" className="w-4 h-4 inline ml-1" />
                    </p>
                  </div>
                </div>
                <p className="text-black mt-2">{formData.cloName}</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end items-center px-6 py-4 bg-gray-50 rounded-b-lg space-x-2 shrink-0">
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-white border border-gray-300 rounded hover:bg-gray-100"
          >
            <FiDownload className="text-gray-600" />
            Download as PDF
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm bg-[#1C64F2] text-white rounded hover:bg-[#155cd1]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default PdfExportModal;
