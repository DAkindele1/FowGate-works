


// // import React, { useState, useEffect } from "react";
// // import IncidentTable from "./IncidentTable";
// // import IncidentForm from "./IncidentForm";
// // import SpillReportingDashboard from "../../../Spill/component/Spillmain/components/SpillReportingDashboard";
// // import axios from "axios";

// // function IncidentReporting() {
// //   const [activeTab, setActiveTab] = useState("incident");
// //   const [incidents, setIncidents] = useState([]);
// //   const [showForm, setShowForm] = useState(false);
// //   const [filterType, setFilterType] = useState("All");
// //   const [filterMonth, setFilterMonth] = useState("All");
// //   const [incidentTypes, setIncidentTypes] = useState([]);
// //   const [currentPage, setCurrentPage] = useState(1);
// //   const pageSize = 10;

// //   const token = localStorage.getItem("userAccess");

// //   const fetchIncidents = async () => {
// //     try {
// //       const res = await axios.get(
// //         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/list_incidents",
// //         {
// //           headers: {
// //             "Content-Type": "application/json",
// //             Authorization: `Bearer ${token}`,
// //           },
// //         }
// //       );
// //       setIncidents(res.data || []);
// //     } catch (error) {
// //       console.error("Failed to fetch incidents:", error);
// //     }
// //   };

// //   const fetchIncidentTypes = async () => {
// //     try {
// //       const res = await axios.get(
// //         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/get_default_options",
// //         {
// //           headers: {
// //             "Content-Type": "application/json",
// //             Authorization: `Bearer ${token}`,
// //           },
// //         }
// //       );
// //       setIncidentTypes(res.data.incidentTypes || []);
// //     } catch (error) {
// //       console.error("Failed to fetch incident types:", error);
// //     }
// //   };

// //   useEffect(() => {
// //     fetchIncidents();
// //     fetchIncidentTypes();
// //   }, []);

// //   const handleAddNew = () => setShowForm(true);
// //   const handleCloseForm = () => setShowForm(false);
// //   const handleFormSubmit = (newIncident) => {
// //     setIncidents((prev) => [...prev, newIncident]);
// //     setShowForm(false);
// //   };

// //   const uniqueMonths = [
// //     ...new Set(
// //       incidents.map((incident) => {
// //         const dateStr = incident.reportDate || incident.date;
// //         const date = new Date(dateStr);
// //         return date.toLocaleString("default", { month: "short", year: "numeric" });
// //       })
// //     ),
// //   ];

// //   const filteredIncidents = incidents.filter((incident) => {
// //     const matchesType =
// //       filterType === "All" ||
// //       incident.incidentType === filterType ||
// //       incident.type?.[0] === filterType;

// //     const dateStr = incident.reportDate || incident.date;
// //     const incidentDate = new Date(dateStr);
// //     const monthYear = incidentDate.toLocaleString("default", {
// //       month: "short",
// //       year: "numeric",
// //     });

// //     const matchesMonth = filterMonth === "All" || monthYear === filterMonth;

// //     return matchesType && matchesMonth;
// //   });

// //   const totalFiltered = filteredIncidents.length;
// //   const totalPages = Math.ceil(totalFiltered / pageSize);
// //   const start = (currentPage - 1) * pageSize + 1;
// //   const end = Math.min(start + pageSize - 1, totalFiltered);
// //   const paginatedIncidents = filteredIncidents.slice(start - 1, end);

// //   return (
// //     <div className="">
// //       {/* Header */}
// //       <div className="flex justify-between items-center py-4 bg-white">
// //         <h1 className="text-xl font-medium text-[#292929]">Incident Reporting</h1>
// //         <div className="flex items-center space-x-4">
// //           <img src="/facenotif.svg" alt="chat" width={25} height={40} />
// //           <img src="/notif.svg" alt="notification" width={25} height={40} />
// //           <div className="flex items-center border border-gray-100 rounded-full p-[2px]">
// //             <img src="/memoji.svg" alt="profile" width={20} height={40} className="mr-1" />
// //             <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
// //               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
// //             </svg>
// //           </div>
// //         </div>
// //       </div>
// //       <hr className="-mt-1 border-gray-200" />

// //       {/* Toggle Tabs */}
// //       <div className="pt-6 border-b border-gray-200 mb-4">
// //         <div className="flex space-x-6 text-sm  font-medium px-0">
// //           <button
// //             onClick={() => setActiveTab("incident")}
// //             className={`pb-2 ${activeTab === "incident" ? "border-b-2 border-[#1B5FC1] text-[#1B5FC1]" : "text-gray-500"}`}
// //           >
// //             Incident
// //           </button>
// //           <button
// //             onClick={() => setActiveTab("spill")}
// //             className={`pb-2 ${activeTab === "spill" ? "border-b-2 border-[#1B5FC1] text-[#1B5FC1]" : "text-gray-500"}`}
// //           >
// //             Spill
// //           </button>
// //         </div>
// //       </div>

// //       {/* Main Content */}
// //       {activeTab === "incident" ? (
// //         <div className="pt-3">
// //           <div className="bg-white p-4 rounded-md mb-4 border border-gray-200">
// //             <div className="mb-6 flex justify-between items-center flex-wrap gap-4">
// //               <div className="flex items-center space-x-4">
// //                 <h2 className="text-xl font-semibold text-gray-900">Report History</h2>
// //                 <div className="relative">
// //                   <input
// //                     type="text"
// //                     placeholder="Search title, name..."
// //                     className="w-64 h-9 pr-10 pl-2 border border-gray-100 rounded-[8px] focus:outline-none font-light text-[16px] focus:ring-1 focus:ring-blue-500"
// //                   />
// //                   <img
// //                     src="/search.svg"
// //                     alt="search"
// //                     width={16}
// //                     height={16}
// //                     className="absolute right-2 top-1/2 transform -translate-y-1/2"
// //                   />
// //                 </div>
// //               </div>

// //               <div className="flex items-center gap-3">
// //                 <span className="text-sm text-gray-600 mr-1">
// //                   {totalFiltered === 0 ? "0–0" : `${start}–${end}`} of {totalFiltered}
// //                 </span>

// //                 <button
// //                   className="text-gray-600 hover:text-black px-1"
// //                   disabled={currentPage === 1}
// //                   onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
// //                 >
// //                   <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
// //                     <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
// //                   </svg>
// //                 </button>
// //                 <button
// //                   className="text-gray-600 hover:text-black px-1"
// //                   disabled={currentPage >= totalPages}
// //                   onClick={() => setCurrentPage((prev) => prev + 1)}
// //                 >
// //                   <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
// //                     <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
// //                   </svg>
// //                 </button>

// //                 <select
// //                   className="border border-gray-200 rounded px-2 py-2 text-sm"
// //                   value={filterType}
// //                   onChange={(e) => {
// //                     setFilterType(e.target.value);
// //                     setCurrentPage(1);
// //                   }}
// //                 >
// //                   <option value="All">All Type</option>
// //                   {incidentTypes.map((type) => (
// //                     <option key={type} value={type}>{type}</option>
// //                   ))}
// //                 </select>

// //                 <select
// //                   className="border border-gray-200 rounded px-2 py-2 text-sm"
// //                   value={filterMonth}
// //                   onChange={(e) => {
// //                     setFilterMonth(e.target.value);
// //                     setCurrentPage(1);
// //                   }}
// //                 >
// //                   <option value="All">All Dates</option>
// //                   {uniqueMonths.map((monthYear) => (
// //                     <option key={monthYear} value={monthYear}>{monthYear}</option>
// //                   ))}
// //                 </select>

// //                 <button
// //                   type="button"
// //                   className="bg-[#1B5FC1] hover:bg-blue-700 text-white text-sm h-9 px-3 flex items-center rounded-[8px]"
// //                   onClick={handleAddNew}
// //                 >
// //                   <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
// //                     <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
// //                   </svg>
// //                   Add New
// //                 </button>
// //               </div>
// //             </div>

// //             <p className="text-[16px]">
// //               Total No of Incident: <span className="font-bold">{totalFiltered}</span>
// //             </p>

// //             {filteredIncidents.length > 0 && <IncidentTable incidents={paginatedIncidents} />}
// //             {!filteredIncidents.length && !showForm && (
// //               <div className="flex flex-col items-center justify-center py-10 text-gray-500">
// //                 <img src="/book.svg" alt="empty" width={150} height={40} />
// //                 <p className="font-medium text-[20px] text-[#292929]">No incident report</p>
// //                 <p className="text-sm text-[#707070]">Use the "Add New" button</p>
// //               </div>
// //             )}
// //             {showForm && <IncidentForm onSubmit={handleFormSubmit} onClose={handleCloseForm} />}
// //           </div>
// //         </div>
// //       ) : (
// //         <SpillReportingDashboard />
// //       )}
// //     </div>
// //   );
// // }

// // export default IncidentReporting;



// import React, { useState, useEffect } from "react";
// import IncidentTable from "./IncidentTable";
// import IncidentForm from "./IncidentForm";
// import SpillReportingDashboard from "../../../Spill/component/Spillmain/components/SpillReportingDashboard";
// import axios from "axios";

// function IncidentReporting() {
//   const [activeTab, setActiveTab] = useState("incident");
//   const [incidents, setIncidents] = useState([]);
//   const [showForm, setShowForm] = useState(false);
//   const [filterType, setFilterType] = useState("All");
//   const [filterMonth, setFilterMonth] = useState("All");
//   const [incidentTypes, setIncidentTypes] = useState([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const pageSize = 10;

//   const token = localStorage.getItem("userAccess");

//   const fetchIncidents = async () => {
//     try {
//       const res = await axios.get(
//         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/list_incidents",
//         {
//           headers: {
//             "Content-Type": "application/json",
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       const normalizedIncidents = (res.data || []).map((incident) => ({
//         ...incident,
//         communityAffected: incident.community_affected || incident.communityAffected || incident.location || "N/A",
//         attachment: incident.attachment_url
//           ? { name: incident.attachment_name || incident.file_name || "File" }
//           : incident.attachment || null,
//         incidentType: Array.isArray(incident.type) ? incident.type[0] : incident.incidentType || "N/A",
//       }));
//       console.log("List incidents response:", res.data);
//       console.log("Normalized incidents:", normalizedIncidents);
//       setIncidents(normalizedIncidents);
//     } catch (error) {
//       console.error("Failed to fetch incidents:", error);
//     }
//   };

//   const fetchIncidentTypes = async () => {
//     try {
//       const res = await axios.get(
//         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/get_default_options",
//         {
//           headers: {
//             "Content-Type": "application/json",
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       setIncidentTypes(res.data.incidentTypes || []);
//     } catch (error) {
//       console.error("Failed to fetch incident types:", error);
//     }
//   };

//   useEffect(() => {
//     fetchIncidents();
//     fetchIncidentTypes();
//   }, []);

//   const handleStatusUpdate = () => {
//     fetchIncidents();
//   };

//   const handleAddNew = () => setShowForm(true);
//   const handleCloseForm = () => setShowForm(false);

//   const handleFormSubmit = async (formData) => {
//     // formData is already normalized by IncidentForm
//     setIncidents((prev) => [...prev, formData]);
//     setShowForm(false);
//   };

//   const uniqueMonths = [
//     ...new Set(
//       incidents.map((incident) => {
//         const dateStr = incident.reportDate || incident.date;
//         const date = new Date(dateStr);
//         return date.toLocaleString("default", { month: "short", year: "numeric" });
//       })
//     ),
//   ];

//   const filteredIncidents = incidents.filter((incident) => {
//     const matchesType =
//       filterType === "All" ||
//       incident.incidentType === filterType ||
//       incident.type?.[0] === filterType;

//     const dateStr = incident.reportDate || incident.date;
//     const incidentDate = new Date(dateStr);
//     const monthYear = incidentDate.toLocaleString("default", {
//       month: "short",
//       year: "numeric",
//     });

//     const matchesMonth = filterMonth === "All" || monthYear === filterMonth;

//     return matchesType && matchesMonth;
//   });

//   const totalFiltered = filteredIncidents.length;
//   const totalPages = Math.ceil(totalFiltered / pageSize);
//   const start = (currentPage - 1) * pageSize + 1;
//   const end = Math.min(start + pageSize - 1, totalFiltered);
//   const paginatedIncidents = filteredIncidents.slice(start - 1, end);

//   return (
//     <div className="">
//       {/* Header */}
//       <div className="flex justify-between items-center py-4 bg-white">
//         <h1 className="text-xl font-medium text-[#292929]">Incident Reporting</h1>
//         <div className="flex items-center space-x-4">
//           <img src="/facenotif.svg" alt="chat" width={25} height={40} />
//           <img src="/notif.svg" alt="notification" width={25} height={40} />
//           <div className="flex items-center border border-gray-100 rounded-full p-[2px]">
//             <img src="/memoji.svg" alt="profile" width={20} height={40} className="mr-1" />
//             <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//             </svg>
//           </div>
//         </div>
//       </div>
//       <hr className="-mt-1 border-gray-200" />

//       {/* Toggle Tabs */}
//       <div className="pt-6 border-b border-gray-200 mb-4">
//         <div className="flex space-x-6 text-sm font-medium px-0">
//           <button
//             onClick={() => setActiveTab("incident")}
//             className={`pb-2 ${activeTab === "incident" ? "border-b-2 border-[#1B5FC1] text-[#1B5FC1]" : "text-gray-500"}`}
//           >
//             Incident
//           </button>
//           <button
//             onClick={() => setActiveTab("spill")}
//             className={`pb-2 ${activeTab === "spill" ? "border-b-2 border-[#1B5FC1] text-[#1B5FC1]" : "text-gray-500"}`}
//           >
//             Spill
//           </button>
//         </div>
//       </div>

//       {/* Main Content */}
//       {activeTab === "incident" ? (
//         <div className="pt-3">
//           <div className="bg-white p-4 rounded-md mb-4 border border-gray-200">
//             <div className="mb-6 flex justify-between items-center flex-wrap gap-4">
//               <div className="flex items-center space-x-4">
//                 <h2 className="text-xl font-semibold text-gray-900">Report History</h2>
//                 <div className="relative">
//                   <input
//                     type="text"
//                     placeholder="Search title, name..."
//                     className="w-64 h-9 pr-10 pl-2 border border-gray-100 rounded-[8px] font-light text-[16px] focus:outline-none focus:ring-1 focus:ring-blue-500"
//                   />
//                   <img
//                     src="/search.svg"
//                     alt="search"
//                     width={16}
//                     height={16}
//                     className="absolute right-2 top-1/2 transform -translate-y-1/2"
//                   />
//                 </div>
//               </div>

//               <div className="flex items-center gap-3">
//                 <span className="text-sm text-gray-600 mr-1">
//                   {totalFiltered === 0 ? "0–0" : `${start}–${end}`} of {totalFiltered}
//                 </span>

//                 <button
//                   className="text-gray-600 hover:text-black px-1"
//                   disabled={currentPage === 1}
//                   onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
//                 >
//                   <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
//                     <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
//                   </svg>
//                 </button>
//                 <button
//                   className="text-gray-600 hover:text-black px-1"
//                   disabled={currentPage >= totalPages}
//                   onClick={() => setCurrentPage((prev) => prev + 1)}
//                 >
//                   <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
//                     <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
//                   </svg>
//                 </button>

//                 <select
//                   className="border border-gray-200 rounded px-2 py-2 text-sm"
//                   value={filterType}
//                   onChange={(e) => {
//                     setFilterType(e.target.value);
//                     setCurrentPage(1);
//                   }}
//                 >
//                   <option value="All">All Type</option>
//                   {incidentTypes.map((type) => (
//                     <option key={type} value={type}>{type}</option>
//                   ))}
//                 </select>

//                 <select
//                   className="border border-gray-200 rounded px-2 py-2 text-sm"
//                   value={filterMonth}
//                   onChange={(e) => {
//                     setFilterMonth(e.target.value);
//                     setCurrentPage(1);
//                   }}
//                 >
//                   <option value="All">All Dates</option>
//                   {uniqueMonths.map((monthYear) => (
//                     <option key={monthYear} value={monthYear}>{monthYear}</option>
//                   ))}
//                 </select>

//                 <button
//                   type="button"
//                   className="bg-[#1B5FC1] hover:bg-blue-700 text-white text-sm h-9 px-3 flex items-center rounded-[8px]"
//                   onClick={handleAddNew}
//                 >
//                   <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
//                     <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
//                   </svg>
//                   Add New
//                 </button>
//               </div>
//             </div>

//             <p className="text-[16px]">
//               Total No of Incident: <span className="font-bold">{totalFiltered}</span>
//             </p>

//             {filteredIncidents.length > 0 && <IncidentTable incidents={paginatedIncidents} onStatusUpdate={handleStatusUpdate} />}
//             {!filteredIncidents.length && !showForm && (
//               <div className="flex flex-col items-center justify-center py-10 text-gray-500">
//                 <img src="/book.svg" alt="empty" width={150} height={40} />
//                 <p className="font-medium text-[20px] text-[#292929]">No incident report</p>
//                 <p className="text-sm text-[#707070]">Use the "Add New" button</p>
//               </div>
//             )}
//             {showForm && <IncidentForm onSubmit={handleFormSubmit} onClose={handleCloseForm} />}
//           </div>
//         </div>
//       ) : (
//         <SpillReportingDashboard />
//       )}
//     </div>
//   );
// }

// export default IncidentReporting;













import React, { useState, useEffect } from "react";
import IncidentTable from "./IncidentTable";
import IncidentForm from "./IncidentForm";
import SpillReportingDashboard from "../../../Spill/component/Spillmain/components/SpillReportingDashboard";
import axios from "axios";

function IncidentReporting() {
  const [activeTab, setActiveTab] = useState("incident");
  const [incidents, setIncidents] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [filterType, setFilterType] = useState("All");
  const [filterMonth, setFilterMonth] = useState("All");
  const [incidentTypes, setIncidentTypes] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const token = localStorage.getItem("userAccess");

  const fetchIncidents = async () => {
    if (!token) {
      console.error("No token found for fetchIncidents");
      return;
    }
    try {
      const res = await axios.get(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/list_incidents",
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const normalizedIncidents = (res.data || []).map((incident) => ({
        ...incident,
        communityAffected: incident.community_affected || incident.communityAffected || incident.location || "N/A",
        attachment: incident.attachment_url
          ? { name: incident.attachment_name || incident.file_name || incident.attachment_url.split("/").pop() || "File" }
          : incident.attachment || null,
        attachment_url: incident.attachment_url || "",
        incidentType: Array.isArray(incident.type) ? incident.type[0] : incident.incidentType || "N/A",
      }));
      console.log("List incidents response:", JSON.stringify(res.data, null, 2)); // Improved logging
      console.log("Normalized incidents:", JSON.stringify(normalizedIncidents, null, 2)); // Improved logging
      setIncidents(normalizedIncidents);
    } catch (error) {
      console.error("Failed to fetch incidents:", error);
    }
  };

  const fetchIncidentTypes = async () => {
    if (!token) {
      console.error("No token found for fetchIncidentTypes");
      return;
    }
    try {
      const res = await axios.get(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setIncidentTypes(res.data.incidentTypes || []);
    } catch (error) {
      console.error("Failed to fetch incident types:", error);
    }
  };

  useEffect(() => {
    fetchIncidents();
    fetchIncidentTypes();
  }, []);

  const handleStatusUpdate = () => {
    fetchIncidents();
  };

  const handleAddNew = () => setShowForm(true);
  const handleCloseForm = () => setShowForm(false);

  const handleFormSubmit = (formData) => {
    console.log("Form submitted:", JSON.stringify(formData, null, 2)); // Debug
    setIncidents((prev) => [...prev, formData]);
    setShowForm(false);
    fetchIncidents(); // Refresh to ensure API data is synced
  };

  const uniqueMonths = [
    ...new Set(
      incidents.map((incident) => {
        const dateStr = incident.reportDate || incident.date;
        const date = new Date(dateStr);
        return date.toLocaleString("default", { month: "short", year: "numeric" });
      })
    ),
  ];

  const filteredIncidents = incidents.filter((incident) => {
    const matchesType =
      filterType === "All" ||
      incident.incidentType === filterType ||
      incident.type?.[0] === filterType;

    const dateStr = incident.reportDate || incident.date;
    const incidentDate = new Date(dateStr);
    const monthYear = incidentDate.toLocaleString("default", {
      month: "short",
      year: "numeric",
    });

    const matchesMonth = filterMonth === "All" || monthYear === filterMonth;

    return matchesType && matchesMonth;
  });

  const totalFiltered = filteredIncidents.length;
  const totalPages = Math.ceil(totalFiltered / pageSize);
  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, totalFiltered);
  const paginatedIncidents = filteredIncidents.slice(start - 1, end);

  return (
    <div className="">
      {/* Header */}
      <div className="flex justify-between items-center py-4 bg-white">
        <h1 className="text-xl font-medium text-[#292929]">Incident Reporting</h1>
        <div className="flex items-center space-x-4">
          <img src="/facenotif.svg" alt="chat" width={25} height={40} />
          <img src="/notif.svg" alt="notification" width={25} height={40} />
          <div className="flex items-center border border-gray-100 rounded-full p-[2px]">
            <img src="/memoji.svg" alt="profile" width={20} height={40} className="mr-1" />
            <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </div>
      <hr className="-mt-1 border-gray-200" />

      {/* Toggle Tabs */}
      <div className="pt-6 border-b border-gray-200 mb-4">
        <div className="flex space-x-6 text-sm font-medium px-0">
          <button
            onClick={() => setActiveTab("incident")}
            className={`pb-2 ${activeTab === "incident" ? "border-b-2 border-[#1B5FC1] text-[#1B5FC1]" : "text-gray-500"}`}
          >
            Incident
          </button>
          <button
            onClick={() => setActiveTab("spill")}
            className={`pb-2 ${activeTab === "spill" ? "border-b-2 border-[#1B5FC1] text-[#1B5FC1]" : "text-gray-500"}`}
          >
            Spill
          </button>
        </div>
      </div>

      {/* Main Content */}
      {activeTab === "incident" ? (
        <div className="pt-3">
          <div className="bg-white p-4 rounded-md mb-4 border border-gray-200">
            <div className="mb-6 flex justify-between items-center flex-wrap gap-4">
              <div className="flex items-center space-x-4">
                <h2 className="text-xl font-semibold text-gray-900">Report History</h2>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search title, name..."
                    className="w-64 h-9 pr-10 pl-2 border border-gray-100 rounded-[8px] font-light text-[16px] focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <img
                    src="/search.svg"
                    alt="search"
                    width={16}
                    height={16}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-600 mr-1">
                  {totalFiltered === 0 ? "0–0" : `${start}–${end}`} of {totalFiltered}
                </span>

                <button
                  className="text-gray-600 hover:text-black px-1"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <button
                  className="text-gray-600 hover:text-black px-1"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((prev) => prev + 1)}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </button>

                <select
                  className="border border-gray-200 rounded px-2 py-2 text-sm"
                  value={filterType}
                  onChange={(e) => {
                    setFilterType(e.target.value);
                    setCurrentPage(1);
                  }}
                >
                  <option value="All">All Type</option>
                  {incidentTypes.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>

                <select
                  className="border border-gray-200 rounded px-2 py-2 text-sm"
                  value={filterMonth}
                  onChange={(e) => {
                    setFilterMonth(e.target.value);
                    setCurrentPage(1);
                  }}
                >
                  <option value="All">All Dates</option>
                  {uniqueMonths.map((monthYear) => (
                    <option key={monthYear} value={monthYear}>{monthYear}</option>
                  ))}
                </select>

                <button
                  type="button"
                  className="bg-[#1B5FC1] hover:bg-blue-700 text-white text-sm h-9 px-3 flex items-center rounded-[8px]"
                  onClick={handleAddNew}
                >
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                  Add New
                </button>
              </div>
            </div>

            <p className="text-[16px]">
              Total No of Incident: <span className="font-bold">{totalFiltered}</span>
            </p>

            {filteredIncidents.length > 0 && <IncidentTable incidents={paginatedIncidents} onStatusUpdate={handleStatusUpdate} />}
            {!filteredIncidents.length && !showForm && (
              <div className="flex flex-col items-center justify-center py-10 text-gray-500">
                <img src="/book.svg" alt="empty" width={150} height={40} />
                <p className="font-medium text-[20px] text-[#292929]">No incident report</p>
                <p className="text-sm text-[#707070]">Use the "Add New" button</p>
              </div>
            )}
            {showForm && <IncidentForm onSubmit={handleFormSubmit} onClose={handleCloseForm} />}
          </div>
        </div>
      ) : (
        <SpillReportingDashboard />
      )}
    </div>
  );
}

export default IncidentReporting;