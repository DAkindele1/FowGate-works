


// import React, { useState, useRef, useEffect } from "react";
// import axios from "axios";
// import EditReportForm from "../../actions/componets/EditReportForm";
// import ConfirmationPage from "../../actions/componets/ConfirmationPage";
// import SuccessPage from "../../actions/componets/SuccessPage";
// import PdfExportModal from "../../actions/componets/PdfExportModal";

// function IncidentTable({ incidents, onStatusUpdate }) {
//   const [openDropdown, setOpenDropdown] = useState(null);
//   const dropdownRef = useRef(null);
//   const [isEditFormOpen, setIsEditFormOpen] = useState(false);
//   const [selectedIncident, setSelectedIncident] = useState(null);
//   const [defaultOptions, setDefaultOptions] = useState({
//     times: [],
//     communities: [],
//     incidentTypes: [],
//   });
//   const [showConfirmation, setShowConfirmation] = useState(false);
//   const [showSuccess, setShowSuccess] = useState(false);
//   const [showUnsuccessful, setShowUnsuccessful] = useState(false);
//   const [pendingFormData, setPendingFormData] = useState(null);
//   const [updatedIncidentId, setUpdatedIncidentId] = useState(null);
//   const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
//   const [error, setError] = useState(null);

//   const token = localStorage.getItem("userAccess");

//   // Valid statuses for display
//   const validStatuses = ["In Progress", "Resolved", "Unresolved"];

//   useEffect(() => {
//     const fetchDefaultOptions = async () => {
//       if (!token) {
//         setError("Authentication token is missing. Please log in.");
//         return;
//       }
//       try {
//         const res = await axios.get(
//           "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options",
//           {
//             headers: {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         setDefaultOptions({
//           times: res.data.times || [],
//           communities: res.data.communities || [],
//           incidentTypes: res.data.incidentTypes || [],
//         });
//       } catch (err) {
//         console.error("Failed to fetch default options:", err);
//         setError("Failed to load default options. Please try again.");
//       }
//     };
//     fetchDefaultOptions();
//   }, [token]);

//   useEffect(() => {
//     console.log("Incidents data:", JSON.stringify(incidents, null, 2)); // Improved logging
//     incidents.forEach((incident, index) => {
//       console.log(`Incident ${index} community fields:`, {
//         community_affected: incident.community_affected,
//         communityAffected: incident.communityAffected,
//         location: incident.location,
//       });
//       console.log(`Incident ${index} attachment fields:`, {
//         attachment_count: incident.attachment_count,
//         attachment_url: incident.attachment_url,
//         attachment_name: incident.attachment_name,
//         file_name: incident.file_name,
//         attachment: incident.attachment,
//         hasAttachment: incident.attachment_count !== undefined
//           ? incident.attachment_count
//           : (incident.attachment_url ||
//               incident.attachment_name ||
//               incident.file_name ||
//               (incident.attachment && incident.attachment.name)
//             ? 1
//             : 0),
//       });
//     });
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setOpenDropdown(null);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, [incidents]);

//   const toggleDropdown = (id) => {
//     setOpenDropdown(openDropdown === id ? null : id);
//   };

//   const handleEditClick = (incident) => {
//     setSelectedIncident(incident);
//     setIsEditFormOpen(true);
//     setOpenDropdown(null);
//   };

//   const handleCloseForm = () => {
//     setIsEditFormOpen(false);
//     setSelectedIncident(null);
//     setError(null);
//   };

//   const validateFormData = (formData) => {
//     if (!formData.incidentType) return "Incident type is required.";
//     if (!formData.date) return "Date is required.";
//     if (!formData.time) return "Time is required.";
//     if (!formData.communityAffected) return "Community affected is required.";
//     return null;
//   };

//   const handleSaveForm = (formData) => {
//     const validationError = validateFormData(formData);
//     if (validationError) {
//       setError(validationError);
//       return;
//     }
//     setPendingFormData(formData);
//     setIsEditFormOpen(false);
//     setShowConfirmation(true);
//     setError(null);
//   };

//   const handleConfirm = async () => {
//     if (!token) {
//       setError("Authentication token is missing. Please log in.");
//       setShowConfirmation(false);
//       setShowUnsuccessful(true);
//       return;
//     }

//     setShowConfirmation(false);
//     try {
//       let attachmentUrl = null;
//       if (pendingFormData.attachment) {
//         const formDataUpload = new FormData();
//         formDataUpload.append("file", pendingFormData.attachment);
//         try {
//           const uploadResponse = await axios.post(
//             "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//             formDataUpload,
//             {
//               headers: {
//                 "Content-Type": "multipart/form-data",
//                 Authorization: `Bearer ${token}`,
//               },
//             }
//           );
//           attachmentUrl = uploadResponse.data.fileUrl;
//           console.log("Upload response:", uploadResponse.data); // Debug
//         } catch (uploadError) {
//           console.error("Failed to upload attachment:", uploadError);
//           setError("Failed to upload attachment. Continuing without file.");
//         }
//       }

//       let signatureUrl = null;
//       if (pendingFormData.signature) {
//         const formDataSignature = new FormData();
//         const base64Data = pendingFormData.signature.includes("base64,")
//           ? pendingFormData.signature.split("base64,")[1]
//           : pendingFormData.signature;
//         const binaryString = atob(base64Data);
//         const bytes = new Uint8Array(binaryString.length);
//         for (let i = 0; i < binaryString.length; i++) {
//           bytes[i] = binaryString.charCodeAt(i);
//         }
//         formDataSignature.append(
//           "signature",
//           new Blob([bytes], { type: "image/png" }),
//           "signature.png"
//         );
//         try {
//           const signatureResponse = await axios.post(
//             "https://erpturbo-backend.onrender.com/api/upload",
//             formDataSignature,
//             {
//               headers: {
//                 "Content-Type": "multipart/form-data",
//                 Authorization: `Bearer ${token}`,
//               },
//             }
//           );
//           signatureUrl = signatureResponse.data.fileUrl;
//           console.log("Signature upload response:", signatureResponse.data); // Debug
//         } catch (signatureError) {
//           console.error("Failed to upload signature:", signatureError);
//           setError("Failed to upload signature. Continuing without signature.");
//         }
//       }

//       const payload = {
//         incident_code: selectedIncident.id || selectedIncident.incident_code,
//         updates: {
//           type: Array.isArray(pendingFormData.incidentType) ? pendingFormData.incidentType : [pendingFormData.incidentType || "Unknown"],
//           date: pendingFormData.date || selectedIncident.date || "2025-07-08",
//           time: pendingFormData.time || selectedIncident.time || "10:38",
//           community_affected: pendingFormData.communityAffected || selectedIncident.communityAffected || selectedIncident.location || "Unknown",
//           additional_notes: pendingFormData.additionalNotes || selectedIncident.additional_notes || "",
//           people_involved: Array.isArray(pendingFormData.peopleInvolved) ? pendingFormData.peopleInvolved : selectedIncident.people_involved || [""],
//           stakeholder_role: pendingFormData.stakeholderRole || selectedIncident.stakeholder_role || "Unknown",
//           number_of_people_involved: Number(pendingFormData.numberOfPeopleInvolved) || selectedIncident.number_of_people_involved || 0,
//           actions_taken: Array.isArray(pendingFormData.actionTaken) ? pendingFormData.actionTaken : selectedIncident.actions_taken || [""],
//           clo_response: pendingFormData.cloResponseDetails || selectedIncident.clo_response || "",
//           witnesses: Array.isArray(pendingFormData.witnesses)
//             ? pendingFormData.witnesses.map((w) => ({
//                 name: `${w.title ? w.title + " " : ""}${w.name || ""}`.trim() || "Unknown",
//                 phone_num: w.phone || "",
//               }))
//             : selectedIncident.witnesses || [{ name: "Unknown", phone_num: "" }],
//           submitted_to: pendingFormData.cloName || selectedIncident.submitted_to || "Safety Department",
//           follow_up_actions: Array.isArray(pendingFormData.followUpAction) ? pendingFormData.followUpAction : selectedIncident.follow_up_actions || [""],
//           signature: !!pendingFormData.signature || selectedIncident.signature || false,
//           report_date: pendingFormData.reportDate || selectedIncident.report_date || "2025-07-08",
//           attachment_url: attachmentUrl || selectedIncident.attachment_url || "",
//           signature_url: signatureUrl || selectedIncident.signature_url || "",
//           attachment: attachmentUrl ? { name: pendingFormData.attachment?.name || "File" } : selectedIncident.attachment || null,
//           status: validStatuses.includes(pendingFormData.status) ? pendingFormData.status : selectedIncident.status || "Unresolved", // Default status
//         },
//       };

//       const response = await axios.patch(
//         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/edit_incident",
//         payload,
//         {
//           headers: {
//             accept: "application/json",
//             "Content-Type": "application/json",
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );

//       console.log("Edit incident response:", JSON.stringify(response.data, null, 2)); // Improved logging

//       setUpdatedIncidentId(payload.incident_code);
//       setShowSuccess(true);

//       if (typeof onStatusUpdate === "function") {
//         onStatusUpdate();
//       }
//     } catch (err) {
//       console.error("Failed to update incident:", err);
//       setError(err.response?.data?.message || "Failed to update incident. Please try again.");
//       setShowUnsuccessful(true);
//     }
//   };

//   const handleDelete = async (incidentId) => {
//     if (!token) {
//       setError("Authentication token is missing. Please log in.");
//       setShowUnsuccessful(true);
//       return;
//     }

//     setOpenDropdown(null);
//     try {
//       await axios.delete(
//         `https://erpturbo-backend.onrender.com/api/oml/incident_reporting/delete_incident/${incidentId}`,
//         {
//           headers: {
//             accept: "application/json",
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       setUpdatedIncidentId(incidentId);
//       setShowSuccess(true);
//       if (typeof onStatusUpdate === "function") {
//         onStatusUpdate();
//       }
//     } catch (err) {
//       console.error("Failed to delete incident:", err);
//       setError(err.response?.data?.message || "Failed to delete incident. Please try again.");
//       setShowUnsuccessful(true);
//     }
//   };

//   const handleSuccessClose = () => {
//     setShowSuccess(false);
//     setError(null);
//   };

//   const handleUnsuccessfulClose = () => {
//     setShowUnsuccessful(false);
//     setError(null);
//   };

//   const handlePdfExport = (incident) => {
//     setSelectedIncident(incident);
//     setIsPdfModalOpen(true);
//     setOpenDropdown(null);
//   };

//   return (
//     <div className="rounded-2xl mt-4">
//       {error && (
//         <div className="text-red-500 text-sm mb-4 p-4">{error}</div>
//       )}
//       <table className="min-w-full bg-white border border-gray-200 shadow">
//         <thead>
//           <tr className="bg-[#E8EFF9] text-[10px] font-semibold text-gray-600 tracking-wider">
//             <th className="py-3 px-4 text-left">Date Reported</th>
//             <th className="py-3 px-4 text-left">Incident Type</th>
//             <th className="py-3 px-4 text-left">Location</th>
//             <th className="py-3 px-4 text-left">Status</th>
//             <th className="py-3 px-4 text-left">Attachment</th>
//             <th className="py-3 px-4 text-left">Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {incidents.map((incident) => {
//             const displayStatus = validStatuses.includes(incident.status) ? incident.status : "Unresolved"; // Default to Unresolved
//             return (
//               <tr key={incident.id || incident.incident_code} className="border-t border-gray-200">
//                 <td className="py-3 px-4 text-sm text-gray-500">{incident.reportDate || incident.date || "N/A"}</td>
//                 <td className="py-3 px-4 text-sm text-gray-900">{incident.incidentType || (incident.type?.[0] || "N/A")}</td>
//                 <td className="py-3 px-4 text-sm text-gray-900">
//                   {incident.community_affected || incident.communityAffected || incident.location || "N/A"}
//                 </td>
//                 <td className="py-3 px-4 text-sm">
//                   <div
//                     className={`inline-flex items-center px-2 py-1 rounded-xl text-xs font-medium ${
//                       {
//                         "In Progress": "bg-[#FDF3E6] text-[#EB8A00]",
//                         Resolved: "bg-[#EBF6EE] text-[#34A853]",
//                         Unresolved: "bg-[#FDECEB] text-[#EB4335]",
//                       }[displayStatus] || "bg-[#FDECEB] text-[#EB4335]"
//                     }`}
//                   >
//                     {displayStatus}
//                   </div>
//                 </td>
//                 <td className="py-3 px-4 text-sm text-gray-900">
//                   {(incident.attachment_count !== undefined
//                     ? incident.attachment_count
//                     : (incident.attachment_url ||
//                         incident.attachment_name ||
//                         incident.file_name ||
//                         (incident.attachment && incident.attachment.name)
//                       ? 1
//                       : 0)) || "0"} {/* Ensure default display */}
//                 </td>
//                 <td className="py-3 px-4 text-sm text-gray-900 relative">
//                   <svg
//                     className="w-4 h-4 text-gray-500 cursor-pointer"
//                     fill="none"
//                     stroke="currentColor"
//                     viewBox="0 0 24 24"
//                     xmlns="http://www.w3.org/2000/svg"
//                     onClick={() => toggleDropdown(incident.id || incident.incident_code)}
//                   >
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01" />
//                   </svg>
//                   {openDropdown === (incident.id || incident.incident_code) && (
//                     <div ref={dropdownRef} className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded shadow-lg z-10">
//                       <button
//                         className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                         onClick={() => handlePdfExport(incident)}
//                       >
//                         <img src="/file.svg" alt="chat" className="w-4 h-4 mr-2" /> View Report
//                       </button>
//                       <button
//                         className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                         onClick={() => handleEditClick(incident)}
//                       >
//                         <img src="/pen.svg" alt="edit" className="w-4 h-4 mr-2" /> Edit Report
//                       </button>
//                       <button
//                         className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
//                         onClick={() => handleDelete(incident.id || incident.incident_code)}
//                       >
//                         <img src="/del.svg" alt="delete" className="w-4 h-4 mr-2" /> Delete Report
//                       </button>
//                     </div>
//                   )}
//                 </td>
//               </tr>
//             );
//           })}
//         </tbody>
//       </table>

//       <EditReportForm
//         isOpen={isEditFormOpen}
//         onClose={handleCloseForm}
//         onSave={handleSaveForm}
//         incident={selectedIncident}
//         defaultOptions={defaultOptions}
//       />

//       {showConfirmation && (
//         <ConfirmationPage
//           formData={pendingFormData}
//           onClose={() => setShowConfirmation(false)}
//           onConfirm={handleConfirm}
//         />
//       )}

//       {showSuccess && (
//         <SuccessPage
//           message="Incident updated successfully"
//           incidentId={updatedIncidentId}
//           onClose={handleSuccessClose}
//         />
//       )}

//       {showUnsuccessful && (
//         <SuccessPage
//           message={error || "Incident could not be updated. Please try again."}
//           incidentId={updatedIncidentId}
//           onClose={handleUnsuccessfulClose}
//         />
//       )}

//       <PdfExportModal
//         isOpen={isPdfModalOpen}
//         onClose={() => setIsPdfModalOpen(false)}
//         incident={selectedIncident}
//       />
//     </div>
//   );
// }

// export default IncidentTable;









import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import EditReportForm from "../../actions/componets/EditReportForm";
import ConfirmationPage from "../../actions/componets/ConfirmationPage";
import SuccessPage from "../../actions/componets/SuccessPage";
import PdfExportModal from "../../actions/componets/PdfExportModal";
import toast from "react-hot-toast";

function IncidentTable({ incidents, onStatusUpdate }) {
  const [openDropdown, setOpenDropdown] = useState(null);
  const dropdownRef = useRef(null);
  const [isEditFormOpen, setIsEditFormOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [defaultOptions, setDefaultOptions] = useState({
    times: [],
    communities: [],
    incidentTypes: [],
  });
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showUnsuccessful, setShowUnsuccessful] = useState(false);
  const [pendingFormData, setPendingFormData] = useState(null);
  const [updatedIncidentId, setUpdatedIncidentId] = useState(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [error, setError] = useState(null);

  const token = localStorage.getItem("userAccess");
  const validStatuses = ["In Progress", "Resolved", "Unresolved"];

  useEffect(() => {
    const fetchDefaultOptions = async () => {
      if (!token) {
        setError("Authentication token is missing. Please log in.");
        toast.error("Authentication token is missing. Please log in.");
        return;
      }
      try {
        const res = await axios.get(
          "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setDefaultOptions({
          times: res.data.times || [],
          communities: res.data.communities || [],
          incidentTypes: res.data.incidentTypes || [],
        });
      } catch (err) {
        console.error("Failed to fetch default options:", err);
        setError("Failed to load default options. Please try again.");
        toast.error("Failed to load default options.");
      }
    };
    fetchDefaultOptions();
  }, [token]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [incidents]);

  const toggleDropdown = (id) => {
    setOpenDropdown(openDropdown === id ? null : id);
  };

  const handleEditClick = (incident) => {
    setSelectedIncident(incident);
    setIsEditFormOpen(true);
    setOpenDropdown(null);
  };

  const handleCloseForm = () => {
    setIsEditFormOpen(false);
    setSelectedIncident(null);
    setError(null);
  };

  const validateFormData = (formData) => {
    if (!formData.incidentType) return "Incident type is required.";
    if (!formData.date) return "Date is required.";
    if (!formData.time) return "Time is required.";
    if (!formData.communityAffected) return "Community affected is required.";
    if (!formData.peopleInvolved?.length) return "People involved is required.";
    if (!formData.stakeholderRole) return "Stakeholder role is required.";
    if (!formData.numberOfPeopleInvolved) return "Number of people involved is required.";
    if (!formData.actionTaken?.length) return "Actions taken is required.";
    if (!formData.cloResponseDetails) return "CLO response is required.";
    if (!formData.witnesses?.length || !formData.witnesses[0].name) return "At least one witness name is required.";
    if (!formData.cloName) return "Report submitted to is required.";
    if (!formData.followUpAction?.length) return "Follow-up actions are required.";
    if (!formData.reportDate) return "Report date is required.";
    if (!formData.signature) return "Signature is required.";
    return null;
  };

  const handleSaveForm = (formData) => {
    const validationError = validateFormData(formData);
    if (validationError) {
      setError(validationError);
      toast.error(validationError);
      return;
    }
    setPendingFormData(formData);
    setIsEditFormOpen(false);
    setShowConfirmation(true);
    setError(null);
  };

  const handleConfirm = async () => {
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      setShowConfirmation(false);
      setShowUnsuccessful(true);
      return;
    }

    setShowConfirmation(false);
    const formDataPayload = new FormData();
    const payload = {
      incident_code: selectedIncident.id || selectedIncident.incident_code,
      type: Array.isArray(pendingFormData.incidentType) ? pendingFormData.incidentType : [pendingFormData.incidentType || "Unknown"],
      date: pendingFormData.date || selectedIncident.date || "2025-07-09",
      time: pendingFormData.time || selectedIncident.time || "17:19",
      community_affected: pendingFormData.communityAffected || selectedIncident.communityAffected || selectedIncident.location || "Unknown",
      people_involved: Array.isArray(pendingFormData.peopleInvolved) ? pendingFormData.peopleInvolved : selectedIncident.people_involved || [""],
      stakeholder_role: pendingFormData.stakeholderRole || selectedIncident.stakeholder_role || "Unknown",
      number_of_people_involved: Number(pendingFormData.numberOfPeopleInvolved) || selectedIncident.number_of_people_involved || 0,
      actions_taken: Array.isArray(pendingFormData.actionTaken) ? pendingFormData.actionTaken : selectedIncident.actions_taken || [""],
      clo_response: pendingFormData.cloResponseDetails || selectedIncident.clo_response || "",
      witnesses: Array.isArray(pendingFormData.witnesses)
        ? pendingFormData.witnesses.map((w) => ({
            name: `${w.title ? w.title + " " : ""}${w.name || ""}`.trim() || "Unknown",
            phone_num: w.phone || "",
          }))
        : selectedIncident.witnesses || [{ name: "Unknown", phone_num: "" }],
      additional_notes: pendingFormData.additionalNotes || selectedIncident.additional_notes || "",
      submitted_to: pendingFormData.cloName || selectedIncident.submitted_to || "Safety Department",
      follow_up_actions: Array.isArray(pendingFormData.followUpAction) ? pendingFormData.followUpAction : selectedIncident.follow_up_actions || [""],
      signature: !!pendingFormData.signature || selectedIncident.signature || false,
      report_date: pendingFormData.reportDate || selectedIncident.report_date || "2025-07-09",
      oml: pendingFormData.oml || selectedIncident.oml || "",
      host_community: pendingFormData.hostCommunity || selectedIncident.host_community || "",
      company: pendingFormData.company || selectedIncident.company || "",
      clo_phone: pendingFormData.cloPhone || selectedIncident.clo_phone || "",
      location: pendingFormData.location || selectedIncident.location || "",
      status: validStatuses.includes(pendingFormData.status) ? pendingFormData.status : selectedIncident.status || "Unresolved",
    };

    formDataPayload.append("data", JSON.stringify(payload));

    if (pendingFormData.attachment) {
      try {
        if (pendingFormData.attachment instanceof File) {
          formDataPayload.append("document", pendingFormData.attachment);
        } else {
          setError("Invalid attachment format. Please select a valid file.");
          toast.error("Invalid attachment format. Please select a valid file.");
          setShowUnsuccessful(true);
          return;
        }
      } catch (error) {
        console.error("Failed to process file attachment:", error);
        setError("Failed to process file attachment. Continuing without file.");
        toast.error("Failed to process file attachment. Continuing without file.");
      }
    }

    if (pendingFormData.signature && typeof pendingFormData.signature === "string") {
      try {
        const base64Data = pendingFormData.signature.includes("base64,")
          ? pendingFormData.signature.split("base64,")[1]
          : pendingFormData.signature;
        if (base64Data) {
          const binaryString = atob(base64Data);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          formDataPayload.append(
            "signature",
            new Blob([bytes], { type: "image/png" }),
            "signature.png"
          );
        }
      } catch (error) {
        console.error("Failed to process signature:", error);
        setError("Failed to process signature. Continuing without signature.");
        toast.error("Failed to process signature. Continuing without signature.");
      }
    }

    try {
      const response = await axios.patch(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/edit_incident",
        formDataPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const updatedIncident = {
        ...payload,
        id: payload.incident_code,
        incidentType: payload.type[0] || "Unknown",
        communityAffected: payload.community_affected,
        attachment: response.data.attachment_url
          ? { name: pendingFormData.attachment?.name || response.data.attachment_url.split("/").pop() || "File" }
          : null,
        attachment_url: response.data.attachment_url || "",
        attachment_count: pendingFormData.attachment ? 1 : 0,
        signature_url: response.data.signature_url || pendingFormData.signature || "",
        dateReported: `${payload.date} ${payload.time}`,
      };

      setUpdatedIncidentId(payload.incident_code);
      setShowSuccess(true);
      if (typeof onStatusUpdate === "function") {
        onStatusUpdate(updatedIncident);
      }
    } catch (err) {
      console.error("Failed to update incident:", err);
      const errorMessage =
        err.response?.status === 401
          ? "Unauthorized: Please log in again."
          : err.response?.data?.message || "Failed to update incident. Please try again.";
      setError(errorMessage);
      toast.error(errorMessage);
      setShowUnsuccessful(true);
    }
  };

  const handleDelete = async (incidentId) => {
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      setShowUnsuccessful(true);
      return;
    }

    setOpenDropdown(null);
    try {
      await axios.delete(
        `https://erpturbo-backend.onrender.com/api/oml/incident_reporting/delete_incident/${incidentId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setUpdatedIncidentId(incidentId);
      setShowSuccess(true);
      if (typeof onStatusUpdate === "function") {
        onStatusUpdate();
      }
    } catch (err) {
      console.error("Failed to delete incident:", err);
      const errorMessage =
        err.response?.status === 401
          ? "Unauthorized: Please log in again."
          : err.response?.data?.message || "Failed to delete incident. Please try again.";
      setError(errorMessage);
      toast.error(errorMessage);
      setShowUnsuccessful(true);
    }
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    setError(null);
  };

  const handleUnsuccessfulClose = () => {
    setShowUnsuccessful(false);
    setError(null);
  };

  const handlePdfExport = (incident) => {
    setSelectedIncident(incident);
    setIsPdfModalOpen(true);
    setOpenDropdown(null);
  };

  return (
    <div className="rounded-2xl mt-4">
      {error && (
        <div className="text-red-500 text-sm mb-4 p-4">{error}</div>
      )}
      <table className="min-w-full bg-white border border-gray-200 shadow">
        <thead>
          <tr className="bg-[#E8EFF9] text-[10px] font-semibold text-gray-600 tracking-wider">
            <th className="py-3 px-4 text-left">Date Reported</th>
            <th className="py-3 px-4 text-left">Incident Type</th>
            <th className="py-3 px-4 text-left">Location</th>
            <th className="py-3 px-4 text-left">Status</th>
            <th className="py-3 px-4 text-left">Attachment</th>
            <th className="py-3 px-4 text-left">Action</th>
          </tr>
        </thead>
        <tbody>
          {incidents.map((incident) => {
            const displayStatus = validStatuses.includes(incident.status) ? incident.status : "Unresolved";
            return (
              <tr key={incident.id || incident.incident_code} className="border-t border-gray-200">
                <td className="py-3 px-4 text-sm text-gray-500">{incident.reportDate || incident.date || "N/A"}</td>
                <td className="py-3 px-4 text-sm text-gray-900">{incident.incidentType || (incident.type?.[0] || "N/A")}</td>
                <td className="py-3 px-4 text-sm text-gray-900">
                  {incident.community_affected || incident.communityAffected || incident.location || "N/A"}
                </td>
                <td className="py-3 px-4 text-sm">
                  <div
                    className={`inline-flex items-center px-2 py-1 rounded-xl text-xs font-medium ${
                      {
                        "In Progress": "bg-[#FDF3E6] text-[#EB8A00]",
                        Resolved: "bg-[#EBF6EE] text-[#34A853]",
                        Unresolved: "bg-[#FDECEB] text-[#EB4335]",
                      }[displayStatus] || "bg-[#FDECEB] text-[#EB4335]"
                    }`}
                  >
                    {displayStatus}
                  </div>
                </td>
                <td className="py-3 px-4 text-sm text-gray-900">
                  {(incident.attachment_count !== undefined
                    ? incident.attachment_count
                    : (incident.attachment_url ||
                        incident.attachment_name ||
                        incident.file_name ||
                        (incident.attachment && incident.attachment.name)
                      ? 1
                      : 0)) || "0"}
                </td>
                <td className="py-3 px-4 text-sm text-gray-900 relative">
                  <svg
                    className="w-4 h-4 text-gray-500 cursor-pointer"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                    onClick={() => toggleDropdown(incident.id || incident.incident_code)}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01" />
                  </svg>
                  {openDropdown === (incident.id || incident.incident_code) && (
                    <div ref={dropdownRef} className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded shadow-lg z-10">
                      <button
                        className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => handlePdfExport(incident)}
                      >
                        <img src="/file.svg" alt="chat" className="w-4 h-4 mr-2" /> View Report
                      </button>
                      <button
                        className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => handleEditClick(incident)}
                      >
                        <img src="/pen.svg" alt="edit" className="w-4 h-4 mr-2" /> Edit Report
                      </button>
                      <button
                        className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                        onClick={() => handleDelete(incident.id || incident.incident_code)}
                      >
                        <img src="/del.svg" alt="delete" className="w-4 h-4 mr-2" /> Delete Report
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <EditReportForm
        isOpen={isEditFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveForm}
        incident={selectedIncident}
        defaultOptions={defaultOptions}
      />

      {showConfirmation && (
        <ConfirmationPage
          formData={pendingFormData}
          onClose={() => setShowConfirmation(false)}
          onConfirm={handleConfirm}
        />
      )}

      {showSuccess && (
        <SuccessPage
          message="Incident updated successfully"
          incidentId={updatedIncidentId}
          onClose={handleSuccessClose}
        />
      )}

      {showUnsuccessful && (
        <SuccessPage
          message={error || "Incident could not be updated. Please try again."}
          incidentId={updatedIncidentId}
          onClose={handleUnsuccessfulClose}
        />
      )}

      <PdfExportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        incident={selectedIncident}
      />
    </div>
  );
}

export default IncidentTable;
