
// import React, { useState, useRef, useEffect } from "react";
// import axios from "axios";
// import DOMPurify from "dompurify"; // Import DOMPurify for HTML sanitization

// function Step3({ formData, onChange, onNext, onBack, onClose }) {
//   const token = localStorage.getItem("userAccess");
//   const [cloResponseDetails, setCloResponseDetails] = useState(formData.cloResponseDetails || "");
//   const [actionOptions, setActionOptions] = useState([
//     "Investigation",
//     "Resolution",
//     "Escalation",
//   ]);
//   const [error, setError] = useState(null); // Add state for error handling
//   const contentEditableRef = useRef(null);

//   useEffect(() => {
//     const fetchOptions = async () => {
//       if (!token) {
//         setError("Authentication token is missing. Please log in.");
//         return;
//       }
//       try {
//         const res = await axios.get(
//           "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//           {
//             headers: {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         if (
//           res.data &&
//           Array.isArray(res.data.actions_taken) &&
//           res.data.actions_taken.length > 0
//         ) {
//           setActionOptions(res.data.actions_taken);
//         }
//       } catch (error) {
//         console.warn("Failed to fetch action options. Using default list.");
//         setError("Failed to load action options. Using default options.");
//       }
//     };

//     fetchOptions();
//   }, [token]);

//   const handleContentChange = () => {
//     const value = contentEditableRef.current.innerHTML;
//     setCloResponseDetails(value);
//     // Sanitize HTML before storing in formData
//     const sanitizedValue = DOMPurify.sanitize(value);
//     onChange({ target: { name: "cloResponseDetails", value: sanitizedValue } });
//   };

//   const handleFormat = (command) => {
//     document.execCommand(command, false, null);
//     handleContentChange();
//   };

//   const handleActionChange = (e) => {
//     const { name, value } = e.target;
//     // Transform actionTaken into an array
//     const transformedValue = value ? [value] : [""];
//     onChange({ target: { name, value: transformedValue } });
//   };

//   const handleNextClick = () => {
//     if (!formData.actionTaken || formData.actionTaken.length === 0 || formData.actionTaken[0] === "") {
//       setError("Please select an action taken.");
//       return;
//     }
//     if (!cloResponseDetails || cloResponseDetails.trim() === "") {
//       setError("Please provide details of CLO's response.");
//       return;
//     }
//     setError(null);
//     onNext();
//   };

//   return (
//     <div className="h-[575px] flex flex-col">
//       {/* Header */}
//       <div className="flex justify-between items-center px-4 py-3 rounded-t-md bg-[#1B5FC1]">
//         <div className="flex items-center space-x-2">
//           <img src="/add.svg" alt="add" width={20} height={20} />
//           <h2 className="text-white text-lg font-semibold">Add New</h2>
//         </div>
//         <button onClick={onClose} className="text-white hover:text-gray-200">
//           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//           </svg>
//         </button>
//       </div>

//       {/* Content */}
//       <div className="flex-grow px-4 pt-2 overflow-y-auto">
//         <div className="text-sm text-gray-500 mt-[5%] flex items-center">
//           <span className="w-4 h-4 flex items-center justify-center mr-2">
//             <img src="/three.svg" alt="three" width={20} height={20} />
//           </span>
//           <span className="text-black">
//             3/6 - <span className="font-bold">ACTION TAKEN</span>
//           </span>
//         </div>

//         <hr className="border-t border-gray-300 my-3" />

//         {/* Error Message */}
//         {error && (
//           <div className="text-red-500 text-sm mb-4">{error}</div>
//         )}

//         <form className="space-y-5">
//           {/* Action Taken Dropdown */}
//           <div>
//             <label className="block text-sm text-gray-700">Action Taken</label>
//             <div className="relative mt-1">
//               <select
//                 name="actionTaken"
//                 value={formData.actionTaken && formData.actionTaken[0] ? formData.actionTaken[0] : ""}
//                 onChange={handleActionChange}
//                 className="block w-full border border-gray-300 rounded-[3px] p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
//                 style={{ height: "38px" }}
//                 required
//               >
//                 <option value="" disabled>Select</option>
//                 {actionOptions.map((option, idx) => (
//                   <option key={idx} value={option}>{option}</option>
//                 ))}
//               </select>
//               <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
//                 <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                 </svg>
//               </span>
//             </div>
//           </div>

//           {/* CLO Response Editor */}
//           <div> 

//             <label className="block text-sm text-gray-700 mb-1">Details of CLO's Response</label>
//             <div className="relative">
//               <div
//                  ref={contentEditableRef}
//                  contentEditable
//                 onInput={handleContentChange}
//                 className="block w-full border border-gray-300 rounded-[3px] p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[120px] max-h-[200px] overflow-y-auto h-[266px]"
//                 style={{ paddingBottom: "30px" }}
//                 dangerouslySetInnerHTML={{ __html: cloResponseDetails }}
//               />
              
//               <div className="absolute bottom-2 left-2 flex space-x-1 text-xs">
//                 <button type="button" onClick={() => handleFormat("bold")}>
//                   <img src="/bold.svg" alt="bold" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("italic")}>
//                   <img src="/italic.svg" alt="italic" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("underline")}>
//                   <img src="/under.svg" alt="underline" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("insertOrderedList")}>
//                   <img src="/num.svg" alt="num" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("insertUnorderedList")}>
//                   <img src="/item.png" alt="item" width={20} height={20} />
//                 </button>
//               </div>
//               <span className="absolute bottom-2 right-2 text-xs text-gray-500">
//                 {contentEditableRef.current?.textContent.length || 0}/1500
//               </span>
//             </div>
//           </div>
//         </form>
//       </div>

//       {/* Sticky Footer */}
//       <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
//         <button
//           type="button"
//           onClick={onBack}
//           className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
//         >
//           Prev
//         </button>
//         <button
//           type="button"
//           onClick={handleNextClick}
//           className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
//         >
//           Next
//         </button>
//       </div>
//     </div>
//   );
// }

// export default Step3;













import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import DOMPurify from "dompurify";
import toast from "react-hot-toast";

function Step3({ formData, onChange, onNext, onBack, onClose }) {
  const token = localStorage.getItem("userAccess");
  const [cloResponseDetails, setCloResponseDetails] = useState(formData.cloResponseDetails || "");
  const [actionOptions, setActionOptions] = useState([
    "Investigation",
    "Resolution",
    "Escalation",
  ]);
  const [error, setError] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null); // New state for file
  const [previewFile, setPreviewFile] = useState(null); // New state for file preview
  const fileInputRef = useRef(null); // Ref for file input
  const contentEditableRef = useRef(null);

  useEffect(() => {
    const fetchOptions = async () => {
      if (!token) {
        setError("Authentication token is missing. Please log in.");
        toast.error("Authentication token is missing. Please log in.");
        return;
      }
      try {
        const res = await axios.get(
          "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options", // Corrected endpoint
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (
          res.data &&
          Array.isArray(res.data.actions_taken) &&
          res.data.actions_taken.length > 0
        ) {
          setActionOptions(res.data.actions_taken);
        }
      } catch (error) {
        console.warn("Failed to fetch action options. Using default list:", error);
        setError("Failed to load action options. Using default options.");
        toast.error("Failed to load action options.");
      }
    };

    fetchOptions();
  }, [token]);

  const handleContentChange = () => {
    const value = contentEditableRef.current.innerHTML;
    setCloResponseDetails(value);
    const sanitizedValue = DOMPurify.sanitize(value);
    onChange({ target: { name: "cloResponseDetails", value: sanitizedValue } });
  };

  const handleFormat = (command) => {
    document.execCommand(command, false, null);
    handleContentChange();
  };

  const handleActionChange = (e) => {
    const { name, value } = e.target;
    const transformedValue = value ? [value] : [""];
    onChange({ target: { name, value: transformedValue } });
  };

  // Handle file input
  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setPreviewFile(URL.createObjectURL(file));
    }
  };

  // Validate and submit form data using FormData
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      return;
    }

    // Validate form fields
    if (!formData.actionTaken || formData.actionTaken.length === 0 || formData.actionTaken[0] === "") {
      setError("Please select an action taken.");
      toast.error("Please select an action taken.");
      return;
    }
    if (!cloResponseDetails || cloResponseDetails.trim() === "") {
      setError("Please provide details of CLO's response.");
      toast.error("Please provide details of CLO's response.");
      return;
    }

    // Create FormData instance
    const formDataPayload = new FormData();
    const payload = {
      actions_taken: formData.actionTaken || [""],
      clo_response: DOMPurify.sanitize(cloResponseDetails) || "",
      // Include fields from previous steps for a complete payload
      type: formData.incidentType ? [formData.incidentType] : ["Unknown"],
      date: formData.dateOfIncident || "2025-07-08",
      time: formData.timeOfIncident || "09:59",
      community_affected: formData.communityAffected || "Unknown",
      people_involved: formData.peopleInvolved || [""],
      stakeholder_role: formData.stakeholderRole || "Unknown",
      number_of_people_involved: parseInt(formData.numberOfPeopleInvolved) || 0,
      witnesses: [{ name: "", phone_num: "" }],
      additional_notes: "",
      submitted_to: "Safety Department",
      follow_up_actions: [""],
      signature: true,
      report_date: formData.dateOfIncident || "2025-07-08",
    };

    // Append payload as JSON string
    formDataPayload.append("data", JSON.stringify(payload));

    // Append file if selected
    if (selectedFile) {
      formDataPayload.append("document", selectedFile);
    }

    try {
      const response = await axios.post(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
        formDataPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            // Content-Type is automatically set to multipart/form-data
          },
        }
      );
      console.log("Incident created:", response.data);
      toast.success("Incident details submitted successfully!");
      setError(null);
      onClose(); // Close the form on success
    } catch (error) {
      console.error("Error submitting incident details:", error);
      const errorMessage =
        error.response?.data?.message || "Failed to submit incident details. Please try again.";
      setError(errorMessage);
      toast.error(errorMessage);
    }
  };

  const handleNextClick = () => {
    if (!formData.actionTaken || formData.actionTaken.length === 0 || formData.actionTaken[0] === "") {
      setError("Please select an action taken.");
      toast.error("Please select an action taken.");
      return;
    }
    if (!cloResponseDetails || cloResponseDetails.trim() === "") {
      setError("Please provide details of CLO's response.");
      toast.error("Please provide details of CLO's response.");
      return;
    }
    setError(null);
    onNext();
  };

  return (
    <div className="h-[575px] flex flex-col">
      {/* Header */}
      <div className="flex justify-between items-center px-4 py-3 rounded-t-md bg-[#1B5FC1]">
        <div className="flex items-center space-x-2">
          <img src="/add.svg" alt="add" width={20} height={20} />
          <h2 className="text-white text-lg font-semibold">Add New</h2>
        </div>
        <button onClick={onClose} className="text-white hover:text-gray-200">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Content */}
      <div className="flex-grow px-4 pt-2 overflow-y-auto">
        <div className="text-sm text-gray-500 mt-[5%] flex items-center">
          <span className="w-4 h-4 flex items-center justify-center mr-2">
            <img src="/three.svg" alt="three" width={20} height={20} />
          </span>
          <span className="text-black">
            3/6 - <span className="font-bold">ACTION TAKEN</span>
          </span>
        </div>

        <hr className="border-t border-gray-300 my-3" />

        {/* Error Message */}
        {error && (
          <div className="text-red-500 text-sm mb-4">{error}</div>
        )}

        <form className="space-y-5" onSubmit={handleSubmit}>
          {/* Action Taken Dropdown */}
          <div>
            <label className="block text-sm text-gray-700">Action Taken</label>
            <div className="relative mt-1">
              <select
                name="actionTaken"
                value={formData.actionTaken && formData.actionTaken[0] ? formData.actionTaken[0] : ""}
                onChange={handleActionChange}
                className="block w-full border border-gray-300 rounded-[3px] p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
                style={{ height: "38px" }}
                required
              >
                <option value="" disabled>Select</option>
                {actionOptions.map((option, idx) => (
                  <option key={idx} value={option}>{option}</option>
                ))}
              </select>
              <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </span>
            </div>
          </div>

          {/* CLO Response Editor */}
          <div>
            <label className="block text-sm text-gray-700 mb-1">Details of CLO's Response</label>
            <div className="relative">
              <div
                ref={contentEditableRef}
                contentEditable
                onInput={handleContentChange}
                className="block w-full border border-gray-300 rounded-[3px] p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[120px] max-h-[200px] overflow-y-auto h-[266px]"
                style={{ paddingBottom: "30px" }}
                dangerouslySetInnerHTML={{ __html: cloResponseDetails }}
              />
              <div className="absolute bottom-2872 left-2 flex space-x-1 text-xs">
                <button type="button" onClick={() => handleFormat("bold")}>
                  <img src="/bold.svg" alt="bold" width={20} height={20} />
                </button>
                <button type="button" onClick={() => handleFormat("italic")}>
                  <img src="/italic.svg" alt="italic" width={20} height={20} />
                </button>
                <button type="button" onClick={() => handleFormat("underline")}>
                  <img src="/under.svg" alt="underline" width={20} height={20} />
                </button>
                <button type="button" onClick={() => handleFormat("insertOrderedList")}>
                  <img src="/num.svg" alt="num" width={20} height={20} />
                </button>
                <button type="button" onClick={() => handleFormat("insertUnorderedList")}>
                  <img src="/item.png" alt="item" width={20} height={20} />
                </button>
              </div>
              <span className="absolute bottom-2 right-2 text-xs text-gray-500">
                {contentEditableRef.current?.textContent.length || 0}/1500
              </span>
            </div>
          </div>

          {/* File Input for Supporting Document */}
          {/* <div>
            <label className="block text-sm text-gray-700 mb-1">Supporting Document (Optional)</label>
            <div
              className="border border-gray-300 rounded-[3px] p-4 flex items-center justify-center cursor-pointer hover:bg-gray-100"
              onClick={handleFileClick}
            >
              {previewFile ? (
                <img
                  src={previewFile}
                  alt="Document Preview"
                  className="w-32 h-32 object-cover rounded-[3px]"
                />
              ) : (
                <span className="text-gray-500">Click to upload a document or image</span>
              )}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*,.pdf"
                className="hidden"
              />
            </div>
          </div> */}

          {/* Sticky Footer */}
          <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
            <button
              type="button"
              onClick={onBack}
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
            >
              Prev
            </button>
            {/* <button
              type="submit"
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
            >
              Submit
            </button> */}
            <button
              type="button"
              onClick={handleNextClick}
              className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
            >
              Next
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Step3;