import { useState, useMemo } from "react";

export function useGrievanceFilters(grievances, initialTypes = [], initialStatus = [], initialSeverity = []) {
  const [filterType, setFilterType] = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");
  const [filterSeverity, setFilterSeverity] = useState("All");
  const [filterMonth, setFilterMonth] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const applyFilters = ({ type, status, severity }) => {
    setFilterType(type || "All");
    setFilterStatus(status || "All");
    setFilterSeverity(severity || "All");
    setCurrentPage(1);
  };

  const clearFilters = () => {
    setFilterType("All");
    setFilterStatus("All");
    setFilterSeverity("All");
    setFilterMonth("All");
    setCurrentPage(1);
  };

  const uniqueMonths = useMemo(() => [
    ...new Set(
      grievances.map((grievance) => {
        const dateStr = grievance.reportDate || grievance.grievanceDate || new Date().toISOString();
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return null;
        return date.toLocaleString("default", { month: "short", year: "numeric" });
      }).filter(Boolean)
    ),
  ], [grievances]);

  const filteredGrievances = useMemo(() =>
    grievances.filter((grievance) => {
      const matchesType =
        filterType === "All" ||
        (grievance.grievanceType || "").trim().toLowerCase() === filterType.toLowerCase();
      const matchesStatus =
        filterStatus === "All" ||
        (grievance.status || "").trim().toLowerCase() === filterStatus.toLowerCase();
      const matchesSeverity =
        filterSeverity === "All" ||
        (grievance.urgencyLevel || "").trim().toLowerCase() === filterSeverity.toLowerCase();
      const matchesMonth =
        filterMonth === "All" ||
        (grievance.reportDate || grievance.grievanceDate) &&
        new Date(grievance.reportDate || grievance.grievanceDate).toLocaleString("default", {
          month: "short",
          year: "numeric",
        }) === filterMonth;
      return matchesType && matchesStatus && matchesSeverity && matchesMonth;
    }),
    [grievances, filterType, filterStatus, filterSeverity, filterMonth]
  );

  const totalFiltered = filteredGrievances.length;
  const totalPages = Math.ceil(totalFiltered / pageSize);
  const start = (currentPage - 1) * pageSize + 1;
  const end = Math.min(start + pageSize - 1, totalFiltered);
  const paginatedGrievances = filteredGrievances.slice(start - 1, end);

  return {
    filterType,
    setFilterType,
    filterStatus,
    setFilterStatus,
    filterSeverity,
    setFilterSeverity,
    filterMonth,
    setFilterMonth,
    currentPage,
    setCurrentPage,
    applyFilters,
    clearFilters,
    uniqueMonths,
    filteredGrievances,
    paginatedGrievances,
    totalFiltered,
    totalPages,
    start,
    end,
    pageSize,
  };
}
