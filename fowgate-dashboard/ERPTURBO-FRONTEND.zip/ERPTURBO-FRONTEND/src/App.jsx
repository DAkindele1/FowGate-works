import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Login from "./auth/login";
import TFA from "./auth/twofa";
import NotFound from "./pages/NotFound/notfound";
import SignUp from "./auth/signup";
import FP from "./auth/forgotpassword";
import FPO from "./auth/forgotpasswordotp";
import OTP from "./auth/otpverification";
import CNP from "./auth/createnewpassword";
import ARD from "./pages/Analysis_Reporting/analysis_reporting";
import ApprovalsD from "./pages/Approvals/approvalsdashboard";
import BED from "./pages/Business Entities/business_entities_dashboard";
import CalD from "./pages/Calendar/calendardashboard";
import CMD from "./pages/Compliance Management/compliancemanagementdashboard";
import DashAcct from "./pages/Dashboard Account/accountdashboard";
import ATSD from "./pages/Dashboard ATS/atsdashboard";
import DashHome from "./pages/Dashbord Home/homedashboard";
import MessageD from "./pages/Messages/messagesdashboard";
import PayrollD from "./pages/Payroll/payrolldashboard";
import ProjectsD from "./pages/Projects/projectsdashboard";
import ReportsD from "./pages/Reports/reportsdashboard";
import CompanyCalD from "./pages/Company Calendar/company_calendar";
import SettingsD from "./pages/Settings/settingsdasboard";
import TeamD from "./pages/Team/teamdasboard";
import ProtectedRoute from "./Components/ProtectedRoute";
import DashboardLayout from "./Components/Dashboard/DashboardLayout";
import IncidentReporting from "./Components/Compliance/incidents/components/IncidentReporting";
import GrievanceManagement from "./Components/Grievance/GrievanceManagement";
import CLOCollaboration from "./pages/CLO Collaboration/CLOCOLLABORATION";
import DocumentHub from "./pages/Document Hub/DocumentHub";
function App() {
  return (
    <>
      <Toaster position="top-center" reverseOrder={false} />

      <Router>
        <Routes>
          <Route path="/" element={<DashboardLayout />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/twofactorauthorization" element={<TFA />} />
          <Route path="/forgotpassword" element={<FP />} />
          <Route path="/forgotpassword_otp" element={<FPO />} />
          <Route path="/otp-verification" element={<OTP />} />
          <Route path="/create-new-password" element={<CNP />} />

          <Route
            path=""
            element={
              <DashboardLayout />
            }
          >
            <Route path="/" element={<DashAcct />} />
            <Route path="/analysis_reporting_dashboard" element={<ARD />} />
            <Route path="/approvals_dashboard" element={<ApprovalsD />} />
            <Route path="/business_entities_dashboard" element={<BED />} />

            <Route path="/calendar_dashboard" element={<CalD />} />
            <Route path="/compliance_management_dashboard" element={<CMD />} />
            <Route path="/account_dashboard" element={<DashAcct />} />
            <Route path="/ats_dashboard" element={<ATSD />} />
            <Route path="/home_dashboard" element={<DashHome />} />
            <Route path="/messages_dashboard" element={<MessageD />} />
            <Route path="/payroll_dashboard" element={<PayrollD />} />
            <Route path="/projects_dashboard" element={<ProjectsD />} />
            <Route path="/reports_dashboard" element={<ReportsD />} />
            <Route
              path="/company_calendar_dashboard"
              element={<CompanyCalD />}
            />
            <Route
              path= "/incident_reporting"
              element={<IncidentReporting />}
            />
             <Route path="/grievance_management" element={<GrievanceManagement />} />
            <Route path="/clo_collaboration" element={<CLOCollaboration />} />
            <Route path="/document_hub" element={<DocumentHub />} />
            <Route path="/settings_dashboard" element={<SettingsD />} />
            <Route path="/teams_dashboard" element={<TeamD />} />
          </Route>

          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
