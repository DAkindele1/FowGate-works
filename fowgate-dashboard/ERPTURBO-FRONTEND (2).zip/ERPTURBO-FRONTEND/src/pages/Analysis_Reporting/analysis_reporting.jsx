import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const analysis_reporting = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default analysis_reporting;
