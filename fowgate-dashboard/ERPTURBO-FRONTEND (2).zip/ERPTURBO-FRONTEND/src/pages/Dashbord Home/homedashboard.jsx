import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const homedashboard = () => {
  return (
    <div className="flex">
      {/* <Sidebar /> */}
      <main className="flex-1 overflow-y-auto ">
        <p>Home Page</p>
      </main>
    </div>
  );
};

export default homedashboard;
