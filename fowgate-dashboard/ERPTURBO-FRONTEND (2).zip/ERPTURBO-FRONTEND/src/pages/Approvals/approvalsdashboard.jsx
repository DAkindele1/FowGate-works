import React from "react";
import Sidebar from "../../Components/Dashboard/Sidebar";

const approvalsdashboard = () => {
  return <div>{/* <Sidebar /> */}</div>;
};

export default approvalsdashboard;
