export const handleUnavailableFeature = () => {
  alert('Sorry, this feature is currently unavailable');
};
