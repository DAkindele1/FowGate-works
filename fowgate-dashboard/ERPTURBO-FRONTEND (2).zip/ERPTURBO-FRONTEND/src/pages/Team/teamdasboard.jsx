import React from 'react'
import Sidebar from '../../Components/Dashboard/Sidebar'

const teamdasboard = () => {
  return (
    <div>
      <Sidebar />
    </div>
  )
}

export default teamdasboard
