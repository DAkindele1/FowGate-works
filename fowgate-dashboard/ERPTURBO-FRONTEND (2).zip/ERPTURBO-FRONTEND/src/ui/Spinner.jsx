import React from 'react';

const Spinner = ({ size = 'md' }) => {
  const sizeClasses = {
    sm: 'h-8 w-8',
    md: 'h-20 w-20',
    lg: 'h-16 w-16'
  };

  return (
    <div className={`relative ${sizeClasses[size]} mx-auto my-20`}>
      {/* Blue background circle */}
      <div className={`absolute inset-0 rounded-full bg-white`}></div>
      
      {/* Rolling animation element */}
      <div className={`
        absolute inset-0 
        rounded-full 
        border-10 border-transparent
        border-t-blue-500
        animate-spin
      `}></div>
    </div>
  );
};

export default Spinner;