import React from "react";

const TopPagination = ({ onTabChange,  currTab, tabs }) => {

 

  const handleTabClick = (tabName) => {
    onTabChange(tabName);
  };

  return (
    <nav className="bg-white border-b border-gray-200 mb-[20px] flex items-end">
        <div className="flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.name}
              onClick={() => handleTabClick(tab.name)}
              className={` py-[14px] inline-flex items-center cursor-pointer border-b-3 text-sm font-light leading-[20px] text-[16px] ${
                currTab === tab.name
                  ? "border-[#1B5FC1] text-[#1B5FC1] font-normal"
                  : "border-transparent text-[#707070] hover:text-[#707070] hover:border-gray-300"
              }`}
            >
              {tab.name}
            </button>
          ))}
        </div>
    </nav>
  );
};

export default TopPagination;
