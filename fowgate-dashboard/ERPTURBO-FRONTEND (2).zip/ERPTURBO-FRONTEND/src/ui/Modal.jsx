import React from 'react'
import { CalendarDotsIcon, QuestionIcon, TrashIcon, XIcon } from '@phosphor-icons/react';

export default function Modal({ headBgColor, closeModal, children, contW, contH, headTitle, headerIcon }) {
  return (
      <div className="fixed inset-0 z-[9999999999999] flex  items-center justify-center bg-gray-100/65 border rounded-[4px]">
          <div className={`rounded-sm relative shadow-xl animate-fadeIn  h-fit ${contH} ${contW} bg-[#FFFFFF]`}>
             {headTitle && <div className={` w-full flex ${headBgColor?headBgColor: "bg-[#1B5FC1]"} rounded-t-sm justify-between align-middle p-4 text-white`}>
                   <div className='text-2xl flex items-center gap-2'>
                                 {headerIcon === "trash"? <TrashIcon/> :headerIcon === "calendar"? <CalendarDotsIcon/> : headerIcon === "confirm"? <QuestionIcon weight='fill'/> : ""}
            <p>{headTitle}</p>
                            </div>
                            <button
                                className="cursor-pointer hover:scale-105 transition ease-in-out"
                                onClick={closeModal}
                              >
                                <XIcon/>
                              </button>
              </div>}
              {children}

              
          </div>
    </div>
  )
}
