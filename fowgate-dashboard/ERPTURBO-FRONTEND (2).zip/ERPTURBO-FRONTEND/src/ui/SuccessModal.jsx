import React from 'react'
import CheckMarker from './CheckMarker'

const SuccessModal = ({actionMode, closeModal}) => {
  const getTitle = () => {
    switch (actionMode) {
      case 'delete':
        return 'Job Deleted!'
      case 'create':
        return 'Job Created!'
      case 'edit':
        return 'Job Updated!'
      default:
        return 'Success!'
    }
  }

  const getMessage = () => {
    switch (actionMode) {
      case 'delete':
        return 'The job listing has been successfully deleted.'
      case 'create':
        return 'Your job listing has been successfully created.'
      case 'edit':
        return 'Your job listing has been successfully updated.'
      default:
        return 'Operation completed successfully.'
    }
  }

  return (
    <div className='text-[#292929] mx-auto mt-[32px] text-center flex flex-col gap-[40px] h-[378px] w-[380px]'>
      <CheckMarker/>
      <div className='w-full h-[98px] flex flex-col gap-[8px]'>
        <h1 className='text-[32px] font-medium text-center'>{getTitle()}</h1>
        <p className='text-[16px] font-light text-[#292929] text-center'>
          {getMessage()}
        </p>
      </div>
      <button 
        className='bg-[#1b5fc1] text-[#fff] text-[16px] font-medium hover:bg-blue-600 w-full h-[50px] rounded-sm cursor-pointer py-[12px] px-[10px]' 
        onClick={closeModal}
      >
        Okay
      </button>
    </div>
  )
}

export default SuccessModal
