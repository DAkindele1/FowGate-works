import React from 'react'

export default function Overlay({children}) {
  return (
    <div className='fixed inset-0 z-[9999999999999] flex  items-center justify-center bg-gray-100/65 border rounded-[4px]'>{children}</div>
  )
}
