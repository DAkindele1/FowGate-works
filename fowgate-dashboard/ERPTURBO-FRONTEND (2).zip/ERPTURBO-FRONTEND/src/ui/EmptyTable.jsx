import React from 'react'

export default function EmptyTable({info, instruction}) {
  return (
      <div className='mt-[80px] w-fit  mx-auto flex flex-col items-center gap-[32px] '>
          <div className='w-[150px] h-[150]'>
              <img src="./assets/img/empty-job-list.png" alt="Empty-Job-List" className='w-full h-full'/>
          </div>
      <div className=" flex flex-col items-center gap-[6px] ">
        {info && <p className='font-medium text-[20px] text-[#292929]'>{info}</p>}
      {instruction && <p className='text-[14px] mx-2.5 text-[#707070]'>{instruction}</p>}
      </div>
    </div>
  )
}
