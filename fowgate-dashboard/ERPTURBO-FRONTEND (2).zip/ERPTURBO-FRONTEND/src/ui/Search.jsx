
import React, { useState, useEffect } from "react";
import { FiSearch } from "react-icons/fi";

const Search = ({ onSearch, placeholder = "Search title, name..." }) => {
  const [searchTerm, setSearchTerm] = useState("");

  // Debounce the search input to prevent excessive filtering
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      onSearch(searchTerm);
    }, 300); // 300ms debounce delay

    return () => clearTimeout(delayDebounceFn); // Cleanup on unmount or change
  }, [searchTerm, onSearch]);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <div className="relative">
      <input
        type="text"
        placeholder={placeholder}
        value={searchTerm}
        onChange={handleSearch}
        className="w-48 h-8 pr-8 pl-2 border border-gray-100 rounded-[6px] focus:outline-none font-light text-sm focus:ring-1 focus:ring-blue-500"
      />
      <FiSearch
        className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500"
      />
    </div>
  );
};

export default Search;
