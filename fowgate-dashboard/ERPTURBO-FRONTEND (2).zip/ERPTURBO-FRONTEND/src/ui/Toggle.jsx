import React from "react";
export default function Toggle({ handleToggle, value }) {
  return (
    <div 
      className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors duration-300 ${
        value ? "bg-[#1B5FC1] justify-end" : "bg-gray-300 justify-start"
      }`} 
      onClick={() => handleToggle(!value)} 
    >
      <div className="w-4 h-4 rounded-full bg-white shadow-md transition"></div>
    </div>
  );
}