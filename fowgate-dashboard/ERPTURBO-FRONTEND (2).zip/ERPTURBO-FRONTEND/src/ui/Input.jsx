import React from 'react'

export default function Input({ label, placeholder, inputType, overview, imgUrl, handleChange, index,value, question, required }) {
  return (
    <div className='relative'>
      {label && <div className='flex gap-1'><label className='block mb-2 text-[14px]'>{label}</label> { required && <span className='text-red-600'>*</span> }</div>}
    <input
    value={value}
      type = {!inputType ? "text" : inputType}
      className="w-full border px-2 py-1 text-[16px] text-wrap rounded mb-1  border-gray-200 focus:border-gray-200 outline-none h-[50px] break-words whitespace-normal"
              placeholder={placeholder}
              onChange={
                  !index ? (e) => {
                  handleChange(e.target.value)
              }: (e) => handleChange(index, e.target.value)
              }
          />
          {!overview && <img
                                  src={imgUrl ? imgUrl : "/assets/img/ats-search.png"}
                                  alt={!imgUrl ? "Search Icon" : "Input Icon"}
                                  className={`absolute right-3 ${question? "top-[50%]": "top-[65%]"} transform -translate-y-1/2 `}
                                />}
  </div>
  )
}
