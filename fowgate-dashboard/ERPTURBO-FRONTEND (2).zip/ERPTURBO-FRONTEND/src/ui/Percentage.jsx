import React from 'react'

export default function Percentage({number}) {
  return (
    <span className={`text-[${number >= 70 ? "#34A853" : number > 50 ? "#1B5FC1" :"#EB4335"}]`} >{number ? number : '—' } </span>
  )
}
