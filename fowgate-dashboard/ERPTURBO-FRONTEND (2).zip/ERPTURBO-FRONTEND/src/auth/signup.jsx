import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import LHS from "./LHS/lhs";
// import fowgatelogo from "../assets/img/fowgatelogo.png";
// import googleLogo from "../assets/img/googleLogo.png";
import { authUser } from "../apis/api_auth_user";
import { toast } from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const signup = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [strength, setStrength] = useState("Weak");
  const [loading, setLoading] = useState("");
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const navigate = useNavigate();

  const [userData, setUserData] = useState({
    fullname: "",
    email: "",
    password: "",
    company_code: "",
  });

  const getPasswordStrength = (password) => {
    if (password.length < 8) return "Weak";
    const hasNumbers = /[0-9]/.test(password);
    const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);

    if (hasNumbers && hasSpecialChars && hasUpperCase && hasLowerCase)
      return "Strong";
    if ((hasNumbers && hasSpecialChars && hasLowerCase) || hasUpperCase)
      return "Medium";
    return "Weak";
  };

  const validateFullName = (name) => {
    const fullNameRegex = /^[A-Z][a-z]+(?:\s[A-Z][a-z]+)+$/;
    return fullNameRegex.test(name);
  };

  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  useEffect(() => {
    setStrength(getPasswordStrength(userData.password));
  }, [userData.password]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading("Signing Up");

    if (!validateFullName(userData.fullname)) {
      toast.error("Enter a valid full name (e.g., John Doe).");
      setLoading("Sign Up");
      return;
    }

    if (!validateEmail(userData.email)) {
      toast.error("Invalid email format!");
      setLoading("Sign Up");
      return;
    }

    if (strength === "Strong") {
      // Perform API request

      try {
        const result = await authUser("POST", "/api/auth/signup", userData);

        if (result.success) {
          toast.success(
            result.data.message || "User registered successfully, OTP sent!"
          );
          setShouldNavigate(true); // Trigger navigation after success
        } else {
          toast.error(result.message); // Handle error message
        }
      } catch (err) {
        toast.error("An unexpected error occurred. Please try again.");
      } finally {
        setLoading("Sign Up");
      }
    } else {
      toast.error("Password is too weak! Please make it stronger.");
      setLoading("Sign Up");
      return;
    }
  };

  useEffect(() => {
    if (shouldNavigate) {
      const timeoutId = setTimeout(() => {
        navigate("/otp-verification", {
          state: {
            email: userData.email,
            fullname: userData.fullname,
            password: userData.password,
          },
        });
      }, 3000);

      return () => clearTimeout(timeoutId); // Cleanup timeout properly
    }
  }, [shouldNavigate, navigate]); // Runs when `shouldNavigate` changes

  return (
    <div className="flex flex-row max-h-100vh ">
      <LHS />
      <div className="min-h-screen flex-1 flex justify-center items-center">
        <div className="w-32 fixed top-5 right-10">
          <img src="/assets/img/fowgatelogo.png" alt="" />
        </div>
        <div className="">
          <div className="bg-white  rounded-md w-full max-w-md">
            {/* Title */}
            <h1 className="text-2xl font-bold mb-2">Create an Account</h1>
            <p className="text-gray-500">
              Already have an account?{" "}
              <Link to="/" className="text-[#1B5FC1] font-medium">
                  Sign In
              </Link>
            </p>

            {/* Google Sign-in Button */}
            <button className="w-full flex items-center justify-center border border-gray-300 rounded-md py-2 mt-4 text-gray-600 hover:bg-gray-100 cursor-pointer">
              <img src="/assets/img/googleLogo.png" alt="Google" className="w-5 h-5 mr-2" />
              Google
            </button>

            {/* Divider */}
            <div className="flex items-center my-4">
              <hr className="flex-grow border-gray-300" />
              <span className="px-2 text-gray-500 text-sm">
                or sign in with
              </span>
              <hr className="flex-grow border-gray-300" />
            </div>

            {/* FullName Input */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm mb-1">
                Full Name
              </label>
              <input
                type="text"
                name="fullname"
                onChange={handleChange}
                placeholder="Enter fullname"
                value={userData.fullname}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
              />
            </div>

            {/* Company Code Input */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm mb-1">
                Company Code
              </label>
              <input
                type="text"
                name="company_code"
                onChange={handleChange}
                placeholder="Enter Company Code"
                value={userData.company_code}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
              />
            </div>

            {/* Email Input */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm mb-1">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                onChange={handleChange}
                placeholder="abcde@gmail.com"
                value={userData.email}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
              />
            </div>

            {/* Password Input */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm mb-1">
                Create Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  onChange={handleChange}
                  placeholder="Enter at least 8 characters"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                  value={userData.password}
                />
                <span
                  className="absolute right-3 top-3 cursor-pointer text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </span>
              </div>
            </div>

            <div className="flex justify-between items-center text-sm text-gray-500 pb-5">
              <div className="flex space-x-1">
                {[...Array(4)].map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 w-10 rounded-full ${
                      i <
                      (strength === "Strong"
                        ? 4
                        : strength === "Medium"
                        ? 2
                        : 1)
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                ))}
              </div>
              <span>Password Strength: {strength}</span>
            </div>

            {/* Sign-in Button */}
            <button
              className="w-full bg-[#1B5FC1] text-white py-2 rounded-md hover:bg-blue-700 cursor-pointer"
              type="submit"
              onClick={handleSubmit}
            >
              {loading || "Sign Up"}
            </button>

            {/* Footer Terms */}
            <p className="text-gray-500 text-xs  mt-4">
              By signing in you accept Flowgate’s{" "}
              <a href="#" className="text-blue-500">
                Terms of use
              </a>{" "}
              and acknowledge the{" "}
              <a href="#" className="text-blue-500">
                Privacy statement
              </a>{" "}
              and{" "}
              <a href="#" className="text-blue-500">
                cookie policy
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default signup;
