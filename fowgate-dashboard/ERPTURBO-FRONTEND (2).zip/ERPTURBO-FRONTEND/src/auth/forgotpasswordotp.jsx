import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import LHS from "./LHS/lhs";
// import fowgatelogo from "../assets/img/fowgatelogo.png";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { authUser } from "../apis/api_auth_user";


const forgotpasswordotp = () => {
  const [otp, setOtp] = useState(new Array(6).fill(""));
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const [loading, setLoading] = useState("");
  const inputRefs = useRef([]);

  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email; // Get email from state

  const [userData, setUserData] = useState({
    email: email,
    otp: otp.join(),
  });

  useEffect(() => {
    setUserData((prev) => ({ ...prev, otp: otp.join("") }));
  }, [otp]);

  const handleChange = (e, index) => {
    const value = e.target.value;
    if (!isNaN(value) && value.length <= 1) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Move to next input if value is entered
      if (value !== "" && index < 5) {
        inputRefs.current[index + 1].focus();
      }
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading("Verifying Otp");

    try {
      const result = await authUser("POST","api/auth/verify_login_otp", userData);

      if (result.success) {
        toast.success(result.data.message || "TwoFA verified!");
        setShouldNavigate(true); // Trigger navigation after success
      } else {
        toast.error(result.message); // Handle error message
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading("Verify Otp");
    }
  };

  const handleResend = async(e) => {
        try {
          const result = await authUser("POST","api/auth/forgot_password", email);
    
          if (result.success) {
            toast.success(result.data.message || "User sent forgot password otp");
   
          } else {
            toast.error(result.message); // Handle error message
          }
        } catch (err) {
          toast.error("An unexpected error occurred. Please try again.");
        } finally {
          setLoading("Get Code");
        }
  }

    useEffect(() => {
      if (shouldNavigate) {
        const timeout = setTimeout(() => {
          navigate("/create-new-password", {
            state: { email: userData.email },
          });
        }, 3000);
  
        return () => clearTimeout(timeout); // Cleanup timeout
      }
    }, [shouldNavigate, navigate]); // Runs when `shouldNavigate` changes
  
  return (
    <div className="flex flex-row max-h-100vh ">
      <LHS />
      <div className="min-h-screen flex-1 flex justify-center items-center">
        <div className="w-32 fixed top-5 right-10">
          <img src="/assets/img/fowgatelogo.png" alt="" />
        </div>

        <div className="">
          <div className="">
            <div className=" max-w-md w-full p-6 ">
              <a href="#" className="text-[#1B5FC1] text-sm">
                <Link to="/forgotpassword">&larr; Back</Link>
              </a>
              <h2 className="text-2xl font-semibold mt-5">
                Two Factor Authentication
              </h2>
              <p className="text-gray-600 text-sm mt-1">
                Check your email for a verification code to secure your account.
              </p>

              <div className="mt-4">
                <p className="">Enter code</p>
                <div className="grid grid-cols-6 gap-2 mt-1">
                  {otp.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      value={digit}
                      placeholder="-"
                      onChange={(e) => handleChange(e, index)}
                      onKeyDown={(e) => handleKeyDown(e, index)}
                      maxLength="1"
                      className="w-full h-14 text-center text-lg font-semibold border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ))}
                </div>
              </div>

              <button
                onClick={handleSubmit}
                className="w-full bg-[#1B5FC1]  text-white py-2 mt-4 rounded-md hover:bg-blue-700 transition cursor-pointer"
              >
                {loading || 'Verify Otp'}
              </button>

              <p className="text-[#1B5FC1] text-sm mt-2 cursor-pointer text-center"
              onClick={handleResend}>
                Resend Code
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default forgotpasswordotp;
