import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import LHS from "./LHS/lhs";
// import fowgatelogo from "../assets/img/fowgatelogo.png";
// import googleLogo from "../assets/img/googleLogo.png";
import { authUser } from "../apis/api_auth_user";
import { toast } from "react-hot-toast";
import { useNavigate, useLocation } from "react-router-dom";

const createnewpassword = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [strength, setStrength] = useState("Weak");
  const [loading, setLoading] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const navigate = useNavigate();

  const location = useLocation();
  const email = location.state?.email; // Get email from state

  const [userData, setUserData] = useState({
    email: email,
    password: "",
  });

  const getPasswordStrength = (password) => {
    if (password.length < 8) return "Weak";
    const hasNumbers = /[0-9]/.test(password);
    const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);

    if (hasNumbers && hasSpecialChars && hasUpperCase && hasLowerCase)
      return "Strong";
    if ((hasNumbers && hasSpecialChars && hasLowerCase) || hasUpperCase)
      return "Medium";
    return "Weak";
  };

  useEffect(() => {
    setStrength(getPasswordStrength(userData.password));
  }, [userData.password]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading("Creating New Password");

    if (strength === "Strong") {
      // Perform API request
      if (userData.password === confirmPassword) {

        try {
          const result = await authUser("PATCH", "api/auth/create_new_password", userData);

          if (result.success) {
            toast.success(
              result.data.message || "User registered successfully, OTP sent!"
            );
            setShouldNavigate(true); // Trigger navigation after success
          } else {
            toast.error(result.message); // Handle error message
          }
        } catch (err) {
          toast.error("An unexpected error occurred. Please try again.");
        } finally {
          setLoading("Create New Password");
        }
      } else {
        toast.error("Password does not match");
        setLoading("Create New Password");
      }
    } else {
      toast.error("Password is too weak! Please make it stronger.");
      setLoading("Create New Password");
      return;
    }
  };

  useEffect(() => {
    if (shouldNavigate) {
      const timeoutId = setTimeout(() => {
        navigate("/");
      }, 3000);

      return () => clearTimeout(timeoutId); // Cleanup timeout properly
    }
  }, [shouldNavigate, navigate]); // Runs when `shouldNavigate` changes

  return (
    <div className="flex flex-row max-h-100vh ">
      <LHS />
      <div className="min-h-screen flex-1 flex justify-center items-center">
        <div className="w-32 fixed top-5 right-10">
          <img src="/assets/img/fowgatelogo.png" alt="" />
        </div>
        <div className="">
          <div className="bg-white  rounded-md w-full max-w-md">
            {/* Title */}
            <h1 className="text-3xl font-semibold mb-2">Create Password</h1>
            <p className="text-gray-500 mb-7">
              Create a strong and secure password to access your account.
            </p>

            {/* Password Input */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm mb-1">
                Enter Password
              </label>
              <div className="relative">
                <input
                  name="password"
                  onChange={handleChange}
                  value={userData.password}
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter at least 8 characters"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                />
                <span
                  className="absolute right-3 top-3 cursor-pointer text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </span>
              </div>
            </div>

            {/* Confirm Password Input */}
            <div className="mb-4">
              <label className="block text-gray-700 text-sm mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter at least 8 characters"
                  name="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
                />
                <span
                  className="absolute right-3 top-3 cursor-pointer text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </span>
              </div>
            </div>

            <div className="flex justify-between items-center text-sm text-gray-500 mb-10">
              <div className="flex space-x-1">
                {[...Array(4)].map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 w-10 rounded-full ${
                      i <
                      (strength === "Strong"
                        ? 4
                        : strength === "Medium"
                        ? 2
                        : 1)
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                ))}
              </div>
              <span>Password Strength: {strength}</span>
            </div>

            {/* Sign-in Button */}
            <button
              className="w-full bg-[#1B5FC1] text-white py-2 rounded-md hover:bg-blue-700 cursor-pointer"
              onClick={handleSubmit}
            >
              {loading || "Create New Password"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default createnewpassword;
