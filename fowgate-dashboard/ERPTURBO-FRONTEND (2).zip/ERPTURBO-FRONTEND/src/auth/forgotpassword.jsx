import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import LHS from "./LHS/lhs";
// import googleLogo from "../assets/img/googleLogo.png";
import { authUser } from "../apis/api_auth_user";
import { toast } from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const forgotpassword = () => {
  const [loading, setLoading] = useState("");
  const [shouldNavigate, setShouldNavigate] = useState(false);
  const navigate = useNavigate();

  const [userData, setUserData] = useState({
    email: "",
  });

  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading("Sending Code");

    if (!validateEmail(userData.email)) {
      toast.error("Invalid email format!");
      setLoading("Get Code");
      return;
    }

    try {
      const result = await authUser("POST","api/auth/forgot_password", userData);

      if (result.success) {
        toast.success(result.data.message || "User sent forgot password otp");
        setShouldNavigate(true); // Trigger navigation after success
      } else {
        toast.error(result.message); // Handle error message
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setLoading("Get Code");
    }
  };

  useEffect(() => {
    if (shouldNavigate) {
      const timeout = setTimeout(() => {
        navigate("/forgotpassword_otp", {
          state: { email: userData.email },
        });
      }, 3000);

      return () => clearTimeout(timeout); // Cleanup timeout
    }
  }, [shouldNavigate, navigate]); // Runs when `shouldNavigate` changes

  return (
    <div className="flex flex-row max-h-100vh ">
      <LHS />
      <div className="min-h-screen w-full flex flex-1 justify-center items-center ">
        <div className="w-32 fixed top-5 right-10">
          <img src="./assets/img/fowgatelogo.png" alt="Fowgate Logo" />
        </div>
        <div className="w-full max-w-md  ">
          {/* Title */}
          <a href="#" className="text-[#1B5FC1] text-sm">
            <Link to="/">&larr; Back to login</Link>
          </a>
          <h1 className="text-3xl font-semibold mb-2 mt-5">Forgot Password</h1>
          <p className="text-gray-500 mb-7">
            Enter your email and we will send you a reset code
          </p>

          {/* Email Input */}
          <div className="mb-10">
            <label className="block text-gray-700 text-sm mb-1">
              Email Address
            </label>
            <input
              type="email"
              name="email"
              onChange={handleChange}
              placeholder="abcde@gmail.com"
              value={userData.email}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-300"
            />
          </div>

          {/* Sign-in Button */}
        
            <button className="w-full bg-[#1B5FC1] text-white py-2 rounded-md hover:bg-blue-700 cursor-pointer"
            onClick={handleSubmit}>
              
              {loading || 'Get Code'}
            </button>
        
          {/* Footer Terms */}
          <p className="text-gray-500 text-xs text-center mt-2">
            New to Fowgate?{" "}
            <Link to="/signup" className="text-blue-500">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default forgotpassword;
