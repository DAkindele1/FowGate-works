
import React, { useState, useRef, useEffect } from "react";
import { FiChevronDown } from "react-icons/fi";
import toast from "react-hot-toast";

function EditStep1({ formData = {}, handleInputChange, handleNextStep, closeModal, grievance, edits, setEdits}) {
  const grievanceTypes = ["Infrastructure", "Health & Sanitation", "Environment", "Safety","Utilities (Water, Electricity)","other"];
  const urgencyLevels = ["low", "medium", "high"];
  const [errors, setErrors] = useState({});
  const [previewImage, setPreviewImage] = useState(null);
  const fileInputRef = useRef(null);

  // Handle file input click
  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  // Handle file selection
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      handleInputChange({ target: { name: "attachment", value: file } });
      if (file.type.startsWith("image/")) {
        setPreviewImage(URL.createObjectURL(file));
      } else {
        setPreviewImage(null);
      }
    }
  };

  const handleEdit = (e, name) => {
    const value = e.target.value
    setEdits((prev) => ({...prev, [name]: value}))
  }

  // Handle Next button click
  const handleNext = (e) => {
    e.preventDefault();

    // Create FormData object
    const formDataToSend = new FormData();
    formDataToSend.append("title", formData.title);
    formDataToSend.append("grievanceType", formData.grievanceType);
    formDataToSend.append("description", formData.description);
    formDataToSend.append("urgencyLevel", formData.urgencyLevel);
    if (formData.attachment) {
      formDataToSend.append("attachment", formData.attachment);
    }

    // Pass FormData to the next step
    handleNextStep(formDataToSend);
  };

  return (
     <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white overflow-hidden flex flex-col rounded-lg">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="edit" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Edit Report</h2>
          </div>
          <button onClick={closeModal} className="text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="px-4 py-3 overflow-y-auto flex-1">
          <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
            <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
              <img src="/one.svg" alt="one" width={20} height={20} />
            </span>
            <span className="text-black">
              1/4 - <span className="font-bold">GRIEVANCE INFORMATION</span>
            </span>
          </div>
          <hr className="border-t border-gray-300 my-3" />

          <div className="space-y-4 text-sm">
            {/* File Upload */}
            

            {/* Grievance Title */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Grievance Title</label>
              <input
                type="text"
                name="title"
                defaultValue={grievance.title}
                onChange={(e) => handleEdit(e, "title")}
                placeholder="Enter title"
                className={`w-full border ${
                  errors.title ? "border-red-500" : "border-gray-300"
                } rounded-[6px] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
              />
              {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
            </div>

            {/* Grievance Type */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Grievance Type</label>
              <div className="relative">
                <select
                  name="grievanceType"
                  defaultValue={grievance.type}
                  onChange={(e) => handleEdit(e, "type")}
                  className={`w-full border ${
                    errors.grievanceType ? "border-red-500" : "border-gray-300"
                  } rounded-[6px] px-3 py-2 appearance-none pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                >
                  <option value="">Select</option>
                  {grievanceTypes.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                <FiChevronDown className="absolute right-3 top-3 text-gray-500 pointer-events-none" />
              </div>
              {errors.grievanceType && (
                <p className="text-red-500 text-xs mt-1">{errors.grievanceType}</p>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Description</label>
              <textarea
                name="description"
                defaultValue={grievance.description}
                onChange={(e) => handleEdit(e, "description")}
                placeholder="Type here"
                className={`w-full border ${
                  errors.description ? "border-red-500" : "border-gray-300"
                } rounded-[6px] px-3 py-2 text-sm h-24 resize-none focus:outline-none focus:ring-1 focus:ring-blue-500`}
              />
              {errors.description && (
                <p className="text-red-500 text-xs mt-1">{errors.description}</p>
              )}
            </div>

            {/* Urgency Level */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Urgency Level</label>
              <div className="relative">
                <select
                  name="urgencyLevel"
                  defaultValue={grievance.urgency.toLowerCase()}
                  onChange={(e) => handleEdit(e, "urgency")}
                  className={`w-full border ${
                    errors.urgencyLevel ? "border-red-500" : "border-gray-300"
                  } rounded-[6px] px-3 py-2 appearance-none pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500`}
                >
                  <option value="">Select</option>
                  {urgencyLevels.map((level) => (
                    <option key={level} value={level}>{level}</option>
                  ))}
                </select>
                <FiChevronDown className="absolute right-3 top-3 text-gray-500 pointer-events-none" />
              </div>
              {errors.urgencyLevel && (
                <p className="text-red-500 text-xs mt-1">{errors.urgencyLevel}</p>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            type="button"
            onClick={closeModal}
            className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export default EditStep1;