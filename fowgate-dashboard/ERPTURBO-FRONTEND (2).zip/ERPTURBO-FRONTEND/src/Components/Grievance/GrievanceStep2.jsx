


import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { FiChevronDown } from "react-icons/fi";

// Fix Leaflet marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const MapModal = ({ isOpen, onClose, onSelectLocation, mapType }) => {
  const [center, setCenter] = useState([6.5244, 3.3792]);
  const [selectedLocation, setSelectedLocation] = useState(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCenter([position.coords.latitude, position.coords.longitude]);
        },
        () => {
          console.warn("Geolocation unavailable, using default center.");
        }
      );
    }
  }, []);

  const MapClickHandler = () => {
    useMapEvents({
      click: (e) => {
        const { lat, lng } = e.latlng;
        setSelectedLocation([lat, lng]);
        onSelectLocation({ lat, lng, address: `Lat: ${lat}, Lng: ${lng}` });
      },
    });
    return null;
  };

  if (!isOpen) return null;

  const tileUrl =
    mapType === "Satellite View"
      ? "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
      : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  const attribution =
    mapType === "Satellite View"
      ? '© <a href="https://www.esri.com/">Esri</a>'
      : '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-[3px] p-4 w-[80%] h-[80%] max-w-4xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Select Location</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <MapContainer center={center} zoom={10} style={{ width: "100%", height: "90%" }}>
          <TileLayer url={tileUrl} attribution={attribution} />
          {selectedLocation && <Marker position={selectedLocation} />}
          <MapClickHandler />
        </MapContainer>
      </div>
    </div>
  );
};

function GrievanceStep2({ formData = {}, onChange, onNext, onBack, onClose }) {
  const [localFormData, setLocalFormData] = useState({
    state: formData.state || "",
    lga: formData.lga || "",
    community: formData.community || "",
  });

  useEffect(() => {
    setLocalFormData({
      state: formData.state || "",
      lga: formData.lga || "",
      community: formData.community || "",
    });
  }, [formData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLocalFormData((prev) => ({ ...prev, [name]: value }));
    onChange?.(name, value); // ✅ Match Step1
  };

  const [showMapDropdown, setShowMapDropdown] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [selectedMapType, setSelectedMapType] = useState("Map View");
  const [mapPreviewUrl, setMapPreviewUrl] = useState(null);

  const handleMapSelect = (mapType) => {
    setSelectedMapType(mapType);
    setShowMapDropdown(false);
    setShowMapModal(true);
  };

  const handleLocationSelect = ({ lat, lng, address }) => {
    const newCommunity = address || `Lat: ${lat}, Lng: ${lng}`;
    const preview = `https://tile.openstreetmap.org/14/${Math.floor(
      (lng + 180) / 360 * Math.pow(2, 14)
    )}/${Math.floor(
      (1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, 14)
    )}.png`;

    setMapPreviewUrl(preview);
    setLocalFormData((prev) => ({ ...prev, community: newCommunity }));
    onChange?.("community", newCommunity); // ✅ Match Step1
    setShowMapModal(false);
  };

  const handleNext = () => {
    onNext?.({ ...localFormData }); // ✅ Structured like Step1
  };

  return (
    <div className="flex items-center   justify-center backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="add" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Add New</h2>
          </div>
          <button onClick={onClose} className="text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="px-4 py-3 overflow-y-auto flex-1">
          <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
            <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
              <img src="/three.svg" alt="one" width={20} height={20} />
            </span>
            <span className="text-black">
              2/4 - <span className="font-bold">LOCATION DETAILS</span>
            </span>
          </div>
          <hr className="border-t border-gray-300 my-3" />

          <div className="space-y-4 text-sm">
            <div>
              <label className="block text-sm text-gray-700 mb-1">State</label>
              <select
                name="state"
                value={localFormData.state}
                onChange={handleChange}
                className="w-full border border-gray-300 rounded-[6px] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">Select</option>
                <option value="Lagos">Lagos</option>
                <option value="Oyo">Oyo</option>
                <option value="Kano">Kano</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">LGA</label>
              <input
                type="text"
                name="lga"
                value={localFormData.lga}
                onChange={handleChange}
                placeholder="Enter LGA"
                className="w-full border border-gray-300 rounded-[6px] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">Community/Area</label>
              <div className="relative mt-1">
                <div className="flex items-center w-full border border-gray-300 rounded-[6px] p-1.5 focus-within:ring-1 focus-within:ring-blue-500">
                  <FiChevronDown
                    className="text-blue-600 mr-2 cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowMapDropdown((prev) => !prev);
                    }}
                  />
                  <input
                    type="text"
                    name="community"
                    value={localFormData.community}
                    onChange={handleChange}
                    placeholder="Enter"
                    className="flex-1 bg-transparent outline-none text-sm"
                  />
                </div>

                <div
                  className={`absolute left-0 top-full mt-1 w-40 bg-white border border-gray-300 rounded-[6px] shadow-lg z-20 transition-all duration-200 origin-top-left transform ${
                    showMapDropdown ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => handleMapSelect("Map View")}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Map View
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMapSelect("Satellite View")}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Satellite View
                  </button>
                </div>
              </div>

              <div className="mt-2">
                {mapPreviewUrl ? (
                  <img src={mapPreviewUrl} alt="Map Preview" className="w-full h-40 object-cover rounded-[6px]" />
                ) : (
                  <div className="w-full h-40 bg-gray-100 rounded-[6px] flex items-center justify-center text-gray-500 text-sm">
                    No location selected
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            type="button"
            onClick={onBack}
            className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
          >
            Prev
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
          >
            Next
          </button>
        </div>
      </div>

      {/* Map Modal */}
      <MapModal
        isOpen={showMapModal}
        onClose={() => setShowMapModal(false)}
        onSelectLocation={handleLocationSelect}
        mapType={selectedMapType}
      />
    </div>
  );
}

export default GrievanceStep2;
