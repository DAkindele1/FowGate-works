import React from "react";
import { FiX } from "react-icons/fi";

const FilterModal = ({
  onClose,
  types = [],
  statuses = [],
  severities = [],
  current = {},
  onChange,
  onClear,
  onReset,
  onApply,
}) => {
  return (
    <div className="fixed inset-0 z-50  bg-opacity-30 flex items-center justify-center">
      <div className="bg-white rounded-lg w-[90%] max-w-md shadow-lg">
        <div className="flex items-center justify-between px-4 py-3 bg-[#F3F2F2]">
          <h2 className="text-lg font-semibold">Filter by</h2>
          <button onClick={onClose} className="text-black hover:text-black">
            <FiX size={20} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Type */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-medium">Type</label>
              <button
                className="text-blue-600 text-sm"
                onClick={() => onClear("type")}
              >
                Clear
              </button>
            </div>
           <div className="relative">
  <select
    value={current.type || ""}
    onChange={(e) => onChange("type", e.target.value)}
    className="w-full appearance-none border-gray-200   border  rounded-md px-3 py-2 pr-8 text-gray-700"
  >
    <option value="">Select</option>
    {types.map((type) => (
      <option key={type} value={type}>
        {type}
      </option>
    ))}
  </select>

  <img
    src="/arrow.svg"
    alt="Dropdown Arrow"
    className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none  text-gray-400"
  />
</div>

          </div>

          {/* Status */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-medium">Status</label>
              <button
                className="text-blue-600 text-sm"
                onClick={() => onClear("status")}
              >
                Clear
              </button>
            </div>
           <div className="relative">
  <select
    value={current.status || ""}
    onChange={(e) => onChange("status", e.target.value)}
    className="w-full appearance-none border-gray-200   border rounded-md px-3 py-2 pr-8 text-gray-700"
  >
    <option value="">Select</option>
    {statuses.map((status) => (
      <option key={status} value={status}>
        {status}
      </option>
    ))}
  </select>

  <img
    src="/arrow.svg"
    alt="Dropdown Arrow"
    className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none  text-gray-400"
  />
</div>

          </div>

          {/* Severity */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="font-medium">Severity</label>
              <button
                className="text-blue-600 text-sm"
                onClick={() => onClear("severity")}
              >
                Clear
              </button>
            </div>
            {/* <div className="relative">
              <select
                value={current.severity || ""}
                onChange={(e) => onChange("severity", e.target.value)}
                className="w-full border rounded-md px-3 py-2 pr-8 text-gray-700"
              >
                <option value="">Select</option>
                {severities.map((sev) => (
                  <option key={sev} value={sev}>
                    {sev}
                  </option>
                ))}
              </select>
                <img
  src="/arrow.svg"
  alt="Dropdown Arrow" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" /> 
             

            </div> */}

            <div className="relative">
  <select
    value={current.severity || ""}
    onChange={(e) => onChange("severity", e.target.value)}
    className="w-full appearance-none border-gray-200   border rounded-md px-3 py-2 pr-8 text-gray-700"
  >
    <option value="">Select</option>
    {severities.map((sev) => (
      <option key={sev} value={sev}>
        {sev}
      </option>
    ))}
  </select>

  <img
    src="/arrow.svg"
    alt="Dropdown Arrow"
    className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400"
  />
</div>

          </div>
        </div>

        {/* <div className="flex items-center gap-2 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white justify-between px-4 py-3 ">
          <button
            className="text-sm text-gray-500 hover:underline"
            onClick={onReset}
          >
            Reset
          </button>
          <button
            className="text-sm bg-[#E8EFF9] text-[#1B5FC1] px-4 py-2 rounded-md hover:bg-[#174bb2]"
            onClick={onApply}
          >
            Apply Now
          </button>
        </div> */}


        <div className="flex items-center gap-2 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white px-4 py-3">
  <div className="flex items-center gap-6 ml-auto">
    <button
      className="text-sm text-gray-500 "
      onClick={onReset}
    >
      Reset
    </button>
    <button
      className="text-sm bg-[#E8EFF9] text-[#1B5FC1] px-4 py-2 rounded-md hover:bg-[#dde8f7] hover:text-white"
      onClick={onApply}
    >
      Apply Now
    </button>
  </div>
</div>

      </div>
    </div>
  );
};

export default FilterModal;
