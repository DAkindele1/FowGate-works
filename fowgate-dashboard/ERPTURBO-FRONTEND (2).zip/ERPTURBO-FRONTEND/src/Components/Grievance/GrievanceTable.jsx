

import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import EditStep1 from "./EditStep1";
import EditStep2 from "./EditStep2";
import ConfirmPage from "./ConfirmPage";
import SuccessPage from "./SuccessPage";
import GrievanceGridCard from "./GrievanceGridCard";
import Overview from "./Overview";
import ThreadPopup from "./ThreadPopup";

function GrievanceTable({ grievances: initialGrievances, viewMode, onDelete, onUpdate, fetchGrievances }) {
  const [openDropdown, setOpenDropdown] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalStep, setModalStep] = useState(1);
  const [selectedGrievance, setSelectedGrievance] = useState({});
  const [formData, setFormData] = useState({
    cloName: "",
    oml: "",
    hostCommunity: "",
    company: "",
    grievanceDate: "",
    cloPhone: "",
    grievanceTitle: "",
    grievanceType: "",
    urgencyLevel: "",
    description: "",
    complainant: "",
    attachments: [],
    state: "",
    lga: "",
    community: "",
    status: "",
    id: "",
    latitude: 0,
    longitude: 0,
  });
  const [isOverviewOpen, setIsOverviewOpen] = useState(false);
  const [overviewData, setOverviewData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState(null);
  const [edits, setEdits] = useState({});
  const [isThreadOpen, setIsThreadOpen] = useState(false);
  const [selectedThreadGrievance, setSelectedThreadGrievance] = useState(null);
  const [grievances, setGrievances] = useState(initialGrievances);
  // Track optimistic comment count for the thread popup
  const [optimisticThreadCount, setOptimisticThreadCount] = useState(0);

  const dropdownRefs = useRef({});
  const navigate = useNavigate();

  useEffect(() => {
    setGrievances(initialGrievances);
  }, [initialGrievances]);

  useEffect(() => {
    const token = localStorage.getItem("userAccess");
    if (!token || token === "undefined") {
      toast.error("Please log in to continue");
      navigate("/login");
    }
  }, [navigate]);

  useEffect(() => {
    function handleClickOutside(e) {
      const anyOpen = Object.entries(dropdownRefs.current).some(([id, ref]) => {
        return ref && !ref.contains(e.target);
      });
      if (anyOpen) {
        setOpenDropdown(null);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDropdown = (id) => {
    setOpenDropdown(openDropdown === id ? null : id);
  };

  const openEditModal = (grievance) => {
    setSelectedGrievance(grievance);
    setIsModalOpen(true);
    setModalStep(1);
    setOpenDropdown(null);
    setApiError(null);
  };

  const handleViewReport = (grievance) => {
    setOverviewData(grievance);
    setIsOverviewOpen(true);
    setOpenDropdown(null);
  };

  const openThreadPopup = (grievance) => {
    setSelectedThreadGrievance(grievance);
    setOptimisticThreadCount(0); // Reset when opening
    setIsThreadOpen(true);
    setOpenDropdown(null);
  };

  const handleAddComment = async (commentText) => {
    setOptimisticThreadCount((prev) => prev + 1); // Optimistically increment
    const token = localStorage.getItem("userAccess");
    if (!token || token === "undefined") {
      toast.error("Session expired. Please log in again.");
      localStorage.removeItem("userAccess");
      navigate("/login");
      return;
    }
    const grieviance_code = selectedThreadGrievance?.grieviance_code;
    if (!grieviance_code) {
      toast.error("No grievance code found.");
      return;
    }

    setLoading(true);
    setApiError(null);
    try {
      const response = await fetch("https://erpturbo-backend.onrender.com/api/oml/grieviance_management/add_to_thread", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          grieviance_code,
          message: commentText,
        }),
      });
      const result = await response.json();
      if (!response.ok) {
        toast.error(result.message || "Failed to add comment");
        throw new Error(result.message || "Failed to add comment");
      }
      toast.success(result?.message || "Comment added successfully!");
      // Optionally refresh grievances from server
      if (typeof fetchGrievances === "function") await fetchGrievances();
      setOptimisticThreadCount(0); // Reset after refresh
      setIsThreadOpen(false);
    } catch (err) {
      setApiError(err.message || "Failed to add comment.");
      toast.error(err.message || "Failed to add comment");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    if (e.target.type === "file") {
      const files = Array.from(e.target.files);
      setFormData((prev) => ({ ...prev, attachments: files }));
    } else {
      const { name, value } = e.target;
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
    setApiError(null);
  };

  const handleNextStep = () => setModalStep(4);
  const handleSubmit = () => setModalStep(5);

  const handleConfirm = async () => {
    setLoading(true);
    setApiError(null);

    try {
      const token = localStorage.getItem("userAccess");
      if (!token || token === "undefined") {
        toast.error("Session expired. Please log in again.");
        localStorage.removeItem("userAccess");
        navigate("/login");
        return;
      }

      const payload = {
        grieviance_code: selectedGrievance.grieviance_code,
        updates: edits,
      };

      const formDataObj = new FormData();
      formDataObj.append("data", JSON.stringify(payload));

      const endpoint = "https://erpturbo-backend.onrender.com/api/oml/grieviance_management/edit_grieviance";
      const response = await fetch(endpoint, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formDataObj,
      });

      const result = await response.json();

      if (!response.ok) {
        if (response.status === 401) {
          toast.error("Session expired. Please log in again.");
          localStorage.removeItem("userAccess");
          navigate("/login");
          return;
        }
        toast.error(result.message);
        throw new Error(result.message);
      }

      toast.success(result?.message || "Grievance updated successfully!");
      if (typeof fetchGrievances === "function") await fetchGrievances();

      setModalStep(6);
    } catch (err) {
      setApiError(err.message || "Failed to update grievance.");
      toast.error(err.message || "Update failed");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this grievance?")) return;

    setLoading(true);
    setApiError(null);

    try {
      const token = localStorage.getItem("userAccess");
      if (!token || token === "undefined") {
        toast.error("Session expired. Please log in again.");
        localStorage.removeItem("userAccess");
        navigate("/login");
        return;
      }

      const response = await fetch(
        `https://erpturbo-backend.onrender.com/api/oml/grieviance_management/get_grieviances/${id}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        }
      );

      const result = await response.json();
      if (!response.ok) throw new Error(result.message);

      toast.success(result?.message || "Deleted successfully");
      if (typeof onDelete === "function") onDelete(id);
      if (typeof fetchGrievances === "function") await fetchGrievances();

      setOpenDropdown(null);
    } catch (err) {
      setApiError(err.message || "Delete failed");
      toast.error(err.message || "Delete failed");
    } finally {
      setLoading(false);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setModalStep(1);
    setSelectedGrievance(null);
    setFormData({
      cloName: "",
      oml: "",
      hostCommunity: "",
      company: "",
      grievanceDate: "",
      cloPhone: "",
      grievanceTitle: "",
      grievanceType: "",
      urgencyLevel: "",
      description: "",
      complainant: "",
      attachments: [],
      state: "",
      lga: "",
      community: "",
      status: "",
      id: "",
      latitude: 0,
      longitude: 0,
    });
    setApiError(null);
  };

  return (
    <div className="  rounded-lg mt-3 overflow-visible relative z-10">
      {apiError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded mb-4 text-sm">
          {apiError}
        </div>
      )}
      {loading && (
        <div className="flex justify-center mb-4">
          <svg className="w-6 h-6 animate-spin text-blue-500" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        </div>
      )}

      {viewMode === "list" ? (
        <table className="min-w-full bg-white table-fixed">
          <thead>
            <tr className="bg-[#E8EFF9] text-xs font-semibold text-[#292929] tracking-wider">
              <th className="py-3 px-4 text-left w-[120px]">Date Created</th>
              <th className="py-3 px-4 text-left w-[180px]">Grievance Title</th>
              <th className="py-3 px-4 text-left w-[120px]">Type</th>
              <th className="py-3 px-4 text-left w-[120px]">Complainant</th>
              <th className="py-3 px-4 text-left w-[110px]">Urgency</th>
              <th className="py-3 px-4 text-left w-[110px]">Status</th>
              <th className="py-3 px-4 text-left w-[90px]">Action</th>
            </tr>
          </thead>
          {/* <tbody> 

            {grievances.length > 0 ? (
              grievances.map((grievance, index) => {
                const commentCount = grievance.comments?.length || 0;
                return (
                  <tr key={grievance.id || index} className="border-t border-gray-200">
                    <td className="py-2 px-2 text-xs">{grievance.grieviance_date}</td>
                    <td className="py-2 px-2 text-xs">
                      <div className="flex items-center space-x-2">
                        <span>{grievance.title}</span>
                        <span className="bg-blue-50 rounded-full px-3 py-1 flex items-center">
                          <span className="text-gray-400 text-xs">{commentCount}</span>
                          <img src="/bubble-chat.svg" alt="chat" width={16} height={16} className="ml-1" />
                        </span>
                      </div>
                    </td>
                    <td className="py-2 px-2 text-xs">{grievance.type}</td>
                    <td className="py-2 px-2 text-xs">{grievance.complainant || "N/A"}</td>
                    <td className="py-2 px-2 text-xs">
                      <div className="flex items-center space-x-1">
                        <img src={`/${grievance.urgency?.toLowerCase()}.svg`} className="w-4 h-4" alt="" />
                        <span>{grievance.urgency}</span>
                      </div>
                    </td>
                    <td className="py-2 px-2 text-xs">
                      <div className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[12px] ${
                        {
                          "In Progress": "bg-[#FDF3E6] text-[#EB8A00]",
                          Resolved: "bg-[#EBF6EE] text-[#34A853]",
                          Unresolved: "bg-[#FDECEB] text-[#EB4335]",
                          Pending: "bg-[#FDF3E6] text-[#EB8A00]",
                        }[grievance.status] || "bg-[#FDECEB] text-[#EB4335]"
                      }`}>
                        {grievance.status}
                      </div>
                    </td>
                    <td className="py-2 px-2 text-xs relative">
                      <button onClick={() => toggleDropdown(grievance.id || index)} className="p-1 rounded-full hover:bg-gray-100">
                        <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v.01M12 12v.01M12 18v.01" />
                        </svg>
                      </button>
                      {openDropdown === (grievance.id || index) && (
                        <div ref={(el) => dropdownRefs.current[grievance.id || index] = el}
                             className="absolute right-2 top-full mt-1 w-40 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                          <button onClick={() => handleViewReport(grievance)} className="flex items-center w-full px-3 py-1 text-xs hover:bg-gray-100">
                            <img src="/file.svg" className="w-3 h-3 mr-1" alt="View" />
                            View Report
                          </button>
                          <button onClick={() => openEditModal(grievance)} className="flex items-center w-full px-3 py-1 text-xs hover:bg-gray-100">
                            <img src="/pen.svg" className="w-3 h-3 mr-1" alt="Edit" />
                            Edit Report
                          </button>
                          <button onClick={() => openThreadPopup(grievance)} className="flex items-center w-full px-3 py-1 text-xs hover:bg-gray-100">
                            <img src="/chat.svg" className="w-3 h-3 mr-1" alt="Thread" />
                            Thread[{commentCount}]
                          </button>
                          <button onClick={() => handleDelete(grievance.id || index)} className="flex items-center w-full px-3 py-1 text-xs text-red-600 hover:bg-gray-100">
                            <img src="/del.svg" className="w-3 h-3 mr-1" alt="Delete" />
                            Delete Report
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan="7" className="text-center text-sm text-gray-500 py-4">No grievances found.</td>
              </tr>
            )}
          </tbody> */}

          <tbody>
  {grievances.length > 0 ? (
    grievances.map((grievance, index) => {
      const commentCount = (Array.isArray(grievance.thread) && grievance.thread.length > 0)
        ? grievance.thread.length
        : (Array.isArray(grievance.comments) ? grievance.comments.length : 0);
      return (
        <tr key={grievance.id || index} className="border-b border-gray-100 hover:bg-gray-50">
          <td className="py-3 px-4 text-sm text-gray-900 whitespace-nowrap overflow-hidden text-ellipsis w-[120px]">{grievance.grieviance_date}</td>
          <td className="py-3 px-4 text-sm text-gray-900 whitespace-nowrap overflow-hidden text-ellipsis w-[180px]">
            <div className="flex items-center space-x-2">
              <span className="overflow-hidden text-ellipsis whitespace-nowrap max-w-[110px] block">{grievance.title}</span>
              <button
                className="bg-blue-50 rounded-full px-2 py-0.5 flex items-center focus:outline-none hover:bg-blue-100 transition"
                style={{ cursor: 'pointer' }}
                title="View Thread"
                onClick={() => openThreadPopup(grievance)}
              >
                <span className="text-gray-500 text-xs">{commentCount}</span>
                <img src="/bubble-chat.svg" alt="chat" width={14} height={14} className="ml-1" />
              </button>
            </div>
          </td>
          <td className="py-3 px-4 text-sm text-gray-900 w-[120px]">{grievance.type}</td>
          <td className="py-3 px-4 text-sm text-gray-900 w-[120px]">{grievance.complainant || "N/A"}</td>
          <td className="py-3 px-4 text-sm text-gray-900 w-[110px]">
            <div className="flex items-center space-x-1">
              <img src={`/${grievance.urgency?.toLowerCase()}.svg`} className="w-4 h-4" alt="" />
              <span>{grievance.urgency}</span>
            </div>
          </td>
          <td className="py-3 px-4 text-sm w-[110px]">
            <div
              className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                {
                  "In Progress": "bg-[#FDF3E6] text-[#EB8A00]",
                  Resolved: "bg-[#EBF6EE] text-[#34A853]",
                  Unresolved: "bg-[#FDECEB] text-[#EB4335]",
                  Pending: "bg-[#FDF3E6] text-[#EB8A00]",
                }[grievance.status] || "bg-[#FDECEB] text-[#EB4335]"
              }`}
            >
              {grievance.status}
            </div>
          </td>
          <td className="py-3 px-4 text-sm relative w-[90px]">
            <button
              onClick={() => toggleDropdown(grievance.id || index)}
              className="p-1 rounded-full hover:bg-gray-100"
            >
              <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v.01M12 12v.01M12 18v.01" />
              </svg>
            </button>
            {openDropdown === (grievance.id || index) && (
              <div
                ref={(el) => (dropdownRefs.current[grievance.id || index] = el)}
                className="absolute right-2 top-full mt-1 w-44 bg-white border border-gray-200 rounded-lg shadow-lg z-10"
              >
                <button
                  onClick={() => handleViewReport(grievance)}
                  className="flex items-center w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-100"
                >
                  <img src="/file.svg" className="w-3 h-3 mr-2" alt="View" />
                  View Report
                </button>
                <button
                  onClick={() => openEditModal(grievance)}
                  className="flex items-center w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-100"
                >
                  <img src="/pen.svg" className="w-3 h-3 mr-2" alt="Edit" />
                  Edit Report
                </button>
                <button
                  onClick={() => openThreadPopup(grievance)}
                  className="flex items-center w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-100"
                >
                  <img src="/chat.svg" className="w-3 h-3 mr-2" alt="Thread" />
                  Thread[{commentCount}]
                </button>
                <button
                  onClick={() => handleDelete(grievance.id || index)}
                  className="flex items-center w-full px-3 py-2 text-xs text-red-600 hover:bg-gray-100"
                >
                  <img src="/del.svg" className="w-3 h-3 mr-2" alt="Delete" />
                  Delete Report
                </button>
              </div>
            )}
          </td>
        </tr>
      );
    })
  ) : (
    <tr>
      <td colSpan="7" className="text-center text-sm text-gray-500 py-6">
        No grievances found.
      </td>
    </tr>
  )}
</tbody>

        </table>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
          {grievances.length > 0 ? (
            grievances.map((grievance, index) => (
              <GrievanceGridCard
                key={grievance.id || index}
                grievance={grievance}
                index={index}
                onView={() => handleViewReport(grievance)}
                onEdit={() => openEditModal(grievance)}
                onDelete={() => handleDelete(grievance.id || index)}
                onThread={() => openThreadPopup(grievance)}
              />
            ))
          ) : (
            <div className="text-center text-sm text-gray-500 col-span-full py-4">No grievances to show.</div>
          )}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center  backdrop-blur-sm">
          <div className="p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            {modalStep === 1 && (
              <EditStep1
                formData={formData}
                handleInputChange={handleInputChange}
                handleNextStep={handleNextStep}
                closeModal={closeModal}
                grievance={selectedGrievance}
                edits={edits}
                setEdits={setEdits}
              />
            )}
            {modalStep === 4 && (
              <EditStep2
                formData={formData}
                handleInputChange={handleInputChange}
                handleSubmit={handleSubmit}
                setModalStep={setModalStep}
                closeModal={closeModal}
                grievance={selectedGrievance}
                edits={edits}
                setEdits={setEdits}
              />
            )}
            {modalStep === 5 && (
              <ConfirmPage
                formData={formData}
                handleSubmit={handleConfirm}
                setModalStep={setModalStep}
                closeModal={closeModal}
              />
            )}
            {modalStep === 6 && (
              <SuccessPage
                formData={formData}
                closeModal={closeModal}
              />
            )}
          </div>
        </div>
      )}

      {isOverviewOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center  backdrop-blur-sm">
          <div className="p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <Overview grievance={overviewData} closeModal={() => setIsOverviewOpen(false)} />
          </div>
        </div>
      )}

      <ThreadPopup
        isOpen={isThreadOpen}
        onClose={() => setIsThreadOpen(false)}
        grievance={selectedThreadGrievance}
        thread={selectedThreadGrievance?.thread || selectedThreadGrievance?.comments || []}
        commentCount={((selectedThreadGrievance?.thread && Array.isArray(selectedThreadGrievance.thread))
          ? selectedThreadGrievance.thread.length
          : (selectedThreadGrievance?.comments && Array.isArray(selectedThreadGrievance.comments)
            ? selectedThreadGrievance.comments.length
            : 0)) + optimisticThreadCount}
        onAddComment={handleAddComment}
      />
    </div>
  );
}

export default GrievanceTable;