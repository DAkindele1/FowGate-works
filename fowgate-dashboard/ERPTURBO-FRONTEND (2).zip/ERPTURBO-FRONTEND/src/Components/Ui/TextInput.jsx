import React, { useEffect, useRef, useState } from "react";

const TextInput = ({ name, value, onChange, placeholder, required, className }) => {
  return (
    <input
      type="text"
      name={name}
      value={value || ""}
      onChange={onChange}
      className={`w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm ${className}`}
      placeholder={placeholder}
      required={required}
    />
  );
};

export default TextInput;