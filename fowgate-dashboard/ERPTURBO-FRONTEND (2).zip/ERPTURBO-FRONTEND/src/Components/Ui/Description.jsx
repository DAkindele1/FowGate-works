import React, { useRef, useState } from "react";

const Description = ({ value, onChange, label, maxLength = 1500 }) => {
  const contentEditableRef = useRef(null);
  const [charCount, setCharCount] = useState(value?.length || 0);

  const handleContentChange = () => {
    const value = contentEditableRef.current.innerHTML;
    setCharCount(contentEditableRef.current.textContent.length);
    onChange?.({ target: { name: "description", value } });
  };

  const handleFormat = (command) => {
    document.execCommand(command, false, null);
    handleContentChange();
  };

  return (
    <div>
      {label && (
        <label className="block text-sm text-gray-700 mb-1">
          {label}
        </label>
      )}
      <div className="relative">
        <div
          ref={contentEditableRef}
          contentEditable
          onInput={handleContentChange}
          className="block w-full border border-gray-300 rounded-[3px] p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[120px] max-h-[200px] overflow-y-auto h-[266px]"
          style={{ paddingBottom: "30px" }}
          dangerouslySetInnerHTML={{ __html: value || "" }}
        />
        <div className="absolute bottom-2 left-2 flex space-x-1 text-xs">
          <button type="button" onClick={() => handleFormat("bold")}>
            <img src="/bold.svg" alt="bold" width={20} height={20} />
          </button>
          <button type="button" onClick={() => handleFormat("italic")}>
            <img src="/italic.svg" alt="italic" width={20} height={20} />
          </button>
          <button type="button" onClick={() => handleFormat("underline")}>
            <img src="/under.svg" alt="underline" width={20} height={20} />
          </button>
          <button type="button" onClick={() => handleFormat("insertOrderedList")}>
            <img src="/num.svg" alt="num" width={20} height={20} />
          </button>
          <button type="button" onClick={() => handleFormat("insertUnorderedList")}>
            <img src="/item.png" alt="item" width={20} height={20} />
          </button>
        </div>
        <span className="absolute bottom-2 right-2 text-xs text-gray-500">
          {charCount}/{maxLength}
        </span>
      </div>
    </div>
  );
};

export default Description;