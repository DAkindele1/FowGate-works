import React, { useRef } from "react";
import { FiClock } from "react-icons/fi";

const TimePicker = ({ value, onChange, label, required }) => {
  const timeInputRef = useRef(null);

  const handleIconClick = () => {
    timeInputRef.current?.showPicker();
  };

  const handleTimeChange = (e) => {
    const newTime = e.target.value;
    onChange?.({ target: { name: "time", value: newTime } });
  };

  return (
    <div>
      {label && (
        <label className="text-sm text-gray-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <div className="relative w-full mt-1">
        <input
          ref={timeInputRef}
          type="time"
          value={value}
          onChange={handleTimeChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        <div className="flex items-center justify-between w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-900 bg-white relative pointer-events-none">
          <span className="truncate pointer-events-none">{value || "--:--"}</span>
          <FiClock
            size={20}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer pointer-events-auto hover:scale-110 transition"
            onClick={handleIconClick}
          />
        </div>
      </div>
    </div>
  );
};

export default TimePicker;