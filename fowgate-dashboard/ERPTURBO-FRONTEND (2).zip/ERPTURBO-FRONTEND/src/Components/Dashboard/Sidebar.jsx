

import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  BriefcaseIcon, CalculatorIcon, CalendarDotsIcon,
  ChartBarIcon, ChartPieSliceIcon, ChatCenteredTextIcon,
  CheckCircleIcon, FileArchiveIcon, GearIcon, FolderOpenIcon, HeadCircuitIcon,
  ShieldCheckIcon, SquaresFourIcon, UserGearIcon, HouseLineIcon, VanIcon, FilePlusIcon, FilesIcon, ChartPieIcon, FactoryIcon, UserSwitchIcon, HeadsetIcon, ShoppingCartIcon,
  UserIcon, UsersThreeIcon, HandshakeIcon, DesktopIcon, TrashIcon, FileTextIcon, DatabaseIcon,
} from "@phosphor-icons/react";

function Sidebar() {
  const [activeItem, setActiveItem] = useState("My Account");
 
  const tabs = [
    {
      mainHeader: "GENERAL",
      subHeaders: [
        { name: "Dashboard", icon: SquaresFourIcon, pathName: "/home_dashboard" },
        { name: "My Account", icon: UserIcon, pathName: "/account_dashboard" }
      ]
    },
    {
      mainHeader: "COLLABORATION",
      subHeaders: [
        { name: "Messages", icon: ChatCenteredTextIcon, pathName: "/messages_dashboard" },
        { name: "Projects", icon: BriefcaseIcon, pathName: "/projects_dashboard" },
        { name: "Approvals", icon: CheckCircleIcon, pathName: "/approvals_dashboard" },
        { name: "Calendar", icon: CalendarDotsIcon, pathName: "/calendar_dashboard" }
      ]
    },
    {
      mainHeader: "HCM",
      subHeaders: [
        { name: "ATS", icon: UserGearIcon, pathName: "/ats_dashboard" },
        { name: "Teams", icon: UsersThreeIcon, pathName: "/teams_dashboard" },
        { name: "Payroll", icon: CalculatorIcon, pathName: "/payroll_dashboard" },
        { name: "Compliance Management", icon: ShieldCheckIcon, pathName: "/compliance_management_dashboard" },
        { name: "Analysis & Reporting", icon: ChartBarIcon, pathName: "/analysis_reporting_dashboard" },
        { name: "Company Calendar", icon: CalendarDotsIcon, pathName: "/company_calendar_dashboard" },
        { name: "Settings", icon: GearIcon, pathName: "/settings_dashboard" }
      ]
    },
    {
      mainHeader: "OPERATIONS",
      subHeaders: [
        { name: "Business Entities", icon: FileArchiveIcon, pathName: "/business_entities_dashboard" },
        { name: "Reports", icon: ChartPieSliceIcon, pathName: "/reports_dashboard" }
      ]
    },
    {
      mainHeader: "FINANCIALS",
      subHeaders: [
        { name: "Banking", icon: HouseLineIcon, pathName: "/banking" },
        { name: "Accounts", icon: FileArchiveIcon, pathName: "/accounts" },
        { name: "Customers", icon: UserGearIcon, pathName: "/customers" },
        { name: "Suppliers", icon: VanIcon, pathName: "/suppliers" },
        { name: "Expense Management", icon: FilePlusIcon, pathName: "/expense_management" },
        { name: "Budget & Forecasting", icon: ChartPieIcon, pathName: "/budget_n_forecasting" },
        { name: "Inventory", icon: FilesIcon, pathName: "/inventory" },
        { name: "Fixed Assets", icon: FactoryIcon, pathName: "/fixed_assets" },
        { name: "TAX, VAT, GST", icon: CalculatorIcon, pathName: "/tax" },
        { name: "Reports", icon: ChartPieSliceIcon, pathName: "/reports" }
      ]
    },
    {
      mainHeader: "COMMUNITY LIASON",
      subHeaders: [
        { name: "Engagement Tracking", icon: UsersThreeIcon, pathName: "/engagement_tracking" },
        { name: "Incident Reporting", icon: FilePlusIcon, pathName: "/incident_reporting" },
        { name: "Project Monitoring", icon: ChartBarIcon, pathName: "/project_monitoring" },
        { name: "Grievance Management", icon: ChatCenteredTextIcon, pathName: "/grievance_management" },
        { name: "Document Hub", icon: FolderOpenIcon, pathName: "/document_hub" },
        { name: "CLO Collaboration", icon: HandshakeIcon, pathName: "/clo_collaboration" },
        { name: "Oil Production (BPD)", icon: DatabaseIcon, pathName: "/oil_production" },
        { name: "Production Industry Act", icon: FileTextIcon, pathName: "/production_industry_act" },
        { name: "Data Analytics", icon: ChartPieSliceIcon, pathName: "/data_analytics" },
        { name: "Situation Room", icon: DesktopIcon, pathName: "/situation_room" },
        { name: "Settings", icon: GearIcon, pathName: "/settings" },
        { name: "Trash", icon: TrashIcon, pathName: "/thrash" }
      ]
    },
    {
      mainHeader: "crm",
      subHeaders: [
        { name: "Sales Management", icon: ChartBarIcon, pathName: "/sales_management" },
        { name: "Marketing Automation", icon: HeadCircuitIcon, pathName: "/marketing_automation" },
        { name: "Customer Service", icon: HeadsetIcon, pathName: "/customer_service" },
        { name: "Contact Management", icon: UserGearIcon, pathName: "/contact_management" },
        { name: "Social CRM", icon: VanIcon, pathName: "/social_crm" },
        { name: "E-commerce Integration", icon: ShoppingCartIcon, pathName: "/e-commerce_integration" },
        { name: "My Documents", icon: FolderOpenIcon, pathName: "/my_documents" },
      ]
    },
    {
      mainHeader: "data lake",
      subHeaders: [
        { name: "Explore Lake", icon: DatabaseIcon, pathName: "/explore_lake" },
      ]
    },
    {
      subHeaders: [
        { name: "Settings", icon: UserSwitchIcon, pathName: "/settings" },
      ]
    }
  ];

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className=" w-[250px] bg-gradient-to-br from-[#292929] to-[#111111] text-gray-300 h-dvh rounded-tl-md rounded-bl-md flex flex-col">
        {/* Logo */}
        <div className="h-[96px] flex flex-col justify-between">
          <img src="/assets/img/fowgatelogo.png" alt="" className="w-[96px] h-[32px] my-[32px] ml-[32px]" />
          <div className="w-[90%] h-[2px] mx-auto rounded-r-full bg-gradient-to-r from-transparent via-white/80 to-transparent"></div>
        </div>

        <hr className="mx-5 opacity-15" />

        {/* Menu Sections */}
        <nav className="py-2 flex-1 overflow-y-auto scrollbar-hide">
          {tabs.map((tab, index) => (
            <React.Fragment key={index}>
              <div className="my-5">
                {tab.mainHeader && <p className="px-8 text-[14px] font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                  {tab.mainHeader}
                </p>}
                {tab.subHeaders.map((subHeader, subIndex) => (
                  <MenuItem
                    key={subIndex}
                    icon={subHeader.icon}
                    name={subHeader.name}
                    active={location.pathname === subHeader.pathName}
                    to={subHeader.pathName}
                    onClick={setActiveItem}
                  />
                ))}
              </div>
              {index < tabs.length - 1 && (
                <div className="w-[90%] h-[2px] mx-auto my-4 rounded-r-full bg-gradient-to-r from-transparent via-white/80 to-transparent"></div>
              )}
            </React.Fragment>
          ))}
        </nav>
      </div>
    </div>
  );
}

// MenuItem Component remains the same
function MenuItem({ icon: Icon, name, to, active, onClick }) {
  return (
    <Link
      to={to}
      onClick={() => onClick(name)}
      className={`
        flex items-center px-7 py-2 text-sm cursor-pointer
        transition-all duration-200 relative text-[14px]
        ${
          active
            ? "bg-white/10 text-white before:absolute before:left-0 before:top-0 before:bottom-0 before:w-1 before:bg-white"
            : "text-[#9D9D9D] hover:bg-white/10 hover:text-gray-200"
        }
      `}
    >
      <Icon className="mr-2" size={20}/>
      <span className="truncate">{name}</span>
    </Link>
  );
}

export default Sidebar;