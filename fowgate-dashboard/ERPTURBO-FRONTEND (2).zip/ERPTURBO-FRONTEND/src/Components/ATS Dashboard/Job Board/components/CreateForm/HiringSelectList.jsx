import React, { useState } from "react";
import { CaretDownIcon, PlusIcon, XIcon } from "@phosphor-icons/react";

const options = [{
  value: "Okonkwo Joshua",
  type: "Engineering"
},
  {
    value: "Olivia Rodrigo",
    type: "Engineering"
  },
  {
    value: "Ava Carter",
    type: "Engineering"
  },
  {
    value: "Micheal Jackson",
    type: "Engineering"
  },
  {
    value: "Alex Carter",
    type: "Engineering"
  },
  {
    value: "Sophia Greene",
    type: "Engineering"
  },
  {
    value: "Nathaniel Brooks",
    type: "Engineering"
  },
  {
    value: "Maya Johnson",
    type: "Engineering"
  },
  ];

const HiringSelectList = ({setSelected, selected,  label, required}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const toggleDropdown = () => setIsOpen(!isOpen);

    // Ensure hiringTeam is always an array
    const safeSelected = Array.isArray(selected) ? selected : [];

    const filteredOptions = options.filter(
      (item) =>(item.value.toLowerCase().includes(search.toLowerCase()) &&
        !safeSelected.some((team) => team.value === item.value))       
  );

  
  

  const addItem = (item) => {
    setSelected([ // Pass the new array directly
      ...(Array.isArray(selected) ? selected : []), // Fallback to []
      {
        type: "department",
        value: item.value
      }
    ]);
    setSearch("");
  };

  const removeItem = (item) => {
    setSelected(selected.filter((i) => i !== item));
  };

  return (
    <div className={ "mt-5"}>
      <div className=" h-[78px] w- flex flex-col gap-[8px] "  onClick={toggleDropdown}>
      <div className='flex gap-1'> <label className="block text-[14px]">{label}</label> { required && <span className='text-red-600'>*</span> }</div>
        <div className={`flex items-center justify-between  mb-2  p-2 border border-gray-200 rounded-sm`}>
          <input
            type="text"
            placeholder="Search here"
            className="w-full p-2  rounded-md focus:outline-none focus:none text-[16px]"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button
            className="ml-2 text-gray-700"
           
          >
            <CaretDownIcon className="text-black font-bold" size={15} />
          </button>
        </div>
      </div>

        {/* Selected items */}
        <div className={`flex flex-wrap gap-2 mb-3 mt-5`}>
          {safeSelected.map((item, index) => (
            <span
              key={index}
              className="flex items-center bg-[#E8EFF9] text-[#1B5fc1] rounded-full px-3 py-1 text-sm "
            >
              {item.value}
              <button onClick={() => removeItem(item)} className="ml-2  hover:text-red-600 cursor-pointer">
                <XIcon size={16} />
              </button>
            </span>
          ))}
        </div>

        {/* Dropdown options */}
        {isOpen && filteredOptions.length > 0 && (
          <div className="mt-2 border border-gray-200 rounded-[6px]">
            <div className="flex gap-3 flex-wrap  p-[16px] ">
              {filteredOptions.map((item, index) => (
                <button
                  key={index}
                  onClick={() => addItem(item)}
                  className="text-sm text-left bg-white cursor-pointer border border-gray-200  w-fit rounded-full px-2 py-1 hover:bg-gray-200 flex items-center gap-2"
                >
                  {item.value}
                  <PlusIcon size={16}/>
                </button>
              ))}
            </div>
          </div>
        )}
    </div>
  );
};

export default HiringSelectList;
