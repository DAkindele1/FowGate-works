import React from 'react'
import Input from '../../../../../ui/Input'
import Select from '../../../../../ui/Select'

export default function JobDetails({setJobTitle, jobTitle, setIndustry, industry, setAvailability, availability, setJobType, jobType, setSalaryRange, salaryRange, setRequiredSkills, requiredSkills, setSalaryCurrency, salaryCurrency, setQualification,qualification,}) {
  return (
    <><Input label={"Job Title"} placeholder={"Search title"} handleChange={setJobTitle} value={ jobTitle} />
    <Select label={"Industry"} optionsArr={["Advertising", "E-Commerce", "Education", "Finance", "Healthcare"]} handleChange={setIndustry} value={industry}/>
    <Select label={"Availability"} optionsArr={["Full-Time", "Part-Time", "Contract"]} handleChange={setAvailability} value={availability}/>
    <Select label={"Job Type"} optionsArr={["Remote", "Hybrid", "Onsite"]} handleChange={setJobType} value={jobType}/>
    <Select label={"Salary Currency"} optionsArr={["AUD (Australian Dollar)", "BRL (Brazilian Real)", "CAD (Canadian Dollar)", "EUR (Euro)", "GBP (British Pound)"]} handleChange={setSalaryCurrency} value={salaryCurrency}/>
    <Select label={"Salary Range"} optionsArr={["1,000 - 10,000", "10,000 - 20,000", "20,000 - 30,000"]} handleChange={setSalaryRange} value={salaryRange}/>
    <Select label={"Required Skills"} optionsArr={["Option 1", "Option 2"]} handleChange={setRequiredSkills} value={requiredSkills}/>
    <Select label={"Qualifications"} optionsArr={["High School Diploma", "Bachelor's Degree (B.Sc)", "Master's Degree (M.Sc)" ,"Doctorate (Ph.D)", "Associate Degree"]} handleChange={setQualification} value={qualification}/>
    <Select label={"Years of Experience"} optionsArr={["0 - 1 Year", "1 - 3 Years", "3 - 5 Years", "5 - 8 Years", "8 - 10 Years"]} handleChange={setQualification} value={qualification}/></>
  )
}
