import React, { useState } from 'react';
import Input from '../../../../../ui/Input';
import Select from '../../../../../ui/Select';
import {MdClose} from "react-icons/md"
import AdditionalDetails from './AdditionalDetails';
import Progressbar from '../../../../../ui/Progressbar'
import {FaArrowLeft} from "react-icons/fa"
import Questionnaire from './Questionnaire';
import {FaCircleQuestion} from "react-icons/fa6"
import CheckMarker from '../../../../../ui/CheckMarker';
import Spinner from '../../../../../ui/Spinner';
import Review from './Review';
import FormBtns from '../../../../../ui/FormBtns';
import { createJobListing, editJobListing } from '../../services/api_job_board';
import toast from 'react-hot-toast';
import { FilePlusIcon } from '@phosphor-icons/react';
import DropDownSelect from './DropDownList';
import HiringSelectList from './HiringSelectList';
import { QueryClient, useMutation, useQueryClient } from '@tanstack/react-query';

export default function CreateJobForm({ handleClose, mode = 'create', jobData = null }) {
  // State initialization based on mode
  const [step, setStep] = useState(1);
  const [jobPosted, setJobPosted] = useState(false);

  const queryClient = useQueryClient();

  const {mutate} = useMutation({
    mutationFn: mode === 'create' ? createJobListing : editJobListing,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['job-listing'] });
      setJobPosted(true); // Set jobPosted to true on success
    setStep(7);
    },
    onError: (error) => {
    toast.error(error.message || "Operation failed");
  }
  })

const defaultFormData = {
    title: "",
    hiring_team: [],
    industry: "",
    salary_range: "",
    currency: "",
    required_skills: [],
    qualifications: [],
    experience: "",
    upload_resume: false,
    cover_letter: false,
    portfolio: false,
    description: "",
    questions: [],
    audience: ["public"],
  add_as_template: false,
    application_url : "",
  };
  
  
  const [formData, setFormData] = useState(
    mode === 'edit' && jobData 
      ? { 
          ...defaultFormData, 
          ...jobData, 
        hiring_team: Array.isArray(jobData.hiring_team) ? jobData.hiring_team : [],
        audience: Array.isArray(jobData.audience) ? jobData.audience : ["public"],
        required_skills: Array.isArray(jobData.required_skills) ? jobData.required_skills : [],
        questions: jobData.questions || [],
        qualifications: Array.isArray(jobData.qualifications) ? jobData.qualifications : [],
        } 
      : defaultFormData
  );

  const tabName = ["JOB OPENING", "ADDITIONAL DETAILS", "QUESTIONNAIRE", "INVITE HIRING TEAM", "PREVIEW & PUBLISH"];

  const closeModal = () => {
    handleClose();
  };


  const nextStep = () => {
    setStep(prev => prev + 1);
    step === 6 && handleSubmit();
  };

  const prevStep = async () => {
    setStep(p => p - 1);
  };

  const handleSubmit = async () => {
  if (!formData.title ||!formData.description || formData.hiring_team.length === 0 ||formData.required_skills.length === 0 || formData.qualifications.length === 0) {
    setStep(1);
    toast.error("Please fill all required fields");
    return;
  }

  if (mode === 'create') {
    setJobPosted(false);
    mutate(formData);
  }
  
  if (mode === 'edit') {
    // 1. Prepare the complete payload with ALL fields
  //   {
  //   job_code: jobCode,
  //   updates: {...payload}
  // }
    const payload = {
      job_code: jobData.job_code,
      updates: {
        title: formData.title,
        description: formData.description,
        hiring_team: formData.hiring_team.map(member => ({
          type: member.type || 'department',
          value: member.value
        })),
        audience: formData.audience,
        industry: formData.industry,
        currency: formData.currency,
        salary_range: formData.salary_range,
        upload_resume: formData.upload_resume,
        cover_letter: formData.cover_letter,
        questions: (formData.questions || []).map(question => ({
          type: question?.type || '',
          question: question?.question || '',
          options: (question?.options || []).map(option => ({
            option: option?.option || '',
            is_selected: option?.is_selected || false
          })),
          answer: question?.answer || ''
        })),
        required_skills: formData.required_skills,
        qualifications: formData.qualifications,
        experience: formData.experience,
        add_as_template: formData.add_as_template,
      },
    };

    mutate( payload);
  }
};

  const handleAIJobDetails = () => {
    
  }

  // Update specific form fields
  const updateField = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: Array.isArray(value) ? [...value] : value
    }));
  };


  const skillsList = ["Node.js","Python (Django, Flask)", "Figma",
    "Adobe XD",
    "Sketch",
    "Photoshop",
    "UI/UX Design",
    "Prototyping","Express.js","REST APIs","JavaScript","TypeScript","React","HTML5","CSS3","SASS/SCSS", "Tailwind CSS", "jQuery","Bootstrap","Webpack","Vite"
  ];

  const qualificationsList = ["High School Diploma", "Bachelor's Degree (B.Sc)","Master's Degree (M.Sc)","Doctorate (Ph.D)", "Associate Degree",]




  return (
    <div>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
        <div className={`bg-white rounded-sm relative shadow-xl animate-fadeIn w-[528px] ${step === 6 ? "h-[252px]" :step === 7 ? "h-[442px]" : " h-[744px] max-h-[90vh]"}`}>
          
          {/* Form Header */}
          {step <= 6 && (
            <div className="bg-[#1B5fc1] flex rounded-t-sm justify-between align-middle h-[78px] py-[22px] px-[24px] text-white">
              <div className='text-[24px] font-medium flex items-center gap-2'>
                {step <= 5 ? <FilePlusIcon size={32} weight='fill'/> : <FaCircleQuestion/>}
                {step <= 5 ? (mode === 'create' ? "Create Job" : "Edit Job") : "Confirm Action"}
              </div>
              <button className="cursor-pointer" onClick={closeModal}>
                <MdClose size={24}/>
              </button>
            </div>
          )}

          {/* MODAL BODY */}
          <div className={`px-6  overflow-y-auto ${step === 6 ? "h-24" : "max-h-[calc(77.5vh-78px)] h-[588px]"}`}>
            {step <= 5 && (
              <div className="flex items-center gap-2 justify-between border-b py-5 border-b-gray-200 ">
                <div className='flex items-center gap-1.5'>
                  {step !== 1 && <div className='cursor-pointer' onClick={prevStep}><FaArrowLeft/></div>}
                  <Progressbar step={step} totalSteps={5} />
                  <span className="text-gray-400 min-w-[42px]">{step}/5 -</span>
                  <span className='font-bold text-[#292929] '>{tabName[step-1]}</span>
                </div>
                {(step === 1 || step === 3) && <Select
  optionsArr={["Template 1", "Template 2"]}
  special="Choose Template"
  // No value prop needed for initial placeholder
  handleChange={(selected) => console.log(selected)}
/>}
                
              </div>
            )}

            {/* STEP 1 */}
            {step === 1 && (
              <div>
                <div className="mt-4">
                <Input 
                    label={"Job Title"}
                  required ={true}  
                  placeholder={"Search title"} 
                  handleChange={(val) => updateField('title', val)} 
                  value={formData.title} 
                              />
                </div>
                <div className="mt-4">
                <Input 
                  label={"Job Overview"} 
                  placeholder={"Type job overview"} 
                  required ={true}  
                  handleChange={(val) => updateField('description', val)} 
                    value={formData.description} 
                    overview={true}
                              />
                </div>
                
                    <div className="my-2"><Select 
                  label={"Industry"} 
                  optionsArr={["Advertising", "E-Commerce", "Education", "Finance", "Healthcare"]} 
                  handleChange={(val) => updateField('industry', val)} 
                  value={formData.industry}
                /></div>         
                    <div className="my-2"><Select 
                  label={"Availability"} 
                  optionsArr={["Full-Time", "Part-Time", "Contract"]} 
                  handleChange={(val) => updateField('availability', val)} 
                  value={formData.availability}
                /></div>         
                    <div className="my-2"><Select 
                  label={"Job Type"} 
                  optionsArr={["Remote", "Hybrid", "Onsite"]} 
                  handleChange={(val) => updateField('job_type', val)} 
                  value={formData.job_type}
                /></div>         
                    <div className="my-2"><Select 
                  label={"Salary Currency"} 
                  optionsArr={["NGN (Nigerian Naira)","AUD (Australian Dollar)", "BRL (Brazilian Real)", "CAD (Canadian Dollar)", "EUR (Euro)", "GBP (British Pound)"]} 
                  handleChange={(val) => updateField('currency', val)} 
                  value={formData.currency}
                /></div>         
                    <div className="my-2"> <Select 
                  label={"Salary Range"} 
                  optionsArr={["1,000 - 10,000", "10,000 - 20,000", "20,000 - 30,000"]} 
                  handleChange={(val) => updateField('salary_range', val)} 
                  value={formData.salary_range}
                /></div>
                 <div>
               
                  <DropDownSelect
                    options={skillsList}
                    label={"Required Skills"}
                    required={true}
                    selected={formData.required_skills || []} 
                    setSelected={(newTeam) => 
                      setFormData(prev => ({
                        ...prev,
                        required_skills: Array.isArray(newTeam) ? newTeam : []
                      }))
                    }
/>
             </div>
                          
                 <div>
               
                  <DropDownSelect
                    options={qualificationsList}
                    label={"Qualifications"}
                    required={true}
                    selected={formData.qualifications || []} 
                    setSelected={(newTeam) => 
                      setFormData(prev => ({
                        ...prev,
                        qualifications: Array.isArray(newTeam) ? newTeam : []
                      }))
                    }
/>
             </div>
                    <div className="my-2"><Select 
                  label={"Years of Experience"} 
                  optionsArr={["0 - 1 Year", "1 - 3 Years", "3 - 5 Years", "5 - 8 Years", "8 - 10 Years"]} 
                  handleChange={(val) => updateField('experience', val)} 
                  value={formData.experience}
                /></div>                
                
                
                
                
               
                
                
                
              </div>
            )}

            {/* STEP 2 */}
            {step === 2 && (
              <div>
                <AdditionalDetails 
  heading={"Upload Resume"} 
  body={"Toggle on to require resume uploads"} 
  handleToggle={(val) => updateField('upload_resume', val)}
  value={formData.upload_resume}
/>
                <AdditionalDetails 
                  heading={"Attach Cover Letter"} 
                  body={"Toggle on to require cover letter attachment"} 
                  handleToggle={(val) => updateField('cover_letter', val)} 
                  value={formData.cover_letter}
                />
                <AdditionalDetails 
                  heading={"Attach Portfolio"} 
                  body={"Toggle on to require portfolio attachment"} 
                  handleToggle={(val) => updateField('portfolio', val)} 
                  value={formData.portfolio}
                />
              </div>
            )}

            {/* STEP 3 */}
            {step === 3 && (
  <Questionnaire 
  questions={formData.questions} 
  setQuestions={(newQuestions) => updateField('questions', newQuestions)}
/>
)}

            {/* STEP 4 */}
            {step === 4 && (
              <div>
               
                <HiringSelectList
                  label={"Select Hiring Team"}
  selected={formData.hiring_team || []}
  required={true}
  setSelected={(newTeam) => 
    setFormData(prev => ({
      ...prev,
      hiring_team: Array.isArray(newTeam) ? newTeam : []
    }))
  }
/>
              </div>
            )}

            {/* Step 5 */}
            {step === 5 && (
              <div>
                <Review 
                  setStep={setStep} 
                  jobTitle={formData.title} 
                  industry={formData.industry} 
                  salaryCurrency={formData.currency} 
                  salaryRange={formData.salary_range} 
                  requiredSkills={formData.required_skills} 
                  resume={formData.upload_resume} 
                  coverLetter={formData.cover_letter} 
                  hiringTeam={formData.hiring_team || []}
                  jobOverview={formData.description}
                  questions={formData.questions}
                />
              </div>
            )}

            {/* Step 6 */}
            {step === 6 && (
              <p className='py-4'>
                Are you sure you want to {mode === 'create' ? 'publish' : 'update'} this job posting? Once {mode === 'create' ? 'published' : 'updated'}, it will be visible to all applicants.
              </p>
            )}

            {/* STEP 7 */}
            {step === 7 && (jobPosted ? (
            // <SuccessModal actionMode={`${mode === 'create' ? 'create' : ''}`} closeModal={closeModal}/>
                <div className='text-[#292929] mx-auto mt-[32px] text-center flex flex-col gap-[40px]  h-[378px] w-[380px]'>
                <CheckMarker/>
                <div  className='w-ful h-[98px] flex flex-col gap-[8px]  '>
                <h1 className='text-[32px] font-medium text-center '>Job {mode === 'create' ? 'Published' : 'Updated'}!</h1>
                <p className=' text-[16px] font-light text-[#292929] text-center '>
                  {mode === 'create' 
                    ? 'Your listing is now live. Check your dashboard to track applications.' 
                    : 'Your changes have been saved successfully.'}
                </p>
                </div>
                <button 
                  className='bg-[#1b5fc1] text-[#fff] text-[16px] font-medium hover:bg-blue-600 w-full h-[50px] rounded-sm cursor-pointer py-[12px] px-[10px]' 
                  onClick={closeModal}
                >
                  Okay
                </button>
              </div>
            ) : <Spinner/>)}
          </div>

          {step <= 6 && (
            <FormBtns 
              closeModal={closeModal} 
              step={step} 
              nextStep={nextStep} 
              mode={mode} 
            />
          )}

          {/* AI Button */}
          {(step === 1 && formData.title.length >= 3) || step === 3 ? (
            <div className={`w-12 h-12 absolute bottom-25 rounded-full cursor-pointer hover:bg-blue-800 right-8 bg-[#1B5fc1] p-2 animate-bounce`} onClick={() => handleAIJobDetails}>
              <img src="/assets/img/sparkle.png" alt="AI icon" className='w-full h-full' />
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}