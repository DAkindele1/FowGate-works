import {toast} from "react-hot-toast"
const token = localStorage.getItem("userAccess")

const API_BASE_URL = import.meta.env.VITE_ERP_TURBO_API_BASE_URL

const fetchAllJobListing = async () => {

    try {

      const response = await fetch(
        `${API_BASE_URL}/api/hcm/ats/job_board/get_all_job_listings`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();
      if (data.status !== "success") {
        throw new Error(data.message)
      }

      
      
      

      return data
    
    } catch (error) {
      console.error("Failed to fetch candidates:", error);
    } 
};

const createJobListing = async (jobData) => {
 
  console.log("Job Data ===>", jobData)

    try {
      const response = await fetch(
        `${API_BASE_URL}/api/hcm/ats/job_board/create_job_listing`,
        {
          method: "POST",
          headers: {
            'Authorization': `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(jobData),
        }
      );

      
      const data = await response.json();

      if (data.status !== "success") {
        throw new Error(data.message)
      }

    
      toast.success("Job successfully created");
      return data
    
    } catch (err) {
      console.log("Error Idyllic ===>", err);
      
      
    } 
};

const createJobListingWithAI = async (jobData) => {
 

    try {
      const response = await fetch(
        `${API_BASE_URL}/api/hcm/ats/job_board/create_job_listing`,
        {
          method: "POST",
          headers: {
            'Authorization': `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(jobData),
        }
      );

      
      const data = await response.json();

      if (data.status !== "success") {
        throw new Error(data.message)
      }

    
      return data
    
    } catch (err) {
      console.log("Error Idyllic ===>", err);
      
      toast.error(err);
      
    } 
};

const editJobListing = async (payload) => {
 
  
  console.log("Final Payload ===>", payload)
  
  try {

    const response = await fetch(`${API_BASE_URL}/api/hcm/ats/job_board/edit_job_listing`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)  // Send complete payload
    });

    const data = await response.json()

    if (data.status !== "success") {
      throw new Error(data.message)
    }

    return data;
  } catch (error) {
    console.error('API Error:', {
      error: error.message,
      payload
    });
    throw error;
  }
};

const deleteJobListing = async (jobCode) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/hcm/ats/job_board/delete_job_listing?job_code=${encodeURIComponent(jobCode)}`,
      {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const data =  await response.json()

    if (data.status !== "success") {
      throw new Error(data.message)
    }

    // toast.success("Job successfully deleted")
    return data;
  } catch (error) {
    console.error('Delete job error:', error);
    throw error; 
  }
};




  export {fetchAllJobListing, createJobListing, deleteJobListing, createJobListingWithAI, editJobListing}