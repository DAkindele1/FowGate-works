import toast from "react-hot-toast";

const token = localStorage.getItem("userAccess")

const API_BASE_URL = import.meta.env.VITE_ERP_TURBO_API_BASE_URL

const fetchAllCandidates = async () => {

  // setLoading(true);
 
    try {
      const requestBody = {
        company_code: "COMPANY123",
      };
      

      const response = await fetch(
        `${API_BASE_URL}/api/hcm/ats/apply/get_applications`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(requestBody),
        }
      );
      const data = await response.json();

      if (data.status !== "success") {
        throw new Error(data.message)
      }

      

      return data
    
    } catch (error) {
      console.error("Failed to fetch candidates:", error);
    } finally {
      // setLoading(false);
    }
};
  
  // Fetch shortlisted candidates from the API
  const fetchShortlistedCandidates = async () => {
    try {
      const requestBody = {
        company_code: "COMPANY123", 
        job_code: "JOB123", 
        // Optional filters
        start_date: "", // Format: YYYY-MM-DD
        end_date: "", // Format: YYYY-MM-DD
        filter_by: "",
        filter_value: "",
      };

      const response = await fetch(
        "/api/ats/apply/get_shortlisted_applications",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",

            // "Authorization": `Bearer ${localStorage.getItem("userAccess")}`,
          },
          body: JSON.stringify(requestBody),
        }
      );
      const data = await response.json();

      if (data.status !== "success") {
        throw new Error(data.message)
      }


      

     
    } catch (error) {
      console.error("Failed to fetch shortlisted candidates:", error);
      // Keep using the default data for now
    } finally {
      console.log("API Called");
      
    }
};

const shortlistApplication = async (applicationCode, mode) => {
  
  
    try {
      const response = await fetch(`${API_BASE_URL}/api/hcm/ats/apply/${mode}_application?application_code=${applicationCode}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
              });
  
      const data = await response.json();

      if (data.status !== "success") {
        throw new Error(data.message)
      }
     
      return data;

    } catch (error) {
      console.error('Error shortlisting application:', error);
      
      throw error;
    }
  };
const markFavourite = async (applicationCode, mode="mark") => {
  
    try {
      const response = await fetch(`${API_BASE_URL}/api/hcm/ats/apply/${mode}_application_as_favorite?application_code=${applicationCode}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        // body: JSON.stringify({
        //   application_code: applicationCode
        // })
      });
  
      const data = await response.json();

      if (data.status !== "success") {
        throw new Error(data.message)
      }
     
      return data;

    } catch (error) {
      console.error('Error shortlisting application:', error);
    }
};

const talentPool = async (applicationCode, mode="add_to") => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/hcm/ats/apply/${mode}_talent_pool?application_code=${applicationCode}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      if (data.status !== "success") {
        throw new Error(data.message)
      }
  
     
      return data;

    } catch (error) {
      console.error('Error adding:', error);
      toast.error('Error adding as talent pool')
      throw error;
    }
};
const hiringAPI = async (applicationCode, mode) => {
  
    try {
      const response = await fetch(`${API_BASE_URL}/api/hcm/ats/apply/${mode}_applicant?application_code=${applicationCode}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
  
      if (data.status !== "success") {
        throw new Error(data.message)
      }
  
     
      return data;

    } catch (error) {
      console.error('Error adding:', error);
      throw error;
    }
};


  export {fetchAllCandidates, hiringAPI, fetchShortlistedCandidates, shortlistApplication, markFavourite, talentPool}