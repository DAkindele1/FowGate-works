import { CaretDownIcon,  GearSixIcon, PlusIcon, TrashIcon } from '@phosphor-icons/react'
import { BellIcon } from 'lucide-react'
import React, { useEffect, useState, useRef, useCallback } from 'react'
import { createAssessmentQuestions, deleteAnAssessmentQuestion, editAssessmentQuestion, getAIAssessmentQuestions } from '../services/api_interview_central'
import Modal from '../../../../../../ui/Modal'
import SuccessModal from '../../../../../../ui/SuccessModal'

export default function ManageAIContainer({ setManageAI, jobCode }) {
  const [aiQuestions, setAiQuestions] = useState([])
  const [activeQues, setActiveQues] = useState(1)
  const [questionValue, setQuestionValue] = useState('');
  const [questionType, setQuestionType] = useState('');
  const [selectedQuestion, setSelectedQuestion] = useState([])
  const [showConfirmDelete, setShowConfirmDelete] = useState(false)
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [successAction, setSuccessAction] = useState('') // 'create', 'edit', 'delete'
  const questionRef = useRef(null);
  const optionRefs = useRef([]);

  // Auto-resize function for textareas
  const autoResize = (textarea) => {
      if (textarea) {
          textarea.style.height = 'auto';
          textarea.style.height = textarea.scrollHeight + 'px';
      }
  };

  const fetchQuestions = useCallback(async () => {
      try {
          const { data } = await getAIAssessmentQuestions(jobCode || "JBL_kBIOh_kGnax");
          console.log("data===>", data);

          const filteredQuestions = data.ai_questions.filter(q =>
              data.active_questions.includes(q.id)
          );

          setAiQuestions(filteredQuestions);
            
          const questionIndex = Math.min(activeQues - 1, filteredQuestions.length - 1);
          const selectedIndex = Math.max(0, questionIndex);
            
          if (filteredQuestions.length > 0) {
              setSelectedQuestion(filteredQuestions[selectedIndex]);
          } else {
              setSelectedQuestion(null);
          }
      } catch (error) {
          console.log(error);
          setSelectedQuestion(null);
      }
  }, [jobCode]);

  useEffect(() => {
      fetchQuestions();
  }, [fetchQuestions]);

  // Auto-resize main question textarea
  useEffect(() => {
      autoResize(questionRef.current);
  }, [selectedQuestion?.question]);

  // Auto-resize option textareas
  useEffect(() => {
      if (selectedQuestion?.options) {
          selectedQuestion.options.forEach((_, index) => {
              autoResize(optionRefs.current[index]);
          });
      }
  }, [selectedQuestion?.options]);

  const handleDelete = async (id) => {
      setShowConfirmDelete(false);
      const payload = {
          job_code: jobCode, 
          question_id: id
      }
    
      try {
          await deleteAnAssessmentQuestion(payload);
          setActiveQues(1);
          fetchQuestions();
        
          // Show success modal
          setSuccessAction('delete');
          setShowSuccessModal(true);
      } catch (error) {
          console.error('Error deleting question:', error);
      }
  }

  const handleAddMore = () => {
      const newQuestion = {
          question: "",
          type: "OPQ",
          options: [], // Start with empty options, will be populated when type changes to MCQ
          not_required: false,
      };
      setAiQuestions(prev => {
          const updated = [newQuestion, ...prev];
          setActiveQues(1);
          setSelectedQuestion(newQuestion);
          return updated;
      });
  };

  const handleSubmit = async () => {
      const payloadForCreate = {
          "job_code": jobCode,
          "question": {
              "type": selectedQuestion.type || "OPQ",
              "question": selectedQuestion.question,
              "not_required": selectedQuestion.not_required || false,
              ...(selectedQuestion.type === "MCQ" && { "options": selectedQuestion.options || [] })
          }
      }
      const payloadForEdit = {
          "job_code": jobCode,
          "updates": {
              "type": selectedQuestion.type || "OPQ",
              "question": selectedQuestion.question,
              "not_required": selectedQuestion.not_required || false,
              "id": selectedQuestion.id,
              ...(selectedQuestion.type === "MCQ" && { "options": selectedQuestion.options || [] })
          }
      }
        
      try {
          const isEdit = !!selectedQuestion.id;
        
          !selectedQuestion.id ? await createAssessmentQuestions(payloadForCreate) : await editAssessmentQuestion(payloadForEdit);
          setShowConfirmSubmit(false);
        
          // Reset to first question after submit
          setActiveQues(1);
          fetchQuestions();
        
          // Show success modal
          setSuccessAction(isEdit ? 'edit' : 'create');
          setShowSuccessModal(true);
      } catch (error) {
          console.error('Error submitting question:', error);
      }
  }

  console.log(selectedQuestion, "Selected Question");
  
  return (
      <div className='w-full min-h-screen h-screen flex flex-col'>
          <header className='flex items-center justify-between border-b border-gray-300 pt-[7px] pb-[29px]'>
              <div className="flex items-center gap-1.5 w-fit h-[22px] text-[14px] justify-center text-[#707070]">
                  <div className='font-light cursor-pointer hover:scale-[105%] ease-in-out transition' onClick={() => setManageAI(false)}>
                      Shortlisted Candidate
                  </div>
                  /
                  <div className='text-[#292929] flex items-center'>
                      Manage AI Assessment
                  </div>
              </div>
              <div className='w-[202px] h-[42px] flex items-center justify-between'>
                  <div className="relative border border-gray-200 rounded-md w-[42px] h-[42px] flex items-center justify-center">
                      <img
                          src="/assets/img/message_antenna_icon.png"
                          alt="Profile"
                          className="w-[26px] h-[26px] rounded-full object-cover"
                      />
                  </div>
                  <button className="relative border border-gray-200 rounded-md w-[42px] h-[42px] flex items-center justify-center">
                      <BellIcon size={24} className="text-gray-600" />
                      <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
                  </button>
                  <div className="flex items-center justify-center gap-[8px] border border-gray-200 p-0.5 rounded-full h-[42px] w-[70px]">
                      <img
                          src="/assets/img/memoji.png"
                          alt="Profile"
                          className="w-[26px] h-[26px] rounded-full object-cover"
                      />
                      <CaretDownIcon size={20} className="text-gray-600" />
                  </div>
              </div>
          </header>
          <div className='flex-1 flex w-full gap-[32px] h-full mt-[28px]'>
              {/* LHS */}
              <div className="flex-1 border border-gray-300 w-[360px] rounded-[10px] flex flex-col">
                  <header className="px-5 py-4  flex items-center h-[57px] border-b border-b-gray-300">
                      <div className=" flex items-center justify-between w-full h-full">
                          <h2 className='font-medium text-[18px] text-[#292929] uppercase flex items-center gap-1'>
                              <span>{aiQuestions.length === 1 ? "Question" : "Questions"}</span> 
                              <span className=' bg-[#1B5FC1] text-[10px] text-white p-0.5 h-[16px] w-[16px] rounded-full flex items-center justify-center '>{aiQuestions.length}</span>
                          </h2>
                          <div
                              className='flex items-center gap-1.5 text-[#1B5FC1] rounded-[4px] cursor-pointer hover:scale-105 transition ease-in-out duration-300'
                              onClick={handleAddMore}
                          >
                              <PlusIcon size={18}/>
                              <p className='text-[14px]'>Add More</p>
                          </div>
                      </div>
                  </header>
                  {/* Question List */}
                  {aiQuestions.map((question, index) => {
                      return <div key={index} className={
                          `h-[62px] p-5 border-b cursor-pointer border-b-[#EAEAEA] text-[#292929] text-[16px] 
                          transition-colors duration-200
                          ${activeQues === index + 1 ? "font-medium bg-[#F8F8F8]" : "hover:bg-[#F3F6FA]"}`
                      }
                      onClick={() => {
                          setActiveQues(index + 1);
                          setSelectedQuestion(question);
                      }} >
                          <p className='truncate'>{question.question || "Unnamed"}</p>
                      </div>
                  })}
              </div>
              {/* RHS */}
              <div className="flex-1 border border-gray-300 w-[702px] rounded-[10px] flex flex-col">
                  <header className="h-[57px] px-5 py-4 flex items-center justify-between border-b border-b-[#eaeaea] ">
                      <h1 className='font-medium text-[18px] text-[#292929] '>Manage Questions for AI Assessment</h1>
                      <div><GearSixIcon size={24} color='#707070'/></div>
                  </header>
                  <div className="flex-1 m-5 flex flex-col gap-5 overflow-auto">
                      <div className=" h-fit flex flex-col gap-2 ">
                          <p className='text-[14px] text-[#292929]  '>Question</p>
                          <textarea
                              ref={questionRef}
                              className='px-3 py-2 focus:outline-none border border-[#eaeaea] rounded-[6px] resize-none overflow-hidden leading-tight' 
                              style={{ minHeight: '40px', height: 'auto' }}
                              rows={1}
                              value={selectedQuestion?.question || ""}
                              onChange={e => {
                                  const updatedQuestion = { ...selectedQuestion, question: e.target.value };
                                  setSelectedQuestion(updatedQuestion);
                                  setAiQuestions(prev =>
                                      prev.map(q =>
                                          q.id === selectedQuestion.id ? updatedQuestion : q
                                      )
                                  );
                                  setQuestionValue(e.target.value);
                                  // Auto-resize on change
                                  autoResize(e.target);
                              }}
                          />
                      </div>
                      <div className=" min-h-[78px] flex flex-col gap-2 ">
                          <p className='text-[14px] text-[#292929]  '>Answer Type</p>
                          <select 
                              className='h-fit p-3 focus:outline-none border border-[#eaeaea] rounded-[6px] text-[16px]' 
                              value={selectedQuestion?.type === "OPQ" ? "longAnswer" : "mcq"} 
                              onChange={e => {
                                  const newType = e.target.value === "longAnswer" ? "OPQ" : "MCQ";
                                  const updatedQuestion = { 
                                      ...selectedQuestion, 
                                      type: newType,
                                      // Initialize options array for MCQ, clear for OPQ
                                      options: newType === "MCQ" ? (selectedQuestion.options || ["", "", "", ""]) : []
                                  };
                                  setSelectedQuestion(updatedQuestion);
                                  setAiQuestions(prev =>
                                      prev.map(q =>
                                          q.id === selectedQuestion.id ? updatedQuestion : q
                                      )
                                  );
                                  setQuestionType(newType); // Update questionType state
                              }}
                          >
                              <option value="longAnswer">Long Answer</option>
                              <option value="mcq">Multiple Choice</option>
                          </select>
                      </div>
                      {selectedQuestion?.type === "MCQ" && (
                          <div className='flex flex-col gap-5'>
                              <div className='flex items-center justify-between'>
                                  <p className='text-[14px] text-[#292929]'>Options</p>
                                  <button
                                      type="button"
                                      className='text-[#1B5FC1] text-[12px] flex items-center gap-1 hover:scale-105 transition'
                                      onClick={() => {
                                          const updatedOptions = [...(selectedQuestion.options || []), ""];
                                          const updatedQuestion = { ...selectedQuestion, options: updatedOptions };
                                          setSelectedQuestion(updatedQuestion);
                                          setAiQuestions(prev =>
                                              prev.map(q =>
                                                  q.id === selectedQuestion.id ? updatedQuestion : q
                                              )
                                          );
                                      }}
                                  >
                                      <PlusIcon size={14}/>
                                      Add Option
                                  </button>
                              </div>
                              {selectedQuestion?.options?.map((option, i) => (
                                  <div key={i} className='flex items-center gap-2'>
                                      <div className='flex-1 flex flex-col gap-2'>
                                          <p className='text-[14px] text-[#292929]'>Option {i + 1}</p>
                                          <textarea
                                              ref={el => optionRefs.current[i] = el}
                                              value={option}
                                              className='px-3 py-2 w-full border border-[#eaeaea] rounded-[6px] resize-none overflow-hidden leading-tight'
                                              style={{ minHeight: '40px', height: 'auto' }}
                                              rows={1}
                                              onChange={e => {
                                                  const updatedOptions = [...selectedQuestion.options];
                                                  updatedOptions[i] = e.target.value;
                                                  const updatedQuestion = {
                                                      ...selectedQuestion,
                                                      options: updatedOptions,
                                                  };
                                                  setSelectedQuestion(updatedQuestion);
                                                  setAiQuestions(prev =>
                                                      prev.map(q =>
                                                          q.id === selectedQuestion.id ? updatedQuestion : q
                                                      )
                                                  );
                                                  // Auto-resize on change
                                                  autoResize(e.target);
                                              }}
                                          />
                                      </div>
                                      {selectedQuestion.options.length >= 2 && (
                                          <button
                                              type="button"
                                              className='text-[#EB4335] hover:scale-105 transition mt-6'
                                              onClick={() => {
                                                  const updatedOptions = selectedQuestion.options.filter((_, index) => index !== i);
                                                  const updatedQuestion = { ...selectedQuestion, options: updatedOptions };
                                                  setSelectedQuestion(updatedQuestion);
                                                  setAiQuestions(prev =>
                                                      prev.map(q =>
                                                          q.id === selectedQuestion.id ? updatedQuestion : q
                                                      )
                                                  );
                                              }}
                                          >
                                              <TrashIcon size={16}/>
                                          </button>
                                      )}
                                  </div>
                              ))}
                          </div>
                      )}
                      <div className=' min-h-6 gap-2 flex items-center '>
                          {/* Toggle */}
                          <div
                              className={`h-full w-10 flex items-center rounded-full p-0.5 cursor-pointer transition-all duration-700
                                  ${selectedQuestion.not_required ? "bg-[#eaeaea] justify-start" : "bg-[#1B5FC1] justify-end"}`}
                              onClick={() => {
                                  const updatedQuestion = { ...selectedQuestion, not_required: !selectedQuestion.not_required };
                                  setSelectedQuestion(updatedQuestion);
                                  setAiQuestions(prev =>
                                      prev.map(q =>
                                          q.id === selectedQuestion.id ? updatedQuestion : q
                                      )
                                  );
                              }}
                          >
                              <div className="bg-white h-[18px] w-[18px] rounded-full transition-all duration-300"></div>
                          </div>
                          <p>Make this question compulsory</p>
                      </div>
                  </div>
                  <div className="mt-auto">
                      <div className="flex py-[17px] px-[24px] gap-4 border-t border-gray-300 justify-end text-[14px] h-[78px]">
                          <button 
                              className={`border border-gray-300 text-center py-[10px] px-3 rounded-sm transition cursor-pointer  flex items-center gap-1 text-[#EB4335]`}
                              onClick={()=>setShowConfirmDelete(true)}
                          >
                              <TrashIcon size={16}/>
                              Delete
                          </button>
                          <button 
                              onClick={()=>setShowConfirmSubmit(true)} 
                              className={`bg-[#E8EFF9] text-[#1B5fc1] cursor-pointer hover:text-[#E8EFF9] hover:bg-[#1B5fc1] py-2 px-3 w-[117px] block rounded-sm transition`}
                          >
                              Save
                          </button>
                      </div>
                  </div>
              </div>
          </div>
            
          {/* Success Modal */}
          {showSuccessModal && (
              <div className="fixed inset-0 bg-gray-100/65 flex items-center justify-center z-50">
                  <SuccessModal
                      actionMode={successAction}
                      closeModal={() => setShowSuccessModal(false)}
                      mainText={
                          successAction === 'create' ? 'Question Created!' :
                          successAction === 'edit' ? 'Question Updated!' :
                          successAction === 'delete' ? 'Question Deleted!' : 'Success!'
                      }
                      subText={
                          successAction === 'create' ? 'Your assessment question has been successfully created and is now available.' :
                          successAction === 'edit' ? 'Your assessment question has been successfully updated with the new changes.' :
                          successAction === 'delete' ? 'The assessment question has been successfully removed from the system.' : 'Operation completed successfully.'
                      }
                  />
              </div>
          )}
            
          {/* Existing Modals */}
          {showConfirmDelete && <Modal contW={"w-[528px]"} headerIcon={"trash"} closeModal={() => setShowConfirmDelete(false)} headTitle={"Delete Interview Question"} headBgColor={"bg-[#eb4335]"} contH={"h-[230px]"}>
              <p className="border-b border-gray-200 py-[20px] px-[24px] text-[16px] font-light">Are you sure you want to delete this question? This action cannot be undone.</p>
              <div className="flex py-2 px-3 gap-6 border-t border-gray-300 justify-end">
                  <button onClick={() => handleDelete(selectedQuestion.id)} className=' text-[#EB4335] bg-[#FDECEB] hover:text-[#FDECEB] hover:bg-[#EB4335]  py-2 px-10 block rounded-sm cursor-pointer '>Yes, I'm sure</button>
                  <button className='text-center py-2 px-5 text-[#292929]  rounded-sm block transition cursor-pointer hover:border hover:border-gray-200 ' onClick={()=> setShowConfirmDelete(false)}>Cancel</button>
                            
              </div>
          </Modal>}
            
          {/* Submit Modal */}
          {showConfirmSubmit && <Modal contW={"w-[528px]"} headerIcon={"confirm"} closeModal={() => setShowConfirmSubmit(false)} headTitle={"Confirm Action"} headBgColor={"bg-[#1B5FC1]"} contH={"h-[230px]"}>
              <p className="border-b border-gray-200 py-[20px] px-[24px] text-[16px] font-light">Are you sure you want to proceed with this assessment creation? You can make changes later if needed.</p>
              <div className="flex py-2 px-3 gap-6 border-t border-gray-300 justify-end">
                  <button className='text-center py-2 px-5  rounded-sm block transition text-[#292929] cursor-pointer hover:text-[#FDECEB] hover:bg-[#1B5FC1]' onClick={()=> setShowConfirmSubmit(false)}>Cancel</button>
                  <button onClick={() => handleSubmit(selectedQuestion.id)} className='  py-2 px-10 block rounded-sm cursor-pointer hover:border hover:border-gray-200 text-[#1B5FC1] bg-[#E8EFF9]'>Yes, I'm sure</button>
                            
              </div>
          </Modal>}
      </div>
  )
}
