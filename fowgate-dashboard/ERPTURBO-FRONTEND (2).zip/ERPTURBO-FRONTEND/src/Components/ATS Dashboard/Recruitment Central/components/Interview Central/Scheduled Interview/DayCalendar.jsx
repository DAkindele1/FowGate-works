import React from 'react';
import DisplayName from '../../../../Job Board/services/DisplayName';
import { useEffect } from 'react';
import { getAllInterviews } from '../services/api_interview_central';

export default function DayCalendar({ setTotalMeetings, interviewDay, handleInterviewDetailsModal, selectedDayMeeting,  setSelectedDayMeeting,
  refreshFlag, interviewMonth  }) {

  
   // useEffect to fetch meetings when day/month or refreshFlag changes
   useEffect(() => {
    const fetchMeetings = async () => {
      try {
        const data = await getAllInterviews(interviewMonth, interviewDay);
        setSelectedDayMeeting(data.meetings);
        setTotalMeetings(data.meetings.length);
      } catch (error) {
        console.error("Error fetching meetings:", error);
      }
    };
    
    fetchMeetings();
  }, [interviewDay, interviewMonth, refreshFlag, setSelectedDayMeeting, setTotalMeetings])

  const calculateMeetingPositions = (meetings) => {
    if (!meetings || meetings.length === 0) return [];
    
    // Sort meetings by start time, then by end time
    const sortedMeetings = [...meetings].sort((a, b) => {
      if (a.start_time === b.start_time) {
        return a.end_time.localeCompare(b.end_time);
      }
      return a.start_time.localeCompare(b.start_time);
    });
  
    const columns = [];
    const result = [];
  
    // First pass: group identical time meetings
    const groupedMeetings = [];
    let currentGroup = [sortedMeetings[0]];
  
    for (let i = 1; i < sortedMeetings.length; i++) {
      const current = sortedMeetings[i];
      const lastInGroup = currentGroup[currentGroup.length - 1];
      
      if (current.start_time === lastInGroup.start_time && 
          current.end_time === lastInGroup.end_time) {
        currentGroup.push(current);
      } else {
        groupedMeetings.push(currentGroup);
        currentGroup = [current];
      }
    }
    groupedMeetings.push(currentGroup);
  
    // Second pass: calculate positions with wider spacing
    groupedMeetings.forEach(group => {
      const [startHour, startMinute] = group[0].start_time.split(':').map(Number);
      const [endHour, endMinute] = group[0].end_time.split(':').map(Number);
      
      const startMinutes = startHour * 60 + startMinute;
      const endMinutes = endHour * 60 + endMinute;
      
      // Find first available column
      let columnIndex = 0;
      while (columnIndex < columns.length) {
        if (columns[columnIndex] <= startMinutes) break;
        columnIndex++;
      }
      
      columns[columnIndex] = endMinutes;
      
      const startPosition = (startMinutes * 100) / (24 * 60);
      const heightPercent = ((endMinutes - startMinutes) * 100) / (24 * 60);
      const baseLeft = columnIndex * 15;
      
      // Calculate width with wider spacing between same-time meetings
      const spacingPercentage = 1; // Additional spacing between meetings (2%)
      const totalSpacing = (group.length - 1) * spacingPercentage;
      const availableWidth = 100 - baseLeft - totalSpacing;
      const meetingWidth = group.length > 1 
        ? availableWidth / group.length 
        : availableWidth;
      
      group.forEach((meeting, index) => {
        const left = group.length > 1
          ? baseLeft + (index * (meetingWidth + spacingPercentage))
          : baseLeft;
        
        result.push({
          ...meeting,
          style: {
            top: `${startPosition}%`,
            height: `${heightPercent}%`,
            left: `${left}%`,
            width: `${meetingWidth}%`,
            zIndex: columnIndex + 1
          }
        });
      });
    });
  
    return result;
  };

    const positionedMeetings = calculateMeetingPositions(selectedDayMeeting);
    
    function timeToNumber(timeStr) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        return hours + (minutes / 100); // Returns number 10.3 (but value is precise)
      }
      
      // Format for display:
      function formatDecimal(num) {
        return num.toFixed(2); // Returns string "10.30"
      }

  return (
    <div className='overflow-auto'>
      <div className='relative'>
        {Array.from({ length: 24 }).map((_, i) => (
          <div className="flex h-[100px] gap-6 border-b border-b-[#F3F2F2]" key={i}>
            <div className='h-full w-[100px] flex items-center justify-center text-[#707070] text-[14px] bg-[#F3F2F2] border-b border-b-white'>
              {i === 0 ? "12" : i > 12 ? `${i - 12}` : i}:00{i > 11 ? "PM" : "AM"}
            </div>
          </div>
        ))}
        
        <div className="absolute top-0 left-[123px] h-full" style={{ width: 'calc(100% - 123px)' }}>
          <div className="w-full h-full relative">
                      {positionedMeetings.map((meeting) => {
                          const start_time = timeToNumber(meeting.start_time)
                          const end_time = timeToNumber(meeting.end_time)
                          return <div
                              key={meeting._id}
                              className="absolute rounded-[10px] bg-white p-0.5 cursor-pointer transition duration-200 ease-in-out hover:scale-105 overflow-hidden"
                              onClick={() => handleInterviewDetailsModal(meeting)}
                              style={meeting.style}
                          >
                              <div className="bg-[#E8EFF9] rounded-[10px] p-3 h-full flex flex-col gap-2 ">
                                  <div className='text-[14px] text-[#292929] font-normal  '> <span className='font-light text-[#9D9D9D]'> {start_time>12? formatDecimal(start_time-12): formatDecimal(start_time) } { start_time>12? "PM": "AM"} - {end_time>13? formatDecimal(end_time-12): formatDecimal(end_time) } { end_time>12? "PM": "AM"}</span> {meeting.title} </div>
                                  <div className="p-1 rounded-[40px] h-[28px] w-fit bg-white flex items-center ">
                                      
                                      {meeting.attendees.length > 1 && meeting.attendees.slice(0, 7).map((el, i) => <div key={i} className={`${el.length !== 1 && "text-[#1b5fc1] font-medium rounded-full h-[20px] w-[20px] flex items-center justify-center bg-white p-[.5px]"} ${i !== 0 && `${"-ml-1"}`} `}> <div className={el.length !== 1 && "w-[18px] h-[18px] rounded-full bg-[#E8EFF9] flex items-center justify-center"}>
                                                    <DisplayName name={`${el.firstname} ${el.lastname}`} fontSize={'text-[8px]'} />
                                      </div></div>)
                                      }

                                      {meeting.attendees.length === 1 && <div className="flex items-center gap-2">
                                                    <div className="font-medium w-[18px] h-[18px] rounded-full p-1 flex items-center justify-center bg-[#E8EFF9] text-[#1b5fc1]">
                                                    <DisplayName name={`${meeting.attendees[0].firstname} ${meeting.attendees[0].lastname} `} fontSize={'text-[8px]'}/>
                                                    </div>
                                                    <p className='text-[12px]'>{meeting.attendees[0].firstname} {meeting.attendees[0].lastname}</p></div>}
                                                  
                                                {meeting.attendees.length > 7 && (
                                                  <span className="text-[8px] -ml-1 w-[18px] h-[18px] rounded-full p-1 flex items-center justify-center bg-[#E8EFF9] text-[#1b5fc1]">
                                                    +{meeting.attendees.length - 7}
                                                  </span>
                                                      )}
                                      
                                  </div>
                              </div>
                          </div>
                      })}
          </div>
        </div>
      </div>
    </div>
  );
}