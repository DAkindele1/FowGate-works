import React, { useEffect, useRef, useState } from 'react'
import { getAllInterviews } from '../services/api_interview_central';
import DisplayName from '../../../../Job Board/services/DisplayName';

export default function WeekCalendar({interviewMonth, setTotalMeetings, handleInterviewDetailsModal}) {

    
      const [interviews, setInterviews] = useState([]);
    
  const headerRef = useRef(null);
  const bodyRef = useRef(null);
  const dayColumnRef = useRef(null);
    const timeColumnsRef = useRef(null);
    

    // API
    useEffect(() => {
        const interviewData = async () => {
          const data = await getAllInterviews(interviewMonth);
          setTotalMeetings(data.total_meetings);
          setInterviews(data.meetings);
        };
        interviewData();
      }, [interviewMonth, setTotalMeetings]);
    

       // Synchronize horizontal scrolling between header and body
   useEffect(() => {
    const bodyEl = bodyRef.current;
    const headerEl = headerRef.current;

    if (!bodyEl || !headerEl) return;

    const handleScroll = () => {
      headerEl.scrollLeft = bodyEl.scrollLeft;
    };

    bodyEl.addEventListener('scroll', handleScroll);
    return () => bodyEl.removeEventListener('scroll', handleScroll);
  }, []);

  // Synchronize vertical scrolling between day column and time columns
  useEffect(() => {
    const dayColumn = dayColumnRef.current;
    const timeColumns = timeColumnsRef.current;

    if (!dayColumn || !timeColumns) return;

    const handleScroll = () => {
      dayColumn.scrollTop = timeColumns.scrollTop;
    };

    timeColumns.addEventListener('scroll', handleScroll);
    return () => timeColumns.removeEventListener('scroll', handleScroll);
  }, []);
    
  function timeToDecimal(timeStr) {
    if (!timeStr) return 0;
    const [hours, minutes, seconds] = timeStr.split(':').map(Number);
    return hours + (minutes / 60) + (seconds / 3600);
    }
    
  return (
      <>
      {/* TABLE HEADER - Single "Day" column */}
    <div className="flex">
      <div className="w-[100px] flex-shrink-0 bg-[#E8EFF9] flex items-center justify-center h-10 border-b border-r border-gray-200">
        <span className="text-[#707070] text-[14px]">Day/Time</span>
      </div>
      
      {/* Time headers with corrected order (12AM first) */}
      <div 
        ref={headerRef}
        className="flex overflow-x-hidden bg-[#E8EFF9]"
        style={{ width: 'calc(100% - 100px)' }}
      >
        {/* 12AM first */}
        <div className='h-10 w-[100px] flex-shrink-0 flex items-center justify-center border-b border-r border-gray-200'>
          <span className="text-[#707070] text-[14px]">12:00 AM</span>
        </div>
        
        {/* Then 1AM-11AM */}
        {Array.from({ length: 11 }).map((_, i) => (
          <div
            key={`am-${i}`}
            className='h-10 w-[100px] flex-shrink-0 flex items-center justify-center border-b border-r border-gray-200'
          >
            <span className="text-[#707070] text-[14px]">
              {`${i + 1}:00 AM`}
            </span>
          </div>
        ))}
        
        {/* Then 12PM */}
        <div className='h-10 w-[100px] flex-shrink-0 flex items-center justify-center border-b border-r border-gray-200'>
          <span className="text-[#707070] text-[14px]">12:00 PM</span>
        </div>
        
        {/* Then 1PM-11PM */}
        {Array.from({ length: 11 }).map((_, i) => (
          <div
            key={`pm-${i}`}
            className='h-10 w-[100px] flex-shrink-0 flex items-center justify-center border-b border-r border-gray-200'
          >
            <span className="text-[#707070] text-[14px]">
              {`${i + 1}:00 PM`}
            </span>
          </div>
        ))}
      </div>
    </div>

    {/* TABLE BODY */}
    <div className="flex flex-1 overflow-hidden">
      {/* Day column - 62 rows (2 per day) */}
      <div 
        ref={dayColumnRef}
        className="w-[100px] flex-shrink-0 overflow-y-auto"
        style={{ scrollbarWidth: 'none' }}
      >
        {Array.from({ length: 62 }).map((_, i) => (
          <div 
            key={i}
            className='h-[103px] flex items-center justify-center border-b border-r border-gray-200 bg-white'
          >
            {i%2===0 ? `${i<18 ? "0":""}${(i+2)/2}` : ""}
          </div>
        ))}
      </div>
      
      {/* Time columns - main scroll area */}
      <div 
        ref={bodyRef}
        className="flex-1 overflow-auto relative"
        style={{ 
          scrollbarWidth: 'none',
          msOverflowStyle: 'none'
        }}
        onScroll={(e) => {
          if (headerRef.current) {
            headerRef.current.scrollLeft = e.currentTarget.scrollLeft;
          }
          if (dayColumnRef.current) {
            dayColumnRef.current.scrollTop = e.currentTarget.scrollTop;
          }
        }}
      >
        <div style={{ width: '100%', height: '6386px', }}>
          {/* Grid cells - 62 rows */}
          {Array.from({ length: 62 }).map((_, rowIdx) => (
            <div 
              key={rowIdx} 
              className="flex absolute left-0"
              style={{ 
                top: rowIdx * 103,
                height: 103 
              }}
            >
              {/* 12AM first */}
              <div className="h-[103px] w-[100px] flex-shrink-0  border-b border-b-gray-300 "/>
              
              {/* 1AM-11AM */}
              {Array.from({ length: 11 }).map((_, i) => (
                <div
                  key={`am-cell-${i}`}
                  className="h-[103px] w-[100px] flex-shrink-0 border-l border-b border-b-gray-300 border-l-gray-300"
                />
              ))}
              
              {/* 12PM */}
              <div className="h-[103px] w-[100px] flex-shrink-0 border-l border-b border-b-gray-300 border-l-gray-300"/>
              
              {/* 1PM-11PM */}
              {Array.from({ length: 11 }).map((_, i) => (
                <div
                  key={`pm-cell-${i}`}
                  className="h-[103px] w-[100px] flex-shrink-0 border-l border-b border-b-gray-300 border-l-gray-300"
                />
              ))}
            </div>
          ))}
          
          {/* Interview items */}
          {interviews.map((interview, i) => {
            const startTime = interview.start_time;
            const endTime = interview.end_time;
            
            // Calculate position (12AM is first column)
            let startHour = parseInt(startTime.split(':')[0]);
            const startMin = parseInt(startTime.split(':')[1]);
            const isStartPM = startHour >= 12;
            const startCol = isStartPM ? 
              (startHour === 12 ? 12 : startHour - 12 + 12) : 
              (startHour === 0 ? 0 : startHour);
              
            const left = startCol * 100 + (startMin/60) * 100;
            const width = (timeToDecimal(endTime) - timeToDecimal(startTime)) * 100;
            
            const day = parseInt(interview.date.split('-')[2]);
            const top = ((day - 1) * 2) * 103; // 2 rows per day
            
            return (
              <div 
                key={i} 
                className="cursor-pointer absolute bg-[#FFF1DD] flex flex-col gap-6 p-3 rounded-[10px]"
                style={{
                  width: `${width}px`,
                  left: `${left}px`,
                  top: `${top}px`,
                  height: '100px'
                }} 
                onClick={() => handleInterviewDetailsModal(interview)}
              >
                {interviews.map((interview, i) => {
                const startDecimal = timeToDecimal(interview.start_time);
                const endDecimal = timeToDecimal(interview.end_time);
                const width = 200 * (endDecimal - startDecimal);
                const left = 100 * startDecimal;  
                return (
                  <div 
                    key={i} 
                    className="cursor-pointer h-[157px] absolute top-1 bg-[#FFF1DD] flex flex-col gap-6 p-3 rounded-[10px]" 
                    style={{
                      width: `${width}px`,
                      left: `${left}px`,
                    }} 
                    onClick={() => handleInterviewDetailsModal(interview)}
                  >
                    <div className="flex flex-col gap-4">
                      <div className='h-[45px] flex flex-col gap-2 '>
                        <p className='truncate text-[#292929] text-[14px]'>{interview.title}</p>
                        <p className='font-light text-[#707070] text-[12px] '>
                          {`${interview.start_time.substring(0, 5)} - ${interview.end_time.substring(0, 5)}`}
                        </p>
                      </div>
                      <div className="p-1 rounded-full bg-white w-[120px] h-[28px] flex items-center">
                        {interview.attendees.length > 1 && interview.attendees.slice(0, 4).map((attendee, i) => (
                          <div className={`text-[#1b5fc1] bg-white p-[.5px] font-medium rounded-full h-[25px] w-[25px] flex items-center justify-center ${i !== 0 && "-ml-2"}`} key={i}>
                            <div className="h-[23px] w-[23px] rounded-full bg-[#E8EFF9] flex items-center justify-center">
                              <DisplayName name={`${attendee.firstname || "Samuel"} ${attendee.lastname || "Adedeji"}`} fontSize={"text-[12px]"} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="h-5 flex gap-1 items-center text-[14px]">
                      <img
                        src="/assets/img/google-meet.png"
                        alt="Google Meet Icon"
                        className="w-[18px] h-[18px]"
                      />
                      <p>Lunch Meeting</p>
                    </div>
                  </div>
                );
              })}
              </div>
            );
          })}
        </div>
      </div>
          </div>
      </>
  )
}
