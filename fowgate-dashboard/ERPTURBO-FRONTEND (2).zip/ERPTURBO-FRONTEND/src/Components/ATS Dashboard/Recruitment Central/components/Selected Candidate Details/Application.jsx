import { DownloadSimpleIcon } from '@phosphor-icons/react/dist/ssr'
import React from 'react'

export default function Application({candidateData}) {
  return (
    <>
          <div className="mt-4">
            <h3 className="font-medium mb-2 text-[#292929] text-[16px]">
              About {candidateData.firstname}
            </h3>
            <p className="text-[14px] text-[#545454] font-light leading-relaxed">
              {candidateData.about}
            </p>
          </div>

          <div className="mt-6">
            <h3 className="font-medium mb-2 text-[#292929] text-[16px]">
              Top Skills
            </h3>
            <div className="flex flex-wrap gap-3">
              {candidateData.top_skills.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-gray-100 text-[#292929] text-[13px] font-normal rounded-full "
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-medium mb-2 text-[#292929] text-[16px]">
              Resume
            </h3>
            <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
              <div className="flex items-center">
                <div className="w-8 h-10 flex items-center justify-center rounded mr-3">
                  <img src="/assets/img/pdf.png" alt="PDF Icon" />
                </div>
                <div>
                  <p className="font-normal text-sm">
                  {candidateData.resume? candidateData.resume : `${candidateData.firstname} ${candidateData.lastname}_Resume.pdf`}
                  </p>
                  <p className="text-xs text-gray-500">
                    {candidateData.resume?candidateData.resume : "No size"}
                  </p>
                </div>
              </div>
              <button className="flex items-center gap-2 cursor-pointer text-[#1B5FC1] text-sm font-medium hover:text-[#3D82F0]">
                Download
                <DownloadSimpleIcon size={20} />
              </button>
            </div>
          </div>
        </>
  )
}
