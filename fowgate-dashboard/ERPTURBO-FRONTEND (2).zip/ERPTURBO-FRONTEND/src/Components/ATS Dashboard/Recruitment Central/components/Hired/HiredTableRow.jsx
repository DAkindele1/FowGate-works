
import React, { useState, useEffect } from "react";
import { HiDotsVertical } from "react-icons/hi";
import HiredActionsModal from "./HiredActionsModal";
import toast from "react-hot-toast";
import { StarIcon } from "@phosphor-icons/react";
// import { deleteJobListing } from "../services/api_job_board";

const HiredTableRow = ({ candidate, setIsEdit, setSelectedJob }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
  const [confirmModal, setConfirmModal] = useState(false)
    
    
      const handleDotsClick = (e) => {
        e.stopPropagation()
        setAnchorEl(e.currentTarget);
        setIsModalOpen(true)
    
  };

 
  
  
  const handleEdit = () => {
    setSelectedJob(candidate); // Set the selected job
    setIsEdit(true); // Open the edit modal
  };

    
  const handleDelete = (jobCode) => {
    setIsModalOpen(false)
    setConfirmModal(false)
    // deleteJobListing(jobCode)
    toast.success("Job listing deleted successfully")
      };
         
      const statusColors = {
        published: "bg-green-[#EEFFF3] text-[#34A853]",
        cancelled: "bg-[#FDECEB] text-[#EB4335]",
        draft: "bg-[#FFF1DD] text-[#EB8A00]",
        pending: "bg-[#FFF1DD] text-[#EB8A00]",
  };
  
  const starFill = candidate.match >= 70 ? "#34A853" : candidate.match >= 50 ? "#6694D5" : "#F28178"

  
    
        return (<>  <div className="grid grid-cols-[1.5fr_1.2fr_.5fr_.6fr_1.4fr_1fr_0.4fr] gap-8 border-b border-gray-300 px-3 py-2 text-[#292929] text-[14px] font-normal items-center ">
          <div className="flex gap-2 items-center justify-start">
            <div className="text-[#1b5fc1] font-medium rounded-full h-[38px] w-[38px] flex items-center justify-center bg-white p-[.5px]">
              <div className= "w-[35px] h-[35px] rounded-full bg-[#E8EFF9] flex items-center justify-center">{candidate.firstname[0]} {candidate.lastname[0]}</div>
            </div>
            <span>{candidate.firstname}</span><span>{candidate.lastname}</span></div>
          <div className=" truncate">
            {candidate.role}
          </div>
          <div className=" text-center">{candidate.availability ? candidate.availability : '—'}</div>
          
          {/* Job Type Column */}
          <div className=" w-full text-center"><span className=" w-fit">{candidate.work_type ? candidate.work_type : '—'}</span></div>

          {/* Score Column */}
          <div className="w-full  flex justify-center">
          <span className="text-[14px] w-fit font-normal bg-[#F3F2F2] rounded-full py-1 px-3 flex items-center gap-1">
              <StarIcon color={starFill} weight="fill"/>
        <span className={`${candidate.match >= 70 ? "text-[#34A853]" : candidate.match >= 50 ? "text-[#6694D5]" : "text-[#F28178]"}`}>
  {candidate.match ? candidate.match : '—'}%
              </span>
              {candidate.match >= 70 ? "Excellent" : candidate.match >= 50 ? "Good" : candidate.match > 0 ? "Low" : ""} Score
          </span>
          </div>
          
          {/* Status Column */}
          <div className="w-full  flex justify-center">
          <span className={` text-[#34A853] px-3 py-1 rounded-full bg-[#EEFFF3] w-fit`}>Hired</span>
          </div>

          {/* Action */}
            <button className='cursor-pointer flex justify-center items-center' onClick={handleDotsClick}><HiDotsVertical /></button>
          {isModalOpen &&
             <HiredActionsModal
            
             isOpen={isModalOpen}
             onDelete={handleDelete}
             onEdit={handleEdit} // Pass the edit handler
             anchorEl={anchorEl}
             onClose={() => setIsModalOpen(false)}
             confirmModal={confirmModal}
             showConfirmedModal={()=>setConfirmModal(true)}
            closeConfirmedModal={() => setConfirmModal(false)}
            candidate={candidate}
           />
          }
        </div>
          
          
        
        </>)
    
};

export default HiredTableRow;