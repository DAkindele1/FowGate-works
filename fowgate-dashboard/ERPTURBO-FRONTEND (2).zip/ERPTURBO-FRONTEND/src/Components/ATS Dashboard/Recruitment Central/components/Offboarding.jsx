import React, { useState } from "react";
import {
  Search,
  MoreVertical,
  ChevronDown,
  Calendar,
  Clock,
} from "lucide-react";

// Mock data for offboarding employees
const offboardingEmployees = [
  {
    id: 1,
    name: "Samuel Adeyemi",
    role: "Software Developer",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Lagos, Nigeria",
    rating: 4.1,
    duration: "1 yr, 5 Months",
    phone: "+234-810-589-4695",
    positionType: "Remote",
    availability: "Full-Time",
    startDate: "27 Nov, 2024",
    resignationLetter: {
      name: "Resignation Letter",
      size: "855KB",
      pages: 1,
    },
    cases: [
      {
        id: 1,
        title: "Lateness to the Office",
        type: "Disciplinary",
        priority: "Medium",
        dateCreated: "27 Nov, 2024",
        status: "Resolved",
      },
      {
        id: 2,
        title: "Unauthorized Absence",
        type: "Disciplinary",
        priority: "High",
        dateCreated: "27 Nov, 2024",
        status: "Resolved",
      },
      {
        id: 3,
        title: "Workplace Misconduct",
        type: "Disciplinary",
        priority: "High",
        dateCreated: "27 Nov, 2024",
        status: "Resolved",
      },
    ],
  },
  {
    id: 2,
    name: "Ahmed Bello",
    role: "UI/UX Designer",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Abuja, Nigeria",
    rating: 3.8,
    duration: "2 yrs, 3 Months",
    phone: "+234-703-456-7890",
    positionType: "Remote",
    availability: "Full-Time",
    startDate: "15 Jan, 2023",
    resignationLetter: {
      name: "Resignation Letter",
      size: "720KB",
      pages: 2,
    },
    cases: [],
  },
  {
    id: 3,
    name: "Jane Smith",
    role: "Project Manager",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Accra, Ghana",
    rating: 4.5,
    duration: "3 yrs, 2 Months",
    phone: "+233-24-123-4567",
    positionType: "Hybrid",
    availability: "Full-Time",
    startDate: "10 Mar, 2022",
    resignationLetter: {
      name: "Resignation Letter",
      size: "910KB",
      pages: 1,
    },
    cases: [],
  },
  {
    id: 4,
    name: "Grace Nwosu",
    role: "Sales Marketer",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Port Harcourt, Nigeria",
    rating: 4.2,
    duration: "1 yr, 8 Months",
    phone: "+234-815-123-4567",
    positionType: "Onsite",
    availability: "Full-Time",
    startDate: "5 May, 2023",
    resignationLetter: {
      name: "Resignation Letter",
      size: "780KB",
      pages: 1,
    },
    cases: [],
  },
  {
    id: 5,
    name: "Linda Eze",
    role: "Data Analyst",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Lagos, Nigeria",
    rating: 3.9,
    duration: "2 yrs, 1 Month",
    phone: "+234-812-345-6789",
    positionType: "Remote",
    availability: "Part-Time",
    startDate: "12 Oct, 2022",
    resignationLetter: {
      name: "Resignation Letter",
      size: "830KB",
      pages: 1,
    },
    cases: [],
  },
  {
    id: 6,
    name: "Daniel Okafor",
    role: "Backend Developer",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Enugu, Nigeria",
    rating: 4.3,
    duration: "1 yr, 11 Months",
    phone: "+234-814-987-6543",
    positionType: "Remote",
    availability: "Full-Time",
    startDate: "3 Feb, 2023",
    resignationLetter: {
      name: "Resignation Letter",
      size: "795KB",
      pages: 1,
    },
    cases: [],
  },
  {
    id: 7,
    name: "Alfred Beckett",
    role: "Content Strategist",
    avatar: "/placeholder.svg?height=40&width=40",
    location: "Kumasi, Ghana",
    rating: 4.0,
    duration: "1 yr, 3 Months",
    phone: "+233-54-765-4321",
    positionType: "Remote",
    availability: "Full-Time",
    startDate: "20 Aug, 2023",
    resignationLetter: {
      name: "Resignation Letter",
      size: "840KB",
      pages: 1,
    },
    cases: [],
  },
];

const Offboarding = () => {
  const [employees, setEmployees] = useState(offboardingEmployees);
  const [selectedEmployee, setSelectedEmployee] = useState(
    offboardingEmployees[0]
  );
  const [showActionMenu, setShowActionMenu] = useState(false);
  const [activeTab, setActiveTab] = useState("Off-Boarding Process");
  const [terminationLetterText, setTerminationLetterText] = useState("");
  const [interviewNotes, setInterviewNotes] = useState("");

  // Handle employee selection
  const handleEmployeeSelect = (employee) => {
    setSelectedEmployee(employee);
    setShowActionMenu(false);
  };

  // Render star rating
  const renderStarRating = (rating) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];

    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <svg
            key={i}
            className="w-4 h-4 text-yellow-400 fill-current"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
          >
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
          </svg>
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <svg
            key={i}
            className="w-4 h-4 text-yellow-400 fill-current"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
          >
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
          </svg>
        );
      } else {
        stars.push(
          <svg
            key={i}
            className="w-4 h-4 text-gray-300 fill-current"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
          >
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
          </svg>
        );
      }
    }

    return stars;
  };

  // Get priority icon and color
  const getPriorityDisplay = (priority) => {
    switch (priority) {
      case "High":
        return {
          icon: (
            <span className="inline-block w-4 h-4">
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M8 3.33334V12.6667"
                  stroke="#FF4D4F"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M3.33331 8H12.6666"
                  stroke="#FF4D4F"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
          ),
          text: "High",
          textColor: "text-red-500",
        };
      case "Medium":
        return {
          icon: (
            <span className="inline-block w-4 h-4">
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M3.33331 8H12.6666"
                  stroke="#F59E0B"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
          ),
          text: "Medium",
          textColor: "text-amber-500",
        };
      default:
        return {
          icon: (
            <span className="inline-block w-4 h-4">
              <svg
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M3.33331 8H12.6666"
                  stroke="#10B981"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
          ),
          text: "Low",
          textColor: "text-green-500",
        };
    }
  };

  return (
    <div className="flex flex-1 space-x-4 p-6">
      {/* Left Column - Employee List */}
      <div className="w-1/3 bg-white rounded-lg border border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <span className="font-medium">All Status</span>
              <ChevronDown className="h-4 w-4" />
            </div>
          </div>
          <div className="relative">
            <input
              type="text"
              placeholder="Search name, skill..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none"
            />
            <Search
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
              size={18}
            />
          </div>
        </div>

        <div className="divide-y divide-gray-100">
          {employees.map((employee) => (
            <div
              key={employee.id}
              className={`p-4 flex items-center hover:bg-gray-50 cursor-pointer ${
                employee.id === selectedEmployee.id ? "bg-blue-50" : ""
              }`}
              onClick={() => handleEmployeeSelect(employee)}
            >
              <img
                src={employee.avatar || "/placeholder.svg"}
                alt={employee.name}
                className="w-10 h-10 rounded-full object-cover mr-3"
              />
              <div className="flex-1">
                <h2 className="font-medium text-gray-900">{employee.name}</h2>
                <p className="text-sm text-gray-500">{employee.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Column - Employee Details */}
      <div className="w-2/3 bg-white rounded-lg border border-gray-200 relative">
        {/* Employee Header */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center">
            <img
              src={selectedEmployee.avatar || "/placeholder.svg"}
              alt={selectedEmployee.name}
              className="w-12 h-12 rounded-full object-cover mr-3"
            />
            <div>
              <h2 className="text-lg font-semibold">{selectedEmployee.name}</h2>
              <div className="text-sm text-gray-500 flex gap-1">
                <img
                  src="/assets/img/location.png"
                  alt="location icon"
                  className="w-4 h-4"
                />
                <p>{selectedEmployee.location}</p>
              </div>
            </div>
          </div>
          <button className="p-1.5 hover:bg-gray-100 rounded-md">
            <MoreVertical className="h-5 w-5 text-gray-400" />
          </button>
        </div>

        {/* Employee Stats */}
        <div className="p-4 pt-2 flex items-center gap-4">
          {/* STARSS */}
          <div className="flex items-center bg-[#F3F2F2] w-fit rounded-full gap-1 px-[12px] py-[10px]">
            <div className="flex mr-1">
              {renderStarRating(selectedEmployee.rating)}
            </div>
            <span className="text-sm">{selectedEmployee.rating}</span>
          </div>

          {/* CALENDAR */}
          <div className="flex items-center bg-[#F3F2F2] w-fit rounded-full gap-1 px-[12px] py-[10px]">
            <div className="rounded-full flex items-center justify-center mr-2">
              <img
                src="/assets/img/briefcase-01.png"
                alt="Brief Case Icon"
                className="w-4 h-4 "
              />
            </div>
            <div>
              <p className="text-sm">{selectedEmployee.duration}</p>
            </div>
          </div>

          {/* PHONE */}
          <div className="flex items-center bg-[#F3F2F2] w-fit rounded-full gap-1 px-[12px] py-[10px]">
            <div className="rounded-full flex items-center justify-center mr-2">
              <img
                src="/assets/img/phone.png"
                alt="Phone Icon"
                className="w-4 h-4 "
              />
            </div>
            <div>
              <p className="text-[14px] font-normal">
                {selectedEmployee.phone}
              </p>
            </div>
          </div>
        </div>

        {/* Position Details */}
        <div className="flex justify-between items-center border border-gray-200 mx-5 rounded-md">
          <div className="p-4">
            <p className="text-[14px] text-[#707070] font-normal">
              Position Type
            </p>
            <p className="font-normal text-[14px] text-[#292929]">
              {selectedEmployee.positionType}
            </p>
          </div>
          <div className="p-4">
            <p className="text-[14px] text-[#707070] font-normal">
              Availability
            </p>
            <p className="font-normal text-[14px] text-[#292929]">
              {selectedEmployee.availability}
            </p>
          </div>
          <div className="p-4">
            <p className="text-[14px] text-[#707070] font-normal">Start Date</p>
            <p className="font-normal text-[14px] text-[#292929]">
              {selectedEmployee.startDate}
            </p>
          </div>
        </div>

        {/* Attached File */}
        <div className="px-5 my-8 ">
          <h3 className="font-medium mb-3">Attached File</h3>
          <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
            <div className="flex items-center">
              <div className="w-10 h-12 flex items-center justify-center rounded mr-3">
                <img src="/assets/img/pdf.png" alt="File Icon" />
              </div>
              <div>
                <p className="font-normal text-[14px] text-[#292929]">
                  {selectedEmployee.resignationLetter.name}
                </p>
                <p className="text-[12px] font-light text-[#707070]">
                  {selectedEmployee.resignationLetter.size} •{" "}
                  {selectedEmployee.resignationLetter.pages} page
                </p>
              </div>
            </div>
            <button className="text-[#1B5FC1] text-[14px] font-normal">
              View File
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="px-4 mb-4 ">
          <div className="flex border-b border-gray-200 space-x-4">
            <button
              className={`py-2 text-sm ${
                activeTab === "Off-Boarding Process"
                  ? "text-[#1B5FC1] border-b-3 border-[#1B5FC1] text-[16px] font-normal"
                  : "text-[#545454] hover:text-gray-700 text-[16px] font-light"
              }`}
              onClick={() => setActiveTab("Off-Boarding Process")}
            >
              Off-Boarding Process
            </button>
            <button
              className={`py-2 ${
                activeTab === "Exit Interview"
                  ? "text-[#1B5FC1] border-b-3 border-[#1B5FC1] text-[16px] font-normal"
                  : "text-[#545454] hover:text-gray-700 text-[16px] font-light"
              }`}
              onClick={() => setActiveTab("Exit Interview")}
            >
              Exit Interview
            </button>
            <button
              className={`py-2 ${
                activeTab === "Case Management"
                  ? "text-[#1B5FC1] border-b-3 border-[#1B5FC1] text-[16px] font-normal"
                  : "text-[#545454] hover:text-gray-700 text-[16px] font-light"
              }`}
              onClick={() => setActiveTab("Case Management")}
            >
              Case Management (5)
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="px-4 mb-20">
          {activeTab === "Off-Boarding Process" && (
            <div>
              <h3 className="font-medium mb-3">Termination Letter</h3>
              <div className="mb-4">
                <textarea
                  className="w-full p-3 border border-gray-200 rounded-md min-h-[150px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Type here"
                  value={terminationLetterText}
                  onChange={(e) => setTerminationLetterText(e.target.value)}
                ></textarea>
              </div>
              <div className="flex justify-between items-center">
                <div className="relative">
                  <button className="flex items-center px-4 py-2 border border-gray-200 rounded-md">
                    <span className="mr-2">Choose Template</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>
                </div>
                <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-md">
                  Send to Employee
                </button>
              </div>
            </div>
          )}

          {activeTab === "Exit Interview" && (
            <div>
              <div className="flex justify-center items-center flex-col py-8">
                <div className="w-20 h-20 mb-4">
                  <img
                    src="/assets/img/empty-document.svg"
                    alt="Document Icon"
                    className="w-full h-full"
                  />
                </div>
                <div className="text-center mb-6">
                  <h3 className="text-lg font-medium mb-2">
                    Schedule Exit Interview
                  </h3>
                  <p className="text-gray-500 text-sm max-w-md">
                    Schedule an exit interview to gather feedback from the
                    employee about their experience with the company.
                  </p>
                </div>
                <div className="flex space-x-4">
                  <button className="flex items-center px-4 py-2 border border-gray-200 rounded-md">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>Schedule Interview</span>
                  </button>
                  <button className="flex items-center px-4 py-2 bg-blue-50 text-blue-600 rounded-md">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>Send Questionnaire</span>
                  </button>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="font-medium mb-3">Interview Notes</h3>
                <div className="mb-4">
                  <textarea
                    className="w-full p-3 border border-gray-200 rounded-md min-h-[150px] focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Add notes from the exit interview here..."
                    value={interviewNotes}
                    onChange={(e) => setInterviewNotes(e.target.value)}
                  ></textarea>
                </div>
                <div className="flex justify-end">
                  <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-md">
                    Save Notes
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "Case Management" && (
            <div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-[#F8F9FC]">
                    <tr>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Case Title
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Case Type
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Priority
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Date Created
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {selectedEmployee.cases &&
                    selectedEmployee.cases.length > 0 ? (
                      selectedEmployee.cases.map((caseItem) => {
                        const priorityDisplay = getPriorityDisplay(
                          caseItem.priority
                        );
                        return (
                          <tr key={caseItem.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {caseItem.title}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {caseItem.type}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                {priorityDisplay.icon}
                                <span
                                  className={`ml-2 text-sm ${priorityDisplay.textColor}`}
                                >
                                  {caseItem.priority}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {caseItem.dateCreated}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                {caseItem.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td
                          colSpan={5}
                          className="px-6 py-4 text-center text-sm text-gray-500"
                        >
                          No cases found for this employee.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Action Button */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-gray-200 p-4 bg-white flex justify-end">
          <button className="px-4 py-2 bg-blue-600 text-white rounded">
            Complete Offboarding
          </button>
        </div>
      </div>
    </div>
  );
};

export default Offboarding;
