import React, { useState, useEffect, useMemo } from "react";
import Hired from "./Hired/Hired";
import Offboarding from "./Offboarding";
import { fetchAllCandidates } from "../services/api_recruitment_central";
import { CalendarDotsIcon, CaretDownIcon, CaretLeftIcon, CaretRightIcon, FunnelIcon, XIcon } from "@phosphor-icons/react";
import Spinner from "../../../../ui/Spinner";
import RecruitmentList from "./RecruitmentList";
import CandidateDetails from "./CandidateDetails";
import EmptyList from "../../../../ui/EmptyTable";

const RecruitmentCentralReuse = ({mainTab, setScheduledInterviews, setJobCode, setManageAI}) => {
  const [apiCandidates, setApiCandidates] = useState([]);
  const [apiTalentPoolCandidates, setApiTalentPoolCandidates] = useState([]);
  const [selectedCandidate, setSelectedCandidate] = useState([]);
  const [isDetailsLoading, setIsDetailsLoading] = useState(true)
  const [currentTab, setCurrentTab] = useState("ALL CANDIDATES");
  const [fetchError, setFetchError] = useState(false);
  const [talentFilter, setTalentFilter] = useState("all")

  const tabs = [
    { name: "ALL CANDIDATES", count: apiCandidates.length },
    { name: "SHORTLISTED", count: apiCandidates.filter(data => data.is_shortlisted).length },
    { name: "INTERVIEW CENTRAL", count: apiCandidates.filter(data => data.is_interviewed).length },
    { name: "HIRED", count: apiCandidates.filter(data => !data.is_hired).length },
    { name: "ONBOARDING", count: 0 },
    { name: "OFFBOARDING", count: 5 },
  ];

  const handleTalentFilter = (e) => {
    e.stopPropagation()
    setTalentFilter(e.target.value);
  }

  console.log("Selected Candidate:", selectedCandidate );
  
  
  useEffect(() => {
    if (selectedCandidate && selectedCandidate.job_code) {
      setJobCode(selectedCandidate.job_code);
    } else if (apiCandidates.filter(data => data.is_shortlisted)[0]?.job_code) {
      setJobCode(apiCandidates.filter(data => data.is_shortlisted)[0]?.job_code);
    }
  }, [selectedCandidate, setJobCode, apiCandidates]);
  
  
  const filteredCandidates = useMemo(() => {
    return currentTab === "ALL CANDIDATES" 
      ? apiCandidates
      : currentTab === "SHORTLISTED" 
        ? apiCandidates.filter(data => data.is_shortlisted) 
        : currentTab === "INTERVIEW CENTRAL" 
        ? apiCandidates.filter(data => data.is_interviewed)
        : currentTab === "HIRED" 
          ? apiCandidates.filter(data => !data.is_hired) 
        : currentTab === "ONBOARDING" 
          ? apiCandidates
        : currentTab === "OFFBOARDING" 
          ? apiCandidates
          : [];
  }, [currentTab, apiCandidates]);
  
  
  useEffect(() => {
    const getAllCandidates = async () => {
      setIsDetailsLoading(true);
      setFetchError(false);
      try {
        const data = await fetchAllCandidates();
        setApiCandidates(data.applications.filter(data => !data.talent_pool));
        setApiTalentPoolCandidates(data.applications.filter(data => data.talent_pool));
        setIsDetailsLoading(false);
      } catch (err) {
        setFetchError(true);
        setIsDetailsLoading(false);
        console.log(err);
        
      }
    };
    getAllCandidates();
  }, []);
  
  // Handle candidate selection
  const handleCandidateSelect = (candidate) => {
    setSelectedCandidate(candidate);
  };

  const handleShortlistToggle = (applicationCode, isShortlisted) => {
    // Update apiCandidates
    setApiCandidates(prev => prev.map(candidate => 
      candidate.application_code === applicationCode
        ? { ...candidate, is_shortlisted: !isShortlisted }
        : candidate
    ));
    
    // Update selectedCandidate
    if (selectedCandidate.application_code === applicationCode) {
      setSelectedCandidate(prev => ({
        ...prev,
        is_shortlisted: !isShortlisted
      }));
    }
  };
  const handleTalentToggle = (applicationCode, isTalentPool) => {
    // Update apiCandidates
    setApiCandidates(prev => prev.map(candidate => 
      candidate.application_code === applicationCode
        ? { ...candidate, talent_pool: !isTalentPool }
        : candidate
    ));
    
    // Update selectedCandidate
    if (selectedCandidate.application_code === applicationCode) {
      setSelectedCandidate(prev => ({
        ...prev,
       talent_pool: !isTalentPool
      }));
    }
  };

  const handleFavouriteToggle = (applicationCode, isFavorite) => {
    // Update apiCandidates
    setApiCandidates(prev => prev.map(candidate => 
      candidate.application_code === applicationCode
        ? { ...candidate, is_favorite: !isFavorite }
        : candidate
    ));
    
    // Update selectedCandidate
    if (selectedCandidate.application_code === applicationCode) {
      setSelectedCandidate(prev => ({
        ...prev,
        is_favorite: !isFavorite
      }));
    }
  };

  // Handle tab switching
 // Handle tab switching
const handleTabChange = (tabName) => {
  setCurrentTab(tabName);
  
  // If switching to SHORTLISTED tab, find and select the first shortlisted candidate
  if (tabName === "SHORTLISTED") {
    const firstShortlisted = apiCandidates.find(candidate => candidate.is_shortlisted);
    if (firstShortlisted) {
      setSelectedCandidate(firstShortlisted);
    }
  }
  
  // Similar logic for other tabs if needed
  if (tabName === "HIRED") {
    const firstHired = apiCandidates.find(candidate => candidate.is_hired);
    if (firstHired) {
      setSelectedCandidate(firstHired);
    }
  }
};

  
  // Fetch candidates when component mounts
  useEffect(() => {
    if (currentTab === "ALL CANDIDATES") {
      fetchAllCandidates();
    }
  }, [currentTab]);


  return (
    <>
      <div className="border border-gray-300 rounded-xl min-h-[80vh]">
        {/* Job Title Filter */}
        <div className="flex items-center justify-between h-[82px] p-[20px] ">


          {/* LHS */}
          <div className="relative h-[42px]">
              {mainTab === "talentPool" ?
                <div className="flex items-center gap-1">
                <h1 className="font-medium text-[20px]">Talent List </h1> 
                <span className="bg-[#1B5FC1] text-white flex items-center justify-center h-5 w-5 rounded-full text-sm">{apiTalentPoolCandidates.length }</span>
             
                </div> :
                currentTab === "HIRED" || currentTab === "INTERVIEW CENTRAL" ? <div className="flex justify-center items-center gap-10 ">
              <h1 className="text-[18px] font-medium text-[#292929]">{currentTab === "HIRED" ? "Hired List": "Interview Central"}</h1>

              {/* Search */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search here"
                  className="pl-4 pr-10 py-1 border border-gray-300 h-10 rounded w-64 focus:outline-none"
                />

                <img
                  src="/assets/img/ats-search.png"
                  alt="search icon"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2"
                />
              </div>
                </div> :
                  <div className="flex items-center gap-[8px] px-[12px]  bg-gray-100 rounded-md text-gray-800  py-[7px] h-[40px] w-full">
              <span className="font-medium text-[20px] text-[#292929] ">
                Software Engineer
              </span>
                <CaretDownIcon size={24} />
              </div>}
          </div>


          {/* RHS */}
          {currentTab === "SHORTLISTED" || currentTab == "INTERVIEW CENTRAL" ? 
            <div> <div className="flex items-center justify-between w-[390px] h-[40px] text-[14px] ">
            <div className="px-3 py-2.5 border text-[#252525] rounded-[4px] hover:bg-gray-100 border-gray-300 transition-colors duration-200 cursor-pointer" onClick={()=>setManageAI(true)}>
    Manage AI Assessment
  </div>
  <div className="px-3 py-2.5 border rounded-[4px] flex items-center gap-1.5 text-[#1B5FC1]
                 hover:bg-[#1B5FC1] hover:text-white
                 transition-colors duration-200 cursor-pointer" onClick={()=>setScheduledInterviews(true)}>
    <CalendarDotsIcon className="hover:fill-white" />
    <p>Scheduled Interviews</p>
  </div>
            </div></div>:
              <div className={`flex items-center justify-between  h-[40px] ${mainTab === "talentPool" ? "w-[329px] gap-2" : "w-[397px]"}`}>
              <div className=" h-[36px] flex items-center gap-[12px]">
              <p className="text-[12px]  text-[#707070] font-light">Filter by:</p>
            <div className="relative">
                {mainTab === "talentPool" ? <select className="cursor-pointer outline-none border border-gray-300 rounded-sm text-[#707070] p-1" onChange={handleTalentFilter}>
                  <option value="all">All</option>
                  <option value="shortlisted">Shortlisted</option>
                  <option value="favourite">Favourite</option>
                  </select> :
                    <div className="flex items-center gap-[24px] py-[8px] rounded-md">
                      <div className="flex items-center gap-[6px] h-[20px] w-[121px]">
                      <CalendarDotsIcon size={18}/>
                <span className="text-[14px] text-[#292929] font-normal">
                  Jul 15 - Nov 25
                </span>
             </div>

                
                <CaretDownIcon />
              </div>}
            </div>
            </div>
            <button className="flex items-center gap-[6px] w-[143px] h-[40px] bg-blue-50 text-[#1B5FC1] rounded-[4px]  px-[12px] py-[10px] ">
              <CalendarDotsIcon size={20}/>

              <span className="text-[14px]">View Calendar</span>
            </button>
              </div> 
              
            }
        </div>

        {/* Tabs */}
        {mainTab === "main" && <div className="h-[76px] w-full mx-auto  border-t border-gray-300">
          <div className="max-w-[1054px] mx-auto">
          <div className="flex justify-between grid-cols-[186px_166px_208px_107px_162px_164px]  items-center my-[20px] pr-2">
          {tabs.map((tab,i) => (
            <button
              key={i}
              className={`py-[8px] px-[12px] text-[14px] font-normal rounded-[50px] space-x-2 ${i === 0 ? "ml-1.5 w-[186px]":i === 1 ? "w-[166px]":i === 2 ? "w-[208px]":i === 3 ? "w-[107px]":i === 4 ? "w-[162px]": "164px"}  ${
                tab.name === currentTab
                  ? "text-[#1B5FC1] bg-[#ECF4FF]  cursor-not-allowed"
                  : "text-gray-500 hover:text-gray-700 cursor-pointer"
              }`}
              onClick={() => handleTabChange(tab.name)}
            >
              <span> {tab.name}</span>
              <span
                // className="ml-1 bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded-full"
                className={`ml-1 px-1 py-0.5 rounded-full text-white  ${
                  tab.name === currentTab
                    ? " bg-[#1B5FC1]"
                    : " bg-gray-200"
                }`}
              >
                {tab.count} 
              </span>
            </button>
          ))}
          </div></div>
        </div>}
        {mainTab === "talentPool" ?
          <div className="flex flex-1 space-x-4 px-6 py-2 ">
            {/* Left Column - Candidate List */}
           
            <RecruitmentList 
    selectedCandidate={selectedCandidate} 
    handleCandidateSelect={handleCandidateSelect} 
    candidatesData={apiTalentPoolCandidates} 
    onFavoriteToggle={handleFavouriteToggle}
            mainTab={mainTab}
            filter={talentFilter}
    />

            {/* Right Column - Candidate Details */}

            {!isDetailsLoading && !fetchError ? (
              <CandidateDetails 
                selectedCandidate={selectedCandidate} 
                onFavoriteToggle={handleFavouriteToggle}
                onTalentToggle={handleTalentToggle}
                onShortlistToggle={handleShortlistToggle}
                candidatesData={apiTalentPoolCandidates} 
                currentTab={currentTab}
                mainTab={mainTab}
              />
            ) : fetchError ? (
              <div className="w-full flex justify-center items-center h-40">
                <p className="text-red-400">Network error. Please check your internet and refresh. <br /> If error persists, try to re-login.</p>
              </div>
            ) : (
              <Spinner/>
            )}
            
     
          </div>
          :
          <div>{
            currentTab === "ALL CANDIDATES" ? (
              
              // ALL CANDIDATES

          <div className="flex flex-1 space-x-4 px-6 py-2 ">
            {/* Left Column - Candidate List */}
           
            <RecruitmentList 
    selectedCandidate={selectedCandidate} 
    handleCandidateSelect={handleCandidateSelect} 
    candidatesData={filteredCandidates} 
    onFavoriteToggle={handleFavouriteToggle}
              currentTab={currentTab}  // Add this if needed
              mainTab={mainTab}
    />

            {/* Right Column - Candidate Details */}

            {!isDetailsLoading && !fetchError ? (
              <CandidateDetails 
                selectedCandidate={selectedCandidate} 
                onFavoriteToggle={handleFavouriteToggle}
                onTalentToggle={handleTalentToggle}
                onShortlistToggle={handleShortlistToggle}
                candidatesData={filteredCandidates} 
                currentTab={currentTab}
              />
            ) : fetchError ? (
              <div className="w-full flex justify-center items-center h-40">
                <p className="text-red-500">Network error. Please check your internet and refresh.</p>
              </div>
            ) : (
              <Spinner/>
            )}
            
     
          </div>
            ) : currentTab === "SHORTLISTED" ? (
                
              // ALL SHORTLISTED

          <div className="flex flex-1 space-x-4 px-6 py-2 ">
          {/* Left Column - Candidate List */}
         
          <RecruitmentList 
    selectedCandidate={selectedCandidate} 
    handleCandidateSelect={handleCandidateSelect} 
    candidatesData={filteredCandidates}
    onFavoriteToggle={handleFavouriteToggle}
    currentTab={currentTab} 
  />

          {/* Right Column - Candidate Details */}

          {!isDetailsLoading && !fetchError ? (<CandidateDetails 
                selectedCandidate={selectedCandidate} 
                candidatesData={filteredCandidates} 
                condition ={"isShortlisted"}
    onFavoriteToggle={handleFavouriteToggle}
    onTalentToggle={handleTalentToggle}
                onShortlistToggle={handleShortlistToggle}
                currentTab={currentTab}
    />): fetchError ? (
      <div className="w-full flex justify-center items-center h-40">
        <p className="text-red-500">Network error. Please check your internet and refresh.</p>
      </div>
    )  : <Spinner/>}
        
 
      </div>
            ) : currentTab === "INTERVIEW CENTRAL" ? (
                
                // INTERVIEW CENTRAL
                
                <>          
              <div className="flex flex-1 space-x-4 px-6 py-2">
        {/* Left Column - Candidate List */}
       
        <RecruitmentList 
    selectedCandidate={selectedCandidate} 
    handleCandidateSelect={handleCandidateSelect} 
    candidatesData={filteredCandidates} 
    onFavoriteToggle={handleFavouriteToggle}
    currentTab={currentTab}  // Add this if needed
/>

        {/* Right Column - Candidate Details */}

        {!isDetailsLoading && !fetchError ?( <CandidateDetails 
                selectedCandidate={selectedCandidate} 
                candidatesData={filteredCandidates} 
    onFavoriteToggle={handleFavouriteToggle}
    onTalentToggle={handleTalentToggle}
                onShortlistToggle={handleShortlistToggle}
                currentTab={currentTab}
    />) : fetchError ? (
      <div className="w-full flex justify-center items-center h-40">
        <p className="text-red-500">Network error. Please check your internet and refresh.</p>
      </div>
    ) : <Spinner/>}
        
 
      </div>    
                </>
        ) : currentTab === "HIRED" ? (
          <Hired candidatesData={filteredCandidates} />
                  ) : currentTab === "ONBOARDING" ? (
                      
                      // ONBOARDING
                    <div className="flex flex-1 space-x-4 px-6 py-2 ">
                    {/* Left Column - Candidate List */}
                   
                    <RecruitmentList 
              selectedCandidate={selectedCandidate} 
              handleCandidateSelect={handleCandidateSelect} 
              candidatesData={filteredCandidates} 
              onFavoriteToggle={handleFavouriteToggle}
              currentTab={currentTab}  // Add this if needed
            />
            
                    {/* Right Column - Candidate Details */}
            
                    {!isDetailsLoading && !fetchError ? (<CandidateDetails 
                          selectedCandidate={selectedCandidate} 
                          candidatesData={filteredCandidates} 
      onFavoriteToggle={handleFavouriteToggle}
      onTalentToggle={handleTalentToggle}
                          onShortlistToggle={handleShortlistToggle}
                          currentTab={currentTab}
      /> ): fetchError ? (
        <div className="w-full flex justify-center items-center h-40">
          <p className="text-red-500">Network error. Please check your internet and refresh.</p>
        </div>
      ): <Spinner/>}
                </div>
        ) : currentTab === "OFFBOARDING" ? (
          
         // OFFBOARDING
         <div className="flex flex-1 space-x-4 px-6 py-2 ">
         {/* Left Column - Candidate List */}
        
         <RecruitmentList 
   selectedCandidate={selectedCandidate} 
   handleCandidateSelect={handleCandidateSelect} 
   candidatesData={filteredCandidates} 
   onFavoriteToggle={handleFavouriteToggle}
   currentTab={currentTab}  // Add this if needed
 />
 
         {/* Right Column - Candidate Details */}
 
         {!isDetailsLoading && !fetchError ? (<CandidateDetails 
               selectedCandidate={selectedCandidate} 
               candidatesData={filteredCandidates} 
onFavoriteToggle={handleFavouriteToggle}
onTalentToggle={handleTalentToggle}
               onShortlistToggle={handleShortlistToggle}
               currentTab={currentTab}
/> ): fetchError ? (
<div className="w-full flex justify-center items-center h-40">
<p className="text-red-500">Network error. Please check your internet and refresh.</p>
</div>
): <Spinner/>}
     </div>
              ) : null}
            </div>
          }
      </div>
    </>
  );
};

export default RecruitmentCentralReuse;
