import React, { useState } from 'react';
import InterviewAssessRow from './InterviewAssessRow';

export default function InterviewAssessment() {
    // State for each category's score
    const [courtesyMark, setCourtesyMark] = useState(0);
    const [appearanceMark, setAppearanceMark] = useState(0);
    const [personalityMark, setPersonalityMark] = useState(0);
    const [educationMark, setEducationMark] = useState(0);
    const [interestMark, setInterestMark] = useState(0);
    const [skillMark, setSkillMark] = useState(0);
    const [responseMark, setResponseMark] = useState(0);
    const [closeOfInterviewMark, setCloseOfInterviewMark] = useState(0);

    // State to track which row is open (null means all are initially closed)
    const [openRow, setOpenRow] = useState("");

    // Function to handle row toggling
    const handleRowToggle = (rowTitle) => {
        setOpenRow(prev => prev === rowTitle ? null : rowTitle);
    };

    // Calculate total score
    const totalScore = courtesyMark + appearanceMark + personalityMark + 
                      educationMark + interestMark + skillMark + 
                      responseMark + closeOfInterviewMark;

    return (
        <div className='flex flex-col gap-3 h-full max-h-[800px] relative overflow-y-auto'>
            {/* Candidate's Courtesy */}
            <InterviewAssessRow 
                totalMark={courtesyMark}
                setTotalMark={setCourtesyMark}
                title={"Candidate's Courtesy"}
                isOpen={openRow === "Candidate's Courtesy"}
                onToggle={() => handleRowToggle("Candidate's Courtesy")}
            >
                <p>Proper Introduction</p>
                <p>Positive First Impression</p>
            </InterviewAssessRow>

            {/* Candidate's Appearance */}
            <InterviewAssessRow 
                totalMark={appearanceMark}
                setTotalMark={setAppearanceMark}
                title={"Candidate's Appearance"}
                isOpen={openRow === "Candidate's Appearance"}
                onToggle={() => handleRowToggle("Candidate's Appearance")}
            >
                <p>Professional Attire</p>
                <p>Neat Grooming</p>
            </InterviewAssessRow>

            {/* Personality and Poise */}
            <InterviewAssessRow 
                totalMark={personalityMark}
                setTotalMark={setPersonalityMark}
                title={"Personality and Poise"}
                isOpen={openRow === "Personality and Poise"}
                onToggle={() => handleRowToggle("Personality and Poise")}
            >
                <p>Confidence Level</p>
                <p>Body Language</p>
            </InterviewAssessRow>

            {/* Education and Experience */}
            <InterviewAssessRow 
                totalMark={educationMark}
                setTotalMark={setEducationMark}
                title={"Education and Experience"}
                isOpen={openRow === "Education and Experience"}
                onToggle={() => handleRowToggle("Education and Experience")}
            >
                <p>Relevant Qualifications</p>
                <p>Work Experience</p>
            </InterviewAssessRow>

            {/* Candidate's Interest */}
            <InterviewAssessRow 
                totalMark={interestMark}
                setTotalMark={setInterestMark}
                title={"Candidate's Interest"}
                isOpen={openRow === "Candidate's Interest"}
                onToggle={() => handleRowToggle("Candidate's Interest")}
            >
                <p>Enthusiasm for Role</p>
                <p>Company Knowledge</p>
            </InterviewAssessRow>

            {/* Communication Skills */}
            <InterviewAssessRow 
                totalMark={skillMark}
                setTotalMark={setSkillMark}
                title={"Communication Skills"}
                isOpen={openRow === "Communication Skills"}
                onToggle={() => handleRowToggle("Communication Skills")}
            >
                <p>Clarity of Expression</p>
                <p>Active Listening</p>
            </InterviewAssessRow>

            {/* Response Analysis */}
            <InterviewAssessRow 
                totalMark={responseMark}
                setTotalMark={setResponseMark}
                title={"Response Analysis"}
                isOpen={openRow === "Response Analysis"}
                onToggle={() => handleRowToggle("Response Analysis")}
            >
                <p>Quality of Answers</p>
                <p>Problem-Solving Ability</p>
            </InterviewAssessRow>

            {/* Close of Interview */}
            <InterviewAssessRow 
                totalMark={closeOfInterviewMark}
                setTotalMark={setCloseOfInterviewMark}
                title={"Close of Interview"}
                isOpen={openRow === "Close of Interview"}
                onToggle={() => handleRowToggle("Close of Interview")}
            >
                <p>Closing Questions</p>
                <p>Follow-up Understanding</p>
            </InterviewAssessRow>

            {/* Fixed Total Score Footer */}
            <div className="fix bottom-0 left-0 w-full h-12 bg-[#E8EFF9] rounded-[5px] flex items-center justify-between px-3">
                <p className='text-[#292929] font-medium text-[14px]'>TOTAL SCORE EARNED</p>
                <button className='bg-[#1b5fc1] rounded-[4px] w-[43px] h-[25px] py-1 px-3 text-white font-medium text-[12px]'>
                    {totalScore}
                </button>
            </div>
        </div>
    );
}