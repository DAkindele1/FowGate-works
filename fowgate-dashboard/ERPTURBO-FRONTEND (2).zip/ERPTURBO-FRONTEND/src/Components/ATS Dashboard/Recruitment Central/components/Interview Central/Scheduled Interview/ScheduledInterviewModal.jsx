import React, { useState, useEffect } from 'react';
import Modal from '../../../../../../ui/Modal';
import SuccessModal from '../../../../../../ui/SuccessModal';
import FormBtns from '../../../../../../ui/FormBtns';
import Input from '../../../../../../ui/Input';
import Select from '../../../../../../ui/Select';
import { CaretDownIcon, CaretUpIcon } from '@phosphor-icons/react';
import { createScheduledInterview, editScheduledInterview } from '../services/api_interview_central';
import toast from 'react-hot-toast';

export default function ScheduledInterviewModal({
  showInterviewModal,
  showSuccessModal,
  showConfirmModal,
  setShowInterviewModal,
  setShowShortlistedCandidates,
  showShortlistedCandidates,
  candidatesData,
  toggleSelectAll,
  toggleCandidate,
  selectedCandidates,
  setShowConfirmModal,
  setShowSuccessModal,
  handleCloseModal,
  onInterviewCreated,
  setSelectedCandidates,
  editData,
  onClose,
}) {

  const MEETING_TYPE_VALUES = {
    "AI Assessment Interview": "ai_assessment",
    "Physical Interview": "physical", 
    "Virtual Interview": "virtual"
  };

  const isFormValid = () => {
    const { title, date, start_time, end_time, type } = formData;
    return (
      title?.trim() &&
      date &&
      start_time &&
      end_time &&
      type &&
      selectedCandidates.length > 0
    );
  };

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    baseurl: "",
    title: "",
    description: "",
    date: "",
    start_time: "",
    end_time: "",
    attendees: [],
    created_by: "",
    location: "",
    hiring_team: [{
      type: "department",
      value: ""
    }],
    type: "virtual",
    metadata: {},
    company_code: "COM_101",
    redirect_after_auth: window.location.href, // <-- set to current URL
    platform: "meet"
  });

  useEffect(() => {
    if (editData) {
      setFormData({
        ...editData,
        company_code: "COM_101",
        created_by: "current_user_id",
        redirect_after_auth: window.location.href, // <-- set to current URL
        platform: "meet"
      });
      setSelectedCandidates(editData.attendees.map(attendee => attendee.application_code));
    } else {
      setFormData({
        baseurl: "",
        title: "",
        description: "",
        date: "",
        start_time: "",
        end_time: "",
        attendees: [],
        created_by: "",
        location: "",
        hiring_team: [{
          type: "department",
          value: ""
        }],
        type: "virtual",
        metadata: {},
        company_code: "COM_101",
        redirect_after_auth: window.location.href, // <-- set to current URL
        platform: "meet"
      });
      setSelectedCandidates([]);
    }
  }, [editData]);

  const handleSubmit = async () => {
    // 1. Set loading state
    setIsSubmitting(true);
  
    try {
      // 2. Validate required fields
      if (!formData.title) throw new Error("Title is required");
      if (!formData.date) throw new Error("Date is required");
      if (!formData.start_time) throw new Error("Start time is required");
      if (!formData.end_time) throw new Error("End time is required");
      if (selectedCandidates.length === 0) throw new Error("At least one candidate is required");
  
      // 3. Prepare attendees array
      const preparedAttendees = selectedCandidates.map(candidateId => {
        // 3a. Try to find candidate in candidatesData
        const candidateFromData = candidatesData.find(c => c._id === candidateId);
        
        // 3b. For edit mode, try to find in existing attendees
        const candidateFromEdit = editData?.attendees?.find(a => 
          a.application_code === candidateId || a._id === candidateId
        );
        
        // 3c. Use found candidate or fallback to empty object
        const candidate = candidateFromData || candidateFromEdit || {
          firstname: "",
          lastname: "",
          _id: candidateId,
          email: ""
        };
  
        // 3d. Return properly formatted attendee
        return {
          firstname: candidate.firstname || "",
          lastname: candidate.lastname || "",
          application_code: candidate._id?.toString() || candidateId.toString(),
          email: candidate.email || 'no-email@example.com'
        };
      });
  
      // 4. Format date and times
      const formattedDate = new Date(formData.date).toISOString().split('T')[0];
      const formattedStartTime = convert12to24(formData.start_time);
      const formattedEndTime = convert12to24(formData.end_time);
  
      // 5. Handle Edit Mode
      if (editData) {
        // 5a. Prepare edit payload
        const editPayload = {
          company_code: "COM_101", // Required by API
          meeting_code: editData.meeting_code, // Required by API
          updates: {
            baseurl: formData.baseurl || "",
            title: formData.title,
            description: formData.description || "",
            date: formattedDate,
            start_time: formattedStartTime,
            end_time: formattedEndTime,
            attendees: preparedAttendees,
            created_by: formData.created_by || "current_user",
            location: formData.location || "",
            hiring_team: formData.hiring_team || [{ type: "department", value: "" }],
            type: formData.type || "virtual",
            metadata: formData.metadata || {},
            redirect_after_auth: formData.redirect_after_auth || "",
            platform: formData.platform || "meet"
          }
        };
  
        // 5b. Make API call
        await editScheduledInterview(editPayload);
        toast.success("Interview updated successfully");
      } 
      // 6. Handle Create Mode
      else {
        // 6a. Prepare create payload
        const createPayload = {
          baseurl: formData.baseurl || "",
          title: formData.title,
          description: formData.description || "",
          date: formattedDate,
          start_time: formattedStartTime,
          end_time: formattedEndTime,
          attendees: preparedAttendees,
          created_by: formData.created_by || "current_user",
          location: formData.location || "",
          hiring_team: formData.hiring_team || [{ type: "department", value: "" }],
          type: formData.type || "virtual",
          metadata: formData.metadata || {},
          redirect_after_auth: formData.redirect_after_auth || "",
          platform: formData.platform || "meet",
          company_code: "COM_101" // Added for consistency
        };
  
        // 6b. Make API call
        await createScheduledInterview(createPayload);
        toast.success("Interview scheduled successfully");
      }
  
      // 7. Handle success
      setShowConfirmModal(false);
      setShowSuccessModal(true);
      if (onInterviewCreated) onInterviewCreated();
  
    } catch (error) {
      // 8. Handle errors
      console.error("Interview save error:", error);
      toast.error(error.message || "Failed to save interview");
    } finally {
      // 9. Reset loading state
      setIsSubmitting(false);
    }
  };
  
  // Initialize form when editData changes
  useEffect(() => {
    if (editData) {
      // 1. Set form data from editData
      setFormData({
        baseurl: editData.baseurl || "",
        title: editData.title || "",
        description: editData.description || "",
        date: editData.date || "",
        start_time: editData.start_time || "",
        end_time: editData.end_time || "",
        created_by: editData.created_by || "current_user",
        location: editData.location || "",
        hiring_team: editData.hiring_team || [{ type: "department", value: "" }],
        type: editData.type || "virtual",
        metadata: editData.metadata || {},
        redirect_after_auth: editData.redirect_after_auth || "",
        platform: editData.platform || "meet",
        company_code: "COM_101"
      });
  
      // 2. Set selected candidates from attendees
      if (editData.attendees && editData.attendees.length > 0) {
        const candidateIds = editData.attendees.map(attendee => 
          attendee.application_code || attendee._id
        ).filter(id => id); // Filter out any undefined/null values
        
        setSelectedCandidates(candidateIds);
      } else {
        setSelectedCandidates([]);
      }
    } else {
      // 3. Reset form for new interview
      setFormData({
        baseurl: "",
        title: "",
        description: "",
        date: "",
        start_time: "",
        end_time: "",
        created_by: "current_user",
        location: "",
        hiring_team: [{ type: "department", value: "" }],
        type: "virtual",
        metadata: {},
        redirect_after_auth: "",
        platform: "meet",
        company_code: "COM_101"
      });
      setSelectedCandidates([]);
    }
  }, [editData]);

  function convert12to24(time12h) {
    const date = new Date(`2000-01-01 ${time12h}`);
    return date.toTimeString().slice(0, 8);
  }

  function convert24to12(time24h) {
    if (!time24h) return '12:00 AM';
    const [hours, minutes] = time24h.split(':');
    const hourNum = parseInt(hours, 10);
    
    if (hourNum === 0) return `12:${minutes} AM`;
    if (hourNum < 12) return `${hourNum}:${minutes} AM`;
    if (hourNum === 12) return `12:${minutes} PM`;
    return `${hourNum - 12}:${minutes} PM`;
  }

  useEffect(() => {
    if (!showInterviewModal) {
      if (!editData) {
        setFormData({
          baseurl: "",
          title: "",
          description: "",
          date: "",
          start_time: "",
          end_time: "",
          created_by: "current_user",
          location: "",
          hiring_team: [{ type: "department", value: "" }],
          type: "virtual",
          metadata: {},
          redirect_after_auth: window.location.href, // <-- set to current URL
          platform: "meet",
          company_code: "COM_101"
        });
        setSelectedCandidates([]);
      }
      setShowShortlistedCandidates(false);
      setShowConfirmModal(false);
      setShowSuccessModal(false);
      onClose?.();
    }
  }, [showInterviewModal]);

  const modalTitle = editData ? "Edit Interview" : "Schedule Interview";

  return (
    <div>
      {showInterviewModal && (
        <div className="border">
          {!showSuccessModal ? (
            <Modal 
              contW={"w-[528px]"} 
              headerIcon={showConfirmModal ? "confirm" : "calendar"} 
              headTitle={showConfirmModal ? "Confirm Changes" : modalTitle} 
              contH={"max-h-[744px]"} 
              closeModal={() => setShowInterviewModal(false)}
            >
              <div className='p-6'>
                {showConfirmModal ? (
                  <div>
                    <p className='font-light text-[16px] mb-4'>
                      Are you sure you want to proceed with this interview schedule? You can make changes later if needed.
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-4 max-h-[400px] overflow-y-scroll">
                    <Input 
                      label={"Meeting Title"} 
                      placeholder={"Enter Title"} 
                      overview={true} 
                      value={formData.title} 
                      handleChange={(val) => setFormData({ ...formData, title: val })} 
                    />
                    
                    <Input 
                      label={"Date"} 
                      inputType={"date"} 
                      placeholder={"Select"} 
                      overview={true} 
                      value={formData.date} 
                      handleChange={(val) => setFormData({...formData, date: val})} 
                    />

                    <div className="flex items-center justify-between h-[50px]">
                      <p className='text-[16px]'>Select Time</p>
                      <div className="h-8 flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          <p className="font-light text-[14px]">From</p>
                          <div className='px-2 py-1.5 flex items-center gap-2 rounded-[4px] border border-gray-300'>
                            <select 
                              className='focus:outline-none' 
                              value={convert24to12(formData.start_time)} 
                              onChange={(e) => setFormData({...formData, start_time: convert12to24(e.target.value)})}
                            >
                              {Array.from({ length: 24 }).map((_,i) => (
                                <option key={i} className='h-10 w-[100px] flex focus:outline-none items-center justify-center font-[14px]'>
                                  {i<12 ? `${i + 1}`: i===23 ? "00" : `${i-11}`}:00 {i<11 || i === 23 ? "AM" : "PM"}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <p className="font-light text-[14px]">To</p>
                          <div className='px-2 py-1.5 flex items-center gap-2 rounded-[4px] border border-gray-300'>
                            <select 
                              className='focus:outline-none' 
                              value={convert24to12(formData.end_time)} 
                              onChange={(e) => setFormData({...formData, end_time: convert12to24(e.target.value)})}
                            >
                              {Array.from({ length: 24 }).map((_,i) => (
                                <option key={i} className='h-10 w-[100px] flex items-center justify-center font-[14px] focus:outline-none'>
                                  {i<12 ? `${i + 1}`: i===23 ? "00" : `${i-11}`}:00 {i<11 || i === 23 ? "AM" : "PM"}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Select
                      label={"Meeting Option"}
                      optionsArr={Object.keys(MEETING_TYPE_VALUES)}
                      value={Object.keys(MEETING_TYPE_VALUES).find(
                        key => MEETING_TYPE_VALUES[key] === formData.type
                      )}
                      handleChange={(val) => setFormData({
                        ...formData, 
                        type: MEETING_TYPE_VALUES[val]
                      })}
                    />
                    
                    <div>
                      <label className='mb-2 text-[14px]'>Select Candidates</label>
                      <div 
                        className="min-h-[50px] py-0.5 px-3 w-full border border-gray-300 rounded-sm flex items-center justify-between mb-3 cursor-pointer" 
                        onClick={()=>setShowShortlistedCandidates((c)=> !c)}
                      >
                        <div className="font-light text-[16px] text-[#9D9D9D] w-full h-full flex items-center">
                          {selectedCandidates.length > 0 ? (
                            <div className="flex flex-wrap gap-1 overflow-hidden">
                              {selectedCandidates.slice(0, 3).map(candidateId => {
                                const candidate = candidatesData.find(c => c._id === candidateId);
                                return (
                                  <span key={candidateId} className="bg-blue-100 text-[#1B5FC1] text-[16px] px-2 py-1 rounded">
                                    {candidate?.firstname} {candidate?.lastname}
                                  </span>
                                );
                              })}
                              {selectedCandidates.length > 3 && (
                                <span className="bg-blue-100 text-[#1B5FC1] text-[16px] px-2 py-1 rounded">
                                  +{selectedCandidates.length - 3} more
                                </span>
                              )}
                            </div>
                          ) : (
                            "Select"
                          )}
                        </div>
                        {showShortlistedCandidates ? <CaretUpIcon /> : <CaretDownIcon />}
                      </div>
                      {showShortlistedCandidates && (
                        <div className="p-4 flex flex-col gap-2 rounded-[6px] shadow-lg transition ease-in-out duration-1000">
                          <div className='flex items-center justify-between'>
                            <p className='text-[#111111]'>
                              SHORTLISTED CANDIDATES
                              <span className='text-[#707070]'> ({candidatesData.length})</span>
                            </p>
                            <p 
                              className='text-[#1B5FC1] cursor-pointer' 
                              onClick={toggleSelectAll}
                            >
                              {selectedCandidates.length === candidatesData.length
                                ? 'Deselect All'
                                : 'Select All'}
                            </p>
                          </div>
                          <div>
                            {candidatesData.map((candidate, i) => (
                              <div className="flex py-2.5 items-center gap-2" key={i}>
                                <input 
                                  type="checkbox"
                                  checked={selectedCandidates.includes(candidate._id)}
                                  onChange={() => toggleCandidate(candidate._id)} 
                                  className='w-[18px] h-[18px] border border-gray-300 rounded-[2px]'
                                />
                                <p>{candidate.firstname} {candidate.lastname}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              <FormBtns 
                firstBtnText={"Cancel"} 
                mode='schedule' 
                secondBtnText={
                  showConfirmModal 
                    ? isSubmitting ? "Submitting..." : "Yes, I'm sure" 
                    : editData ? "Update Interview" : "Schedule Interview"
                } 
                closeModal={() => setShowInterviewModal(false)} 
                nextStep={
                  showConfirmModal 
                    ? handleSubmit 
                    : () => setShowConfirmModal(true)
                }
                disabled={!showConfirmModal && !isFormValid()}
              />
            </Modal>
          ) : (
            <Modal contW={"w-[472px]"}>
              <SuccessModal 
                closeModal={handleCloseModal} 
                mainText={editData ? "Interview Updated!" : "Interview Scheduled!"} 
                subText={editData ? "Your interview has been updated successfully" : "Your interview has been added. You can review or edit it anytime"} 
              />
            </Modal>
          )}
        </div>
      )}
    </div>
  );
}