import React from 'react'
import HiredTable from './HiredTable'
import EmptyList from '../../../../../ui/EmptyTable'

export default function Hired({candidatesData}) {
  return (
    <div className='p-4'>
       <div className="w-full  ">
          {/* Table Headers */}    
                <div className="grid grid-cols-[1.5fr_1.2fr_.5fr_.6fr_1.4fr_1fr_0.4fr] gap-8 p-3 bg-[#E8EFF9] text-[14px] font-medium text-[#292929] rounded-tr-lg rounded-tl-lg">
                  <div>Candidate</div>
                  <div >Role Applied For</div>
                  <div>Availability</div>
                  <div >Job Type</div>
                  <div className='text-center' >Interview Score</div>
                  <div className='text-center' >Offer status</div>
                  <div>Action</div>
                </div>
            {/* Table Body */}
              <div >
              {
                
                  candidatesData.length <= 0 ? <EmptyList><div>
                  <p className='font-bold text-black'>No candidate in the hired list</p>
            </div></EmptyList> : <HiredTable candidates={candidatesData}
              // setIsEdit={setOpenEditJob} setSelectedJob={setSelectedJob}
            />}
              
              </div> 
            </div>
    </div>
  )
}
