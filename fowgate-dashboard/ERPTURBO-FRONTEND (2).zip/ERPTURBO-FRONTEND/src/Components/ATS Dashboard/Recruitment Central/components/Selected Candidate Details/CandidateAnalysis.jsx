import React from 'react'

export default function CandidateAnalysis() {
  return (
    <div>CandidateAnalysis</div>
  )
}
