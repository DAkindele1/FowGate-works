import { StarIcon } from '@phosphor-icons/react'
import React from 'react'
import { markFavourite, talentPool } from '../../services/api_recruitment_central';
import toast from 'react-hot-toast';

export default function SelectedCandidateAction({ candidateData, setShowActionMenu, onFavoriteToggle, onTalentToggle }) {


  
  const handleFavourite = async (applicationCode, check) => {
    const mode = check ? "unmark" : "mark"
    
    try {
      const result = await markFavourite(applicationCode, mode);
      toast.success(`Candidate ${mode === "mark" ? "added to" : "removed from"} favorites`);
      onFavoriteToggle(applicationCode, check); 
    } catch (err) {
      toast.error(err.message);
    } finally {
      setShowActionMenu(false);
    }
  };
  const handleTalentPool = async (applicationCode, check) => {
    const mode = check ? "remove_from" : "add_to"
    
    try {
      const result = await talentPool(applicationCode, mode);
      toast.success(`Candidate ${mode === "add_to" ? "added to" : "removed from"} talent pool`);
      onTalentToggle(applicationCode, check); 
    } catch (err) {
      toast.error(err.message);
    } finally {
      setShowActionMenu(false);
    }
  };



    

    
  return (
    <div className="absolute right-0 top-full mt-1 w-fit h-[136px] bg-white rounded-[5px] shadow-md  z-10 border border-gray-200 px-[8px]">
              <div className="  h-full flex flex-col items-center justify-center gap-1.5">
                <button className="flex items-center p-2 gap-2 rounded-[8px] text-[14px] truncate text-[#292929] hover:border-gray-100 cursor-pointer h-[36px] w-[164px] hover:border" onClick={()=>handleFavourite(candidateData.application_code, candidateData.is_favorite)}>
                  <StarIcon 
                      className=' h-[18px] w-[18px]'
                    color={candidateData.is_favorite ? "#EB8A00" : undefined}
                    weight={candidateData.is_favorite ? "fill" : "light"}
                  />
                  {candidateData.is_favorite ? "Unmark" : "Mark"} As Favorite
                </button>
                <button className="flex items-center h-[36px] w-[164px] p-2 gap-2 rounded-[8px] text-[14px] text-gray-700 hover:border-gray-100 cursor-pointer  hover:border" onClick={()=>handleTalentPool(candidateData.application_code, candidateData.talent_pool)}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-[18px] w-[18px]  text-gray-500"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
          </svg>
          <span className='truncate'>{`${candidateData.talent_pool ? "Remove From" : "Add To"} Talent Pool`}</span>
                  
                </button>
                <button className="flex items-center h-[36px] w-[164px] p-2 gap-2 rounded-[8px] text-[14px] text-red-600 hover:border-gray-100 cursor-pointer hover:border">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-[18px] w-[18px]  text-red-500"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                  Delete Candidate
                </button>
              </div>
            </div>
  )
}
