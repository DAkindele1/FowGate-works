import React, { useState } from "react";
import {
  Search,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  Filter,
  Calendar,
} from "lucide-react";

// import atsSearch from "../../../assets/img/ats-search.png";

const hiredCandidates = [
  {
    id: 1,
    name: "Lisa Carter",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Software Engineer",
    availability: "Contract",
    jobType: "Remote",
    interviewScore: { percentage: 65, rating: "Good" },
    offerStatus: "Offered",
  },
  {
    id: 2,
    name: "Maya Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "HR Specialist",
    availability: "Full-Time",
    jobType: "Onsite",
    interviewScore: { percentage: 76, rating: "Excellent" },
    offerStatus: "Hired",
  },
  {
    id: 3,
    name: "Viola Kove",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "UI/UX Designer",
    availability: "Contract",
    jobType: "Remote",
    interviewScore: { percentage: 58, rating: "Good" },
    offerStatus: "Offer Accepted",
  },
  {
    id: 4,
    name: "Myomming Cho",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Project Manager",
    availability: "Contract",
    jobType: "Remote",
    interviewScore: { percentage: 70, rating: "Excellent" },
    offerStatus: "Hired",
  },
  {
    id: 5,
    name: "Arjun Sharma",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Frontend Developer",
    availability: "Contract",
    jobType: "Remote",
    interviewScore: { percentage: 75, rating: "Excellent" },
    offerStatus: "Hired",
  },
  {
    id: 6,
    name: "Emily Davis",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Software Engineer",
    availability: "Full-Time",
    jobType: "Onsite",
    interviewScore: { percentage: 65, rating: "Good" },
    offerStatus: "Offered",
  },
  {
    id: 7,
    name: "Olivia Taylor",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Senior NET Developer",
    availability: "Full-Time",
    jobType: "Hybrid",
    interviewScore: { percentage: 55, rating: "Good" },
    offerStatus: "Hired",
  },
  {
    id: 8,
    name: "William White",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Creative Director",
    availability: "Full-Time",
    jobType: "Hybrid",
    interviewScore: { percentage: 49, rating: "Low" },
    offerStatus: "Screen",
  },
  {
    id: 9,
    name: "William White",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Creative Director",
    availability: "Part-Time",
    jobType: "Onsite",
    interviewScore: { percentage: 40, rating: "Low" },
    offerStatus: "Screen",
  },
];

const HiredTab = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const totalItems = 500;

  const getScoreColor = (percentage) => {
    if (percentage >= 70) return "text-green-600";
    if (percentage >= 50) return "text-blue-600";
    return "text-red-600";
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Hired":
        return "bg-green-100 text-green-800";
      case "Offered":
      case "Offer Accepted":
        return "bg-blue-100 text-blue-800";
      case "Screen":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="w-full">
      <div className="flex flex-col">
       

        {/* Table */}
        <div className="mt-2">
          {/* Table Header */}
          <div className="grid grid-cols-[1fr_1fr_0.6fr_0.6fr_1fr_0.8fr_0.3fr] gap-2 px-4 py-2 bg-[#E8EFF9] text-[14px] font-medium text-[#292929] rounded-tr-lg rounded-tl-lg mx-6"
          >
            <div>Candidate</div>
            <div>Role Applied For</div>
            <div>Availability</div>
            <div>Job Type</div>
            <div>Interview Score</div>
            <div>Offer Status</div>
            <div>Action</div>
          </div>

          {/* Table Body */}
          <div className="mx-6">
            {hiredCandidates.map((candidate, index) => (
              <div
                key={candidate.id}
                className={`grid grid-cols-[1fr_1fr_0.6fr_0.6fr_1fr_0.8fr_0.3fr] gap-2 px-4 py-2 text-sm bg-white
                }`}
              >
                {/* Candidate */}
                <div className="flex items-center gap-2">
                  <img
                    src={candidate.avatar || "/placeholder.svg"}
                    alt={candidate.name}
                    className="w-8 h-8 rounded-full"
                  />
                  <span>{candidate.name}</span>
                </div>

                {/* Role */}
                <div>{candidate.role}</div>

                {/* Availability */}
                <div>{candidate.availability}</div>

                {/* Job Type */}
                <div>{candidate.jobType}</div>

                {/* Interview Score */}
                <div className="flex items-center gap-1">
                  <span
                    className={`${getScoreColor(
                      candidate.interviewScore.percentage
                    )}`}
                  >
                    {candidate.interviewScore.percentage}%
                  </span>
                  <span className="text-gray-600">
                    {candidate.interviewScore.rating}
                  </span>
                </div>

                {/* Offer Status */}
                <div>
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${getStatusColor(
                      candidate.offerStatus
                    )}`}
                  >
                    {candidate.offerStatus}
                  </span>
                </div>

                {/* Action */}
                <div>
                  <button className="p-1 rounded hover:bg-gray-100">
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pagination */}
        <div className="flex justify-center items-center gap-2 py-4">
          <button className="p-1 rounded hover:bg-gray-100">
            <ChevronLeft className="h-4 w-4" />
          </button>

          <button className="w-8 h-8 flex items-center justify-center rounded bg-blue-600 text-white">
            1
          </button>

          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100">
            2
          </button>

          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100">
            3
          </button>

          <span className="px-2">...</span>

          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100">
            12
          </button>

          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100">
            13
          </button>

          <button className="p-1 rounded hover:bg-gray-100">
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default HiredTab;
