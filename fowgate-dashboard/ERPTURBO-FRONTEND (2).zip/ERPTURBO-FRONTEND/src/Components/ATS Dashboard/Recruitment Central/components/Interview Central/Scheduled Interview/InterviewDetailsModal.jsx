import { PencilSimpleIcon, PlusIcon, TrashIcon, XIcon } from '@phosphor-icons/react'
import React from 'react'
import DisplayName from '../../../../Job Board/services/DisplayName'
import FormBtms from '../../../../../../ui/FormBtns'
import moment from 'moment/moment';
// import { deleteAnInterview } from '../services/api_interview_central';
import toast from 'react-hot-toast';
import { useState } from 'react';
import Modal from '../../../../../../ui/Modal';

export default function InterviewDetailsModal({ 
  showInterviewDetailsModal, 
  setShowInterviewDetailsModal, 
  selectedInterview,
  setShowInterviewModal,
  setEditInterviewData, onInterviewDeleted
}) {

  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const formatTime = (timeStr) => {
    return moment(timeStr, "HH:mm:ss").format("h:mm A")
  }

  const handleDelete = async (meeting_code) => {
    try {
      // Call parent component to handle deletion first
      if (onInterviewDeleted) {
        await onInterviewDeleted(meeting_code); // Wait for completion
      }
      
      // Then close the modal
      setShowInterviewDetailsModal(false);
      
      toast.success("Interview deleted successfully");
    } catch (error) {
      toast.error("Failed to delete interview");
      console.error("Delete error:", error);
    } finally {
      setShowConfirmModal(false)
    }
  };

  const handleEdit = (interview) => {
    const editData = {
      title: interview.title,
      description: interview.description,
      date: interview.date,
      start_time: interview.start_time,
      end_time: interview.end_time,
      type: interview.type,
      location: interview.location,
      hiring_team: interview.metadata.hiring_team,
      metadata: interview.metadata,
      meeting_code: interview.meeting_code,
      attendees: interview.attendees.map(attendee => ({
        _id: attendee.application_code,
        firstname: attendee.firstname,
        lastname: attendee.lastname,
        email: attendee.email
      }))
    };
    
    setEditInterviewData(editData);
    setShowInterviewModal(true);
    setShowInterviewDetailsModal(false);
  };

  const handleMeetingLink = (meetingLink) => {
    window.open(meetingLink, "_blank");
  };

  return (
    <div>{
      showInterviewDetailsModal && (
        <div
          className="fixed inset-0 z-[9999999999999] flex items-center justify-end bg-gray-100/50 rounded-[4px]"
          onClick={e => {
            // Only close if the overlay itself is clicked, not a child
            if (e.target === e.currentTarget) {
              setShowInterviewDetailsModal(false);
            }
          }}
        >
          <div className='bg-white h-screen w-[608px] flex flex-col'>
            <div className="border-b border-b-gray-300 h-[78px] flex items-center justify-center w-full">
              <div className="flex items-center justify-between h-[34px] w-[560px]">
                <h1 className="text-[24px] font-medium text-[#292929]">{selectedInterview.title || ""}</h1>
                <div className="w-22 flex items-center justify-between h-full">
                  <div 
                    className="border w-[34px] rounded-[4px] h-full border-gray-300 flex hover:scale-110 transition duration-500 cursor-pointer items-center justify-center text-[#292929]" 
                    onClick={() => handleEdit(selectedInterview)}
                  >
                    <PencilSimpleIcon size={20}/>
                  </div>
                  <div 
                    className="border w-[34px] rounded-[4px] h-full border-gray-300 flex hover:scale-110 transition duration-500 cursor-pointer items-center justify-center text-[#EB4335]" 
                    onClick={() => setShowConfirmModal(true)}
                  >
                    <TrashIcon size={20}/>
                  </div>
                </div>
              </div>
            </div>

            <div className="m-6 flex flex-col gap-5 flex-1 overflow-y-auto">
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between h-[33px]">
                  <p className='text-[18px] text-[#292929]'>Assignee</p>
                  <div className='w-fit flex items-center justify-between'>
                    {selectedInterview.metadata.hiring_team.length > 1 && 
                      selectedInterview.metadata.hiring_team.slice(0, 7).map((el, i) => (
                        <div 
                          key={i} 
                          className={`${el.length !== 1 && "text-[#1b5fc1] font-medium rounded-full h-[32px] w-[32px] flex items-center justify-center bg-white p-[.5px]"} ${i !== 0 && "-ml-1"}`}
                        >
                          <div className={el.length !== 1 && "rounded-full bg-[#E8EFF9] flex items-center justify-center"}>
                            <DisplayName name={`${el.value || "No Hiring"}`} fontSize={'text-[13px]'} />
                          </div>
                        </div>
                      ))
                    }
                    
                    {selectedInterview.metadata.hiring_team.length === 1 && (
                      <div className="flex items-center gap-2">
                        <div className="font-medium h-[32px] w-[32px] rounded-full flex items-center justify-center bg-[#E8EFF9] text-[#1b5fc1]">
                          <DisplayName name={`${selectedInterview.metadata.hiring_team[0].value || "No Hiring"}`} fontSize={'text-[13px]'}/>
                        </div>
                        <p>{selectedInterview.metadata.hiring_team[0].value || "No Hiring Team"}</p>
                      </div>
                    )}
                    
                    {selectedInterview.metadata.hiring_team.length > 7 && (
                      <span className="text-[8px] -ml-1 [18px] h-[18px] rounded-full p-1 flex items-center justify-center bg-[#E8EFF9] text-[#1b5fc1]">
                        +{selectedInterview.metadata.hiring_team.length - 7}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between h-[41px]">
                  <p>Meeting Date</p>
                  <div className='w-fit px-4 py-2 rounded-full h-full text-[#EB8A00] bg-[#FFF1DD]'>
                    {moment(selectedInterview.date).format("D MMMM, YYYY")}
                  </div>
                </div>

                <div className="flex items-center justify-between h-[41px]">
                  <p>Meeting Time</p>
                  <div className='w-fit px-4 py-2 rounded-full h-full text-[#292929] bg-[#F7F7F7]'>
                    {formatTime(selectedInterview.start_time)} - {formatTime(selectedInterview.end_time)}
                  </div>
                </div>
                
                <div className="flex items-center justify-between h-[41px]">
                  <p>Meeting Type</p>
                  <div className='w-fit capitalize px-4 py-2 rounded-full h-full text-[#1B5FC1] bg-[#E8EFF9]'>
                    {selectedInterview.type}
                  </div>
                </div>
              </div>

              <div className="border-b h-[.5px] border-b-gray-300"></div>

              {selectedInterview.type !== "physical" && (
                <div className="h-[54px] flex items-center justify-between">
                  <div className='flex flex-col gap-[3px] h-full'>
                    <h1 className='font-medium text-[20px]'>Interview Link</h1>
                    {selectedInterview.metadata.platform === "google_meet" && (
                      <p className='h-[22px] text-[16px] text-[#707070]'>
                        {selectedInterview.metadata.google_hangout_link?.replace(/^https?:\/\//, "") || ""}
                      </p>
                    )}
                  </div>

                  {selectedInterview.metadata.platform === "google_meet" && (
                    <div 
                      className="h-11 rounded-[4px] py-2.5 px-2 w-[191px] bg-[#1B5FC1] flex items-center gap-1.5 hover:bg-[#1A4FAF] hover:shadow-md transition-all duration-200" 
                      onClick={() => handleMeetingLink(selectedInterview.metadata.google_hangout_link)}
                    >
                      <div>
                        <img src='/assets/img/google-meet.png' className='w-6 h-6'/>
                      </div> 
                      <p className="text-white text-[14px] cursor-pointer">Join with Google Meet</p>
                    </div>
                  )}
                </div>
              )}

              <div className="h-[162px] flex flex-col gap-2">
                <p className='text-[14px]'>Description</p>
                <div className='h-[134px] p-3 border border-gray-300 rounded-[6px]'>
                  <textarea 
                    className='focus:outline-none w-full h-full text-[#9D9D9D] font-light text-[16px]'
                    value={selectedInterview.description || ""}
                    readOnly
                  />
                </div>
              </div>

              <div className='border border-gray-300 rounded-[6px]'>
                <div className="h-[52px] flex items-center justify-between p-3 rounded-[6px] bg-[#F8F8F8]">
                  <p className="font-medium text-[20px] text-[#292929]">
                    Candidates <span className='font-normal text-[#707070]'>({selectedInterview.attendees.length})</span>
                  </p>
                  <div className="h-[22px] w-[90px] flex items-center justify-between gap-1.5 text-[#1B5FC1]">
                    <PlusIcon size={20}/>
                    <span className='font-medium text-[14px]'>Add More</span>
                  </div>
                </div>

                <div className='mx-3 mb-3'>
                  {selectedInterview.attendees.map((attendee, index) => (
                    <div
                      key={index}
                      className={`h-[56px] flex items-center justify-between py-3 ${
                        index !== selectedInterview.attendees.length - 1 ? 'border-b border-b-gray-300' : ''
                      }`}
                    >
                      <div className='flex h-[32px] items-center gap-1.5'>
                        <div className="font-medium h-[32px] w-[32px] rounded-full flex items-center justify-center bg-[#E8EFF9] text-[#1b5fc1]">
                          <DisplayName fontSize={'text-[12px]'} name={`${attendee.firstname} ${attendee.lastname}`}/>
                        </div>
                        <div>{`${attendee.firstname} ${attendee.lastname}`}</div>
                      </div>
                      <div className='text-[#EB4335] cursor-pointer'>
                        <XIcon size={20}/>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-2">
              <FormBtns 
                firstBtnText={"Close"} 
                secondBtnText={"Save Changes"}
                closeModal={() => setShowInterviewDetailsModal(false)}
              />
            </div>
          </div>
        </div>
      )}
      {showConfirmModal && <Modal contW={"w-[450px]"} headerIcon={"trash"} closeModal={()=> setShowConfirmModal(false)} headTitle={"Delete Job"} headBgColor={"bg-[#eb4335]"} contH={"h-[230px]"}><p className="border-b border-gray-200 py-[20px] px-[24px] text-[16px] font-light">Are you sure you want to delete this Interview <span className="font-normal">"{selectedInterview.title}"</span> ? This action cannot be undone. </p>
            <div className="flex py-2 px-3 gap-6 border-t border-gray-300 justify-end"><button onClick={()=>handleDelete(selectedInterview.meeting_code)} className='text-[#292929]  py-2 px-10 block rounded-sm cursor-pointer hover:border hover:border-gray-200'>Yes, I'm sure</button>
                    <button className='text-center py-2 px-5 text-[#EB4335] bg-[#FDECEB] rounded-sm block transition cursor-pointer hover:text-[#FDECEB] hover:bg-[#EB4335]' onClick={()=> setShowConfirmModal(false)}>Cancel</button>
                    
                    </div>
            </Modal>}
    </div>
  );
}