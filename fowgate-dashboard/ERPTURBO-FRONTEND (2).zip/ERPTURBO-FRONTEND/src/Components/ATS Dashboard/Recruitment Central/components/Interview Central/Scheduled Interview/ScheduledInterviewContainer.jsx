import React, { useEffect, useState } from 'react';
import "react-datepicker/dist/react-datepicker.css";
import { BellIcon, CaretLeftIcon, CaretRightIcon, CaretDownIcon, MagnifyingGlassIcon } from '@phosphor-icons/react';
import ScheduledInterviewModal from './ScheduledInterviewModal';
import InterviewDetailsModal from './InterviewDetailsModal';
import DayCalendar from './DayCalendar';
import MonthCalendar from './MonthCalendar';
import WeekCalendar from './WeekCalendar';
import { getAllInterviews } from '../services/api_interview_central';
import { fetchAllCandidates } from '../../../services/api_recruitment_central';

export default function ScheduledInterviewContainer({ setScheduledInterviews }) {
  // Modal visibility states
  const [showInterviewModal, setShowInterviewModal] = useState(false);
  const [showInterviewDetailsModal, setShowInterviewDetailsModal] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showShortlistedCandidates, setShowShortlistedCandidates] = useState(false);

  // Interview data states
  const [interviews, setInterviews] = useState([]);
  const [interviewType, setInterviewType] = useState([]);
  const [selectedInterview, setSelectedInterview] = useState(null);
  const [selectedDayMeeting, setSelectedDayMeeting] = useState([]);
  const [totalMeeting, setTotalMeetings] = useState(0);
  const [editData, setEditData] = useState(null);

  // Candidate selection states
  const [selectedCandidates, setSelectedCandidates] = useState([]);
  const [shortlistedCandidates, setShortlistedCandidates] = useState([]);

  // Calendar navigation states
  const [interviewYear, setInterviewYear] = useState(new Date().getFullYear());
  const [interviewMonth, setInterviewMonth] = useState(new Date().getMonth() + 1);
  const [interviewDay, setInterviewDay] = useState(new Date().getDate());
  const [filterBy, setFilterBy] = useState("month");

  // Refresh trigger
  const [refreshFlag, setRefreshFlag] = useState(false);

  // Month names for display
  const months = ["Jan.", "Feb.", "Mar.", "Apr.", "May", "Jun.", "Jul.", "Aug.", "Sep.", "Oct.", "Nov.", "Dec."];

  // Fetch all interviews when month or refreshFlag changes
  useEffect(() => {
    const fetchInterviews = async () => {
      try {
        const data = await getAllInterviews(interviewMonth);
        setInterviews(data.meetings);
        setTotalMeetings(data.meetings.length);
      } catch (error) {
        console.error("Error fetching interviews:", error);
      }
    };
    fetchInterviews();
  }, [interviewMonth, refreshFlag]);

  // Fetch shortlisted candidates on component mount
  useEffect(() => {
    const getAllCandidates = async () => {
      try {
        const data = await fetchAllCandidates();
        setShortlistedCandidates(data.applications.filter(app => app.is_shortlisted && !app.talent_pool));
      } catch (error) {
        console.error("Error fetching candidates:", error);
      }
    };
    getAllCandidates();
  }, []);

  // Handler for when an interview is successfully created
  const handleInterviewCreated = () => {
    setRefreshFlag(prev => !prev);
    setShowInterviewModal(false);
    setShowSuccessModal(true);
  };

  // Handler for when an interview is deleted
  const handleInterviewDeleted = async (deletedMeetingCode) => {
    // Optimistic UI updates
    const updatedInterviews = interviews.filter(m => m.meeting_code !== deletedMeetingCode);
    setInterviews(updatedInterviews);
    setTotalMeetings(updatedInterviews.length);
    
    // Update day meetings if in day view
    if (filterBy === "day") {
      const updatedDayMeetings = selectedDayMeeting.filter(m => m.meeting_code !== deletedMeetingCode);
      setSelectedDayMeeting(updatedDayMeetings);
    }
    
    // Close the details modal
    setShowInterviewDetailsModal(false);
    
    // Trigger data refresh from server
    setRefreshFlag(prev => !prev);
  };

  // Toggle selection of individual candidates
  const toggleCandidate = (candidateId) => {
    setSelectedCandidates((prev) =>
      prev.includes(candidateId)
        ? prev.filter((id) => id !== candidateId)
        : [...prev, candidateId]
    );
  };

  // Toggle selection of all candidates
  const toggleSelectAll = () => {
    setSelectedCandidates(prev =>
      prev.length === shortlistedCandidates.length
        ? []
        : shortlistedCandidates.map(candidate => candidate._id)
    );
  };

  // Change calendar filter view
  const handleFilter = (e) => {
    setFilterBy(e.target.value);
    setInterviewDay(1);
  };

  // Set interview type
  const handleInterviewType = (e) => {
    setInterviewType(e);
  };

  // Open interview scheduling modal
  const handleOpenModal = () => {
    setShowInterviewModal(true);
    setShowConfirmModal(false);
    setShowSuccessModal(false);
  };

  // Close interview scheduling modal
  const handleCloseModal = () => {
    setShowInterviewModal(false);
    setSelectedCandidates([]);
    setEditData(null);
  };

  // Open interview details modal
  const handleInterviewDetailsModal = (details) => {
    setShowInterviewDetailsModal(true);
    setSelectedInterview(details);
  };

  // Navigate to previous time period
  const handlePrev = async () => {
    if (filterBy === "day") {
      const prevDay = interviewDay;
      const prevMonth = interviewMonth;
      
      if (prevDay === 1 && [5, 7, 10, 12].includes(prevMonth)) {
        setInterviewMonth(prev => prev - 1);
        setInterviewDay(30);
      } else if (prevDay === 1 && prevMonth === 1) {
        setInterviewYear(prev => prev - 1);
        setInterviewMonth(12);
        setInterviewDay(31);
      } else if (prevDay === 1) {
        setInterviewMonth(prev => prev - 1);
        setInterviewDay(31);
      } else {
        setInterviewDay(prev => prev - 1);
      }

      try {
        const newDay = prevDay === 1 ? 
          (prevMonth === 1 ? 31 : [5, 7, 10, 12].includes(prevMonth) ? 30 : 31) : 
          prevDay - 1;
        const newMonth = prevDay === 1 ? 
          (prevMonth === 1 ? 12 : prevMonth - 1) : 
          prevMonth;
        
        const data = await getAllInterviews(newMonth, newDay);
        setSelectedDayMeeting(data.meetings);
        setTotalMeetings(data.meetings.length);
      } catch (error) {
        console.error("Error fetching interviews:", error);
      }
    }
    
    if (filterBy === "month") {
      const prevMonth = interviewMonth;
      setInterviewMonth(prev => (prev === 1 ? 12 : prev - 1));
      if (prevMonth === 1) {
        setInterviewYear(prev => prev - 1);
      }

      try {
        const newMonth = prevMonth === 12 ? 1 : prevMonth - 1;
        const data = await getAllInterviews(newMonth);
        setInterviews(data.meetings);
        setTotalMeetings(data.meetings.length);
      } catch (error) {
        console.error("Error fetching interviews:", error);
      }
    }
  };

  // Navigate to next time period
  const handleNext = async () => {
    if (filterBy === "day") {
      const prevDay = interviewDay;
      const prevMonth = interviewMonth;
      
      if (prevDay === 30 && [4, 6, 9, 11].includes(prevMonth)) {
        setInterviewMonth(prev => prev + 1);
        setInterviewDay(1);
      } else if (prevDay === 31 && prevMonth === 12) {
        setInterviewYear(prev => prev + 1);
        setInterviewMonth(1);
        setInterviewDay(1);
      } else if (prevDay === 31) {
        setInterviewMonth(prev => prev + 1);
        setInterviewDay(1);
      } else {
        setInterviewDay(prev => prev + 1);
      }

      try {
        const newDay = prevDay === 30 && [4, 6, 9, 11].includes(prevMonth) ? 1 :
                      prevDay === 31 ? 1 : 
                      prevDay + 1;
        const newMonth = prevDay === 30 && [4, 6, 9, 11].includes(prevMonth) ? prevMonth + 1 :
                         prevDay === 31 ? (prevMonth === 12 ? 1 : prevMonth + 1) :
                         prevMonth;
        
        const data = await getAllInterviews(newMonth, newDay);
        setSelectedDayMeeting(data.meetings);
        setTotalMeetings(data.meetings.length);
      } catch (error) {
        console.error("Error fetching interviews:", error);
      }
    }
    
    if (filterBy === "month") {
      const prevMonth = interviewMonth;
      setInterviewMonth(prev => (prev !== 12 ? prev + 1 : 1));
      if (prevMonth === 12) {
        setInterviewYear(prev => prev + 1);
      }

      try {
        const newMonth = prevMonth === 12 ? 1 : prevMonth + 1;
        const data = await getAllInterviews(newMonth);
        setInterviews(data.meetings);
        setTotalMeetings(data.meetings.length);
      } catch (error) {
        console.error("Error fetching interviews:", error);
      }
    }
  };

  return (
    <div className='w-full h-fit'>
      <header className='flex items-center justify-between border-b border-gray-300 pt-[7px] pb-[29px]'>
        <div className="flex items-center gap-1.5 w-fit h-[22px] text-[14px] justify-center text-[#707070]">
          <div className='font-light cursor-pointer hover:scale-[105%] ease-in-out transition' onClick={() => setScheduledInterviews(false)}>
            Shortlisted Candidate
          </div>
          /
          <div className='text-[#292929] flex items-center'>
            Scheduled Interview <span className='bg-[#1B5FC1] text-white text-[10px] flex items-center justify-center h-[20px] w-[20px] rounded-full ml-1'>
              {totalMeeting}
            </span>
          </div>
        </div>
        <div className='w-[202px] h-[42px] flex items-center justify-between'>
          <div className="relative border border-gray-200 rounded-md w-[42px] h-[42px] flex items-center justify-center">
            <img
              src="/assets/img/message_antenna_icon.png"
              alt="Profile"
              className="w-[26px] h-[26px] rounded-full object-cover"
            />
          </div>
          <button className="relative border border-gray-200 rounded-md w-[42px] h-[42px] flex items-center justify-center">
            <BellIcon size={24} className="text-gray-600" />
            <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          </button>
          <div className="flex items-center justify-center gap-[8px] border border-gray-200 p-0.5 rounded-full h-[42px] w-[70px]">
            <img
              src="/assets/img/memoji.png"
              alt="Profile"
              className="w-[26px] h-[26px] rounded-full object-cover"
            />
            <CaretDownIcon size={20} className="text-gray-600" />
          </div>
        </div>
      </header>

      <div className='border border-gray-300 rounded-xl h-fit mt-5 w-full'>
        <div className="h-[82px] border-b border-b-gray-300 flex items-center justify-between p-5">
          <div className='h-[42px] w-fit max-w-[508px] flex items-center justify-between gap-4'>
            <div className="h-7 w-fit max-w-[192px] flex items-center justify-between text-[#292929]">
              <p className='font-medium text-[20px]'>{ filterBy === "day" ? interviewDay : ""} {months[interviewMonth-1]} {interviewYear}</p>
              <div onClick={handlePrev} className='cursor-pointer'>
                <CaretLeftIcon size={24} weight="bold" />
              </div>
              <div onClick={handleNext} className='cursor-pointer'>
                <CaretRightIcon size={24} weight="bold"/>
              </div>
            </div>
            <div className="relative w-[300px] h-full text-[#BDBDBD]">
              <input type="text" className='border border-gray-300 focus:outline-none w-full h-full rounded-[5px] px-3 py-2' placeholder='Search here' />
              <MagnifyingGlassIcon size={20} className='absolute top-1/4 right-2'/>
            </div>
          </div>
          <div className="h-10 w-fit flex gap-4 items-center justify-between">
            <div className='h-9 w-[125px] flex items-center justify-between'>
              <p className="font-light text-[14px] text-[#707070]">Filter by:</p>
              <div className='w-[67px] h-10 rounded-[5px] flex items-center justify-center border border-gray-300'>
                <select className='focus:outline-none text-[14px] truncate' value={filterBy} onChange={handleFilter}>
                  <option value="month">Month</option>
                  <option value="day">Day</option>
                  <option value="week">Week</option>
                </select>
              </div>
            </div>
            <div 
              className="h-10 w-fit cursor-pointer flex items-center justify-between bg-[#1B5FC1] text-white rounded-[4px] text-[14px] px-3 py-2.5 transition duration-500 hover:bg-[#1b60c1df]"
              onClick={handleOpenModal}
            >
              Schedule Interview
            </div>
          </div>
        </div>

        <div className="h-[750px] w-full">
          <div className="w-full h-full flex flex-col overflow-hidden">
            {filterBy === "day" ?
              <DayCalendar 
                refreshFlag={refreshFlag} 
                setTotalMeetings={setTotalMeetings} 
                interviewDay={interviewDay} 
                interviewMonth={interviewMonth} 
                setSelectedDayMeeting={setSelectedDayMeeting} 
                handleInterviewDetailsModal={handleInterviewDetailsModal} 
                selectedDayMeeting={selectedDayMeeting} 
              /> :
              
              filterBy === "month" ? 
              <MonthCalendar 
                  interviews={interviews}
                  setInterviews={setInterviews}
                refreshFlag={refreshFlag} 
                setSelectedDayMeeting={setSelectedDayMeeting} 
                monthName={months[interviewMonth - 1]} 
                setTotalMeetings={setTotalMeetings} 
                interviewMonth={interviewMonth} 
                year={interviewYear} 
                setFilterBy={setFilterBy} 
                setInterviewDay={setInterviewDay} 
                showInterviewDetailsModal={showInterviewDetailsModal} 
                onInterviewDeleted={handleInterviewDeleted}
                setShowInterviewDetailsModal={setShowInterviewDetailsModal} 
                selectedInterview={selectedInterview} 
                setSelectedInterview={setSelectedInterview} 
              /> :
                
              <WeekCalendar 
                interviewMonth={interviewMonth} 
                setTotalMeetings={setTotalMeetings} 
                handleInterviewDetailsModal={handleInterviewDetailsModal} 
              />
            }
          </div>
        </div>

        <ScheduledInterviewModal 
          onInterviewCreated={handleInterviewCreated}
          showInterviewModal={showInterviewModal} 
          showSuccessModal={showSuccessModal} 
          showConfirmModal={showConfirmModal} 
          setShowInterviewModal={setShowInterviewModal} 
          interviewType={interviewType} 
          handleInterviewType={handleInterviewType} 
          setShowShortlistedCandidates={setShowShortlistedCandidates} 
          showShortlistedCandidates={showShortlistedCandidates} 
          candidatesData={shortlistedCandidates} 
          toggleSelectAll={toggleSelectAll} 
          toggleCandidate={toggleCandidate} 
          selectedCandidates={selectedCandidates} 
          setShowConfirmModal={setShowConfirmModal} 
          setShowSuccessModal={setShowSuccessModal} 
          handleCloseModal={handleCloseModal} 
          setSelectedCandidates={setSelectedCandidates}
          editData={editData}
          onClose={() => setEditData(null)}
        />
        
        <InterviewDetailsModal 
          showInterviewDetailsModal={showInterviewDetailsModal} 
          setShowInterviewDetailsModal={setShowInterviewDetailsModal} 
          selectedInterview={selectedInterview}           
          setShowInterviewModal={setShowInterviewModal}
          setEditInterviewData={setEditData}
          onInterviewDeleted={handleInterviewDeleted}
        />
      </div>
    </div>
  );
}