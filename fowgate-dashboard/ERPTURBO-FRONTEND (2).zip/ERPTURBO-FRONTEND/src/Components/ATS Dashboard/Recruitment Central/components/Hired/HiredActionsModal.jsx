import React, { useEffect, useRef } from 'react';
import { HiOutlineTrash } from "react-icons/hi2";
import { MdOutlineCancel } from "react-icons/md";
import { GoPencil } from "react-icons/go";
import { FiFileText } from "react-icons/fi";
import Modal from '../../../../../ui/Modal';
import { useState } from 'react';
import { hiringAPI } from '../../services/api_recruitment_central';
import toast from 'react-hot-toast';
const JobActionsModal = ({ jobCode, isOpen, anchorEl, onClose, showConfirmedModal, onEdit, closeConfirmedModal, confirmModal, onDelete, jobTitle, candidate }) => {

  const modalRef = useRef(null);
  

  console.log(candidate.application_code);
  
   // Close modal when clicking outside
   useEffect(() => {
    const handleClickOutside = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target) && e.target !== anchorEl) {
        onClose();
      }
    };
    if (isOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, anchorEl, onClose]);


  // Calculate position relative to the dots button
  const anchorRect = anchorEl.getBoundingClientRect();
  const modalWidth = 200; // Approximate modal width
  const rightSpace = window.innerWidth - anchorRect.right;

  
  const left = rightSpace >= modalWidth 
    ? anchorRect.left 
    : anchorRect.left - (modalWidth - anchorRect.width);
  
  const handleHire = async (applicationCode) => {
    console.log(applicationCode);
    
    try {
      await hiringAPI(applicationCode, "unhire");
      toast.success(`Candidate unhired"}`);
     
    } catch (err) {
      toast.error(err.message);
    }
  }

  return (
    <>
      
    { !confirmModal && <div
      ref={modalRef}
      className="absolute bg-white shadow-lg rounded-md p-2 z-50 border border-gray-100"
      style={{
        top: `${anchorRect.bottom + 4}px`, // 4px gap below dots
        left: `${left}px`,
        minWidth: '160px',
      }}
    >
      <ul className="space-y-1 text-[#292929] text-[14px]">
        <li>
          <button className="w-full flex items-center cursor-pointer gap-2 p-1 hover:bg-gray-50 rounded">
           
            <span>View Offer Letter</span>
          </button>
        </li>
        <li>
          <button className="w-full flex items-center cursor-pointer gap-2 p-1 hover:bg-gray-50 rounded" onClick={onEdit}>
           
            <span>Schedule For Onboarding</span>
          </button>
        </li>
        <li onClick={handleHire}>
          <button className="w-full flex items-center cursor-pointer gap-2 p-1 hover:bg-gray-50 rounded" onClick={onEdit}>
           
            <span>Delete</span>
          </button>
        </li>
      </ul>
      </div>}
      {confirmModal && <Modal closeModal={closeConfirmedModal} confirmAction={()=>onDelete(jobCode)}><p className="border-b border-gray-200 py-7 px-4 text-[16px] font-light">Are you sure you want to delete this Job post <span className="font-normal">"{jobTitle}"</span> ? This action cannot be undone. </p></Modal>}
    </>
  );
};

export default JobActionsModal;