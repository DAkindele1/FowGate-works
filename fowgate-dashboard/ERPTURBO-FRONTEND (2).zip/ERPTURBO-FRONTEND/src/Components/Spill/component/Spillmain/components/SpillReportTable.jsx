


// import React, { useState, useRef, useEffect } from "react";
// import EditSpillReportForm from "../../Spilledit/components/EditSpillReportForm";
// import PdfExportModal from "../../Spillpdf/components/PdfExportModal";

// function SpillReportTable({ incidents, onStatusUpdate }) {
//   const [openDropdown, setOpenDropdown] = useState(null);
//   const dropdownRef = useRef(null);
//   const [isEditFormOpen, setIsEditFormOpen] = useState(false);
//   const [selectedIncident, setSelectedIncident] = useState(null);
//   const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
//   const [updatedIncidentId, setUpdatedIncidentId] = useState(null);

//   const toggleDropdown = (id) => {
//     setOpenDropdown(openDropdown === id ? null : id);
//   };

//   const handleEditClick = (incident) => {
//     setSelectedIncident(incident);
//     setIsEditFormOpen(true);
//     setOpenDropdown(null);
//   };

//   const handleCloseForm = () => {
//     setIsEditFormOpen(false);
//     setSelectedIncident(null);
//   };

//   const handleSaveForm = async (formData) => {
//     try {
//       const payload = {
//         incident_code: selectedIncident.id,
//         updates: {
//           date: formData.date,
//           time: formData.time,
//           cause: formData.cause,
//           spillType: formData.spillType,
//           volume: formData.volume,
//           location: formData.location,
//           riskLevel: formData.riskLevel,
//           additional_notes: formData.description,
//         },
//       };

//       // Simulate API call
//       await new Promise((resolve) => setTimeout(resolve, 1000));

//       // Notify parent to refetch data
//       if (typeof onStatusUpdate === "function") {
//         onStatusUpdate();
//       }

//       setUpdatedIncidentId(payload.incident_code);
//     } catch (err) {
//       console.error("Failed to update spill report:", err);
//     }
//   };

//   const handlePdfExport = (incident) => {
//     setSelectedIncident(incident);
//     setIsPdfModalOpen(true);
//     setOpenDropdown(null);
//   };

//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setOpenDropdown(null);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   return (
//     <div className="rounded-2xl mt-4">
//       <table className="min-w-full bg-white border border-gray-200 shadow">
//         <thead>
//           <tr className="bg-[#E8EFF9] text-[10px] font-semibold text-gray-600 uppercase tracking-wider">
//             <th className="py-3 px-4 text-left">Date Reported</th>
//             <th className="py-3 px-4 text-left">Spill Type</th>
//             <th className="py-3 px-4 text-left">Location</th>
//             <th className="py-3 px-4 text-left">Status</th>
//             <th className="py-3 px-4 text-left">Volume</th>
//             <th className="py-3 px-4 text-left">Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {incidents.map((incident) => (
//             <tr key={incident.id} className="border-t border-gray-200">
//               <td className="py-3 px-4 text-sm text-gray-500">{incident.dateReported}</td>
//               <td className="py-3 px-4 text-sm text-gray-900">{incident.spillType}</td>
//               <td className="py-3 px-4 text-sm text-gray-900">{incident.location}</td>
//               <td className="py-3 px-4 text-sm">
//                 <div
//                   className={`inline-flex items-center px-2 py-1 rounded-xl text-xs font-medium ${
//                     {
//                       Unresolved: "bg-[#FDECEB] text-[#EB4335]",
//                       Resolved: "bg-[#EBF6EE] text-[#34A853]",
//                     }[incident.status] || ""
//                   }`}
//                 >
//                   {incident.status || "Unresolved"}
//                 </div>
//               </td>
//               <td className="py-3 px-4 text-sm text-gray-900">{incident.volume}</td>
//               <td className="py-3 px-4 text-sm text-gray-900 relative">
//                 <svg
//                   className="w-5 h-5 text-gray-500 cursor-pointer hover:text-gray-700"
//                   fill="none"
//                   stroke="currentColor"
//                   viewBox="0 0 24 24"
//                   xmlns="http://www.w3.org/2000/svg"
//                   onClick={() => toggleDropdown(incident.id)}
//                 >
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01" />
//                 </svg>

//                 {openDropdown === incident.id && (
//                   <div
//                     ref={dropdownRef}
//                     className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded shadow-lg z-10"
//                   >
//                     <button
//                       className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                       onClick={() => handlePdfExport(incident)}
//                     >
//                       <img src="/file.svg" alt="view" className="w-4 h-4 mr-2" />
//                       View Report
//                     </button>

//                     <button
//                       className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                       onClick={() => handleEditClick(incident)}
//                     >
//                       <img src="/pen.svg" alt="edit" className="w-4 h-4 mr-2" />
//                       Edit Report
//                     </button>

//                     <button className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
//                       <img src="/del.svg" alt="delete" className="w-4 h-4 mr-2" />
//                       Delete Report
//                     </button>
//                   </div>
//                 )}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>

//       {/* Modals */}
//       <EditSpillReportForm
//         isOpen={isEditFormOpen}
//         onClose={handleCloseForm}
//         onSave={handleSaveForm}
//         incident={selectedIncident}
//       />

//       <PdfExportModal
//         isOpen={isPdfModalOpen}
//         onClose={() => setIsPdfModalOpen(false)}
//         incident={selectedIncident}
//       />
//     </div>
//   );
// }


// export default SpillReportTable;









import React, { useState, useRef, useEffect } from "react";
import EditSpillReportForm from "../../Spilledit/components/EditSpillReportForm";
import PdfExportModal from "../../Spillpdf/components/PdfExportModal";

function SpillReportTable({ incidents, onStatusUpdate }) {
  const [openDropdown, setOpenDropdown] = useState(null);
  const dropdownRef = useRef(null);
  const [isEditFormOpen, setIsEditFormOpen] = useState(false);
  const [selectedSpill, setSelectedSpill] = useState(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [updatedSpillId, setUpdatedSpillId] = useState(null);

  const toggleDropdown = (id) => {
    setOpenDropdown(openDropdown === id ? null : id);
  };

  const handleEditClick = (spill) => {
    setSelectedSpill(spill);
    setIsEditFormOpen(true);
    setOpenDropdown(null);
  };

  const handleCloseForm = () => {
    setIsEditFormOpen(false);
    setSelectedSpill(null);
  };

  const handleSaveForm = async (formData) => {
    try {
      const payload = {
        spill_code: selectedSpill.id,
        updates: {
          date: formData.date,
          time: formData.time,
          cause: formData.cause,
          spillType: formData.spillType,
          volume: formData.volume,
          location: formData.location,
          riskLevel: formData.riskLevel,
          additional_notes: formData.description,
        },
      };

      await new Promise((resolve) => setTimeout(resolve, 1000));

      if (typeof onStatusUpdate === "function") {
        onStatusUpdate();
      }

      setUpdatedSpillId(payload.spill_code);
    } catch (err) {
      console.error("Failed to update spill report:", err);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return ( 
    <div className="rounded-2xl mt-4">
      <table className="min-w-full bg-white border border-gray-200 shadow">
        <thead>
          <tr className="bg-[#E8EFF9] text-[10px] font-semibold text-gray-600 uppercase tracking-wider">
            <th className="py-3 px-4 text-left">Date Reported</th>
            <th className="py-3 px-4 text-left">Spill Type</th>
            <th className="py-3 px-4 text-left">Location</th>
            <th className="py-3 px-4 text-left">Status</th>
            <th className="py-3 px-4 text-left">Volume</th>
            <th className="py-3 px-4 text-left">Action</th>
          </tr>
        </thead>
        <tbody>
          {incidents.map((spill) => (
            <tr key={spill.id} className="border-t border-gray-200">
              <td className="py-3 px-4 text-sm text-gray-500">{spill.dateReported}</td>
              <td className="py-3 px-4 text-sm text-gray-900">{spill.spillType}</td>
              <td className="py-3 px-4 text-sm text-gray-900">{spill.location}</td>
              <td className="py-3 px-4 text-sm">
                <div
                  className={`inline-flex items-center px-2 py-1 rounded-xl text-xs font-medium ${
                    {
                      Unresolved: "bg-[#FDECEB] text-[#EB4335]",
                      Resolved: "bg-[#EBF6EE] text-[#34A853]",
                    }[spill.status] || ""
                  }`}
                >
                  {spill.status || "Unresolved"}
                </div>
              </td>
              <td className="py-3 px-4 text-sm text-gray-900">{spill.volume}</td>
              <td className="py-3 px-4 text-sm text-gray-900 relative">
                <svg
                  className="w-5 h-5 text-gray-500 cursor-pointer hover:text-gray-700"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                  onClick={() => toggleDropdown(spill.id)}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M12 5v.01M12 12v.01M12 19v.01"
                  />
                </svg>

                {openDropdown === spill.id && (
                  <div
                    ref={dropdownRef}
                    className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded shadow-lg z-10"
                  >
                    <button
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={() => {
                        setSelectedSpill(spill);
                        setIsPdfModalOpen(true);
                        setOpenDropdown(null);
                      }}
                    >
                      <img src="/file.svg" alt="view" className="w-4 h-4 mr-2" />
                      View Report
                    </button>

                    <button
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={() => handleEditClick(spill)}
                    >
                      <img src="/pen.svg" alt="edit" className="w-4 h-4 mr-2" />
                      Edit Report
                    </button>

                    <button className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                      <img src="/del.svg" alt="delete" className="w-4 h-4 mr-2" />
                      Delete Report
                    </button>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Edit Modal */}
      <EditSpillReportForm
        isOpen={isEditFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveForm}
        incident={selectedSpill}
      />

      {/* PDF Modal - only renders when isPdfModalOpen is true */}
      {isPdfModalOpen && (
        <PdfExportModal
          isOpen={isPdfModalOpen}
          onClose={() => {
            setIsPdfModalOpen(false);
            setSelectedSpill(null);
          }}
          incident={selectedSpill}
        />
      )}
    </div>
  );
}

export default SpillReportTable;

