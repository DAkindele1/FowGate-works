import React, { useState } from "react";
import axios from "axios";
import Step1Overview from "../../Spillsteps/components/Step1Overview";
import Step2Details from "../../Spillsteps/components/Step2Details";
import Step3 from "../../Spillsteps/components/Step3";
import Step4 from "../../Spillsteps/components/Step4";
import Step5 from "../../Spillsteps/components/Step5";
import ConfirmationPage from "../../Spillsteps/components/ConfirmationPage";
import SuccessPage from "../../Spillsteps/components/SuccessPage";

function SpillForm({ onSubmit, onClose }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({  
    date: "",
    time: "",
    cause: "",
    spillType: "",
    volume: "",
    location: "",
    riskLevel: "",
    attachment: null,
    reportDate: "2025-06-23T00:28:00+01:00", // Current date and time in WAT
  });

  const [referenceId, setReferenceId] = useState("");
  const [submittedSpill, setSubmittedSpill] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const token = localStorage.getItem("userAccess");

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleNext = () => setStep((prev) => prev + 1);
  const handleBack = () => setStep((prev) => prev - 1);
  const handleFinalSubmit = () => setStep(6);
  const handleCancel = () => setStep(5);
  const handleYesIAm = () => handleConfirmSubmit();

  const handleConfirmSubmit = async () => {
    setIsLoading(true);
    const payload = {
      date: formData.date,
      time: formData.time,
      cause: formData.cause,
      spillType: formData.spillType,
      volume: formData.volume,
      location: formData.location,
      riskLevel: formData.riskLevel,
      attachment: formData.attachment ? formData.attachment.name : null,
      reportDate: formData.reportDate,
    };

    try {
      const response = await axios.post(
        "https://erpturbo-backend.onrender.com/api/spill/report",
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const savedSpill = {
        ...formData,
        id: response.data.incident_code || `SPILL${Date.now()}`,
        status: "Unresolved",
        dateReported: `${formData.date} ${formData.time}`,
      };

      setReferenceId(response.data.incident_code);
      setSubmittedSpill(savedSpill);
      setStep(7); // Move to success screen
    } catch (error) {
      console.error("Submission error:", error);
      alert("Failed to submit spill report. Please try again.");
      setStep(5);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuccessClose = () => {
    if (submittedSpill) {
      onSubmit(submittedSpill);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white w-full max-w-md rounded-md shadow-lg overflow-hidden">
        {step === 1 && <Step1Overview formData={formData} onChange={handleChange} onNext={handleNext} onClose={onClose} />}
        {step === 2 && <Step2Details formData={formData} onChange={handleChange} onNext={handleNext} onBack={handleBack} onClose={onClose} />}
        {step === 3 && <Step3 formData={formData} onChange={handleChange} onNext={handleNext} onBack={handleBack} onClose={onClose} />}
        {step === 4 && <Step4 formData={formData} onChange={handleChange} onNext={handleNext} onBack={handleBack} onClose={onClose} />}
        {step === 5 && <Step5 formData={formData} onChange={handleChange} onSubmit={handleFinalSubmit} onBack={handleBack} onEdit={() => setStep(1)} />}
        {step === 6 && <ConfirmationPage formData={formData} onConfirmSubmit={handleYesIAm} onCancel={handleCancel} onClose={handleCancel} />}
        {step === 7 && <SuccessPage referenceId={referenceId} onClose={handleSuccessClose} />}
        {isLoading && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-60">
            <div className="text-white">Loading...</div>
          </div>
        )}
      </div>
    </div>
  );
}

export default SpillForm;