


import React, { useRef,  useEffect } from "react";


     const FileUpload = ({ value, onChange }) => {
       const fileInputRef = useRef(null);

       const validateFile = (file) => {
         const maxSize = 5 * 1024 * 1024;
         const allowedTypes = [
           "image/jpeg", "image/png", "image/gif", "video/mp4", "video/mpeg",
           "audio/mpeg", "audio/wav", "application/pdf", "application/msword",
           "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
         ];
         if (!file) return false;
         if (file.size > maxSize) {
           alert("File size exceeds 5MB limit.");
           return false;
         }
         if (!allowedTypes.includes(file.type)) {
           alert("Invalid file type.");
           return false;
         }
         return true;
       };

       const handleFile = (file) => {
         if (file && validateFile(file)) {
           onChange?.({ target: { name: "attachment", value: file } });
         }
       };

       const handleInputChange = (e) => {
         const file = e.target.files?.[0];
         handleFile(file);
       };

       const handleDrop = (e) => {
         e.preventDefault();
         const file = e.dataTransfer.files?.[0];
         handleFile(file);
       };

       const handleDragOver = (e) => {
         e.preventDefault();
       };

       return (
         <div
           className="mt-0 flex justify-center px-6 pt-5 pb-6 border-2 border-[#1B5FC1] border-dashed 
           rounded-[3px] bg-blue-50"
           onDrop={handleDrop}
           onDragOver={handleDragOver}
         >
           <div className="space-y-1 text-center">
             <img src="/upload.svg" alt="upload" className="mx-auto h-12 w-12" />
             <div className="flex text-sm text-gray-600 justify-center">
               <span className="mr-1 font-bold">Drag and drop file or</span>
               <a href="#" className="text-blue-600 underline font-bold" onClick={(e) => { e.preventDefault(); fileInputRef.current.click(); }}>
                 Browse
               </a>
             </div>
             <p className="text-xs text-gray-500">Max 5MB – Images, Video, Audio, Documents</p>
             <input
               type="file"
               ref={fileInputRef}
               className="hidden"
               accept="image/*,video/*,audio/*,application/pdf,.doc,.docx"
               onChange={handleInputChange}
             />
             {value?.name && <p className="text-xs text-gray-600 mt-2">Selected: {value.name}</p>}
           </div>
         </div>
       );
     };

     

     const Step3 = ({ formData, onNext, onPrev }) => {
       return (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
           <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
             <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
               <div className="flex items-center space-x-2">
                 <img src="/add.svg" alt="add" className="w-5 h-5" />
                 <h2 className="text-white font-semibold text-lg">Report Spill</h2>
               </div>
               <button onClick={onPrev} className="text-white">
                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                 </svg>
               </button>
             </div>
             <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center px-4">
               <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
                 <img src="/four.svg" alt="three" width={20} height={20} />
               </span>
               <span className="text-black">
                 3/5 - <span className="font-bold">SUPPORTING INFORMATION</span>
               </span>
             </div>
             <hr className="border-t border-gray-300 my-0" />
             <div className="px-4 pb-4 pt-8 overflow-y-auto flex-1 space-y-4">
               <div>
                 <label className="block text-sm  text-gray-700 mb-1">
                   Upload JIV Report
                 </label>
                 <FileUpload
                   value={formData.attachment || null}
                   onChange={(e) => onNext({ attachment: e.target.value })}
                 />
               </div>
             </div>
             <div className="bg-white  px-4 py-3 flex justify-end space-x-2  mt-auto 
        shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4  w-full">
               <button
                 onClick={onPrev}
                 className="px-4 py-2 text-sm border border-gray-300 rounded-[3px]"
               >
                 Prev
               </button>
               <button
                 onClick={() => onNext({})}
                 className="px-4 py-2 text-sm bg-[#E8EFF9] text-[#1B5FC1]  rounded-[3px]"
               >
                 Save & Continue
               </button>
             </div>
           </div>
         </div>
       );
     };

     export default Step3;