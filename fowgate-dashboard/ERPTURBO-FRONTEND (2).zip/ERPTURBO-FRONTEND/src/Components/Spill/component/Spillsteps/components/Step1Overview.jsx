
import React, { useEffect, useRef, useState } from "react";
import { FiClock, FiChevronDown } from "react-icons/fi";
import axios from "axios";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix Leaflet marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

// FileUpload Component
const FileUpload = ({ value, onChange }) => {
  const fileInputRef = useRef(null);

  const validateFile = (file) => {
    const maxSize = 5 * 1024 * 1024;
    const allowedTypes = [
      "image/jpeg", "image/png", "image/gif", "video/mp4", "video/mpeg",
      "audio/mpeg", "audio/wav", "application/pdf", "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ];
    if (!file) return false;
    if (file.size > maxSize) {
      alert("File size exceeds 5MB limit.");
      return false;
    }
    if (!allowedTypes.includes(file.type)) {
      alert("Invalid file type.");
      return false;
    }
    return true;
  };

  const handleFile = (file) => {
    if (file && validateFile(file)) {
      onChange?.({ target: { name: "attachment", value: file } });
    }
  };

  const handleInputChange = (e) => {
    const file = e.target.files?.[0];
    handleFile(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    handleFile(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  return (
    <div
      className="mt-1 p-8 border-2  border-dashed border-blue-500 bg-blue-50 rounded-md  text-center"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      <label htmlFor="file-upload" className="block cursor-pointer ">
        <img src="/upload.svg" alt="upload" className=" h-12 w-12 mx-auto mb-1" />
        <p className="text-sm text-gray-500 font-bold">
          Drag and drop or <span className="text-blue-600 underline font-bold">Browse</span>
          <p className="text-xs text-gray-500">Images, Video, Audio, Documents – Max 5MB</p>
        </p>
      </label>
      <input
        id="file-upload"
        type="file"
        ref={fileInputRef}
        onChange={handleInputChange}
        className="hidden"
      />
      {value && (
        <p className="text-xs text-gray-600 mt-1 truncate">Selected: {value.name}</p>
      )}
    </div>
  );
};

// DatePicker Component
const DatePicker = ({ value, onChange }) => {
  const dateInputRef = useRef(null);

  const handleIconClick = () => {
    dateInputRef.current?.showPicker();
  };

  const handleDateChange = (e) => {
    const newDate = e.target.value;
    onChange?.({ target: { name: "date", value: newDate } });
  };

  const formatDate = (isoString) => {
    if (!isoString) return "";
    const [year, month, day] = isoString.split("-");
    return `${day}/${month}/${year}`;
  };

  return (
    <div className="relative w-full">
      <input
        ref={dateInputRef}
        type="date"
        value={value}
        onChange={handleDateChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
      />
      <div className="flex items-center justify-between w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-900 bg-white relative pointer-events-none">
        <span className="truncate pointer-events-none">
          {value ? formatDate(value) : "dd/mm/yyyy"}
        </span>
        <img
          src="/calendar.svg"
          alt="calendar"
          className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 cursor-pointer pointer-events-auto hover:scale-110 transition"
          onClick={handleIconClick}
        />
      </div>
    </div>
  );
};

// TimePicker Component
const TimePicker = ({ value, onChange }) => {
  const timeInputRef = useRef(null);

  const handleIconClick = () => {
    timeInputRef.current?.showPicker();
  };

  const handleTimeChange = (e) => {
    const newTime = e.target.value;
    onChange?.({ target: { name: "time", value: newTime } });
  };

  return (
    <div className="relative w-full">
      <input
        ref={timeInputRef}
        type="time"
        value={value}
        onChange={handleTimeChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
      />
      <div className="flex items-center justify-between w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-900 bg-white relative pointer-events-none">
        <span className="truncate pointer-events-none">{value || "--:--"}</span>
        <FiClock
          size={20}
          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer pointer-events-auto hover:scale-110 transition"
          onClick={handleIconClick}
        />
      </div>
    </div>
  );
};

// MapModal Component
const MapModal = ({ isOpen, onClose, onSelectLocation, mapType }) => {
  const [center, setCenter] = useState([4.8430, 7.0330]); // Default: Port Harcourt, Rumudara
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedAddress, setSelectedAddress] = useState(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCenter([position.coords.latitude, position.coords.longitude]);
        },
        () => {
          alert("Unable to access your location. Using default map center.");
        }
      );
    }
  }, []);

  const MapClickHandler = () => {
    useMapEvents({
      click: async (e) => {
        const { lat, lng } = e.latlng;
        setSelectedLocation([lat, lng]);

        try {
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
            {
              headers: {
                "User-Agent": "IncidentReportingApp (nackycynthia@gmail.com)",
              },
            }
          );
          const address = response.data.display_name || `Lat: ${lat}, Lng: ${lng}`;
          setSelectedAddress(address);
        } catch (error) {
          console.error("Geocoding error:", error);
          setSelectedAddress(`Lat: ${lat}, Lng: ${lng}`);
          alert("Unable to retrieve address. Using coordinates instead.");
        }
      },
    });
    return null;
  };

  const handleConfirm = () => {
    if (selectedLocation && selectedAddress) {
      onSelectLocation({
        lat: selectedLocation[0],
        lng: selectedLocation[1],
        address: selectedAddress,
      });
    }
    onClose();
  };

  if (!isOpen) return null;

  const tileUrl =
    mapType === "Satellite View"
      ? "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
      : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  const attribution =
    mapType === "Satellite View"
      ? '© <a href="https://www.esri.com/">Esri</a>'
      : '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-[3px] p-4 w-[80%] h-[80%] max-w-4xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg ">Select Spill Location</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="mb-2 text-sm text-gray-700">
          {selectedAddress ? (
            <p>Selected: {selectedAddress}</p>
          ) : (
            <p>Click on the map to select a location</p>
          )}
        </div>
        <MapContainer
          center={center}
          zoom={10}
          style={{ width: "100%", height: "80%" }}
        >
          <TileLayer url={tileUrl} attribution={attribution} />
          {selectedLocation && <Marker position={selectedLocation} />}
          <MapClickHandler />
        </MapContainer>
        <div className="flex justify-end -mt-2">
          <button
            type="button"
            onClick={handleConfirm}
            className="bg-[#1B5FC1] text-white px-4 py-2 rounded-[3px]"
            disabled={!selectedLocation}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};

// Main Step1Overview Component
const Step1Overview = ({ formData = {}, onChange, onNext, onClose }) => {
  const [showMapDropdown, setShowMapDropdown] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [selectedMapType, setSelectedMapType] = useState(null);

  const handleMapSelect = (mapType) => {
    setShowMapDropdown(false);
    setSelectedMapType(mapType);
    setShowMapModal(true);
  };

  const handleLocationSelect = ({ lat, lng, address }) => {
    onChange?.({
      target: {
        name: "location",
        value: address,
      },
    });
    setShowMapModal(false);
  };

  const handleNext = () => {
    // Validate required fields
    if (!formData.location || !formData.date || !formData.time || !formData.spillType || !formData.cause || !formData.attachment) {
      alert("Please fill all required fields.");
      return;
    }
    onNext();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded-[3px] shadow-lg flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="add" className="w-5 h-5" />
            <h2 className="text-white font-semibold text-lg">Report Spill</h2>
          </div>
          <button onClick={onClose} className="text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Form Content */}
        <div className="px-4 py-3 overflow-y-auto flex-1">
          <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
            <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
              <img src="/one.svg" alt="one" width={20} height={20} />
            </span>
            <span className="text-black">
              1/5 - <span className="font-bold">SPILL OVERVIEW</span>
            </span>
          </div>
     <hr className="border-t border-gray-300 my-3" />
          <div className="space-y-3">
            {/* Location */}
            <div>
              <label className="text-sm  text-gray-700">
                Spill Location <span className="text-red-500">*</span>
              </label>
              <div className="relative mt-1">
                <div className="flex items-center w-full border border-gray-300 rounded-md px-3 py-2 focus-within:ring-1 focus-within:ring-blue-500 transition-all duration-150">
                  <button
                    type="button"
                    onClick={() => setShowMapDropdown((prev) => !prev)}
                    className="flex items-center text-sm text-[#1B5FC1]  mr-2"
                  >
                    <FiChevronDown className="mr-1" />
                    
                  </button>
                  <input
                    type="text"
                    name="location"
                    value={formData.location || ""}
                    onChange={onChange}
                    className="flex-1 bg-transparent outline-none text-sm"
                    placeholder="Type here"
                    required
                  />
                </div>
                <div
                  className={`absolute left-0 top-full mt-1 w-40 bg-white border border-gray-300
                     rounded-[3px] shadow-lg z-20 transition-all duration-200 origin-top-left transform ${
                    showMapDropdown ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => handleMapSelect("Map View")}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Map View
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMapSelect("Satellite View")}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Satellite View
                  </button>
                </div>
              </div>
            </div>

            {/* Date and Time */}
            <div className="flex space-x-3">
              <div className="w-1/2">
                <label className="text-sm  text-gray-700">
                  Date of Spill <span className="text-red-500">*</span>
                </label>
                <DatePicker value={formData.date || ""} onChange={onChange} />
              </div>
              <div className="w-1/2">
                <label className="text-sm  text-gray-700">
                  Time of Spill <span className="text-red-500">*</span>
                </label>
                <TimePicker value={formData.time || ""} onChange={onChange} />
              </div>
            </div>

            {/* Spill Type and Volume */}
            <div className="flex space-x-3">
              <div className="w-1/2">
                <label className="text-sm  text-gray-700">
                  Spill Type <span className="text-red-500">*</span>
                </label>
                <select
                  name="spillType"
                  value={formData.spillType || ""}
                  onChange={onChange}
                  className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">Select</option>
                  <option value="oil">Oil</option>
                  <option value="chemical">Chemical</option>
                </select>
              </div>
              <div className="w-1/2">
                <label className="text-sm  text-gray-700">Volume</label>
                <div className="flex items-center border border-gray-300 rounded-[3px] px-3 py-2">
                  <input
                    type="text"
                    name="volume"
                    value={formData.volume || ""}
                    onChange={onChange}
                    className="flex-1 focus:outline-none text-sm"
                    placeholder="Enter"
                  />
                  <span className="-ml-4 text-sm text-gray-400  px-1 bg-gray-200  rounded-[3px]">Barrels</span>
                </div>
              </div>
            </div>

            {/* Source */}
            <div>
              <label className="text-sm  text-gray-700">
                Source <span className="text-red-500">*</span>
              </label>
              <select
                name="cause"
                value={formData.cause || ""}
                onChange={onChange}
                className="w-full border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">Select</option>
                <option value="pipeline">Pipeline</option>
                <option value="tank">Tank</option>
              </select>
            </div>

            {/* Upload */}
            <div>
              <label className="text-sm  text-gray-700">
                Upload Evidence <span className="text-red-500">*</span>
              </label>
              <FileUpload
                value={formData.attachment || null}
                onChange={onChange}
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-white px-4 py-3 flex justify-end space-x-2 mt-auto shadow-[0_-1px_3px_rgba(0,0,0,0.15)]">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm border border-gray-300 rounded-[3px]"
          >
            Close
          </button>
          <button
            onClick={handleNext}
            className="px-4 py-2 text-sm bg-[#E8EFF9] text-[#1B5FC1] rounded-[3px]"
          >
            Save & Continue
          </button>
        </div>

        {/* Map Modal */}
        <MapModal
          isOpen={showMapModal}
          onClose={() => setShowMapModal(false)}
          onSelectLocation={handleLocationSelect}
          mapType={selectedMapType}
        />
      </div>
    </div>
  );
};

export default Step1Overview;
