




import React, { useRef, useState } from "react";

const Step4 = ({ formData, onChange, onNext, onPrev }) => {
  const fileInputRefs = useRef([]);
  const [tiers, setTiers] = useState([
    { tier: "Tier 1", report: null, certificate: null, isOpen: true },
  ]);

  const handleFileChange = (index, field, e) => {
    const file = e.target.files[0];
    if (file) {
      const updatedTiers = [...tiers];
      updatedTiers[index][field] = file;
      setTiers(updatedTiers);
      onChange({ target: { name: "tiers", value: updatedTiers } });
    }
  };

  const handleAddTier = (tierName) => {
    if (!tiers.find((t) => t.tier === tierName)) {
      const newTier = { tier: tierName, report: null, certificate: null, isOpen: true };
      setTiers([...tiers, newTier]);
    }
  };

  const toggleTier = (index) => {
    const updatedTiers = [...tiers];
    updatedTiers[index].isOpen = !updatedTiers[index].isOpen;
    setTiers(updatedTiers);
  };

  const handleDeleteTier = (index) => {
    const updatedTiers = [...tiers];
    updatedTiers.splice(index, 1);
    setTiers(updatedTiers);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-[500px] h-[575px] bg-white rounded shadow-lg flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="add" className="w-5 h-5" />
            <h2 className="text-white font-medium text-base">Report Spill</h2>
          </div>
          <button onClick={onPrev} className="text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Step Indicator */}
        <div className=" pt-4 pb-2 text-sm font-medium text-[#1B5FC1]">
          <div className="text-sm text-gray-500  mt-0 flex items-center">
            <span className="w-4 h-4 flex items-center justify-center mr-4 text-xs font-bold text-blue-700">
              <img src="/two.svg" alt="one" width={20} height={20} className="ml-4" />
            </span>
            <span className="text-black">
              4/5 - <span className="font-bold">REMEDIATION</span>
            </span>
          </div>
        </div>
<hr className="border-t border-gray-300 my-0" />
        {/* Body */}
        <div className="px-4  pb-4 pt-8 flex-1 overflow-y-auto space-y-3">
          {tiers.map((tier, index) => (
            <div key={index}>
              <div className="border border-gray-200 rounded">
                <div className="bg-[#F7F7F8] px-4 py-2 flex justify-between items-center text-sm  text-gray-800">
                  <button type="button" onClick={() => toggleTier(index)} className="flex-1 text-left">
                    {tier.tier}
                  </button>
                  <div className="flex items-center space-x-2">
                    {tier.tier !== "Tier 1" && (
                      <button
                        type="button"
                        onClick={() => handleDeleteTier(index)}
                        className="text-red-500 hover:text-red-600"
                        title="Delete Tier"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6M9 7h6m-6 0V5a1 1 0 011-1h4a1 1 0 011 1v2" />
                        </svg>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => toggleTier(index)}
                      className="text-gray-500 hover:text-gray-600"
                      title={tier.isOpen ? "Collapse" : "Expand"}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className={`w-4 h-4 transition-transform ${tier.isOpen ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                  </div>
                </div>

                {tier.isOpen && (
                  <div className="px-4 py-3 space-y-4">
                    {/* Upload Report */}
                    <div>
                      <label className="block text-sm  text-[#344054] mb-1">
                        Upload Report - {tier.tier} <span className="text-red-500">*</span>
                      </label>
                      <div className="bg-[#F9FAFB] p-1 rounded-md">
                        <div className="border border-[#D0D5DD] rounded-[3px] px-3 py-[9px] bg-white flex items-center">
                          <div className="bg-[#F5F5F5] px-3 py-1.5 rounded-[3px] border border-[#D0D5DD]">
                            <button
                              type="button"
                              onClick={() => fileInputRefs.current[index * 2].click()}
                              className="text-sm font-medium text-[#344054]"
                            >
                              Choose files
                            </button>
                          </div>
                          <input
                            type="file"
                            ref={el => (fileInputRefs.current[index * 2] = el)}
                            onChange={(e) => handleFileChange(index, "report", e)}
                            className="hidden"
                          />
                          <span className="ml-3 text-sm text-[#667085] truncate">
                            {tier.report ? tier.report.name : "No file chosen"}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Upload Certificate */}
                    <div>
                      <label className="block text-sm font-medium text-[#344054] mb-1">
                        Upload Certificate - {tier.tier} <span className="text-red-500">*</span>
                      </label>
                      <div className="bg-[#F9FAFB] p-1 rounded-md">
                        <div className="border border-[#D0D5DD] rounded-md px-3 py-[9px] bg-white flex items-center">
                          <div className="bg-[#F5F5F5] px-3 py-1.5 rounded border border-[#D0D5DD]">
                            <button
                              type="button"
                              onClick={() => fileInputRefs.current[index * 2 + 1].click()}
                              className="text-sm font-medium text-[#344054]"
                            >
                              Choose files
                            </button>
                          </div>
                          <input
                            type="file"
                            ref={el => (fileInputRefs.current[index * 2 + 1] = el)}
                            onChange={(e) => handleFileChange(index, "certificate", e)}
                            className="hidden"
                          />
                          <span className="ml-3 text-sm text-[#667085] truncate">
                            {tier.certificate ? tier.certificate.name : "No file chosen"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Tier Add Buttons */}
          <div className="flex flex-col items-end space-y-2 pt-4">
            {!tiers.find(t => t.tier === "Tier 2") && (
              <button
                type="button"
                onClick={() => handleAddTier("Tier 2")}
                className="text-sm text-[#667085] flex items-center hover:text-blue-600"
              >
                <span className="mr-1 text-base ">+</span> Add Tier 2 Remediation Report
              </button>
            )}
            {!tiers.find(t => t.tier === "Tier 3") && (
              <button
                type="button"
                onClick={() => handleAddTier("Tier 3")}
                className="text-sm text-[#667085] flex items-center  hover:text-blue-600"
              >
                <span className="mr-1 text-base ">+</span> Add Tier 3 Remediation Report
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-white  px-4 py-3 flex justify-end space-x-2  mt-auto 
        shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4  w-full">
          <button
            onClick={onPrev}
            className="px-4 py-2 text-sm border border-gray-300 rounded-[3px] text-gray-700"
          >
            Prev
          </button>
          <button
            onClick={onNext}
            className="px-4 py-2 text-sm bg-[#E9F0FB] text-[#1B5FC1]  rounded-[3px]"
          >
            Save & Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default Step4;
