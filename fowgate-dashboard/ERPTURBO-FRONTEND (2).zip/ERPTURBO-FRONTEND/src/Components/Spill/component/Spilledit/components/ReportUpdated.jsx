



import React, { useEffect, useRef } from 'react';

const ReportUpdated = ({ message, onClose }) => {
  const checkRef = useRef(null);

  useEffect(() => {
    if (checkRef.current) {
      checkRef.current.classList.add("scale-100");
    }
    return () => {
      if (checkRef.current) {
        checkRef.current.classList.remove("scale-100");
      }
    };
  }, []);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center"
      role="dialog"
      aria-modal="true"
      aria-labelledby="successTitle"
      aria-describedby="successMessage"
    >
      <div className="w-[400px] bg-white rounded-[3px] shadow-lg p-6 text-center">
        {/* Animated Checkmark */}
        <div className="flex justify-center mb-5">
          <div
            ref={checkRef}
            className="transform scale-0 transition-transform duration-700 ease-out text-green-500 text-5xl"
          >
            ✔
          </div>
        </div>

        {/* Message */}
        <h2 id="successTitle" className="text-xl font-semibold text-gray-900 mb-2">
          Report Updated!
        </h2>
        <p id="successMessage" className="text-gray-700 text-sm mb-6">
          {message}
        </p>

        {/* CTA */}
        <button
          onClick={onClose}
          className="w-full py-2 bg-[#1B5FC1] text-white rounded-md hover:bg-blue-700 transition"
        >
          Okay
        </button>
      </div>
    </div>
  );
};

export default ReportUpdated;
