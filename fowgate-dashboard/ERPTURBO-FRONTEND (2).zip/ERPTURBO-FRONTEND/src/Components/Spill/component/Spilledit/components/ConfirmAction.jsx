


import React from 'react';

const ConfirmAction = ({ onClose, onConfirm }) => {
  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center"
      role="dialog"
      aria-labelledby="confirm-action-title"
    >
      <div className="w-[400px] bg-white rounded-[3px] shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-[#1B5FC1] px-4 py-3 flex items-center justify-between">
          <h2 id="confirm-action-title" className="text-white text-[17px] font-semibold">
            Confirm Action
          </h2>
          <button onClick={onClose} className="text-white hover:text-gray-200" aria-label="Close modal">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="px-4 py-5 text-sm text-gray-700 leading-relaxed">
          Are you sure you want to save the changes made to this incident report? Ensure all details are correct before proceeding.
        </div>

        {/* Actions */}
        <div className="bg-white px-4 py-3 flex justify-end space-x-2 border-t">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm border border-gray-300 rounded-md"
            aria-label="Cancel"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-5 py-2 text-sm bg-[#EAF1FD] text-[#1B5FC1] font-medium rounded-md hover:bg-[#d5e6fc]"
            aria-label="Confirm"
          >
            Yes, I'm sure
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmAction;
