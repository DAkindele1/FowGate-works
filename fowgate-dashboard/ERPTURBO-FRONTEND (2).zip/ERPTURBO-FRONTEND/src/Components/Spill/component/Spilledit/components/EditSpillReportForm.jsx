



// import React, { useState, useEffect } from 'react';
// import SpillOverview from './SpillOverview';
// import SpillInvestigation from './SpillInvestigation';
// import ConfirmAction from './ConfirmAction';
// import ReportUpdated from './ReportUpdated';

// const EditSpillReportForm = ({ isOpen, onClose, onSave, incident }) => {
//   const [step, setStep] = useState(1);
//   const [formData, setFormData] = useState({});
//   const [referenceId, setReferenceId] = useState('');
//   const [isLoading, setIsLoading] = useState(false);

//   // Only reset when opening (and not during step 7 success screen)
//   useEffect(() => {
//     if (isOpen && incident && step !== 7) {
//       setFormData(incident);
//       setStep(1);
//       setIsLoading(false);
//     }
//   }, [isOpen, incident]);

//   const handleNext = (data) => {
//     setFormData((prev) => ({ ...prev, ...data }));
//     setStep(2);
//   };

//   const handleSave = (data) => {
//     setFormData((prev) => ({ ...prev, ...data }));
//     setStep(6); // Show confirmation step
//   };

//   const handleYesIAm = async () => {
//     setIsLoading(true);
//     try {
//       // Simulate save delay
//       await new Promise((res) => setTimeout(res, 1500));

//       // Create reference ID (or use actual one)
//       const id = `INC-${new Date().getFullYear()}${new Date().getTime().toString().slice(-5)}-X9Z`;
//       setReferenceId(id);
//       setStep(7); // Show success page

//       // Call parent after a short delay to avoid interfering with step
//       setTimeout(() => {
//         if (onSave) onSave(formData);
//       }, 300);
//     } catch (error) {
//       console.error('Error updating spill report:', error);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const handleCancel = () => {
//     setStep(1);
//     onClose();
//   };

//   const handleSuccessClose = () => {
//     setStep(1);
//     setReferenceId('');
//     onClose();
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 bg-opacity-60">
//       <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-2xl relative">
//         <button
//           className="absolute top-2 right-2 text-gray-600 hover:text-red-500 text-xl"
//           onClick={handleCancel}
//         >
//           &times;
//         </button>

//         {/* Step 1: Overview */}
//         {step === 1 && <SpillOverview onNext={handleNext} formData={formData} />}

//         {/* Step 2: Investigation */}
//         {step === 2 && <SpillInvestigation onSave={handleSave} formData={formData} />}

//         {/* Step 6: Confirmation */}
//         {step === 6 && (
//           <ConfirmAction
//             formData={formData}
//             onConfirm={handleYesIAm}
//             onCancel={handleCancel}
//             onClose={handleCancel}
//           />
//         )}

//         {/* Step 7: Success */}
//         {step === 7 && (
//           <ReportUpdated
//             message={`The incident report (${referenceId}) has been successfully updated with the latest information.`}
//             onClose={handleSuccessClose}
//           />
//         )}

//         {/* Loading Overlay */}
//         {isLoading && (
//           <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-60">
//             <div className="text-white text-lg">Loading...</div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default EditSpillReportForm;



import React, { useState, useEffect } from 'react';
import SpillOverview from './SpillOverview';
import SpillInvestigation from './SpillInvestigation';
import ConfirmAction from './ConfirmAction';
import ReportUpdated from './ReportUpdated';

const EditSpillReportForm = ({ isOpen, onClose, onSave, incident }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});
  const [referenceId, setReferenceId] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Reset when form is opened, unless on success screen
  useEffect(() => {
    if (isOpen && incident && step !== 7) {
      setFormData(incident);
      setStep(1);
      setIsLoading(false);
    }
  }, [isOpen, incident]);

  const handleNext = (data) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setStep(2);
  };

  const handleSave = (data) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setStep(6); // Confirmation step
  };

  const handleYesIAm = async () => {
    setIsLoading(true);
    try {
      await new Promise((res) => setTimeout(res, 1500)); // Simulate delay

      const id = `INC-${new Date().getFullYear()}${new Date().getTime().toString().slice(-5)}-X9Z`;
      setReferenceId(id);
      setStep(7); // Success step

      setTimeout(() => {
        if (onSave) onSave(formData);
      }, 300);
    } catch (error) {
      console.error('Error updating spill report:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setStep(1);
    onClose(); // This hides the modal from the parent
  };

  const handleSuccessClose = () => {
    setStep(1);
    setReferenceId('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 bg-opacity-60">
      <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-2xl relative">
        <button
          className="absolute top-2 right-2 text-gray-600 hover:text-red-500 text-xl"
          onClick={handleCancel}
        >
          &times;
        </button>

        {/* Step 1: Overview */}
        {step === 1 && <SpillOverview onNext={handleNext} 
        onClose={handleCancel}
        formData={formData} />}

        {/* Step 2: Investigation */}
        {step === 2 && (
          <SpillInvestigation
            onSave={handleSave}
            onClose={handleCancel} // ✅ Pass the onClose handler
            formData={formData}
          />
        )}

        {/* Step 6: Confirmation */}
        {step === 6 && (
          <ConfirmAction
            formData={formData}
            onConfirm={handleYesIAm}
            onCancel={handleCancel}
            onClose={handleCancel}
          />
        )}

        {/* Step 7: Success */}
        {step === 7 && (
          <ReportUpdated
            message={`The incident report (${referenceId}) has been successfully updated with the latest information.`}
            onClose={handleSuccessClose}
          />
        )}

        {/* Loading Overlay */}
        {isLoading && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-60">
            <div className="text-white text-lg">Loading...</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EditSpillReportForm;
