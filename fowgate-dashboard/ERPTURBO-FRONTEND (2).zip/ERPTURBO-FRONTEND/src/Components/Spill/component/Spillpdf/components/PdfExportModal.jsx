// import React from 'react';
// import jsPDF from 'jspdf';
// import { FiDownload } from 'react-icons/fi';

// const PdfExportModal = ({ isOpen, onClose, incident }) => {
//   if (!isOpen) return null;

//   const handleDownload = () => {
//     const doc = new jsPDF();
//     doc.text('Exported PDF content goes here...', 10, 10);
//     doc.save('incident_report.pdf');
//   };

//   return (
//     <div
//       className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50"
//       onClick={onClose}
//     >
//       <div
//         className="bg-white w-[480px] rounded-[3px] shadow-lg max-h-[90vh] border flex flex-col"
//         onClick={(e) => e.stopPropagation()}
//       >
//         {/* Header */}
//         <div className="flex items-center justify-between bg-[#1B5FC1] text-white h-[80px] px-6">
//           <div className="flex items-center space-x-2">
//             <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
//             <h2 className="text-white text-lg font-semibold">Incident Overview</h2>
//           </div>
//           <button onClick={onClose} className="text-white text-xl font-bold">
//             &times;
//           </button>
//         </div>

//         {/* Scrollable Content */}
//         <div className="px-6 py-4 text-sm text-gray-800 overflow-y-auto space-y-6 flex-1">
//           {/* Officer Details */}
//           <div>
//             <div className="bg-[#dbe9fd] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
//               Reporting Officer Details
//             </div>
//             <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700 divide-y divide-gray-200">
//               <div className="pb-2">
//                 <p className="text-xs text-gray-500">Name of CLO</p>
//                 <p>{incident?.cloName || 'Kingsley Tamuno'}</p>
//               </div>
//               <div className="pb-2">
//                 <p className="text-xs text-gray-500">OML</p>
//                 <p>{incident?.oml || 'OML 58'}</p>
//               </div>
//               <div className="pt-2 pb-2 col-span-1">
//                 <p className="text-xs text-gray-500">Cluster/Host Community</p>
//                 <p>{incident?.community || 'Rumueme Community'}</p>
//               </div>
//               <div className="pt-2 pb-2 col-span-1">
//                 <p className="text-xs text-gray-500">Company</p>
//                 <p>{incident?.company || 'NAOC (Nigerian Agip Oil Company)'}</p>
//               </div>
//               <div className="pt-2 pb-2 col-span-1">
//                 <p className="text-xs text-gray-500">Date of Report</p>
//                 <p>{incident?.reportDate || 'N/A'}</p>
//               </div>
//               <div className="pt-2 pb-2 col-span-1">
//                 <p className="text-xs text-gray-500">CLO Contact Number</p>
//                 <p>{incident?.cloPhone || 'N/A'}</p>
//               </div>
//             </div>
//           </div>

//           {/* Incident Overview */}
//           {/* <div>
//             <div className="bg-[#dbe9fd] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
//               Incident Overview
//             </div>
//             <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700 divide-y divide-gray-200">
//               <div className="pb-2">
//                 <p className="text-xs text-gray-500">Date of Incident</p>
//                 <p>{incident?.dateOfIncident || 'N/A'}</p>
//               </div>
//               <div className="pb-2">
//                 <p className="text-xs text-gray-500">Time of Incident</p>
//                 <p>{incident?.timeOfIncident || '3:45 PM'}</p>
//               </div>
//               <div className="pt-2 pb-2 col-span-1">
//                 <p className="text-xs text-gray-500">Location</p>
//                 <p>{incident?.location || 'Near Rumuokoro Pipeline Station...'}</p>
//               </div>
//               <div className="pt-2 pb-2 col-span-1">
//                 <p className="text-xs text-gray-500">Community Affected</p>
//                 <p>{incident?.communityAffected || 'Rumueme Community'}</p>
//               </div>
//               <div className="pt-2 col-span-2">
//                 <p className="text-xs text-gray-500 mb-1">Incident Type</p>
//                 <div className="bg-gray-200 text-gray-700 text-xs px-3 py-1 rounded-full">
//                   <span
//                     className={`truncate ${!incident?.incidentType ? 'text-gray-400 italic' : 'text-gray-900'}`}
//                   >
//                     {incident?.incidentType || 'No incident type provided'}
//                   </span>
//                 </div>
//               </div>
//             </div>
//           </div> */}

//            {/* Spill Overview */}
//             <div className="bg-white rounded-lg border border-gray-300">
//               <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
//                 Spill Overview
//                 <div className="flex items-center gap-4">
//                   <img src="/pen.svg" alt="Edit spill overview" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowSpillOverview(prev => !prev)}
//                     className="focus:outline-none"
//                     aria-expanded={showSpillOverview}
//                     aria-label="Toggle Spill Overview"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showSpillOverview ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               <div
//                 className={`transition-all duration-300 ease-in-out ${
//                   showSpillOverview ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
//                 }`}
//               >
//                 <div className="grid grid-cols-2 gap-2 p-4 text-sm space-x-2">
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Date of Spill</p>
//                     <p className="text-black">{formData?.spillDate || "Not provided"}</p>
//                   </div>
//                   <div>
//                         <p className="text-gray-500 text-[12px]">Time of Spill</p>
//                     <p className="text-black">{formData?.spillTime || "Not provided"} </p>
//                   </div>
//                   <hr className="border-gray-300 col-span-2 my-2" />
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Spill Location</p>
//                     <p className="text-black">{formData?.location || "Not provided"}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Source</p>
//                     <p className="text-black">{formData?.source || "Not provided"}</p>
//                   </div>
//                   <hr className="border-gray-300 col-span-2 my-2" />
//                   <div>
//                       <p className="text-gray-500 text-[12px]">Spill Content</p>
//                     <p className="text-black">{formData?.spillType || "Not provided"}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Volume</p>
//                     <p className="text-black">{formData?.volume ? `${formData.volume}` : "Not provided"}</p>
//                   </div>
                   
//                    <div>
//                   <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
//                   <div className="space-y-1">
//                     {Array.isArray(formData?.uploadedEvidence) && formData.uploadedEvidence.length > 0
//                       ? formData.uploadedEvidence.map((evidence, index) => (
//                           <div key={index} className="flex justify-between items-center p-2 hover:bg-gray-100 rounded">
//                             <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
//                             <button
//                               className="text-red-500 hover:bg-red-100 rounded-full p-1 transition-colors duration-200"
//                               aria-label={`Remove ${evidence?.name || `File ${index + 1}`}`}
//                             >
//                               X
//                             </button>
//                           </div>
//                         ))
//                       : <p className="text-black"> Not provided</p>}
//                   </div>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             {/* Spill Investigation */}
//             <div className="bg-white rounded-lg border border-gray-300">
//               <h3 className="bg-[#F1F1F1]  px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
//                 Spill Investigation
//                 <div className="flex items-center gap-2">
//                   <img src="/pen.svg" alt="Edit spill investigation" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowSpillInvestigation(prev => !prev)}
//                     className="focus:outline-none"
//                     aria-expanded={showSpillInvestigation}
//                     aria-label="Toggle Spill Investigation"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showSpillInvestigation ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               <div
//                 className={`transition-all duration-300 ease-in-out ${
//                   showSpillInvestigation ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
//                 }`}
//               >
//                 <div className="px-4 py-4 text-sm">
//                   <div className="grid grid-cols-2 gap-4 space-x-2">
//                     <div>
//                       <p className="text-gray-500 text-[12px]">Cause of Spill</p>
//                       <p className="text-black">{formData?.causeOfSpill || "Not provided"}</p>
//                     </div>
//                     <div>
//                       <p className="text-gray-500 text-[12px]">Response Time</p>
//                       <p className="text-black">{formData?.responseTime || "Not provided"}</p>
//                     </div>
//                   </div>
//                   <hr className="border-gray-300 col-span-2 my-2" />
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Area of Impact</p>
//                     <p className="text-black">{formData?.areaOfImpact || "Not provided"}</p>
//                   </div>
//                   <hr className="border-gray-300 col-span-2 my-2" />
//                   <div className="grid grid-cols-2 gap-4">
//                     <div>
//                       <p className="text-gray-500 text-[12px]">Receptors</p>
//                       <p className="text-black">{formData?.receptors || "Not provided"}</p>
//                     </div>
//                     <div>
//                       <p className="text-gray-500 text-[12px]">Risk Level</p>
//                       <p className="text-orange-500 text bg-orange-200 rounded-3xl px-2 py-1 inline-block">
//                         {formData?.riskLevel || "Not provided"}
//                       </p>
//                     </div>
//                   </div>
//                   <hr className="border-gray-300 col-span-2 my-2" />
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Consequence</p>
//                     <p className="text-black">{formData?.consequence || "Not provided"}</p>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             {/* Supporting Information */}
//             <div className="bg-white rounded-lg border border-gray-300">
//               <h3 className="bg-[#F1F1F1]  px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
//                 Supporting Information
//                 <div className="flex items-center gap-2">
//                   <img src="/pen.svg" alt="Edit supporting information" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowSupportingInfo(prev => !prev)}
//                     className="focus:outline-none"
//                     aria-expanded={showSupportingInfo}
//                     aria-label="Toggle Supporting Information"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showSupportingInfo ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               <div
//                 className={`transition-all duration-300 ease-in-out ${
//                   showSupportingInfo ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
//                 }`}
//               >
//                 <div className="px-4 py-4 text-sm ">
//                   <p className="text-gray-500 text-[12px]">Witness Name</p>
//                   <p className="text-black">
//                     {Array.isArray(formData?.witnesses) && formData.witnesses.length > 0
//                       ? formData.witnesses[0]
//                       : "Not provided"}
//                   </p>
//                   {/* <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
//                   <div className="space-y-1">
//                     {Array.isArray(formData?.uploadedEvidence) && formData.uploadedEvidence.length > 0
//                       ? formData.uploadedEvidence.map((evidence, index) => (
//                           <div key={index} className="flex justify-between items-center p-2 hover:bg-gray-100 rounded">
//                             <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
//                             <button
//                               className="text-red-500 hover:bg-red-100 rounded-full p-1 transition-colors duration-200"
//                               aria-label={`Remove ${evidence?.name || `File ${index + 1}`}`}
//                             >
//                               X
//                             </button>
//                           </div>
//                         ))
//                       : <p className="text-black">IMG_0887.jpg, IMG_0888.jpg, Video_034.mp4, Krakama JIV Report.pdf</p>}
//                   </div> */}
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Additional Notes</p>
//                   <p className="text-black">{formData?.additionalNotes || "Not provided"}</p>
//                 </div>
//               </div>
//             </div>

//             {/* Remediation Reports */}
//             <div className="bg-white rounded-lg border border-gray-300">
//               <h3 className="bg-[#F1F1F1]  px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
//                 Remediation Reports
//                 <div className="flex items-center gap-2">
//                   <img src="/pen.svg" alt="Edit remediation reports" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowRemediationReports(prev => !prev)}
//                     className="focus:outline-none"
//                     aria-expanded={showRemediationReports}
//                     aria-label="Toggle Remediation Reports"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showRemediationReports ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               <div
//                 className={`transition-all duration-300 ease-in-out ${
//                   showRemediationReports ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
//                 }`}
//               >
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Tier 1 Report</p>
//                   <p className="text-black">{formData?.remediationReports?.[0] || "Not provided"}</p>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Tier 3 Report</p>
//                   <p className="text-black">{formData?.remediationReports?.[1] || "Not provided"}</p>
//                 </div>
//               </div>
//             </div>


//         </div>

//         {/* Footer */}
//         <div className="flex justify-end items-center px-6 py-4 bg-gray-50 rounded-b-lg space-x-2">
//           <button
//             onClick={handleDownload}
//             className="flex items-center gap-2 px-4 py-2 text-sm bg-white border border-gray-300 rounded hover:bg-gray-100"
//           >
//             <FiDownload className="text-gray-600" />
//             Download as PDF
//           </button>
//           <button
//             onClick={onClose}
//             className="px-4 py-2 text-sm bg-[#1C64F2] text-white rounded hover:bg-[#155cd1]"
//           >
//             Close
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PdfExportModal;



import React, { useState } from 'react'; // Import useState
import jsPDF from 'jspdf';
import { FiDownload } from 'react-icons/fi';

const PdfExportModal = ({ isOpen, onClose, incident, formData }) => {
  // Define state for controlling collapsible sections
  const [showSpillOverview, setShowSpillOverview] = useState(false);
  const [showSpillInvestigation, setShowSpillInvestigation] = useState(false);
  const [showSupportingInfo, setShowSupportingInfo] = useState(false);
  const [showRemediationReports, setShowRemediationReports] = useState(false);

  if (!isOpen) return null;

  const handleDownload = () => {
    const doc = new jsPDF();
    doc.text('Exported PDF content goes here...', 10, 10);
    doc.save('incident_report.pdf');
  };

  return (
    <div
      className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white w-[480px] rounded-[3px] shadow-lg max-h-[90vh] border flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between bg-[#1B5FC1] text-white h-[80px] px-6">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
            <h2 className="text-white text-lg font-semibold">Incident Overview</h2>
          </div>
          <button onClick={onClose} className="text-white text-xl font-bold">
            ×
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="px-6 py-4 text-sm text-gray-800 overflow-y-auto space-y-6 flex-1">
          {/* Officer Details */}
          <div>
            <div className="bg-[#F1F1F1] font-semibold text-gray-800 px-4 py-2 rounded-t-md">
              Reporting Officer Details
            </div>
            <div className="grid grid-cols-2 gap-4 p-4 border border-gray-300 rounded-[3px] text-gray-700 divide-y divide-gray-200">
              <div className="pb-2">
                <p className="text-xs text-gray-500">Name of CLO</p>
                <p>{incident?.cloName || 'Kingsley Tamuno'}</p>
              </div>
              <div className="pb-2">
                <p className="text-xs text-gray-500">OML</p>
                <p>{incident?.oml || 'OML 58'}</p>
              </div>
              <div className="pt-2 pb-2 col-span-1">
                <p className="text-xs text-gray-500">Cluster/Host Community</p>
                <p>{incident?.community || 'Rumueme Community'}</p>
              </div>
              <div className="pt-2 pb-2 col-span-1">
                <p className="text-xs text-gray-500">Company</p>
                <p>{incident?.company || 'NAOC (Nigerian Agip Oil Company)'}</p>
              </div>
              <div className="pt-2 pb-2 col-span-1">
                <p className="text-xs text-gray-500">Date of Report</p>
                <p>{incident?.reportDate || 'N/A'}</p>
              </div>
              <div className="pt-2 pb-2 col-span-1">
                <p className="text-xs text-gray-500">CLO Contact Number</p>
                <p>{incident?.cloPhone || 'N/A'}</p>
              </div>
            </div>
          </div>

          {/* Spill Overview */}
          <div className="bg-white rounded-lg border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
              Spill Overview
              <div className="flex items-center gap-4">
                <img src="/pen.svg" alt="Edit spill overview" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowSpillOverview(prev => !prev)}
                  className="focus:outline-none"
                  aria-expanded={showSpillOverview}
                  aria-label="Toggle Spill Overview"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showSpillOverview ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            <div
              className={`transition-all duration-300 ease-in-out ${
                showSpillOverview ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
              }`}
            >
              <div className="grid grid-cols-2 gap-2 p-4 text-sm space-x-2">
                <div>
                  <p className="text-gray-500 text-[12px]">Date of Spill</p>
                  <p className="text-black">{formData?.spillDate || "Not provided"}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-[12px]">Time of Spill</p>
                  <p className="text-black">{formData?.spillTime || "Not provided"}</p>
                </div>
                <hr className="border-gray-300 col-span-2 my-2" />
                <div>
                  <p className="text-gray-500 text-[12px]">Spill Location</p>
                  <p className="text-black">{formData?.location || "Not provided"}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-[12px]">Source</p>
                  <p className="text-black">{formData?.source || "Not provided"}</p>
                </div>
                <hr className="border-gray-300 col-span-2 my-2" />
                <div>
                  <p className="text-gray-500 text-[12px]">Spill Content</p>
                  <p className="text-black">{formData?.spillType || "Not provided"}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-[12px]">Volume</p>
                  <p className="text-black">{formData?.volume ? `${formData.volume}` : "Not provided"}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                  <div className="space-y-1">
                    {Array.isArray(formData?.uploadedEvidence) && formData.uploadedEvidence.length > 0
                      ? formData.uploadedEvidence.map((evidence, index) => (
                          <div key={index} className="flex justify-between items-center p-2 hover:bg-gray-100 rounded">
                            <span className="text-black">{evidence?.name || `File ${index + 1}`}</span>
                            <button
                              className="text-red-500 hover:bg-red-100 rounded-full p-1 transition-colors duration-200"
                              aria-label={`Remove ${evidence?.name || `File ${index + 1}`}`}
                            >
                              X
                            </button>
                          </div>
                        ))
                      : <p className="text-black">Not provided</p>}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Spill Investigation */}
          <div className="bg-white rounded-lg border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
              Spill Investigation
              <div className="flex items-center gap-2">
                <img src="/pen.svg" alt="Edit spill investigation" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowSpillInvestigation(prev => !prev)}
                  className="focus:outline-none"
                  aria-expanded={showSpillInvestigation}
                  aria-label="Toggle Spill Investigation"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showSpillInvestigation ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            <div
              className={`transition-all duration-300 ease-in-out ${
                showSpillInvestigation ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
              }`}
            >
              <div className="px-4 py-4 text-sm">
                <div className="grid grid-cols-2 gap-4 space-x-2">
                  <div>
                    <p className="text-gray-500 text-[12px]">Cause of Spill</p>
                    <p className="text-black">{formData?.causeOfSpill || "Not provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">Response Time</p>
                    <p className="text-black">{formData?.responseTime || "Not provided"}</p>
                  </div>
                </div>
                <hr className="border-gray-300 col-span-2 my-2" />
                <div>
                  <p className="text-gray-500 text-[12px]">Area of Impact</p>
                  <p className="text-black">{formData?.areaOfImpact || "Not provided"}</p>
                </div>
                <hr className="border-gray-300 col-span-2 my-2" />
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-500 text-[12px]">Receptors</p>
                    <p className="text-black">{formData?.receptors || "Not provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">Risk Level</p>
                    <p className="text-orange-500 text bg-orange-200 rounded-3xl px-2 py-1 inline-block">
                      {formData?.riskLevel || "Not provided"}
                    </p>
                  </div>
                </div>
                <hr className="border-gray-300 col-span-2 my-2" />
                <div>
                  <p className="text-gray-500 text-[12px]">Consequence</p>
                  <p className="text-black">{formData?.consequence || "Not provided"}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Supporting Information */}
          <div className="bg-white rounded-lg border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
              Supporting Information
              <div className="flex items-center gap-2">
                <img src="/pen.svg" alt="Edit supporting information" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowSupportingInfo(prev => !prev)}
                  className="focus:outline-none"
                  aria-expanded={showSupportingInfo}
                  aria-label="Toggle Supporting Information"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showSupportingInfo ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            <div
              className={`transition-all duration-300 ease-in-out ${
                showSupportingInfo ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
              }`}
            >
              <div className="px-4 py-4 text-sm">
                <p className="text-gray-500 text-[12px]">Witness Name</p>
                <p className="text-black">
                  {Array.isArray(formData?.witnesses) && formData.witnesses.length > 0
                    ? formData.witnesses[0]
                    : "Not provided"}
                </p>
                <hr className="border-gray-300 my-2" />
                <p className="text-gray-500 text-[12px]">Additional Notes</p>
                <p className="text-black">{formData?.additionalNotes || "Not provided"}</p>
              </div>
            </div>
          </div>

          {/* Remediation Reports */}
          <div className="bg-white rounded-lg border border-gray-300">
            <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-[3px] flex justify-between items-center text-gray-700 hover:bg-[#c8d8f8] transition-colors duration-200">
              Remediation Reports
              <div className="flex items-center gap-2">
                <img src="/pen.svg" alt="Edit remediation reports" className="w-4 h-4" />
                <button
                  type="button"
                  onClick={() => setShowRemediationReports(prev => !prev)}
                  className="focus:outline-none"
                  aria-expanded={showRemediationReports}
                  aria-label="Toggle Remediation Reports"
                >
                  <svg
                    className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                      showRemediationReports ? "rotate-180" : "rotate-0"
                    }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
            </h3>
            <hr className="border-gray-300" />
            <div
              className={`transition-all duration-300 ease-in-out ${
                showRemediationReports ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0 overflow-hidden"
              }`}
            >
              <div className="px-4 py-4 text-sm">
                <p className="text-gray-500 text-[12px]">Tier 1 Report</p>
                <p className="text-black">{formData?.remediationReports?.[0] || "Not provided"}</p>
                <hr className="border-gray-300 my-2" />
                <p className="text-gray-500 text-[12px]">Tier 3 Report</p>
                <p className="text-black">{formData?.remediationReports?.[1] || "Not provided"}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end items-center px-6 py-4 bg-gray-50 rounded-b-lg space-x-2">
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-white border border-gray-300 rounded hover:bg-gray-100"
          >
            <FiDownload className="text-gray-600" />
            Download as PDF
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm bg-[#1C64F2] text-white rounded hover:bg-[#155cd1]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default PdfExportModal;
