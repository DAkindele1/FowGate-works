
const token = localStorage.getItem("userAccess")

const API_BASE_URL = import.meta.env.VITE_ERP_TURBO_API_BASE_URL

const fetchOptions = async () => {
      try {
        const res = await axios.get(`${API_BASE_URL}/api/oml/incident_reporting/get_default_options`, 
          { headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          }}); 
        if (res.data?.escalation_officers?.length > 0) {
          setOfficers(res.data.escalation_officers);
        }
        if (res.data?.follow_up_actions?.length > 0) {
          setFollowUps(res.data.follow_up_actions);
        }
      } catch (err) {
        console.warn("Using fallback options for officers and follow-up actions.");
      }
    };
    export{fetchOptions}