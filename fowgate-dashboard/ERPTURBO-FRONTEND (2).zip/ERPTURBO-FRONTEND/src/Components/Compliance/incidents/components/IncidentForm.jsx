

// import React, { useState, useEffect, useRef } from "react";
// import Step1Overview from "../../Steps/components/Step1Overview";
// import Step2Details from "../../Steps/components/Step2Details";
// import Step3 from "../../Steps/components/Step3";
// import Step4 from "../../Steps/components/Step4";
// import Step5 from "../../Steps/components/Step5";
// import FinalStep from "../../Steps/components/FinalStep";
// import ConfirmationPage from "../../Steps/components/ConfirmationPage";
// import SuccessPage from "../../Steps/components/SuccessPage";
// import axios from "axios";

// function IncidentForm({ onSubmit, onClose }) {
//   const fileInputRef = useRef(null);
//   const [step, setStep] = useState(1);
//   const [formData, setFormData] = useState(() => {
//     const savedFile = sessionStorage.getItem("step4_file");
//     return {
//       incidentType: "",
//       dateOfIncident: "",
//       timeOfIncident: "",
//       communityAffected: "",
//       peopleInvolved: [],
//       stakeholderRole: "",
//       numberOfPeopleInvolved: "",
//       actionTaken: [],
//       cloResponseDetails: "",
//       witnesses: [{ title: "", name: "", phone: "" }],
//       additionalNotes: "",
//       cloName: "",
//       followUpAction: [],
//       signature: null,
//       reportDate: "",
//       incident: {
//         attachment: savedFile ? JSON.parse(savedFile) : null,
//       },
//       attachmentCount: savedFile ? "1" : "",
//       oml: "",
//       hostCommunity: "",
//       company: "",
//       cloPhone: "",
//       location: "",
//     };
//   });
//   const [referenceId, setReferenceId] = useState("");
//   const [submittedIncident, setSubmittedIncident] = useState(null);
//   const [isLoading, setIsLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const token = localStorage.getItem("userAccess");

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     if (name === "incident.attachment") {
//       console.log("Attachment changed:", {
//         isFile: value instanceof File,
//         name: value?.name,
//         type: value?.type,
//         size: value?.size,
//       }); // Enhanced debug
//       setFormData((prev) => {
//         const newFormData = {
//           ...prev,
//           incident: {
//             ...prev.incident,
//             attachment: value,
//           },
//           attachmentCount: value ? "1" : "",
//         };
//         if (!value) {
//           sessionStorage.removeItem("step4_file");
//           if (fileInputRef.current) {
//             fileInputRef.current.value = "";
//           }
//         } else if (value instanceof File) {
//           sessionStorage.setItem("step4_file", JSON.stringify({ name: value.name, type: value.type }));
//         }
//         return newFormData;
//       });
//     } else if (name.startsWith("incident.")) {
//       const key = name.split(".")[1];
//       setFormData((prev) => ({
//         ...prev,
//         incident: {
//           ...prev.incident,
//           [key]: value,
//         },
//       }));
//     } else {
//       setFormData((prev) => ({ ...prev, [name]: value }));
//     }
//   };

//   const handleNext = () => {
//     const validationError = validateFormData(step);
//     if (validationError) {
//       setError(validationError);
//       return;
//     }
//     setError(null);
//     setStep((prev) => prev + 1);
//   };

//   const handleBack = () => setStep((prev) => prev - 1);

//   const handleFinalSubmit = () => setStep(7);

//   const handleCancel = () => {
//     sessionStorage.removeItem("step4_file");
//     setFormData((prev) => ({
//       ...prev,
//       incident: { ...prev.incident, attachment: null },
//       attachmentCount: "",
//     }));
//     if (fileInputRef.current) {
//       fileInputRef.current.value = "";
//     }
//     setStep(6);
//   };

//   const validateFormData = (currentStep) => {
//     if (currentStep >= 1) {
//       if (!formData.incidentType) return "Incident type is required.";
//       if (!formData.dateOfIncident) return "Date of incident is required.";
//       if (!formData.timeOfIncident) return "Time of incident is required.";
//       if (!formData.communityAffected) return "Community affected is required.";
//     }
//     if (currentStep >= 2) {
//       if (!formData.peopleInvolved?.length) return "People involved is required.";
//       if (!formData.stakeholderRole) return "Stakeholder role is required.";
//       if (!formData.numberOfPeopleInvolved) return "Number of people involved is required.";
//     }
//     if (currentStep >= 3) {
//       if (!formData.actionTaken?.length) return "Actions taken is required.";
//       if (!formData.cloResponseDetails) return "CLO response is required.";
//     }
//     if (currentStep >= 4) {
//       if (!formData.witnesses?.length || !formData.witnesses[0].name) return "At least one witness name is required.";
//     }
//     if (currentStep >= 5) {
//       if (!formData.cloName) return "Report submitted to is required.";
//       if (!formData.followUpAction?.length) return "Follow-up actions are required.";
//       if (!formData.reportDate) return "Report date is required.";
//     }
//     return null;
//   };

//   const handleConfirmSubmit = async () => {
//     if (!token) {
//       setError("Authentication token is missing. Please log in.");
//       setStep(6);
//       return;
//     }

//     setIsLoading(true);
//     const formDataPayload = new FormData();
//     const payload = {
//       type: Array.isArray(formData.incidentType) ? formData.incidentType : [formData.incidentType || "Unknown"],
//       date: formData.dateOfIncident || "2025-07-08",
//       time: formData.timeOfIncident || "13:58",
//       community_affected: formData.communityAffected || "Unknown",
//       people_involved: Array.isArray(formData.peopleInvolved) ? formData.peopleInvolved : [""],
//       stakeholder_role: formData.stakeholderRole || "Unknown",
//       number_of_people_involved: Number(formData.numberOfPeopleInvolved) || 0,
//       actions_taken: Array.isArray(formData.actionTaken) ? formData.actionTaken : [""],
//       clo_response: formData.cloResponseDetails || "",
//       witnesses: Array.isArray(formData.witnesses)
//         ? formData.witnesses.map((w) => ({
//             name: `${w.title ? w.title + " " : ""}${w.name || ""}`.trim() || "Unknown",
//             phone_num: w.phone || "",
//           }))
//         : [{ name: "Unknown", phone_num: "" }],
//       additional_notes: formData.additionalNotes || "",
//       submitted_to: formData.cloName || "Safety Department",
//       follow_up_actions: Array.isArray(formData.followUpAction) ? formData.followUpAction : [""],
//       signature: !!formData.signature,
//       report_date: formData.reportDate || "2025-07-08",
//       oml: formData.oml || "",
//       host_community: formData.hostCommunity || "",
//       company: formData.company || "",
//       clo_phone: formData.cloPhone || "",
//       location: formData.location || "",
//     };

//     formDataPayload.append("incident", JSON.stringify(payload));

//     if (formData.incident?.attachment) {
//       try {
//         if (formData.incident.attachment instanceof File) {
//           formDataPayload.append("file", formData.incident.attachment);
//           console.log("Uploading file:", {
//             name: formData.incident.attachment.name,
//             type: formData.incident.attachment.type,
//             size: formData.incident.attachment.size,
//           }); // Enhanced debug
//         } else {
//           console.warn("Attachment is not a valid File object:", formData.incident.attachment);
//           setError("Invalid attachment format. Please select a valid file.");
//           setIsLoading(false);
//           setStep(6);
//           return;
//         }
//       } catch (error) {
//         console.error("Failed to process file attachment:", error);
//         setError("Failed to process file attachment. Continuing without file.");
//       }
//     } else {
//       console.log("No attachment provided for upload"); // Debug
//     }

//     if (formData.signature && typeof formData.signature === "string") {
//       try {
//         const base64Data = formData.signature.includes("base64,")
//           ? formData.signature.split("base64,")[1]
//           : formData.signature;
//         if (base64Data) {
//           const binaryString = atob(base64Data);
//           const bytes = new Uint8Array(binaryString.length);
//           for (let i = 0; i < binaryString.length; i++) {
//             bytes[i] = binaryString.charCodeAt(i);
//           }
//           formDataPayload.append(
//             "signature",
//             new Blob([bytes], { type: "image/png" }),
//             "signature.png"
//           );
//           console.log("Uploading signature"); // Debug
//         }
//       } catch (error) {
//         console.error("Failed to process signature:", error);
//         setError("Failed to process signature. Continuing without signature.");
//       }
//     }

//     try {
//       console.log("Sending FormData payload:", {
//         incident: payload,
//         hasFile: !!formData.incident?.attachment,
//         hasSignature: !!formData.signature,
//       }); // Debug
//       const response = await axios.post(
//         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//         formDataPayload,
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );

//       // Normalize incident for table compatibility
//       const savedIncident = {
//         ...payload,
//         id: response.data.incident_code || `INC${Date.now()}`,
//         incidentType: payload.type[0] || "Unknown",
//         communityAffected: payload.community_affected,
//         attachment: response.data.attachment_url ? { name: formData.incident?.attachment?.name || response.data.attachment_url.split("/").pop() || "File" } : null,
//         attachment_url: response.data.attachment_url || "",
//         attachment_count: formData.incident?.attachment ? 1 : 0, // Set attachment_count
//         status: response.data.status || "Unresolved",
//         dateReported: `${formData.dateOfIncident} ${formData.timeOfIncident}`,
//         signature_url: response.data.signature_url || "",
//       };

//       console.log("Create incident response:", JSON.stringify(response.data, null, 2)); // Debug
//       console.log("Saved incident:", JSON.stringify(savedIncident, null, 2)); // Debug

//       sessionStorage.removeItem("step4_file");
//       setFormData((prev) => ({
//         ...prev,
//         incident: { ...prev.incident, attachment: null },
//         attachmentCount: "",
//       }));
//       if (fileInputRef.current) {
//         fileInputRef.current.value = "";
//       }
//       setReferenceId(response.data.incident_code);
//       setSubmittedIncident(savedIncident);
//       onSubmit(savedIncident);
//       setStep(8);
//     } catch (error) {
//       console.error("Submission error:", error.response?.data || error.message);
//       const errorMessage =
//         error.response?.status === 401
//           ? "Unauthorized: Please log in again."
//           : error.response?.data?.message || "Failed to submit incident. Please check your network or try again.";
//       setError(errorMessage);
//       setStep(6);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const handleSuccessClose = () => {
//     sessionStorage.removeItem("step4_file");
//     setFormData((prev) => ({
//       ...prev,
//       incident: { ...prev.incident, attachment: null },
//       attachmentCount: "",
//     }));
//     if (fileInputRef.current) {
//       fileInputRef.current.value = "";
//     }
//     if (submittedIncident) {
//       onSubmit(submittedIncident);
//     }
//     onClose();
//   };

//   useEffect(() => {
//     if (!token) {
//       setError("Authentication token is missing. Please log in.");
//     }
//     return () => {
//       sessionStorage.removeItem("step4_file");
//     };
//   }, [token]);

//   return (
//     <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-30">
//       <div className="bg-white w-full max-w-md rounded-md shadow-lg overflow-hidden">
//         {error && step !== 8 && (
//           <div className="text-red-500 text-sm p-4">{error}</div>
//         )}
//         {step === 1 && (
//           <Step1Overview
//             formData={formData}
//             onChange={handleChange}
//             onNext={handleNext}
//             onClose={onClose}
//           />
//         )}
//         {step === 2 && (
//           <Step2Details
//             formData={formData}
//             onChange={handleChange}
//             onNext={handleNext}
//             onBack={handleBack}
//             onClose={onClose}
//           />
//         )}
//         {step === 3 && (
//           <Step3
//             formData={formData}
//             onChange={handleChange}
//             onNext={handleNext}
//             onBack={handleBack}
//             onClose={onClose}
//           />
//         )}
//         {step === 4 && (
//           <Step4
//             formData={formData}
//             onChange={handleChange}
//             onNext={handleNext}
//             onBack={handleBack}
//             onClose={onClose}
//             fileInputRef={fileInputRef}
//           />
//         )}
//         {step === 5 && (
//           <Step5
//             formData={formData}
//             onChange={handleChange}
//             onNext={handleNext}
//             onBack={handleBack}
//             onClose={onClose}
//           />
//         )}
//         {step === 6 && (
//           <FinalStep
//             formData={formData}
//             onChange={handleChange}
//             onSubmit={handleFinalSubmit}
//             onBack={handleBack}
//             onEdit={() => setStep(1)}
//           />
//         )}
//         {step === 7 && (
//           <ConfirmationPage
//             formData={formData}
//             onConfirmSubmit={handleConfirmSubmit}
//             onBack={handleCancel}
//             onClose={handleCancel}
//           />
//         )}
//         {step === 8 && (
//           <SuccessPage
//             incidentId={referenceId}
//             onClose={handleSuccessClose}
//           />
//         )}
//         {isLoading && (
//           <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-60">
//             <div className="text-white">Loading...</div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default IncidentForm;











import React, { useState, useEffect, useRef } from "react";
import Step1Overview from "../../Steps/components/Step1Overview";
import Step2Details from "../../Steps/components/Step2Details";
import Step3 from "../../Steps/components/Step3";
import Step4 from "../../Steps/components/Step4";
import Step5 from "../../Steps/components/Step5";
import FinalStep from "../../Steps/components/FinalStep";
import ConfirmationPage from "../../Steps/components/ConfirmationPage";
import SuccessPage from "../../Steps/components/SuccessPage";
import axios from "axios";
import toast from "react-hot-toast";

function IncidentForm({ onSubmit, onClose }) {
  const fileInputRef = useRef(null);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState(() => {
    const savedFile = sessionStorage.getItem("step4_file");
    return {
      incidentType: "",
      dateOfIncident: "",
      timeOfIncident: "",
      communityAffected: "",
      peopleInvolved: [],
      stakeholderRole: "",
      numberOfPeopleInvolved: "",
      actionTaken: [],
      cloResponseDetails: "",
      witnesses: [{ title: "", name: "", phone: "" }],
      additionalNotes: "",
      cloName: "",
      followUpAction: [],
      signature: null,
      reportDate: "",
      incident: {
        attachment: savedFile ? JSON.parse(savedFile) : null,
      },
      attachmentCount: savedFile ? "1" : "",
      oml: "",
      hostCommunity: "",
      company: "",
      cloPhone: "",
      location: "",
    };
  });
  const [referenceId, setReferenceId] = useState("");
  const [submittedIncident, setSubmittedIncident] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const token = localStorage.getItem("userAccess");

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "incident.attachment") {
      setFormData((prev) => {
        const newFormData = {
          ...prev,
          incident: {
            ...prev.incident,
            attachment: value,
          },
          attachmentCount: value ? "1" : "",
        };
        if (!value) {
          sessionStorage.removeItem("step4_file");
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
        } else if (value instanceof File) {
          sessionStorage.setItem("step4_file", JSON.stringify({ name: value.name, type: value.type }));
        }
        return newFormData;
      });
    } else if (name.startsWith("incident.")) {
      const key = name.split(".")[1];
      setFormData((prev) => ({
        ...prev,
        incident: {
          ...prev.incident,
          [key]: value,
        },
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleNext = () => {
    const validationError = validateFormData(step);
    if (validationError) {
      setError(validationError);
      toast.error(validationError);
      return;
    }
    setError(null);
    setStep((prev) => prev + 1);
  };

  const handleBack = () => setStep((prev) => prev - 1);

  const handleFinalSubmit = () => {
    const validationError = validateFormData(6);
    if (validationError) {
      setError(validationError);
      toast.error(validationError);
      return;
    }
    setError(null);
    setStep(7);
  };

  const handleCancel = () => {
    sessionStorage.removeItem("step4_file");
    setFormData((prev) => ({
      ...prev,
      incident: { ...prev.incident, attachment: null },
      attachmentCount: "",
    }));
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setStep(6);
  };

  const validateFormData = (currentStep) => {
    if (currentStep >= 1) {
      if (!formData.incidentType) return "Incident type is required.";
      if (!formData.dateOfIncident) return "Date of incident is required.";
      if (!formData.timeOfIncident) return "Time of incident is required.";
      if (!formData.communityAffected) return "Community affected is required.";
    }
    if (currentStep >= 2) {
      if (!formData.peopleInvolved?.length) return "People involved is required.";
      if (!formData.stakeholderRole) return "Stakeholder role is required.";
      if (!formData.numberOfPeopleInvolved) return "Number of people involved is required.";
    }
    if (currentStep >= 3) {
      if (!formData.actionTaken?.length) return "Actions taken is required.";
      if (!formData.cloResponseDetails) return "CLO response is required.";
    }
    if (currentStep >= 4) {
      if (!formData.witnesses?.length || !formData.witnesses[0].name) return "At least one witness name is required.";
    }
    if (currentStep >= 5) {
      if (!formData.cloName) return "Report submitted to is required.";
      if (!formData.followUpAction?.length) return "Follow-up actions are required.";
      if (!formData.reportDate) return "Report date is required.";
      if (!formData.signature) return "Signature is required.";
    }
    return null;
  };

  const handleConfirmSubmit = async () => {
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      setStep(6);
      return;
    }

    setIsLoading(true);
    const formDataPayload = new FormData();
    const payload = {
      type: Array.isArray(formData.incidentType) ? formData.incidentType : [formData.incidentType || "Unknown"],
      date: formData.dateOfIncident || "2025-07-09",
      time: formData.timeOfIncident || "16:59",
      community_affected: formData.communityAffected || "Unknown",
      people_involved: Array.isArray(formData.peopleInvolved) ? formData.peopleInvolved : [""],
      stakeholder_role: formData.stakeholderRole || "Unknown",
      number_of_people_involved: Number(formData.numberOfPeopleInvolved) || 0,
      actions_taken: Array.isArray(formData.actionTaken) ? formData.actionTaken : [""],
      clo_response: formData.cloResponseDetails || "",
      witnesses: Array.isArray(formData.witnesses)
        ? formData.witnesses.map((w) => ({
            name: `${w.title ? w.title + " " : ""}${w.name || ""}`.trim() || "Unknown",
            phone_num: w.phone || "",
          }))
        : [{ name: "Unknown", phone_num: "" }],
      additional_notes: formData.additionalNotes || "",
      submitted_to: formData.cloName || "Safety Department",
      follow_up_actions: Array.isArray(formData.followUpAction) ? formData.followUpAction : [formData.followUpAction || ""],
      signature: !!formData.signature,
      report_date: formData.reportDate || "2025-07-09",
      oml: formData.oml || "",
      host_community: formData.hostCommunity || "",
      company: formData.company || "",
      clo_phone: formData.cloPhone || "",
      location: formData.location || "",
    };

    formDataPayload.append("data", JSON.stringify(payload));

    if (formData.incident?.attachment) {
      try {
        if (formData.incident.attachment instanceof File) {
          formDataPayload.append("document", formData.incident.attachment);
        } else {
          setError("Invalid attachment format. Please select a valid file.");
          toast.error("Invalid attachment format. Please select a valid file.");
          setIsLoading(false);
          setStep(6);
          return;
        }
      } catch (error) {
        console.error("Failed to process file attachment:", error);
        setError("Failed to process file attachment. Continuing without file.");
        toast.error("Failed to process file attachment. Continuing without file.");
      }
    }

    if (formData.signature && typeof formData.signature === "string") {
      try {
        const base64Data = formData.signature.includes("base64,")
          ? formData.signature.split("base64,")[1]
          : formData.signature;
        if (base64Data) {
          const binaryString = atob(base64Data);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          formDataPayload.append(
            "signature",
            new Blob([bytes], { type: "image/png" }),
            "signature.png"
          );
        }
      } catch (error) {
        console.error("Failed to process signature:", error);
        setError("Failed to process signature. Continuing without signature.");
        toast.error("Failed to process signature. Continuing without signature.");
      }
    }

    try {
      
      const response = await axios.post(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
        formDataPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const savedIncident = {
        ...payload,
        id: response.data.incident_code || `INC${Date.now()}`,
        incidentType: payload.type[0] || "Unknown",
        communityAffected: payload.community_affected,
        attachment: response.data.attachment_url
          ? { name: formData.incident?.attachment?.name || response.data.attachment_url.split("/").pop() || "File" }
          : null,
        attachment_url: response.data.attachment_url || "",
        attachment_count: formData.incident?.attachment ? 1 : 0,
        status: response.data.status || "Unresolved",
        dateReported: `${formData.dateOfIncident} ${formData.timeOfIncident}`,
        signature_url: response.data.signature_url || formData.signature || "",
      };

      sessionStorage.removeItem("step4_file");
      setFormData((prev) => ({
        ...prev,
        incident: { ...prev.incident, attachment: null },
        attachmentCount: "",
      }));
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      setReferenceId(response.data.incident_code);
      setSubmittedIncident(savedIncident);
      onSubmit(savedIncident);
      setStep(8);
    } catch (error) {
      const errorMessage =
        error.response?.status === 401
          ? "Unauthorized: Please log in again."
          : error.response?.data?.message || "Failed to submit incident. Please check your network or try again.";
      setError(errorMessage);
      toast.error(errorMessage);
      setStep(6);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuccessClose = () => {
    sessionStorage.removeItem("step4_file");
    setFormData((prev) => ({
      ...prev,
      incident: { ...prev.incident, attachment: null },
      attachmentCount: "",
    }));
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    if (submittedIncident) {
      onSubmit(submittedIncident);
    }
    onClose();
  };

  useEffect(() => {
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
    }
    return () => {
      sessionStorage.removeItem("step4_file");
    };
  }, [token]);

  return ( 
    <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-30">
      <div className="bg-white w-full max-w-md rounded-md shadow-lg overflow-hidden">
        {error && step !== 8 && (
          <div className="text-red-500 text-sm p-4">{error}</div>
        )}
        {step === 1 && (
          <Step1Overview
            formData={formData}
            onChange={handleChange}
            onNext={handleNext}
            onClose={onClose}
          />
        )}
        {step === 2 && (
          <Step2Details
            formData={formData}
            onChange={handleChange}
            onNext={handleNext}
            onBack={handleBack}
            onClose={onClose}
          />
        )}
        {step === 3 && (
          <Step3
            formData={formData}
            onChange={handleChange}
            onNext={handleNext}
            onBack={handleBack}
            onClose={onClose}
          />
        )}
        {step === 4 && (
          <Step4
            formData={formData}
            onChange={handleChange}
            onNext={handleNext}
            onBack={handleBack}
            onClose={onClose}
            fileInputRef={fileInputRef}
          />
        )}
        {step === 5 && (
          <Step5
            formData={formData}
            onChange={handleChange}
            onNext={handleNext}
            onBack={handleBack}
            onClose={onClose}
          />
        )}
        {step === 6 && (
          <FinalStep
            formData={formData}
            onChange={handleChange}
            onSubmit={handleFinalSubmit}
            onBack={handleBack}
            onClose={onClose}
          />
        )}
        {step === 7 && (
          <ConfirmationPage
            formData={formData}
            onConfirmSubmit={handleConfirmSubmit}
            onBack={handleCancel}
            onClose={handleCancel}
          />
        )}
        {step === 8 && (
          <SuccessPage
            incidentId={referenceId}
            onClose={handleSuccessClose}
          />
        )}
        {isLoading && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-60">
            <div className="text-white">Loading...</div>
          </div>
        )}
      </div>
    </div>
  );
}

export default IncidentForm;












