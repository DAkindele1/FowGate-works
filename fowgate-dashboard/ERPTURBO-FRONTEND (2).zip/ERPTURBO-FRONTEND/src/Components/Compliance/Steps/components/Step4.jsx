

// import React, { useRef, useState, useEffect } from "react";
// import axios from "axios";
// import DOMPurify from "dompurify";

// const FileUpload = ({ value, onChange, fileInputRef }) => {
//   const [error, setError] = useState(null);

//   const validateFile = (file) => {
//     const maxSize = 5 * 1024 * 1024; // 5MB
//     const allowedTypes = [
//       "image/jpeg",
//       "image/png",
//       "image/gif",
//       "video/mp4",
//       "video/mpeg",
//       "audio/mpeg",
//       "audio/wav",
//       "application/pdf",
//       "application/msword",
//       "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//     ];

//     if (!file) {
//       setError("No file selected.");
//       return false;
//     }
//     if (file.size > maxSize) {
//       setError("File size exceeds 5MB limit.");
//       return false;
//     }
//     if (!allowedTypes.includes(file.type)) {
//       setError("Invalid file type. Allowed: Images, Video, Audio, Documents.");
//       return false;
//     }
//     setError(null);
//     return true;
//   };

//   const handleBrowseClick = (e) => {
//     e.preventDefault();
//     fileInputRef.current.click();
//   };

//   const handleInputChange = (e) => {
//     const file = e.target.files?.[0];
//     console.log("File selected:", {
//       name: file?.name,
//       type: file?.type,
//       size: file?.size,
//       valid: file ? validateFile(file) : false,
//     }); // Debug
//     if (file && validateFile(file)) {
//       onChange?.({ target: { name: "incident.attachment", value: file } });
//       sessionStorage.setItem("step4_file", JSON.stringify({ name: file.name, type: file.type }));
//     }
//   };

//   const handleDrop = (e) => {
//     e.preventDefault();
//     e.stopPropagation();
//     const file = e.dataTransfer.files?.[0];
//     console.log("File dropped:", {
//       name: file?.name,
//       type: file?.type,
//       size: file?.size,
//       valid: file ? validateFile(file) : false,
//     }); // Debug
//     if (file && validateFile(file)) {
//       onChange?.({ target: { name: "incident.attachment", value: file } });
//       sessionStorage.setItem("step4_file", JSON.stringify({ name: file.name, type: file.type }));
//     }
//   };

//   const handleDragOver = (e) => {
//     e.preventDefault();
//     e.stopPropagation();
//   };

//   const handleRemoveFile = () => {
//     console.log("Removing file:", value?.name); // Debug
//     onChange?.({ target: { name: "incident.attachment", value: null } });
//     sessionStorage.removeItem("step4_file");
//     if (fileInputRef.current) {
//       fileInputRef.current.value = "";
//     }
//     setError(null);
//   };

//   return (
//     <div
//       className="mt-0 flex justify-center px-6 pt-5 pb-6 border-2 border-[#1B5FC1] border-dashed rounded-md bg-blue-50"
//       onDragOver={handleDragOver}
//       onDrop={handleDrop}
//     >
//       <div className="space-y-1 text-center">
//         <img src="/upload.svg" alt="upload" width={40} height={20} className="mx-auto h-12 w-12" />
//         <div className="flex text-sm text-gray-600 justify-center">
//           <span className="mr-1 font-bold">Drag and drop file or</span>
//           <a href="#" className="text-blue-600 underline font-bold" onClick={handleBrowseClick}>
//             Browse
//           </a>
//         </div>
//         <p className="text-xs text-gray-500">Images, Video, Audio, Documents – Max 5MB</p>
//         <input
//           type="file"
//           ref={fileInputRef}
//           className="hidden"
//           accept="image/jpeg,image/png,image/gif,video/mp4,video/mpeg,audio/mpeg,audio/wav,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
//           onChange={handleInputChange}
//         />
//         {value && (
//           <div className="mt-2 text-xs text-gray-600">
//             <p>Selected: {value.name}</p>
//             <button
//               type="button"
//               onClick={handleRemoveFile}
//               className="text-blue-500 hover:underline"
//             >
//               Remove File
//             </button>
//           </div>
//         )}
//         {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
//       </div>
//     </div>
//   );
// };

// function Step4({ formData, onChange, onNext, onBack, onClose, fileInputRef }) {
//   const token = localStorage.getItem("userAccess");
//   const contentEditableRef = useRef(null);
//   const [charCount, setCharCount] = useState(formData.additionalNotes?.length || 0);
//   const [witnessTitles, setWitnessTitles] = useState(["Mr", "Mrs", "Ms", "Dr"]);
//   const [phoneError, setPhoneError] = useState("");
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchOptions = async () => {
//       if (!token) {
//         setError("Authentication token is missing. Please log in.");
//         return;
//       }
//       try {
//         const res = await axios.get(
//           "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//           {
//             headers: {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         if (res.data?.witness_titles?.length > 0) {
//           setWitnessTitles(res.data.witness_titles);
//         }
//       } catch (err) {
//         console.warn("Using default witness titles due to API failure");
//         setError("Failed to load witness titles. Using default options.");
//       }
//     };

//     fetchOptions();
//   }, [token]);

//   const handleFormat = (command, value = null) => {
//     document.execCommand(command, false, value);
//     handleContentChange();
//   };

//   const handleContentChange = () => {
//     const text = contentEditableRef.current.textContent;
//     const html = DOMPurify.sanitize(contentEditableRef.current.innerHTML);
//     setCharCount(text.length);
//     onChange({
//       target: {
//         name: "additionalNotes",
//         value: html,
//       },
//     });
//   };

//   const handlePhoneChange = (index, value) => {
//     const cleanedValue = value.replace(/\D/g, "");
//     const newWitnesses = [...(formData.witnesses || [])];
//     newWitnesses[index] = { ...newWitnesses[index], phone: cleanedValue };
//     onChange({ target: { name: "witnesses", value: newWitnesses } });
//     if (cleanedValue.length === 11) {
//       setPhoneError("");
//     } else {
//       setPhoneError("Phone number must be exactly 11 digits");
//     }
//   };

//   const handleWitnessChange = (index, field, value) => {
//     const newWitnesses = [...(formData.witnesses || [])];
//     newWitnesses[index] = { ...newWitnesses[index], [field]: value };
//     onChange({ target: { name: "witnesses", value: newWitnesses } });
//   };

//   const handleAddWitness = () => {
//     const newWitnesses = formData.witnesses
//       ? [...formData.witnesses, { title: "", name: "", phone: "" }]
//       : [{ title: "", name: "", phone: "" }];
//     onChange({ target: { name: "witnesses", value: newWitnesses } });
//   };

//   const handleRemoveWitness = (index) => {
//     const newWitnesses = formData.witnesses.filter((_, i) => i !== index);
//     onChange({ target: { name: "witnesses", value: newWitnesses } });
//   };

//   const handleNextClick = () => {
//     if (!formData.witnesses || formData.witnesses.length === 0 || !formData.witnesses[0].name) {
//       setError("Please add at least one witness with a name.");
//       return;
//     }
//     if (formData.witnesses.some((w) => w.phone && w.phone.length !== 11)) {
//       setError("All phone numbers must be exactly 11 digits.");
//       return;
//     }
//     setError(null);
//     onNext();
//   };

//   useEffect(() => {
//     if (!formData.witnesses || formData.witnesses.length === 0) {
//       onChange({ target: { name: "witnesses", value: [{ title: "", name: "", phone: "" }] } });
//     }
//   }, [formData.witnesses, onChange]);

//   return (
//     <div className="h-[575px] flex flex-col rounded-md overflow-hidden">
//       {/* Header */}
//       <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
//         <div className="flex items-center space-x-2">
//           <img src="/add.svg" alt="add" width={20} height={20} />
//           <h2 className="text-white text-lg font-semibold">Add New</h2>
//         </div>
//         <button onClick={onClose} className="text-white">
//           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//           </svg>
//         </button>
//       </div>

//       <div className="flex-1 overflow-y-auto space-y-6">
//         <div className="text-sm text-gray-200 flex p-6 items-center -mt-2">
//           <span className="w-4 h-4 flex items-center justify-center mr-2">
//             <img src="/four.svg" alt="four" width={20} height={20} />
//           </span>
//           <span className="text-black">
//             4/6 - <span className="font-bold">SUPPORTING INFORMATION</span>
//           </span>
//         </div>
//         <hr className="border-t -mt-6 border-gray-100 my-3" />

//         {/* Error Message */}
//         {error && (
//           <div className="text-red-500 text-sm mb-4 px-6">{error}</div>
//         )}

//         <form className="space-y-6">
//           {/* Witness Info */}
//           <div className="mt-4">
//             <div className="flex space-x-4 p-6 -mt-6">
//               <div className="w-full">
//                 {formData.witnesses &&
//                   formData.witnesses.map((witness, index) => (
//                     <div key={index} className="flex space-x-4 mb-4 items-center">
//                       <div className="w-1/4">
//                         <label className="block text-sm text-gray-700 mb-1">Title</label>
//                         <select
//                           value={witness.title || ""}
//                           onChange={(e) => handleWitnessChange(index, "title", e.target.value)}
//                           className="block w-full border border-gray-300 rounded-[3px] p-2 text-[15px] focus:outline-none focus:ring-1 focus:ring-blue-500"
//                         >
//                           <option value="">Select</option>
//                           {witnessTitles.map((title, idx) => (
//                             <option key={idx} value={title}>{title}</option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="w-2/4">
//                         <label className="block text-sm text-gray-700 mb-1">
//                           Witness Name {index + 1} <span className="text-red-500">*</span>
//                         </label>
//                         <input
//                           type="text"
//                           value={witness.name || ""}
//                           onChange={(e) => handleWitnessChange(index, "name", e.target.value)}
//                           className="block w-full border border-gray-300 rounded-[3px] p-2 text-[15px] focus:outline-none focus:ring-1 focus:ring-blue-500"
//                           placeholder="Name"
//                           required
//                         />
//                       </div>
//                       <div className="w-2/4">
//                         <label className="block text-sm text-gray-700 mb-1">Mobile Number {index + 1}</label>
//                         <div className="flex rounded-[3px] overflow-hidden border border-gray-300">
//                           <div className="w-px bg-gray-300" />
//                           <input
//                             type="tel"
//                             value={witness.phone || ""}
//                             onChange={(e) => handlePhoneChange(index, e.target.value)}
//                             className={`flex-1 px-3 py-2 text-[15px] text-gray-900 focus:outline-none focus:ring-1 focus:ring-blue-500 ${
//                               phoneError && witness.phone && witness.phone.length !== 11 ? "border-red-500" : ""
//                             }`}
//                             placeholder="12345678901"
//                             pattern="[0-9]{11}"
//                             maxLength="11"
//                             inputMode="numeric"
//                           />
//                         </div>
//                       </div>
//                       {index > 0 && (
//                         <button
//                           type="button"
//                           onClick={() => handleRemoveWitness(index)}
//                           className="text-red-500 hover:text-red-700 text-xs w-4 h-4 flex items-center justify-center ml-2"
//                         >
//                           ×
//                         </button>
//                       )}
//                     </div>
//                   ))}
//               </div>
//             </div>
//             <div className="flex justify-end px-6 -mt-2">
//               <button
//                 type="button"
//                 onClick={handleAddWitness}
//                 className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
//               >
//                 <span className="mr-1">+</span> Add Witness
//               </button>
//             </div>
//             {phoneError && <p className="text-xs text-red-500 mt-1 px-6">{phoneError}</p>}
//           </div>

//           {/* Upload Evidence */}
//           <div className="-mt-8 p-4">
//             <label className="block text-sm text-gray-700">Upload Evidence</label>
//             <FileUpload
//               value={formData.incident?.attachment || null}
//               onChange={onChange}
//               fileInputRef={fileInputRef}
//             />
//           </div>

//           {/* Additional Notes */}
//           <div className="-mt-10 p-4">
//             <label className="block text-sm text-gray-700">Additional Notes</label>
//             <div className="relative mt-1">
//               <div
//                 ref={contentEditableRef}
//                 contentEditable
//                 onInput={handleContentChange}
//                 className="block w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[100px]"
//                 dangerouslySetInnerHTML={{ __html: formData.additionalNotes || "" }}
//               />
//               <div className="absolute bottom-2 left-2 flex space-x-1 text-xs">
//                 <button type="button" className="p-0.5 rounded font-bold" onClick={() => handleFormat("bold")}>
//                   <img src="/bold.svg" alt="bold" width={20} height={20} />
//                 </button>
//                 <button type="button" className="p-0.5 rounded italic" onClick={() => handleFormat("italic")}>
//                   <img src="/italic.svg" alt="italic" width={20} height={20} />
//                 </button>
//                 <button type="button" className="p-0.5 rounded underline" onClick={() => handleFormat("underline")}>
//                   <img src="/under.svg" alt="under" width={20} height={20} />
//                 </button>
//                 <button type="button" className="p-0.5 rounded" onClick={() => handleFormat("insertOrderedList")}>
//                   <img src="/num.svg" alt="num" width={20} height={20} />
//                 </button>
//                 <button type="button" className="p-0.5 rounded" onClick={() => handleFormat("insertUnorderedList")}>
//                   <img src="/item.png" alt="item" width={20} height={20} />
//                 </button>
//               </div>
//               <span className="absolute bottom-2 right-2 text-sm text-gray-500">{charCount}/1500</span>
//             </div>
//           </div>
//         </form>
//       </div>

//       <div className="flex justify-end space-x-4 p-4 bg-white shadow-[0_-1px_3px_rgba(0,0,0,0.15)] w-full">
//         <button
//           type="button"
//           onClick={onBack}
//           className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
//         >
//           Prev
//         </button>
//         <button
//           type="button"
//           onClick={handleNextClick}
//           className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
//         >
//           Next
//         </button>
//       </div>
//     </div>
//   );
// }

// export default Step4;










import React, { useRef, useState, useEffect } from "react";
import axios from "axios";
import DOMPurify from "dompurify";
import toast from "react-hot-toast";

const FileUpload = ({ value, onChange, fileInputRef }) => {
  const [error, setError] = useState(null);

  const validateFile = (file) => {
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "video/mp4",
      "video/mpeg",
      "audio/mpeg",
      "audio/wav",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];

    if (!file) {
      setError("No file selected.");
      return false;
    }
    if (file.size > maxSize) {
      setError("File size exceeds 5MB limit.");
      return false;
    }
    if (!allowedTypes.includes(file.type)) {
      setError("Invalid file type. Allowed: Images, Video, Audio, Documents.");
      return false;
    }
    setError(null);
    return true;
  };

  const handleBrowseClick = (e) => {
    e.preventDefault();
    fileInputRef.current.click();
  };

  const handleInputChange = (e) => {
    const file = e.target.files?.[0];
    console.log("File selected:", {
      name: file?.name,
      type: file?.type,
      size: file?.size,
      valid: file ? validateFile(file) : false,
    });
    if (file && validateFile(file)) {
      onChange?.({ target: { name: "incident.attachment", value: file } });
      sessionStorage.setItem("step4_file", JSON.stringify({ name: file.name, type: file.type }));
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const file = e.dataTransfer.files?.[0];
    console.log("File dropped:", {
      name: file?.name,
      type: file?.type,
      size: file?.size,
      valid: file ? validateFile(file) : false,
    });
    if (file && validateFile(file)) {
      onChange?.({ target: { name: "incident.attachment", value: file } });
      sessionStorage.setItem("step4_file", JSON.stringify({ name: file.name, type: file.type }));
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleRemoveFile = () => {
    console.log("Removing file:", value?.name);
    onChange?.({ target: { name: "incident.attachment", value: null } });
    sessionStorage.removeItem("step4_file");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setError(null);
  };

  return (
    <div
      className="mt-0 flex justify-center px-6 pt-5 pb-6 border-2 border-[#1B5FC1] border-dashed rounded-md bg-blue-50"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <div className="space-y-1 text-center">
        <img src="/upload.svg" alt="upload" width={40} height={20} className="mx-auto h-12 w-12" />
        <div className="flex text-sm text-gray-600 justify-center">
          <span className="mr-1 font-bold">Drag and drop file or</span>
          <a href="#" className="text-blue-600 underline font-bold" onClick={handleBrowseClick}>
            Browse
          </a>
        </div>
        <p className="text-xs text-gray-500">Images, Video, Audio, Documents – Max 5MB</p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept="image/jpeg,image/png,image/gif,video/mp4,video/mpeg,audio/mpeg,audio/wav,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          onChange={handleInputChange}
        />
        {value && (
          <div className="mt-2 text-xs text-gray-600">
            <p>Selected: {value.name}</p>
            <button
              type="button"
              onClick={handleRemoveFile}
              className="text-blue-500 hover:underline"
            >
              Remove File
            </button>
          </div>
        )}
        {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
      </div>
    </div>
  );
};

function Step4({ formData, onChange, onNext, onBack, onClose, fileInputRef }) {
  const token = localStorage.getItem("userAccess");
  const contentEditableRef = useRef(null);
  const [charCount, setCharCount] = useState(formData.additionalNotes?.length || 0);
  const [witnessTitles, setWitnessTitles] = useState(["Mr", "Mrs", "Ms", "Dr"]);
  const [phoneError, setPhoneError] = useState("");
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOptions = async () => {
      if (!token) {
        setError("Authentication token is missing. Please log in.");
        toast.error("Authentication token is missing. Please log in.");
        return;
      }
      try {
        const res = await axios.get(
          "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (res.data?.witness_titles?.length > 0) {
          setWitnessTitles(res.data.witness_titles);
        }
      } catch (err) {
        console.warn("Using default witness titles due to API failure:", err);
        setError("Failed to load witness titles. Using default options.");
        toast.error("Failed to load witness titles.");
      }
    };

    fetchOptions();
  }, [token]);

  const handleFormat = (command, value = null) => {
    document.execCommand(command, false, value);
    handleContentChange();
  };

  const handleContentChange = () => {
    const text = contentEditableRef.current.textContent;
    const html = DOMPurify.sanitize(contentEditableRef.current.innerHTML);
    setCharCount(text.length);
    onChange({
      target: {
        name: "additionalNotes",
        value: html,
      },
    });
  };

  const handlePhoneChange = (index, value) => {
    const cleanedValue = value.replace(/\D/g, "");
    const newWitnesses = [...(formData.witnesses || [])];
    newWitnesses[index] = { ...newWitnesses[index], phone: cleanedValue };
    onChange({ target: { name: "witnesses", value: newWitnesses } });
    if (cleanedValue.length === 11) {
      setPhoneError("");
    } else {
      setPhoneError("Phone number must be exactly 11 digits");
    }
  };

  const handleWitnessChange = (index, field, value) => {
    const newWitnesses = [...(formData.witnesses || [])];
    newWitnesses[index] = { ...newWitnesses[index], [field]: value };
    onChange({ target: { name: "witnesses", value: newWitnesses } });
  };

  const handleAddWitness = () => {
    const newWitnesses = formData.witnesses
      ? [...formData.witnesses, { title: "", name: "", phone: "" }]
      : [{ title: "", name: "", phone: "" }];
    onChange({ target: { name: "witnesses", value: newWitnesses } });
  };

  const handleRemoveWitness = (index) => {
    const newWitnesses = formData.witnesses.filter((_, i) => i !== index);
    onChange({ target: { name: "witnesses", value: newWitnesses } });
  };

  // Validate and submit form data using FormData
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      return;
    }

    // Validate form fields
    if (!formData.witnesses || formData.witnesses.length === 0 || !formData.witnesses[0].name) {
      setError("Please add at least one witness with a name.");
      toast.error("Please add at least one witness with a name.");
      return;
    }
    if (formData.witnesses.some((w) => w.phone && w.phone.length !== 11)) {
      setError("All phone numbers must be exactly 11 digits.");
      toast.error("All phone numbers must be exactly 11 digits.");
      return;
    }

    // Create FormData instance
    const formDataPayload = new FormData();
    const payload = {
      witnesses: formData.witnesses || [{ title: "", name: "", phone: "" }],
      additional_notes: DOMPurify.sanitize(formData.additionalNotes) || "",
      // Include fields from previous steps for a complete payload
      type: formData.incidentType ? [formData.incidentType] : ["Unknown"],
      date: formData.dateOfIncident || "2025-07-08",
      time: formData.timeOfIncident || "09:59",
      community_affected: formData.communityAffected || "Unknown",
      people_involved: formData.peopleInvolved || [""],
      stakeholder_role: formData.stakeholderRole || "Unknown",
      number_of_people_involved: parseInt(formData.numberOfPeopleInvolved) || 0,
      actions_taken: formData.actionTaken || [""],
      clo_response: DOMPurify.sanitize(formData.cloResponseDetails) || "",
      submitted_to: "Safety Department",
      follow_up_actions: [""],
      signature: true,
      report_date: formData.dateOfIncident || "2025-07-08",
    };

    // Append payload as JSON string
    formDataPayload.append("data", JSON.stringify(payload));

    // Append file if selected
    if (formData.incident?.attachment) {
      formDataPayload.append("document", formData.incident.attachment);
    }

    try {
      const response = await axios.post(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
        formDataPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            // Content-Type is automatically set to multipart/form-data
          },
        }
      );
      console.log("Incident created:", response.data);
      toast.success("Incident details submitted successfully!");
      setError(null);
      sessionStorage.removeItem("step4_file"); // Clear stored file metadata
      onClose(); // Close the form on success
    } catch (error) {
      console.error("Error submitting incident details:", error);
      const errorMessage =
        error.response?.data?.message || "Failed to submit incident details. Please try again.";
      setError(errorMessage);
      toast.error(errorMessage);
    }
  };

  const handleNextClick = () => {
    if (!formData.witnesses || formData.witnesses.length === 0 || !formData.witnesses[0].name) {
      setError("Please add at least one witness with a name.");
      toast.error("Please add at least one witness with a name.");
      return;
    }
    if (formData.witnesses.some((w) => w.phone && w.phone.length !== 11)) {
      setError("All phone numbers must be exactly 11 digits.");
      toast.error("All phone numbers must be exactly 11 digits.");
      return;
    }
    setError(null);
    onNext();
  };

  useEffect(() => {
    if (!formData.witnesses || formData.witnesses.length === 0) {
      onChange({ target: { name: "witnesses", value: [{ title: "", name: "", phone: "" }] } });
    }
  }, [formData.witnesses, onChange]);

  return (
    <div className="h-[575px] flex flex-col rounded-md overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
        <div className="flex items-center space-x-2">
          <img src="/add.svg" alt="add" width={20} height={20} />
          <h2 className="text-white text-lg font-semibold">Add New</h2>
        </div>
        <button onClick={onClose} className="text-white">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto space-y-6">
        <div className="text-sm text-gray-200 flex p-6 items-center -mt-2">
          <span className="w-4 h-4 flex items-center justify-center mr-2">
            <img src="/four.svg" alt="four" width={20} height={20} />
          </span>
          <span className="text-black">
            4/6 - <span className="font-bold">SUPPORTING INFORMATION</span>
          </span>
        </div>
        <hr className="border-t -mt-6 border-gray-100 my-3" />

        {/* Error Message */}
        {error && (
          <div className="text-red-500 text-sm mb-4 px-6">{error}</div>
        )}

        <form className="space-y-6" onSubmit={handleSubmit}>
          {/* Witness Info */}
          <div className="mt-4">
            <div className="flex space-x-4 p-6 -mt-6">
              <div className="w-full">
                {formData.witnesses &&
                  formData.witnesses.map((witness, index) => (
                    <div key={index} className="flex space-x-4 mb-4 items-center">
                      <div className="w-1/4">
                        <label className="block text-sm text-gray-700 mb-1">Title</label>
                        <select
                          value={witness.title || ""}
                          onChange={(e) => handleWitnessChange(index, "title", e.target.value)}
                          className="block w-full border border-gray-300 rounded-[3px] p-2 text-[15px] focus:outline-none focus:ring-1 focus:ring-blue-500"
                        >
                          <option value="">Select</option>
                          {witnessTitles.map((title, idx) => (
                            <option key={idx} value={title}>{title}</option>
                          ))}
                        </select>
                      </div>
                      <div className="w-2/4">
                        <label className="block text-sm text-gray-700 mb-1">
                          Witness Name {index + 1} <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={witness.name || ""}
                          onChange={(e) => handleWitnessChange(index, "name", e.target.value)}
                          className="block w-full border border-gray-300 rounded-[3px] p-2 text-[15px] focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="Name"
                          required
                        />
                      </div>
                      <div className="w-2/4">
                        <label className="block text-sm text-gray-700 mb-1">Mobile Number {index + 1}</label>
                        <div className="flex rounded-[3px] overflow-hidden border border-gray-300">
                          <div className="w-px bg-gray-300" />
                          <input
                            type="tel"
                            value={witness.phone || ""}
                            onChange={(e) => handlePhoneChange(index, e.target.value)}
                            className={`flex-1 px-3 py-2 text-[15px] text-gray-900 focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                              phoneError && witness.phone && witness.phone.length !== 11 ? "border-red-500" : ""
                            }`}
                            placeholder="12345678901"
                            pattern="[0-9]{11}"
                            maxLength="11"
                            inputMode="numeric"
                          />
                        </div>
                      </div>
                      {index > 0 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveWitness(index)}
                          className="text-red-500 hover:text-red-700 text-xs w-4 h-4 flex items-center justify-center ml-2"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  ))}
              </div>
            </div>
            <div className="flex justify-end px-6 -mt-2">
              <button
                type="button"
                onClick={handleAddWitness}
                className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
              >
                <span className="mr-1">+</span> Add Witness
              </button>
            </div>
            {phoneError && <p className="text-xs text-red-500 mt-1 px-6">{phoneError}</p>}
          </div>

          {/* Upload Evidence */}
          <div className="-mt-8 p-4">
            <label className="block text-sm text-gray-700">Upload Evidence</label>
            <FileUpload
              value={formData.incident?.attachment || null}
              onChange={onChange}
              fileInputRef={fileInputRef}
            />
          </div>

          {/* Additional Notes */}
          <div className="-mt-10 p-4">
            <label className="block text-sm text-gray-700">Additional Notes</label>
            <div className="relative mt-1">
              <div
                ref={contentEditableRef}
                contentEditable
                onInput={handleContentChange}
                className="block w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[100px]"
                dangerouslySetInnerHTML={{ __html: formData.additionalNotes || "" }}
              />
              <div className="absolute bottom-2 left-2 flex space-x-1 text-xs">
                <button type="button" className="p-0.5 rounded font-bold" onClick={() => handleFormat("bold")}>
                  <img src="/bold.svg" alt="bold" width={20} height={20} />
                </button>
                <button type="button" className="p-0.5 rounded italic" onClick={() => handleFormat("italic")}>
                  <img src="/italic.svg" alt="italic" width={20} height={20} />
                </button>
                <button type="button" className="p-0.5 rounded underline" onClick={() => handleFormat("underline")}>
                  <img src="/under.svg" alt="under" width={20} height={20} />
                </button>
                <button type="button" className="p-0.5 rounded" onClick={() => handleFormat("insertOrderedList")}>
                  <img src="/num.svg" alt="num" width={20} height={20} />
                </button>
                <button type="button" className="p-0.5 rounded" onClick={() => handleFormat("insertUnorderedList")}>
                  <img src="/item.png" alt="item" width={20} height={20} />
                </button>
              </div>
              <span className="absolute bottom-2 right-2 text-sm text-gray-500">{charCount}/1500</span>
            </div>
          </div>

          {/* Sticky Footer */}
          <div className="flex justify-end space-x-4 p-4 bg-white shadow-[0_-1px_3px_rgba(0,0,0,0.15)] w-full">
            <button
              type="button"
              onClick={onBack}
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
            >
              Prev
            </button>
            <button
              type="submit"
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
            >
              Submit
            </button>
            <button
              type="button"
              onClick={handleNextClick}
              className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
            >
              Next
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Step4;