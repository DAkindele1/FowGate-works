

// import React, { useState } from "react";

// const ConfirmationPage = ({ formData, onConfirmSubmit, onCancel, onClose }) => {
//   const [loading, setLoading] = useState(false);

//   const handleSubmit = async () => {
//     setLoading(true);
//     try {
//       await onConfirmSubmit(); 
//     } catch (error) {
//       console.error("Error confirming submission:", error);
//       alert("Something went wrong. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="w-[140%] max-w-md mx-auto bg-white overflow-hidden shadow-lg">
//       {/* Header */}
//       <div className="bg-[#1B5FC1] px-6 py-7 flex items-center justify-between">
//         <div className="flex items-center space-x-2">
//           <img src="/help.svg" alt="Info Icon" className="w-5 h-5" />
//           <h3 className="text-white font-semibold text-[17px]">Confirm Action</h3>
//         </div>
//         <button onClick={onClose} className="text-white hover:text-gray-200">
//           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//           </svg>
//         </button>
//       </div>

//       {/* Body */}
//       <div className="px-6 pt-6 pb-8 text-left text-gray-700 text-[13px] leading-relaxed">
//   You're about to submit this incident report.
//   Please ensure all <br /> information is accurate and supporting files are attached.
// </div>


//       {/* Actions */}
//       <hr className="border-t border-gray-100 my-3 " />
//       <div className="flex justify-end gap-4 px-6 pb-6">
//         <button
//           onClick={onCancel}
//           disabled={loading}
//           className="text-gray-800 text-[15px] px-4 py-2 rounded-[4px] hover:bg-gray-100"
//         >
//           Cancel
//         </button>
//         <button
//           onClick={handleSubmit}
//           disabled={loading}
//           className="bg-[#EAF1FD] text-[#1B5FC1] font-medium px-5 py-2 rounded-[6px] hover:bg-[#d5e6fc]"
//         >
//           {loading ? "Submitting..." : "Yes, I’m sure"}
//         </button>
//       </div>
//     </div>
//   );
// };

// export default ConfirmationPage;











import React, { useState } from "react";

const ConfirmationPage = ({ formData, onConfirmSubmit, onCancel, onClose }) => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await onConfirmSubmit();
    } catch (error) {
      console.error("Error confirming submission:", error);
      alert("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white overflow-hidden shadow-lg">
      {/* Header */}
      <div className="bg-[#1B5FC1] px-6 py-7 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <img src="/help.svg" alt="Info Icon" className="w-5 h-5" />
          <h3 className="text-white font-semibold text-[17px]">Confirm Action</h3>
        </div>
        <button onClick={onClose} className="text-white hover:text-gray-200">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Body */}
      <div className="px-6 pt-6 pb-8 text-left text-gray-700 text-[13px] leading-relaxed">
        You're about to submit this incident report.
        Please ensure all information is accurate and supporting files are attached.
      </div>

      {/* Actions */}
      <hr className="border-t border-gray-100 my-3" />
      <div className="flex justify-end gap-4 px-6 pb-6">
        <button
          onClick={onCancel}
          disabled={loading}
          className="text-gray-800 text-[15px] px-4 py-2 rounded-[4px] hover:bg-gray-100"
        >
          Cancel
        </button>
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="bg-[#EAF1FD] text-[#1B5FC1] font-medium px-5 py-2 rounded-[6px] hover:bg-[#d5e6fc]"
        >
          {loading ? "Submitting..." : "Yes, I’m sure"}
        </button>
      </div>
    </div>
  );
};

export default ConfirmationPage;
