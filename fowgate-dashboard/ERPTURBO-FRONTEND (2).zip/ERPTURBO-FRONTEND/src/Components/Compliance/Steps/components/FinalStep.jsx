


// import React, { useState } from "react";

// const FinalStep = ({ formData, onChange, onBack, onSubmit }) => {
//   const [showIncidentOverview, setShowIncidentOverview] = useState(false);
//   const [showSupportingInfo, setShowSupportingInfo] = useState(false);
//   const [showActionTaken, setShowActionTaken] = useState(false);
//   const [showPartiesInvolved, setShowPartiesInvolved] = useState(false);
//   const [showEscalationFollowUp, setShowEscalationFollowUp] = useState(false);
//   const [error, setError] = useState(null);

//   const validateFormData = () => {
//     if (!formData.incidentType?.length) return "Incident type is required.";
//     if (!formData.dateOfIncident) return "Date of incident is required.";
//     if (!formData.timeOfIncident) return "Time of incident is required.";
//     if (!formData.communityAffected) return "Community affected is required.";
//     if (!formData.peopleInvolved?.length) return "People involved is required.";
//     if (!formData.stakeholderRole) return "Stakeholder role is required.";
//     if (!formData.numberOfPeopleInvolved) return "Number of people involved is required.";
//     if (!formData.actionTaken?.length) return "Actions taken is required.";
//     if (!formData.cloResponseDetails && !formData.description) return "CLO response is required.";
//     if (!formData.witnesses?.length || !formData.witnesses[0].name) return "At least one witness name is required.";
//     if (!formData.cloName) return "Report submitted to is required.";
//     if (!formData.followUpAction?.length) return "Follow-up actions are required.";
//     if (!formData.reportDate) return "Report date is required.";
//     return null;
//   };

//   const handleFormSubmit = (e) => {
//     e.preventDefault();
//     const validationError = validateFormData();
//     if (validationError) {
//       setError(validationError);
//       return;
//     }
//     setError(null);
//     onSubmit(); // Navigate to Step 7 (ConfirmationPage)
//   };

//   return (
//     <div className="w-full max-w-3xl mx-auto">
//       <div className="overflow-hidden h-[575px] flex flex-col">
//         {/* Header */}
//         <div className="bg-[#1B5FC1] h-[80px] px-6 flex items-center justify-between">
//           <div className="flex items-center space-x-2">
//             <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
//             <h2 className="text-white text-lg font-semibold">Add New</h2>
//           </div>
//           <button onClick={onBack} className="text-white text-2xl font-bold focus:outline-none">
//             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//             </svg>
//           </button>
//         </div>

//         {/* Error Message */}
//         {error && (
//           <div className="text-red-500 text-sm mb-4 px-4">{error}</div>
//         )}

//         {/* Body */}
//         <div className="overflow-y-auto px-4 py-5 flex-grow bg-transparent">
//           <form onSubmit={handleFormSubmit} className="space-y-6">
//             <div className="flex items-center text-gray-500 mb-6">
//               <img src="/six.svg" alt="step" className="w-4 h-4 mr-2" />
//               <span className="text-black">
//                 6/7 - <span className="font-bold">PREVIEW & SUBMIT</span>
//               </span>
//             </div>
//             <hr className="border-t border-gray-100 my-3" />

//             {/* Reporting Officer Details */}
//             <div className="bg-white rounded-lg border border-gray-300 overflow-hidden">
//               <h3 className="bg-[#F1F1F1] px-6 py-2 text-sm font-medium rounded-t-lg">
//                 Reporting Officer Details
//               </h3>
//               <hr className="border-gray-300" />
//               <div className="px-6 py-4 text-sm space-y-4">
//                 {[
//                   ["Name of CLO", formData?.cloName],
//                   ["OML", formData?.oml || "Not provided"],
//                   ["Cluster/Host Community", formData?.hostCommunity || "Not provided"],
//                   ["Company", formData?.company || "Not provided"],
//                   ["Date of Report", formData?.reportDate],
//                   ["CLO Contact Number", formData?.cloPhone || "Not provided"],
//                 ]
//                   .reduce((rows, item, index) => {
//                     if (index % 2 === 0) rows.push([item]);
//                     else rows[rows.length - 1].push(item);
//                     return rows;
//                   }, [])
//                   .map((row, i) => (
//                     <div key={i} className="grid grid-cols-2 gap-4">
//                       {row.map(([label, value], j) => (
//                         <div key={j}>
//                           <p className="text-gray-500 text-[12px]">{label}</p>
//                           <p className="text-black">{value || "Not provided"}</p>
//                         </div>
//                       ))}
//                       {i < 2 && <div className="col-span-2"><hr className="border-gray-300 mt-2" /></div>}
//                     </div>
//                   ))}
//               </div>
//             </div>

//             {/* Incident Overview */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Incident Overview
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowIncidentOverview((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showIncidentOverview ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showIncidentOverview && (
//                 <div className="grid grid-cols-2 gap-4 p-4 text-sm">
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Date of Incident</p>
//                     <p className="text-black">{formData?.dateOfIncident || "Not provided"}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Time of Incident</p>
//                     <p className="text-black">{formData?.timeOfIncident || "Not provided"}</p>
//                   </div>
//                   <hr className="border-gray-300 col-span-2" />
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Location</p>
//                     <p className="text-black">{formData?.communityAffected || "Not provided"}</p>
//                   </div>
//                   <div>
//                     <p className="text-gray-500 text-[12px]">Community Affected</p>
//                     <p className="text-black">{formData?.communityAffected || "Not provided"}</p>
//                   </div>
//                   <hr className="border-gray-300 col-span-2" />
//                   <div className="col-span-2">
//                     <div className="flex flex-wrap gap-2">
//                       <p className="mb-1 text-gray-500 text-[12px]">Incident Type</p>
//                       <p className="text-black">
//                         {Array.isArray(formData?.incidentType) && formData.incidentType.length > 0
//                           ? formData.incidentType.join(", ")
//                           : "Not provided"}
//                       </p>
//                     </div>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Parties Involved */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Parties Involved
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowPartiesInvolved((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showPartiesInvolved ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showPartiesInvolved && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Names or Groups Involved</p>
//                   <div className="flex flex-wrap gap-2 mb-2">
//                     {Array.isArray(formData?.peopleInvolved) && formData.peopleInvolved.length > 0 ? (
//                       formData.peopleInvolved.map((person, index) => (
//                         <p key={index} className="text-black">
//                           {person}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <p className="text-gray-500 text-[12px]">Stakeholder Role</p>
//                   <p className="text-black">{formData?.stakeholderRole || "Not provided"}</p>
//                   <p className="text-gray-500 text-[12px] mt-2">Number of People Involved</p>
//                   <p className="text-black">{formData?.numberOfPeopleInvolved || "Not provided"}</p>
//                 </div>
//               )}
//             </div>

//             {/* Action Taken */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Action Taken
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowActionTaken((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showActionTaken ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showActionTaken && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Immediate Action Taken</p>
//                   <div className="space-y-2">
//                     {Array.isArray(formData?.actionTaken) && formData.actionTaken.length > 0 ? (
//                       formData.actionTaken.map((action, index) => (
//                         <p key={index} className="text-black">
//                           {action}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Details of CLO's Response</p>
//                   <p className="text-black">{formData?.cloResponseDetails || formData?.description || "Not provided"}</p>
//                 </div>
//               )}
//             </div>

//             {/* Supporting Information */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Supporting Information
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowSupportingInfo((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showSupportingInfo ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showSupportingInfo && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Witnesses</p>
//                   <div className="space-y-1">
//                     {Array.isArray(formData?.witnesses) && formData.witnesses.length > 0 ? (
//                       formData.witnesses.map((witness, index) => (
//                         <p key={index} className="text-black">
//                           {`${witness.title ? witness.title + " " : ""}${witness.name || "Unknown"} (${witness.phone || "No phone"})`}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
//                   <div className="space-y-1">
//                     {formData?.incident?.attachment ? (
//                       <div className="flex justify-between items-center">
//                         <span className="text-black">{formData.incident.attachment.name || "File"}</span>
//                         <button
//                           type="button"
//                           onClick={() => onChange({ target: { name: "incident.attachment", value: null } })}
//                           className="text-red-500"
//                         >
//                           X
//                         </button>
//                       </div>
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <hr className="border-gray-300 my-2" />
//                   <p className="text-gray-500 text-[12px]">Additional Notes</p>
//                   <p className="text-black">{formData?.additionalNotes || "Not provided"}</p>
//                 </div>
//               )}
//             </div>

//             {/* Escalation & Follow-Up */}
//             <div className="bg-white rounded-lg relative border border-gray-300">
//               <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
//                 Escalation & Follow-Up
//                 <div className="flex items-center space-x-2">
//                   <img src="/pen.svg" alt="edit" className="w-4 h-4" />
//                   <button
//                     type="button"
//                     onClick={() => setShowEscalationFollowUp((prev) => !prev)}
//                     className="focus:outline-none"
//                   >
//                     <svg
//                       className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
//                         showEscalationFollowUp ? "rotate-180" : "rotate-0"
//                       }`}
//                       fill="none"
//                       stroke="currentColor"
//                       viewBox="0 0 24 24"
//                     >
//                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                     </svg>
//                   </button>
//                 </div>
//               </h3>
//               <hr className="border-gray-300" />
//               {showEscalationFollowUp && (
//                 <div className="px-4 py-4 text-sm">
//                   <p className="text-gray-500 text-[12px]">Report Submitted To</p>
//                   <p className="text-black">{formData?.cloName || "Not provided"}</p>
//                   <p className="text-gray-500 text-[12px] mt-2">Follow-Up Actions Recommended</p>
//                   <div className="space-y-1">
//                     {Array.isArray(formData?.followUpAction) && formData.followUpAction.length > 0 ? (
//                       formData.followUpAction.map((action, index) => (
//                         <p key={index} className="text-black">
//                           {action}
//                         </p>
//                       ))
//                     ) : (
//                       <p className="text-black">Not provided</p>
//                     )}
//                   </div>
//                   <div className="flex items-center mt-4">
//                     <div className="flex-1">
//                       <p className="text-gray-500 text-[12px]">Signature</p>
//                       <div className="flex items-center space-x-2">
//                         <img
//                           src={formData?.signature || "/signature-placeholder.png"}
//                           alt="Signature"
//                           className="w-20 h-auto"
//                         />
//                         <img src="/pen.svg" alt="Edit Signature" className="w-4 h-4" />
//                       </div>
//                     </div>
//                     <div className="ml-4">
//                       <p className="text-gray-500 text-[12px]">Date</p>
//                       <p className="text-black">
//                         {formData?.reportDate || "Not provided"}
//                         <img src="/calendar.svg" alt="Calendar" className="w-4 h-4 inline ml-1" />
//                       </p>
//                     </div>
//                   </div>
//                   <p className="text-black mt-2">{formData?.cloName || "Not provided"}</p>
//                 </div>
//               )}
//             </div>
//           </form>
//         </div>

//         {/* Footer Buttons */}
//         <div className="flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
//           <button
//             type="button"
//             onClick={onBack}
//             className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
//           >
//             Prev
//           </button>
//           <button
//             type="submit"
//             onClick={handleFormSubmit}
//             className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
//           >
//             Next
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default FinalStep;










import React, { useState } from "react";
import toast from "react-hot-toast";

const FinalStep = ({ formData, onChange, onBack, onSubmit, onClose }) => {
  const [showIncidentOverview, setShowIncidentOverview] = useState(false);
  const [showSupportingInfo, setShowSupportingInfo] = useState(false);
  const [showActionTaken, setShowActionTaken] = useState(false);
  const [showPartiesInvolved, setShowPartiesInvolved] = useState(false);
  const [showEscalationFollowUp, setShowEscalationFollowUp] = useState(false);
  const [error, setError] = useState(null);

  const validateFormData = () => {
    if (!formData.incidentType?.length) return "Incident type is required.";
    if (!formData.dateOfIncident) return "Date of incident is required.";
    if (!formData.timeOfIncident) return "Time of incident is required.";
    if (!formData.communityAffected) return "Community affected is required.";
    if (!formData.peopleInvolved?.length) return "People involved is required.";
    if (!formData.stakeholderRole) return "Stakeholder role is required.";
    if (!formData.numberOfPeopleInvolved) return "Number of people involved is required.";
    if (!formData.actionTaken?.length) return "Actions taken is required.";
    if (!formData.cloResponseDetails && !formData.description) return "CLO response is required.";
    if (!formData.witnesses?.length || !formData.witnesses[0].name) return "At least one witness name is required.";
    if (!formData.cloName) return "Report submitted to is required.";
    if (!formData.followUpAction?.length) return "Follow-up actions are required.";
    if (!formData.reportDate) return "Report date is required.";
    if (!formData.signature) return "Signature is required.";
    return null;
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const validationError = validateFormData();
    if (validationError) {
      setError(validationError);
      toast.error(validationError);
      return;
    }
    setError(null);
    onSubmit(); // Navigate to ConfirmationPage (Step 7)
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="overflow-hidden h-[575px] flex flex-col">
        <div className="bg-[#1B5FC1] h-[80px] px-6 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/add.svg" alt="Info Icon" className="w-5 h-5" />
            <h2 className="text-white text-lg font-semibold">Add New</h2>
          </div>
          <button onClick={onClose} className="text-white text-2xl font-bold focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        {error && (
          <div className="text-red-500 text-sm mb-4 px-4">{error}</div>
        )}
        <div className="overflow-y-auto px-4 py-5 flex-grow bg-transparent">
          <form id="form" onSubmit={handleFormSubmit} className="space-y-6">
            <div className="flex items-center text-gray-500 mb-6">
              <span className="w-4 h-4 flex items-center justify-center mr-2">
                <img src="/six.svg" alt="step" className="w-4 h-4" />
              </span>
              <span className="text-black">
                6/7 - <span className="font-bold">PREVIEW & SUBMIT</span>
              </span>
            </div>
            <hr className="border-t border-gray-100 my-3" />
            <div className="bg-white rounded-lg border border-gray-300 overflow-hidden">
              <h3 className="bg-[#F1F1F1] px-6 py-2 text-sm font-medium rounded-t-lg">
                Reporting Officer Details
              </h3>
              <hr className="border-gray-300" />
              <div className="px-6 py-4 text-sm space-y-4">
                {[
                  ["Name of CLO", formData?.cloName],
                  ["OML", formData?.oml || "Not provided"],
                  ["Cluster/Host Community", formData?.hostCommunity || "Not provided"],
                  ["Company", formData?.company || "Not provided"],
                  ["Date of Report", formData?.reportDate],
                  ["CLO Contact Number", formData?.cloPhone || "Not provided"],
                ]
                  .reduce((rows, item, index) => {
                    if (index % 2 === 0) rows.push([item]);
                    else rows[rows.length - 1].push(item);
                    return rows;
                  }, [])
                  .map((row, i) => (
                    <div key={i} className="grid grid-cols-2 gap-4">
                      {row.map(([label, value], j) => (
                        <div key={j}>
                          <p className="text-gray-500 text-[12px]">{label}</p>
                          <p className="text-black">{value || "Not provided"}</p>
                        </div>
                      ))}
                      {i < 2 && <div className="col-span-2"><hr className="border-gray-300 mt-2" /></div>}
                    </div>
                  ))}
              </div>
            </div>
            <div className="bg-white rounded-lg relative border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
                Incident Overview
                <div className="flex items-center space-x-2">
                  <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowIncidentOverview((prev) => !prev)}
                    className="focus:outline-none"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showIncidentOverview ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              {showIncidentOverview && (
                <div className="grid grid-cols-2 gap-4 p-4 text-sm">
                  <div>
                    <p className="text-gray-500 text-[12px]">Date of Incident</p>
                    <p className="text-black">{formData?.dateOfIncident || "Not provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">Time of Incident</p>
                    <p className="text-black">{formData?.timeOfIncident || "Not provided"}</p>
                  </div>
                  <hr className="border-gray-300 col-span-2" />
                  <div>
                    <p className="text-gray-500 text-[12px]">Location</p>
                    <p className="text-black">{formData?.communityAffected || "Not provided"}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[12px]">Community Affected</p>
                    <p className="text-black">{formData?.communityAffected || "Not provided"}</p>
                  </div>
                  <hr className="border-gray-300 col-span-2" />
                  <div className="col-span-2">
                    <div className="flex flex-wrap gap-2">
                      <p className="mb-1 text-gray-500 text-[12px]">Incident Type</p>
                      <p className="text-black">
                        {Array.isArray(formData?.incidentType) && formData.incidentType.length > 0
                          ? formData.incidentType.join(", ")
                          : "Not provided"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="bg-white rounded-lg relative border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
                Parties Involved
                <div className="flex items-center space-x-2">
                  <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowPartiesInvolved((prev) => !prev)}
                    className="focus:outline-none"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showPartiesInvolved ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              {showPartiesInvolved && (
                <div className="px-4 py-4 text-sm">
                  <p className="text-gray-500 text-[12px]">Names or Groups Involved</p>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {Array.isArray(formData?.peopleInvolved) && formData.peopleInvolved.length > 0 ? (
                      formData.peopleInvolved.map((person, index) => (
                        <p key={index} className="text-black">
                          {person}
                        </p>
                      ))
                    ) : (
                      <p className="text-black">Not provided</p>
                    )}
                  </div>
                  <p className="text-gray-500 text-[12px]">Stakeholder Role</p>
                  <p className="text-black">{formData?.stakeholderRole || "Not provided"}</p>
                  <p className="text-gray-500 text-[12px] mt-2">Number of People Involved</p>
                  <p className="text-black">{formData?.numberOfPeopleInvolved || "Not provided"}</p>
                </div>
              )}
            </div>
            <div className="bg-white rounded-lg relative border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
                Action Taken
                <div className="flex items-center space-x-2">
                  <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowActionTaken((prev) => !prev)}
                    className="focus:outline-none"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showActionTaken ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              {showActionTaken && (
                <div className="px-4 py-4 text-sm">
                  <p className="text-gray-500 text-[12px]">Immediate Action Taken</p>
                  <div className="space-y-2">
                    {Array.isArray(formData?.actionTaken) && formData.actionTaken.length > 0 ? (
                      formData.actionTaken.map((action, index) => (
                        <p key={index} className="text-black">
                          {action}
                        </p>
                      ))
                    ) : (
                      <p className="text-black">Not provided</p>
                    )}
                  </div>
                  <hr className="border-gray-300 my-2" />
                  <p className="text-gray-500 text-[12px]">Details of CLO's Response</p>
                  <p className="text-black">{formData?.cloResponseDetails || formData?.description || "Not provided"}</p>
                </div>
              )}
            </div>
            <div className="bg-white rounded-lg relative border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
                Supporting Information
                <div className="flex items-center space-x-2">
                  <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowSupportingInfo((prev) => !prev)}
                    className="focus:outline-none"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showSupportingInfo ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              {showSupportingInfo && (
                <div className="px-4 py-4 text-sm">
                  <p className="text-gray-500 text-[12px]">Witnesses</p>
                  <div className="space-y-1">
                    {Array.isArray(formData?.witnesses) && formData.witnesses.length > 0 ? (
                      formData.witnesses.map((witness, index) => (
                        <p key={index} className="text-black">
                          {`${witness.title ? witness.title + " " : ""}${witness.name || "Unknown"} (${witness.phone || "No phone"})`}
                        </p>
                      ))
                    ) : (
                      <p className="text-black">Not provided</p>
                    )}
                  </div>
                  <hr className="border-gray-300 my-2" />
                  <p className="text-gray-500 text-[12px]">Uploaded Evidence</p>
                  <div className="space-y-1">
                    {formData?.incident?.attachment ? (
                      <div className="flex justify-between items-center">
                        <span className="text-black">{formData.incident.attachment.name || "File"}</span>
                        <button
                          type="button"
                          onClick={() => onChange({ target: { name: "incident.attachment", value: null } })}
                          className="text-red-500"
                        >
                          X
                        </button>
                      </div>
                    ) : (
                      <p className="text-black">Not provided</p>
                    )}
                  </div>
                  <hr className="border-gray-300 my-2" />
                  <p className="text-gray-500 text-[12px]">Additional Notes</p>
                  <p className="text-black">{formData?.additionalNotes || "Not provided"}</p>
                </div>
              )}
            </div>
            <div className="bg-white rounded-lg relative border border-gray-300">
              <h3 className="bg-[#F1F1F1] px-4 py-2 font-medium text-sm rounded-t-lg flex justify-between items-center">
                Escalation & Follow-Up
                <div className="flex items-center space-x-2">
                  <img src="/pen.svg" alt="edit" className="w-4 h-4" />
                  <button
                    type="button"
                    onClick={() => setShowEscalationFollowUp((prev) => !prev)}
                    className="focus:outline-none"
                  >
                    <svg
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${
                        showEscalationFollowUp ? "rotate-180" : "rotate-0"
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </h3>
              <hr className="border-gray-300" />
              {showEscalationFollowUp && (
                <div className="px-4 py-4 text-sm">
                  <p className="text-gray-500 text-[12px]">Report Submitted To</p>
                  <p className="text-black">{formData?.cloName || "Not provided"}</p>
                  <p className="text-gray-500 text-[12px] mt-2">Follow-Up Actions Recommended</p>
                  <div className="space-y-1">
                    {Array.isArray(formData?.followUpAction) && formData.followUpAction.length > 0 ? (
                      formData.followUpAction.map((action, index) => (
                        <p key={index} className="text-black">
                          {action}
                        </p>
                      ))
                    ) : (
                      <p className="text-black">Not provided</p>
                    )}
                  </div>
                  <div className="flex items-center mt-4">
                    <div className="flex-1">
                      <p className="text-gray-500 text-[12px]">Signature</p>
                      <div className="flex items-center space-x-2">
                        <img
                          src={formData?.signature || "/signature-placeholder.png"}
                          alt="Signature"
                          className="w-20 h-auto"
                        />
                        <img src="/pen.svg" alt="Edit Signature" className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <p className="text-gray-500 text-[12px]">Date</p>
                      <p className="text-black">
                        {formData?.reportDate || "Not provided"}
                        <img src="/calendar.svg" alt="Calendar" className="w-4 h-4 inline ml-1" />
                      </p>
                    </div>
                  </div>
                  <p className="text-black mt-2">{formData?.cloName || "Not provided"}</p>
                </div>
              )}
            </div>
          </form>
        </div>
        <div className="flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
          <button
            type="button"
            onClick={onBack}
            className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
          >
            Prev
          </button>
          <button
            type="submit"
            form="form"
            className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default FinalStep;

