


// import React, { useEffect, useRef, useState } from "react";
// import { FiChevronDown, FiClock } from "react-icons/fi";
// import axios from "axios";
// import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
// import "leaflet/dist/leaflet.css";
// import L from "leaflet";
// import toast from "react-hot-toast";

// // Fix Leaflet marker icon issue
// delete L.Icon.Default.prototype._getIconUrl;
// L.Icon.Default.mergeOptions({
//   iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
//   iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
//   shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
// });

// // DatePicker, TimePicker, and MapModal components remain unchanged
// // ... (Insert the DatePicker, TimePicker, and MapModal components from your original code here)

// // Fix Leaflet marker icon issue


// // DatePicker Component
// const DatePicker = ({ value, onChange }) => {
//   const dateInputRef = useRef(null);

//   const handleIconClick = () => {
//     dateInputRef.current?.showPicker();
//   };

//   const handleDateChange = (e) => {
//     const newDate = e.target.value;
//     onChange?.({ target: { name: "dateOfIncident", value: newDate } });
//   };

//   const formatDate = (isoString) => {
//     if (!isoString) return "";
//     const [year, month, day] = isoString.split("-");
//     return `${day}/${month}/${year}`;
//   };

//   return (
//     <div className="relative w-full transition-all duration-300 ease-in-out">
//       <input
//         ref={dateInputRef}
//         type="date"
//         value={value}
//         onChange={handleDateChange}
//         className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
//       />
//       <div className="flex items-center justify-between w-full border border-gray-300 rounded-[3px] p-1.5 pr-10 text-sm text-gray-900 bg-white relative pointer-events-none">
//         <span className="truncate pointer-events-none">
//           {value ? formatDate(value) : "dd/mm/yyyy"}
//         </span>
//         <img
//           src="/calendar.svg"
//           alt="calendar"
//           width={20}
//           height={20}
//           className="absolute right-2 top-1/2 transform -translate-y-1/2 cursor-pointer pointer-events-auto transition-transform duration-200 hover:scale-110"
//           onClick={handleIconClick}
//         />
//       </div>
//     </div>
//   );
// };

// // TimePicker Component
// const TimePicker = ({ value, onChange }) => {
//   const timeInputRef = useRef(null);

//   const handleIconClick = () => {
//     timeInputRef.current?.showPicker();
//   };

//   const handleTimeChange = (e) => {
//     const newTime = e.target.value;
//     onChange?.({ target: { name: "timeOfIncident", value: newTime } });
//   };

//   return (
//     <div className="relative w-full transition-all duration-300 ease-in-out">
//       <input
//         ref={timeInputRef}
//         type="time"
//         value={value}
//         onChange={handleTimeChange}
//         className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
//       />
//       <div className="flex items-center justify-between w-full border border-gray-300 rounded-[3px] p-1.5 pr-10 text-sm text-gray-900 bg-white relative pointer-events-none">
//         <span className="truncate pointer-events-none">{value || "--:--"}</span>
//         <FiClock
//           size={20}
//           className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer pointer-events-auto transition-transform duration-200 hover:scale-110"
//           onClick={handleIconClick}
//         />
//       </div>
//     </div>
//   );
// };

// // Map Modal Component
// const MapModal = ({ isOpen, onClose, onSelectLocation, mapType }) => {
//   const [center, setCenter] = useState([4.843, 7.033]); // Default: Port Harcourt, Rumudara
//   const [selectedLocation, setSelectedLocation] = useState(null);

//   useEffect(() => {
//     if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition(
//         (position) => {
//           setCenter([position.coords.latitude, position.coords.longitude]);
//         },
//         () => {
//           console.warn("Geolocation unavailable, using default center.");
//         }
//       );
//     }
//   }, []);

//   const MapClickHandler = () => {
//     useMapEvents({
//       click: async (e) => {
//         const { lat, lng } = e.latlng;
//         setSelectedLocation([lat, lng]);

//         try {
//           const response = await axios.get(
//             `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
//             {
//               headers: {
//                 "User-Agent": "IncidentReportingApp (nackycynthia@gmail.com)",
//               },
//             }
//           );
//           const address = response.data.display_name || "Unknown location";
//           onSelectLocation({ lat, lng, address });
//         } catch (error) {
//           console.error("Geocoding error:", error);
//           onSelectLocation({ lat, lng, address: `Lat: ${lat}, Lng: ${lng}` });
//         }
//       },
//     });
//     return null;
//   };

//   if (!isOpen) return null;

//   const tileUrl =
//     mapType === "Satellite View"
//       ? "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
//       : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
//   const attribution =
//     mapType === "Satellite View"
//       ? '© <a href="https://www.esri.com/">Esri</a>'
//       : '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

//   return (
//     <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
//       <div className="bg-white rounded-[3px] p-4 w-[80%] h-[80%] max-w-4xl">
//         <div className="flex justify-between items-center mb-4">
//           <h3 className="text-lg font-semibold">Select Location</h3>
//           <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
//             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//             </svg>
//           </button>
//         </div>
//         <MapContainer center={center} zoom={10} style={{ width: "100%", height: "90%" }}>
//           <TileLayer url={tileUrl} attribution={attribution} />
//           {selectedLocation && <Marker position={selectedLocation} />}
//           <MapClickHandler />
//         </MapContainer>
//       </div>
//     </div>
//   );
// };
// // Main Step1Overview Component
// function Step1Overview({ formData, onChange, onNext, onBack, onClose }) {
//   const token = localStorage.getItem("userAccess");
//   const [incidentTypes, setIncidentTypes] = useState([
//     "Security Breach",
//     "Community Protest",
//     "Land Damage",
//   ]);
//   const [selectedDate, setSelectedDate] = useState(formData.dateOfIncident || "");
//   const [selectedTime, setSelectedTime] = useState(formData.timeOfIncident || "");
//   const [showMapDropdown, setShowMapDropdown] = useState(false);
//   const [showMapModal, setShowMapModal] = useState(false);
//   const [selectedMapType, setSelectedMapType] = useState(null);
//   const [mapPreviewUrl, setMapPreviewUrl] = useState(null);
//   const [description, setDescription] = useState(formData.description || "");
//   const [error, setError] = useState(null);
//   const [selectedImage, setSelectedImage] = useState(null); // New state for file
//   const [previewImage, setPreviewImage] = useState(null); // New state for image preview
//   const fileInputRef = useRef(null); // Ref for file input
//   const contentEditableRef = useRef(null);

//   useEffect(() => {
//     const fetchIncidentTypes = async () => {
//       try {
//         const response = await axios.get(
//           "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options",
//           {
//             headers: {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         if (response.data && Array.isArray(response.data.type)) {
//           setIncidentTypes(response.data.type);
//         }
//       } catch (error) {
//         console.warn("Could not load incident types, using defaults.");
//       }
//     };
//     fetchIncidentTypes();
//   }, [token]);

//   const handleDateChange = (e) => {
//     const value = e.target.value;
//     setSelectedDate(value);
//     onChange?.({ target: { name: "dateOfIncident", value } });
//   };

//   const handleTimeChange = (e) => {
//     const value = e.target.value;
//     setSelectedTime(value);
//     onChange?.({ target: { name: "timeOfIncident", value } });
//   };

//   const handleMapSelect = (mapType) => {
//     setShowMapDropdown(false);
//     setSelectedMapType(mapType);
//     setShowMapModal(true);
//   };

//   const handleLocationSelect = ({ lat, lng, address }) => {
//     setShowMapModal(false);
//     const mapUrl = `https://tile.openstreetmap.org/12/${Math.floor(
//       (lng + 180) / 360 * Math.pow(2, 12)
//     )}/${Math.floor(
//       (1 - Math.log(Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)) / Math.PI) /
//         2 *
//         Math.pow(2, 12)
//     )}.png`;
//     setMapPreviewUrl(mapUrl);
//     onChange?.({
//       target: {
//         name: "communityAffected",
//         value: address || `Lat: ${lat}, Lng: ${lng}`,
//       },
//     });
//   };

//   const handleContentChange = () => {
//     const value = contentEditableRef.current.innerHTML;
//     setDescription(value);
//     onChange?.({ target: { name: "description", value } });
//   };

//   const handleFormat = (command) => {
//     document.execCommand(command, false, null);
//     handleContentChange();
//   };

//   // New file input handlers
//   const handleFileClick = () => {
//     fileInputRef.current.click();
//   };

//   const handleFileChange = (event) => {
//     const file = event.target.files[0];
//     if (file) {
//       setSelectedImage(file);
//       setPreviewImage(URL.createObjectURL(file));
//     }
//   };

//   // Modified handleSubmit to use FormData
//   const handleSubmit = async (e) => {
//     e.preventDefault(); // Prevent default form submission

//     if (!token) {
//       setError("Authentication token is missing. Please log in.");
//       toast.error("Authentication token is missing. Please log in.");
//       return;
//     }

//     // Create FormData instance
//     const formData = new FormData();

//     // Prepare payload and append as JSON string
//     const payload = {
//       type: [formData.incidentType || "Unknown"],
//       date: selectedDate || "2025-07-08",
//       time: selectedTime || "09:59",
//       community_affected: formData.communityAffected || "Unknown",
//       people_involved: [""],
//       stakeholder_role: "Unknown",
//       number_of_people_involved: 0,
//       actions_taken: [""],
//       clo_response: description || "",
//       witnesses: [{ name: "", phone_num: "" }],
//       additional_notes: "",
//       submitted_to: "Safety Department",
//       follow_up_actions: [""],
//       signature: true,
//       report_date: selectedDate || "2025-07-08",
//     };

//     // Append payload as JSON string
//     formData.append("data", JSON.stringify(payload));

//     // Append file if selected
//     if (selectedImage) {
//       formData.append("incident_image", selectedImage);
//     }

//     try {
//       const response = await axios.post(
//         "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//         formData,
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//             // Note: Content-Type is automatically set to multipart/form-data by axios when using FormData
//           },
//         }
//       );
//       console.log("Incident created:", response.data);
//       toast.success("Incident created successfully!");
//       setError(null);
//       onClose(); // Close the form on success
//     } catch (error) {
//       console.error("Error creating incident:", error);
//       const errorMessage =
//         error.response?.data?.message || "Failed to create incident. Please try again.";
//       setError(errorMessage);
//       toast.error(errorMessage);
//     }
//   };

//   return (
//     <div className="h-[575px] flex flex-col">
//       {/* Header */}
//       <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
//         <div className="flex items-center space-x-2">
//           <img src="/add.svg" alt="add" width={20} height={20} />
//           <h2 className="text-white text-lg font-semibold">Add New</h2>
//         </div>
//         <button onClick={onClose} className="text-white hover:text-gray-200">
//           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//           </svg>
//         </button>
//       </div>

//       {/* Body */}
//       <div className="flex-grow p-4 overflow-y-auto">
//         <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
//           <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
//             <img src="/one.svg" alt="one" width={20} height={20} />
//           </span>
//           <span className="text-black">
//             1/6 - <span className="font-bold">INCIDENT OVERVIEW</span>
//           </span>
//         </div>
//         <hr className="border-t border-gray-300 my-4" />

//         {/* Error Message */}
//         {error && (
//           <div className="text-red-500 text-sm mb-4">{error}</div>
//         )}

//         {/* Form */}
//         <form className="space-y-4" onSubmit={handleSubmit}>
//           {/* Incident Type */}
//           <div>
//             <label className="block text-sm text-gray-700">Incident Type</label>
//             <div className="relative">
//               <select
//                 name="incidentType"
//                 value={formData.incidentType}
//                 onChange={onChange}
//                 className="mt-1 block w-full border border-gray-300 rounded-[3px] p-1.5 appearance-none pr-10 focus:outline-none focus:ring-1 focus:ring-blue-500"
//                 required
//               >
//                 <option value="" disabled className="text-sm">
//                   Select
//                 </option>
//                 {incidentTypes.map((type, idx) => (
//                   <option key={idx} value={type}>
//                     {type}
//                   </option>
//                 ))}
//               </select>
//               <FiChevronDown className="absolute right-3 top-2.5 text-gray-500 pointer-events-none" />
//             </div>
//           </div>

//           {/* Date & Time Pickers */}
//           <div className="flex space-x-4">
//             <div className="w-1/2">
//               <label className="block text-sm text-gray-700">Date of Incident</label>
//               <DatePicker value={selectedDate} onChange={handleDateChange} />
//             </div>
//             <div className="w-1/2">
//               <label className="block text-sm text-gray-700">Time of Incident</label>
//               <TimePicker value={selectedTime} onChange={handleTimeChange} />
//             </div>
//           </div>

//           {/* Community Affected */}
//           <div>
//             <label className="block text-sm text-gray-700">Community Affected</label>
//             <div className="relative mt-1">
//               <div className="flex items-center w-full border border-gray-300 rounded-[3px] p-1.5 focus-within:ring-1 focus-within:ring-blue-500 transition-all duration-150 cursor-text">
//                 <FiChevronDown
//                   className="text-blue-600 mr-2 cursor-pointer"
//                   onClick={() => setShowMapDropdown((prev) => !prev)}
//                 />
//                 <input
//                   type="text"
//                   name="communityAffected"
//                   value={formData.communityAffected}
//                   onChange={onChange}
//                   placeholder="Enter"
//                   className="flex-1 bg-transparent outline-none text-sm"
//                   required
//                 />
//               </div>

//               <div
//                 className={`absolute left-0 top-full mt-1 w-40 bg-white border border-gray-300 rounded-[3px] shadow-lg z-20 transition-all duration-200 origin-top-left transform ${
//                   showMapDropdown ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
//                 }`}
//               >
//                 <button
//                   type="button"
//                   onClick={() => handleMapSelect("Map View")}
//                   className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                 >
//                   Map View
//                 </button>
//                 <button
//                   type="button"
//                   onClick={() => handleMapSelect("Satellite View")}
//                   className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                 >
//                   Satellite View
//                 </button>
//               </div>
//             </div>

//             <div className="mt-2">
//               {mapPreviewUrl ? (
//                 <img
//                   src={mapPreviewUrl}
//                   alt="Map Preview"
//                   className="w-full h-40 object-cover rounded-[3px]"
//                 />
//               ) : (
//                 <div className="w-full h-40 bg-gray-100 rounded-[3px] flex items-center justify-center text-gray-500 text-sm">
//                   No location selected
//                 </div>
//               )}
//             </div>
//           </div>

          
//           {/* Description Input (CLO Response Editor) */}
//           <div>
//             <label className="block text-sm text-gray-700 mb-1">Description</label>
//             <div className="relative">
//               <div
//                 ref={contentEditableRef}
//                 contentEditable
//                 onInput={handleContentChange}
//                 className="block w-full border border-gray-300 rounded-[3px] p-2 focus:outline-none focus:ring-1 focus:ring-blue-500 min-h-[120px] max-h-[200px] overflow-y-auto h-[266px]"
//                 style={{ paddingBottom: "30px" }}
//               />
//               <div className="absolute bottom-2 left-2 flex space-x-1 text-xs">
//                 <button type="button" onClick={() => handleFormat("bold")}>
//                   <img src="/bold.svg" alt="bold" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("italic")}>
//                   <img src="/italic.svg" alt="italic" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("underline")}>
//                   <img src="/under.svg" alt="underline" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("insertOrderedList")}>
//                   <img src="/num.svg" alt="num" width={20} height={20} />
//                 </button>
//                 <button type="button" onClick={() => handleFormat("insertUnorderedList")}>
//                   <img src="/item.png" alt="item" width={20} height={20} />
//                 </button>
//               </div>
//               <span className="absolute bottom-2 right-2 text-xs text-gray-500">
//                 {contentEditableRef.current?.textContent.length || 0}/1500
//               </span>
//             </div>
//           </div>

//           {/* Submit Button */}
//           <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
//             <button
//               type="submit"
//               className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
//             >
//               Save & Close
//             </button>
//             <button
//               type="button"
//               onClick={onNext}
//               className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
//             >
//               Next
//             </button>
//           </div>
//         </form>
//       </div>

//       {/* Map Modal */}
//       <MapModal
//         isOpen={showMapModal}
//         onClose={() => setShowMapModal(false)}
//         onSelectLocation={handleLocationSelect}
//         mapType={selectedMapType}
//       />
//     </div>
//   );
// }

// export default Step1Overview;




import React, { useEffect, useRef, useState } from "react";
import { FiChevronDown } from "react-icons/fi";
import axios from "axios";
import toast from "react-hot-toast";
import TextInput from "../../../Ui/TextInput";
import SelectDropdown from "../../../Ui/SelectDropdown";
import FileUpload from "../../../Ui/FileUpload";
import DatePicker from "../../../Ui/DatePicker";
import TimePicker from "../../../Ui/TimePicker";
import MapModal from "../../../Ui/MapModal";
import Description from "../../../Ui/Description";

const Step1Overview = ({ formData = {}, onChange, onNext, onBack, onClose }) => {
  const token = localStorage.getItem("userAccess");
  const [incidentTypes, setIncidentTypes] = useState([
    { value: "Security Breach", label: "Security Breach" },
    { value: "Community Protest", label: "Community Protest" },
    { value: "Land Damage", label: "Land Damage" },
  ]);
  const [selectedDate, setSelectedDate] = useState(formData.dateOfIncident || "");
  const [selectedTime, setSelectedTime] = useState(formData.timeOfIncident || "");
  const [showMapDropdown, setShowMapDropdown] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [selectedMapType, setSelectedMapType] = useState(null);
  const [mapPreviewUrl, setMapPreviewUrl] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchIncidentTypes = async () => {
      try {
        const response = await axios.get(
          "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (response.data && Array.isArray(response.data.type)) {
          setIncidentTypes(response.data.type.map(type => ({ value: type, label: type })));
        }
      } catch (error) {
        console.warn("Could not load incident types, using defaults.");
      }
    };
    fetchIncidentTypes();
  }, [token]);

  const handleDateChange = (e) => {
    const value = e.target.value;
    setSelectedDate(value);
    onChange?.({ target: { name: "dateOfIncident", value } });
  };

  const handleTimeChange = (e) => {
    const value = e.target.value;
    setSelectedTime(value);
    onChange?.({ target: { name: "timeOfIncident", value } });
  };

  const handleMapSelect = (mapType) => {
    setShowMapDropdown(false);
    setSelectedMapType(mapType);
    setShowMapModal(true);
  };

  const handleLocationSelect = ({ lat, lng, address }) => {
    setShowMapModal(false);
    const mapUrl = `https://tile.openstreetmap.org/12/${Math.floor(
      (lng + 180) / 360 * Math.pow(2, 12)
    )}/${Math.floor(
      (1 - Math.log(Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)) / Math.PI) /
        2 *
        Math.pow(2, 12)
    )}.png`;
    setMapPreviewUrl(mapUrl);
    onChange?.({
      target: {
        name: "communityAffected",
        value: address || `Lat: ${lat}, Lng: ${lng}`,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      return;
    }

    const formDataPayload = new FormData();
    const payload = {
      type: [formData.incidentType || "Unknown"],
      date: selectedDate || "2025-07-08",
      time: selectedTime || "09:59",
      community_affected: formData.communityAffected || "Unknown",
      people_involved: [""],
      stakeholder_role: "Unknown",
      number_of_people_involved: 0,
      actions_taken: [""],
      clo_response: formData.description || "",
      witnesses: [{ name: "", phone_num: "" }],
      additional_notes: "",
      submitted_to: "Safety Department",
      follow_up_actions: [""],
      signature: true,
      report_date: selectedDate || "2025-07-08",
    };

    formDataPayload.append("data", JSON.stringify(payload));
    if (formData.incident_image) {
      formDataPayload.append("incident_image", formData.incident_image);
    }

    try {
      const response = await axios.post(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
        formDataPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("Incident created:", response.data);
      toast.success("Incident created successfully!");
      setError(null);
      onClose();
    } catch (error) {
      console.error("Error creating incident:", error);
      const errorMessage =
        error.response?.data?.message || "Failed to create incident. Please try again.";
      setError(errorMessage);
      toast.error(errorMessage);
    }
  };

  return (
    <div className="h-[575px] flex flex-col">
      {/* Header */}
      <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
        <div className="flex items-center space-x-2">
          <img src="/add.svg" alt="add" width={20} height={20} />
          <h2 className="text-white text-lg font-semibold">Add New</h2>
        </div>
        <button onClick={onClose} className="text-white hover:text-gray-200">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Body */}
      <div className="flex-grow p-4 overflow-y-auto">
        <div className="text-sm text-gray-500 mb-3 mt-3 flex items-center">
          <span className="w-4 h-4 flex items-center justify-center mr-2 text-xs font-bold text-blue-700">
            <img src="/one.svg" alt="one" width={20} height={20} />
          </span>
          <span className="text-black">
            1/6 - <span className="font-bold">INCIDENT OVERVIEW</span>
          </span>
        </div>
        <hr className="border-t border-gray-300 my-4" />

        {/* Error Message */}
        {error && (
          <div className="text-red-500 text-sm mb-4">{error}</div>
        )}

        {/* Form */}
        <form className="space-y-4" onSubmit={handleSubmit}>
          {/* Incident Type */}
          <SelectDropdown
            name="incidentType"
            value={formData.incidentType}
            onChange={onChange}
            options={incidentTypes}
            label="Incident Type"
            required
          />

          {/* Date & Time Pickers */}
          <div className="flex space-x-4">
            <div className="w-1/2">
              <DatePicker
                label="Date of Incident"
                value={selectedDate}
                onChange={handleDateChange}
                required
              />
            </div>
            <div className="w-1/2">
              <TimePicker
                label="Time of Incident"
                value={selectedTime}
                onChange={handleTimeChange}
                required
              />
            </div>
          </div>

          {/* Community Affected */}
          <div>
            <label className="block text-sm text-gray-700">Community Affected</label>
            <div className="relative mt-1">
              <div className="relative w-full">
                <TextInput
                  name="communityAffected"
                  value={formData.communityAffected}
                  onChange={onChange}
                  placeholder="Enter"
                  required
                  className="flex-1 bg-transparent outline-none pl-8" // add left padding for icon
                />
                <FiChevronDown
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-blue-600 cursor-pointer"
                  onClick={() => setShowMapDropdown((prev) => !prev)}
                  style={{ pointerEvents: 'auto' }}
                />
              </div>
              <div
                className={`absolute left-0 top-full mt-1 w-40 bg-white border border-gray-300 rounded-[3px] shadow-lg z-20 transition-all duration-200 origin-top-left transform ${
                  showMapDropdown ? "scale-100 opacity-100" : "scale-95 opacity-0 pointer-events-none"
                }`}
              >
                <button
                  type="button"
                  onClick={() => handleMapSelect("Map View")}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Map View
                </button>
                <button
                  type="button"
                  onClick={() => handleMapSelect("Satellite View")}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Satellite View
                </button>
              </div>
            </div>
            <div className="mt-2">
              {mapPreviewUrl ? (
                <img
                  src={mapPreviewUrl}
                  alt="Map Preview"
                  className="w-full h-40 object-cover rounded-[3px]"
                />
              ) : (
                <div className="w-full h-40 bg-gray-100 rounded-[3px] flex items-center justify-center text-gray-500 text-sm">
                  No location selected
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <Description
            label="Description"
            value={formData.description}
            onChange={onChange}
          />

          {/* File Upload */}
          <FileUpload
            label="Upload Evidence"
            value={formData.incident_image}
            onChange={e => {
              // e can be a synthetic event or a File object
              let file;
              if (e && e.target && e.target.files) {
                file = e.target.files[0];
              } else if (e instanceof File) {
                file = e;
              } else if (e && e.file instanceof File) {
                file = e.file;
              }
              if (file) {
                onChange({ target: { name: 'incident_image', value: file } });
              }
            }}
            required
          /> 

          {/* Submit Button */}
          <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
            <button
              type="submit"
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
            >
              Save & Close
            </button>
            <button
              type="button"
              onClick={onNext}
              className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
            >
              Next
            </button>
          </div>
        </form>
      </div>

      {/* Map Modal */}
      <MapModal
        isOpen={showMapModal}
        onClose={() => setShowMapModal(false)}
        onSelectLocation={handleLocationSelect}
        mapType={selectedMapType}
      />
    </div>
  );
};

export default Step1Overview;