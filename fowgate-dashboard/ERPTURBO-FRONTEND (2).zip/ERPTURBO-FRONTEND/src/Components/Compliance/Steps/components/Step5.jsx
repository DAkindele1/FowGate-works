



// import React, { useEffect, useState, useRef } from "react";
// import axios from "axios";

// const DateDisplay = ({ value }) => {
//   return (
//     <div className="w-full border border-gray-300 text-[#707070] rounded-[3px] py-2 text-sm font-medium flex items-center justify-center bg-gray-100">
//       <span className="mr-2 text-[#707070]">
//         {value ? new Date(value).toLocaleDateString() : new Date().toLocaleDateString()}
//       </span>
//       <img src="/calendar.svg" alt="calendar" width={20} height={20} />
//     </div>
//   );
// };

// const SignaturePad = ({ value, onSave, onClose }) => {
//   const canvasRef = useRef(null);
//   const [isDrawing, setIsDrawing] = useState(false);
//   const [signature, setSignature] = useState(value || null);

//   useEffect(() => {
//     const canvas = canvasRef.current;
//     const ctx = canvas.getContext("2d");
//     ctx.lineWidth = 2;
//     ctx.lineCap = "round";
//     ctx.strokeStyle = "#000";

//     if (value) {
//       const img = new Image();
//       img.src = value;
//       img.onload = () => {
//         ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
//       };
//     }

//     const resizeCanvas = () => {
//       const tempCanvas = document.createElement("canvas");
//       tempCanvas.width = canvas.width;
//       tempCanvas.height = canvas.height;
//       const tempCtx = tempCanvas.getContext("2d");
//       tempCtx.drawImage(canvas, 0, 0);
//       canvas.width = canvas.parentElement.clientWidth - 32;
//       canvas.height = 150;
//       ctx.drawImage(tempCanvas, 0, 0, canvas.width, canvas.height);
//     };
//     resizeCanvas();
//     window.addEventListener("resize", resizeCanvas);
//     return () => window.removeEventListener("resize", resizeCanvas);
//   }, [value]);

//   const startDrawing = (e) => {
//     setIsDrawing(true);
//     const canvas = canvasRef.current;
//     const ctx = canvas.getContext("2d");
//     const rect = canvas.getBoundingClientRect();
//     const x = (e.clientX || e.touches[0].clientX) - rect.left;
//     const y = (e.clientY || e.touches[0].clientY) - rect.top;
//     ctx.beginPath();
//     ctx.moveTo(x, y);
//   };

//   const draw = (e) => {
//     if (!isDrawing) return;
//     e.preventDefault();
//     const canvas = canvasRef.current;
//     const ctx = canvas.getContext("2d");
//     const rect = canvas.getBoundingClientRect();
//     const x = (e.clientX || e.touches[0].clientX) - rect.left;
//     const y = (e.clientY || e.touches[0].clientY) - rect.top;
//     ctx.lineTo(x, y);
//     ctx.stroke();
//   };

//   const stopDrawing = () => {
//     setIsDrawing(false);
//     const canvas = canvasRef.current;
//     const ctx = canvas.getContext("2d");
//     ctx.closePath();
//   };

//   const saveSignature = () => {
//     const canvas = canvasRef.current;
//     const dataUrl = canvas.toDataURL("image/png");
//     setSignature(dataUrl);
//     onSave(dataUrl);
//     onClose();
//   };

//   const clearSignature = () => {
//     const canvas = canvasRef.current;
//     const ctx = canvas.getContext("2d");
//     ctx.clearRect(0, 0, canvas.width, canvas.height);
//     setSignature(null);
//     onSave(null);
//   };

//   return (
//     <div className="p-4 bg-white rounded-[3px] shadow-lg">
//       <h3 className="text-sm font-medium text-gray-700 mb-2">Draw Your Signature</h3>
//       <canvas
//         ref={canvasRef}
//         width={300}
//         height={150}
//         className="w-full h-[150px] bg-white border border-gray-300 rounded-[3px]"
//         onMouseDown={startDrawing}
//         onMouseMove={draw}
//         onMouseUp={stopDrawing}
//         onMouseLeave={stopDrawing}
//         onTouchStart={startDrawing}
//         onTouchMove={draw}
//         onTouchEnd={stopDrawing}
//       />
//       <div className="flex justify-between mt-2">
//         <button
//           type="button"
//           onClick={saveSignature}
//           className="text-blue-600 text-xs hover:text-blue-800"
//         >
//           Save Signature
//         </button>
//         <button
//           type="button"
//           onClick={clearSignature}
//           className="text-gray-400 text-xs hover:text-gray-600"
//         >
//           Clear
//         </button>
//       </div>
//       <button
//         type="button"
//         onClick={onClose}
//         className="mt-2 w-full bg-gray-200 text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
//       >
//         Cancel
//       </button>
//     </div>
//   );
// };

// const Step5 = ({ formData, onChange, onClose, onBack, onNext }) => {
//   const token = localStorage.getItem("userAccess");
//   const [reportSubmittedTo, setReportSubmittedTo] = useState(formData.reportSubmittedTo || "");
//   const [followUpAction, setFollowUpAction] = useState(formData.followUpAction || "");
//   const [showSignature, setShowSignature] = useState(!!formData.signature);
//   const [showSignatureModal, setShowSignatureModal] = useState(false);
//   const [officers, setOfficers] = useState(["Officer 1", "Officer 2"]);
//   const [followUps, setFollowUps] = useState(["Review", "Escalate"]);
//   const [cloName, setCloName] = useState(formData.cloName || "");
//   const [error, setError] = useState(null);
//   const currentDate = new Date().toISOString().split("T")[0];

//   useEffect(() => {
//     if (!formData?.reportDate) {
//       onChange?.({ target: { name: "reportDate", value: currentDate } });
//     }

//     if (!token) {
//       setError("Authentication token is missing. Please log in.");
//       return;
//     }

//     const fetchOptions = async () => {
//       try {
//         const res = await axios.get(
//           "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//           {
//             headers: {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         if (res.data?.escalation_officers?.length > 0) {
//           setOfficers(res.data.escalation_officers);
//         }
//         if (res.data?.follow_up_actions?.length > 0) {
//           setFollowUps(res.data.follow_up_actions);
//         }
//       } catch (err) {
//         console.warn("Using fallback options for officers and follow-up actions.");
//         setError("Failed to load options. Using default values.");
//       }
//     };
//     fetchOptions();
//   }, [currentDate, formData?.reportDate, onChange, token]);

//   const handleReportChange = (e) => {
//     const value = e.target.value;
//     setReportSubmittedTo(value);
//     onChange?.({ target: { name: "reportSubmittedTo", value } });
//   };

//   const handleFollowUpChange = (e) => {
//     const value = e.target.value;
//     setFollowUpAction(value);
//     onChange?.({ target: { name: "followUpAction", value: [value] } });
//   };

//   const handleCloNameChange = (e) => {
//     const value = e.target.value;
//     setCloName(value);
//     onChange?.({ target: { name: "cloName", value } });
//   };

//   const handleSaveSignature = (dataUrl) => {
//     setShowSignature(!!dataUrl);
//     onChange?.({ target: { name: "signature", value: dataUrl || null } });
//     setShowSignatureModal(false);
//   };

//   const handleNextClick = () => {
//     if (!followUpAction) {
//       setError("Please select a follow-up action.");
//       return;
//     }
//     setError(null);
//     onNext();
//   };

//   return (
//     <div className="w-full max-w-md mx-auto bg-white rounded-[3px] h-[575px] flex flex-col overflow-hidden shadow">
//       {/* Header */}
//       <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
//         <div className="flex items-center space-x-2">
//           <img src="/add.svg" alt="add" width={20} height={20} />
//           <h2 className="text-white text-lg font-semibold">Add New</h2>
//         </div>
//         <button onClick={onClose} className="text-white hover:text-gray-200">
//           <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
//           </svg>
//         </button>
//       </div>

//       {/* Content */}
//       <div className="flex-1 overflow-y-auto px-6 pt-4 pb-6 text-sm">
//         <div className="flex items-center text-gray-500 mb-6">
//           <img src="/five.svg" alt="step" className="w-4 h-4 mr-2" />
//           <span className="text-black">
//             5/6 - <span className="font-bold">ESCALATION & FOLLOW-UP</span>
//           </span>
//         </div>

//         <hr className="border-t border-gray-100 my-3" />

//         {/* Error Message */}
//         {error && (
//           <div className="text-red-500 text-sm mb-4">{error}</div>
//         )}

//         <form className="space-y-4">
//           {/* CLO Name */}
//           <div>
//             <label className="block text-sm text-gray-700 mb-1">Report Submitted To</label>
//             <div className="relative">
//               <select
//                 name="cloName"
//                 value={cloName}
//                 onChange={handleCloNameChange}
//                 className="w-full h-[44px] border border-gray-300 rounded-md px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
//               >
//                 <option value="">Select</option>
//                 {officers.map((officer, idx) => (
//                   <option key={idx} value={officer}>{officer}</option>
//                 ))}
//               </select>
//               <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400">
//                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                 </svg>
//               </div>
//             </div>
//           </div>

//           {/* Follow-Up Actions Recommended */}
//           <div>
//             <label className="block text-sm text-gray-700 mb-1">Follow-Up Actions Recommended</label>
//             <div className="relative">
//               <select
//                 name="followUpAction"
//                 value={Array.isArray(followUpAction) ? followUpAction[0] || "" : followUpAction}
//                 onChange={handleFollowUpChange}
//                 className="w-full h-[44px] border border-gray-300 rounded-[3px] px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
//                 required
//               >
//                 <option value="">Select</option>
//                 {followUps.map((action, idx) => (
//                   <option key={idx} value={action}>{action}</option>
//                 ))}
//               </select>
//               <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400">
//                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
//                 </svg>
//               </div>
//             </div>
//           </div>

//           {/* Signature and Date */}
//           <div className="flex justify-between items-start space-x-3 mb-8">
//             {/* Signature Section */}
//             <div className="flex-1">
//               {!showSignature ? (
//                 <button
//                   type="button"
//                   onClick={() => setShowSignatureModal(true)}
//                   className="w-full border border-gray-300 rounded-[3px] py-2 text-sm font-medium flex items-center justify-center hover:bg-blue-50"
//                 >
//                   <span className="text-blue-600 text-sm">+ Append Signature</span>
//                 </button>
//               ) : (
//                 <div className="border border-gray-300 rounded-[3px] px-2 py-1 flex items-center justify-between">
//                   <img
//                     src={formData.signature || "/signature-placeholder.png"}
//                     alt="signature"
//                     className="h-12 object-contain"
//                   />
//                   <button
//                     onClick={() => setShowSignatureModal(true)}
//                     className="text-gray-400 hover:text-gray-600 ml-2"
//                   >
//                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                       <path
//                         strokeLinecap="round"
//                         strokeLinejoin="round"
//                         strokeWidth="2"
//                         d="M15.232 5.232l3.536 3.536M9 11l6.586-6.586a2 2 0 112.828 2.828L11.828 13.828a4 4 0 01-1.414.94l-4.121 1.379 1.379-4.121a4 4 0 01.94-1.414z"
//                       />
//                     </svg>
//                   </button>
//                 </div>
//               )}
//             </div>

//             {/* Date Display */}
//             <div className="flex-1">
//               <DateDisplay value={formData.reportDate} />
//             </div>
//           </div>
//         </form>
//       </div>

//       {/* Signature Modal */}
//       {showSignatureModal && (
//         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
//           <div className="w-full max-w-md">
//             <SignaturePad
//               value={formData.signature}
//               onSave={handleSaveSignature}
//               onClose={() => setShowSignatureModal(false)}
//             />
//           </div>
//         </div>
//       )}

//       {/* Footer Navigation */}
//       <div className="flex justify-end space-x-4 p-4 bg-white shadow-[0_-1px_3px_rgba(0,0,0,0.15)] w-full">
//         <button
//           type="button"
//           onClick={onBack}
//           className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
//         >
//           Prev
//         </button>
//         <button
//           type="button"
//           onClick={handleNextClick}
//           className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
//         >
//           Next
//         </button>
//       </div>
//     </div>
//   );
// };

// export default Step5;











import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import toast from "react-hot-toast";

const DateDisplay = ({ value }) => {
  return (
    <div className="w-full border border-gray-300 text-[#707070] rounded-[3px] py-2 text-sm font-medium flex items-center justify-center bg-gray-100">
      <span className="mr-2 text-[#707070]">
        {value ? new Date(value).toLocaleDateString() : new Date().toLocaleDateString()}
      </span>
      <img src="/calendar.svg" alt="calendar" width={20} height={20} />
    </div>
  );
};

const SignaturePad = ({ value, onSave, onClose }) => {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signature, setSignature] = useState(value || null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#000";

    if (value) {
      const img = new Image();
      img.src = value;
      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      };
    }

    const resizeCanvas = () => {
      const tempCanvas = document.createElement("canvas");
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tempCtx = tempCanvas.getContext("2d");
      tempCtx.drawImage(canvas, 0, 0);
      canvas.width = canvas.parentElement.clientWidth - 32;
      canvas.height = 150;
      ctx.drawImage(tempCanvas, 0, 0, canvas.width, canvas.height);
    };
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);
    return () => window.removeEventListener("resize", resizeCanvas);
  }, [value]);

  const startDrawing = (e) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches[0].clientX) - rect.left;
    const y = (e.clientY || e.touches[0].clientY) - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches[0].clientX) - rect.left;
    const y = (e.clientY || e.touches[0].clientY) - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.closePath();
  };

  const saveSignature = () => {
    const canvas = canvasRef.current;
    const dataUrl = canvas.toDataURL("image/png");
    setSignature(dataUrl);
    onSave(dataUrl);
    onClose();
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignature(null);
    onSave(null);
  };

  return (
    <div className="p-4 bg-white rounded-[3px] shadow-lg">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Draw Your Signature</h3>
      <canvas
        ref={canvasRef}
        width={300}
        height={150}
        className="w-full h-[150px] bg-white border border-gray-300 rounded-[3px]"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
      />
      <div className="flex justify-between mt-2">
        <button
          type="button"
          onClick={saveSignature}
          className="text-blue-600 text-xs hover:text-blue-800"
        >
          Save Signature
        </button>
        <button
          type="button"
          onClick={clearSignature}
          className="text-gray-400 text-xs hover:text-gray-600"
        >
          Clear
        </button>
      </div>
      <button
        type="button"
        onClick={onClose}
        className="mt-2 w-full bg-gray-200 text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
      >
        Cancel
      </button>
    </div>
  );
};

const Step5 = ({ formData, onChange, onClose, onBack, onNext }) => {
  const token = localStorage.getItem("userAccess");
  const [reportSubmittedTo, setReportSubmittedTo] = useState(formData.reportSubmittedTo || "");
  const [followUpAction, setFollowUpAction] = useState(formData.followUpAction || "");
  const [showSignature, setShowSignature] = useState(!!formData.signature);
  const [showSignatureModal, setShowSignatureModal] = useState(false);
  const [officers, setOfficers] = useState(["Officer 1", "Officer 2"]);
  const [followUps, setFollowUps] = useState(["Review", "Escalate"]);
  const [cloName, setCloName] = useState(formData.cloName || "");
  const [error, setError] = useState(null);
  const currentDate = new Date().toISOString().split("T")[0];

  useEffect(() => {
    if (!formData?.reportDate) {
      onChange?.({ target: { name: "reportDate", value: currentDate } });
    }

    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      return;
    }

    const fetchOptions = async () => {
      try {
        const res = await axios.get(
          "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (res.data?.escalation_officers?.length > 0) {
          setOfficers(res.data.escalation_officers);
        }
        if (res.data?.follow_up_actions?.length > 0) {
          setFollowUps(res.data.follow_up_actions);
        }
      } catch (err) {
        console.warn("Using fallback options for officers and follow-up actions:", err);
        setError("Failed to load options. Using default values.");
        toast.error("Failed to load options.");
      }
    };
    fetchOptions();
  }, [currentDate, formData?.reportDate, onChange, token]);

  const handleReportChange = (e) => {
    const value = e.target.value;
    setReportSubmittedTo(value);
    onChange?.({ target: { name: "reportSubmittedTo", value } });
  };

  const handleFollowUpChange = (e) => {
    const value = e.target.value;
    setFollowUpAction(value);
    onChange?.({ target: { name: "followUpAction", value: [value] } });
  };

  const handleCloNameChange = (e) => {
    const value = e.target.value;
    setCloName(value);
    onChange?.({ target: { name: "cloName", value } });
  };

  const handleSaveSignature = (dataUrl) => {
    setShowSignature(!!dataUrl);
    onChange?.({ target: { name: "signature", value: dataUrl || null } });
    setShowSignatureModal(false);
  };

  const handleNextClick = () => {
    if (!followUpAction) {
      setError("Please select a follow-up action.");
      toast.error("Please select a follow-up action.");
      return;
    }
    if (!cloName) {
      setError("Please select a CLO name.");
      toast.error("Please select a CLO name.");
      return;
    }
    if (!formData.signature) {
      setError("Please provide a signature.");
      toast.error("Please provide a signature.");
      return;
    }
    setError(null);
    onNext();
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-[3px] h-[575px] flex flex-col overflow-hidden shadow">
      <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
        <div className="flex items-center space-x-2">
          <img src="/add.svg" alt="add" width={20} height={20} />
          <h2 className="text-white text-lg font-semibold">Add New</h2>
        </div>
        <button onClick={onClose} className="text-white hover:text-gray-200">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-6 pt-4 pb-6 text-sm">
        <div className="flex items-center text-gray-500 mb-6">
          <span className="w-4 h-4 flex items-center justify-center mr-2">
            <img src="/five.svg" alt="step" className="w-4 h-4" />
          </span>
          <span className="text-black">
            5/6 - <span className="font-bold">ESCALATION & FOLLOW-UP</span>
          </span>
        </div>
        <hr className="border-t border-gray-100 my-3" />
        {error && (
          <div className="text-red-500 text-sm mb-4">{error}</div>
        )}
        <form className="space-y-4">
          <div>
            <label className="block text-sm text-gray-700 mb-1">Report Submitted To</label>
            <div className="relative">
              <select
                name="cloName"
                value={cloName}
                onChange={handleCloNameChange}
                className="w-full h-[44px] border border-gray-300 rounded-md px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
              >
                <option value="">Select</option>
                {officers.map((officer, idx) => (
                  <option key={idx} value={officer}>{officer}</option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-700 mb-1">Follow-Up Actions Recommended</label>
            <div className="relative">
              <select
                name="followUpAction"
                value={Array.isArray(followUpAction) ? followUpAction[0] || "" : followUpAction}
                onChange={handleFollowUpChange}
                className="w-full h-[44px] border border-gray-300 rounded-[3px] px-3 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
                required
              >
                <option value="">Select</option>
                {followUps.map((action, idx) => (
                  <option key={idx} value={action}>{action}</option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>
          <div className="flex justify-between items-start space-x-3 mb-8">
            <div className="flex-1">
              {!showSignature ? (
                <button
                  type="button"
                  onClick={() => setShowSignatureModal(true)}
                  className="w-full border border-gray-300 rounded-[3px] py-2 text-sm font-medium flex items-center justify-center hover:bg-blue-50"
                >
                  <span className="text-blue-600 text-sm">+ Append Signature</span>
                </button>
              ) : (
                <div className="border border-gray-300 rounded-[3px] px-2 py-1 flex items-center justify-between">
                  <img
                    src={formData.signature || "/signature-placeholder.png"}
                    alt="signature"
                    className="h-12 object-contain"
                  />
                  <button
                    onClick={() => setShowSignatureModal(true)}
                    className="text-gray-400 hover:text-gray-600 ml-2"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M15.232 5.232l3.536 3.536M9 11l6.586-6.586a2 2 0 112.828 2.828L11.828 13.828a4 4 0 01-1.414.94l-4.121 1.379 1.379-4.121a4 4 0 01.94-1.414z"
                      />
                    </svg>
                  </button>
                </div>
              )}
            </div>
            <div className="flex-1">
              <DateDisplay value={formData.reportDate} />
            </div>
          </div>
        </form>
      </div>
      {showSignatureModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="w-full max-w-md">
            <SignaturePad
              value={formData.signature}
              onSave={handleSaveSignature}
              onClose={() => setShowSignatureModal(false)}
            />
          </div>
        </div>
      )}
      <div className="flex justify-end space-x-4 p-4 bg-white shadow-[0_-1px_3px_rgba(0,0,0,0.15)] w-full">
        <button
          type="button"
          onClick={onBack}
          className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
        >
          Prev
        </button>
        <button
          type="button"
          onClick={handleNextClick}
          className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default Step5;
