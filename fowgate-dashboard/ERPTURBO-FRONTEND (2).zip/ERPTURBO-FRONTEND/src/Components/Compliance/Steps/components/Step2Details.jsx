

// import React, { useEffect, useState } from "react";
// import axios from "axios";

// function Step2Details({ formData, onChange, onNext, onBack, onClose }) {
//   const token = localStorage.getItem("userAccess");
//   const [stakeholderRoles, setStakeholderRoles] = useState([
//     "Witness",
//     "Victim",
//     "Authority",
//   ]);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchOptions = async () => {
//       try {
//         const res = await axios.get(
//           "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
//           {
//             headers: {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         if (
//           res.data &&
//           Array.isArray(res.data.stakeholder_roles) &&
//           res.data.stakeholder_roles.length > 0
//         ) {
//           setStakeholderRoles(res.data.stakeholder_roles);
//         }
//       } catch (error) {
//         console.warn("Could not fetch stakeholder roles. Using fallback:", error);
//         setError("Failed to load stakeholder roles. Using default options.");
//       }
//     };

//     if (token) {
//       fetchOptions();
//     } else {
//       setError("Authentication token is missing. Please log in.");
//     }
//   }, [token]);

//   // Handle input changes and transform peopleInvolved into an array
//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     if (name === "peopleInvolved") {
//       // Split by commas or spaces, preserving multi-word names
//       const peopleArray = value
//         .split(/[, ]+/) // Split by commas or spaces (one or more)
//         .map((item) => item.trim())
//         .filter((item) => item); // Remove empty strings
//       console.log("PeopleInvolved input:", {
//         rawInput: value,
//         parsed: peopleArray,
//       }); // Debug
//       onChange({
//         target: {
//           name,
//           value: peopleArray.length > 0 ? peopleArray : [""],
//         },
//       });
//     } else {
//       onChange({ target: { name, value } });
//     }
//   };

//   // Handle input display value for peopleInvolved
//   const getDisplayValue = () => {
//     if (Array.isArray(formData.peopleInvolved)) {
//       return formData.peopleInvolved.join(", ");
//     }
//     return formData.peopleInvolved || "";
//   };

//   // Validate and proceed to the next step
//   const handleNextClick = () => {
//     if (
//       !formData.peopleInvolved ||
//       formData.peopleInvolved.length === 0 ||
//       formData.peopleInvolved[0] === ""
//     ) {
//       setError("Please enter at least one name or group involved.");
//       return;
//     }
//     // Stricter validation to prevent invalid inputs like "nnnn"
//     if (
//       formData.peopleInvolved.some(
//         (name) => !/^[a-zA-Z\s-]+$/.test(name) || name.length < 2
//       )
//     ) {
//       setError(
//         "Names must contain only letters, spaces, or hyphens, and be at least 2 characters."
//       );
//       return;
//     }
//     if (!formData.stakeholderRole) {
//       setError("Please select a stakeholder role.");
//       return;
//     }
//     if (
//       !formData.numberOfPeopleInvolved ||
//       formData.numberOfPeopleInvolved < 0
//     ) {
//       setError("Please enter a valid number of people involved.");
//       return;
//     }
//     setError(null);
//     onNext();
//   };

//   return (
//     <div className="h-[575px] flex flex-col">
//       {/* Header */}
//       <div className="flex justify-between items-center px-4 py-3 rounded-t-md bg-[#1B5FC1]">
//         <div className="flex items-center space-x-2">
//           <img src="/add.svg" alt="add" width={20} height={20} />
//           <h2 className="text-white text-lg font-semibold">Add New</h2>
//         </div>
//         <button
//           onClick={onClose}
//           className="text-white hover:text-gray-200"
//         >
//           <svg
//             className="w-6 h-6"
//             fill="none"
//             stroke="currentColor"
//             viewBox="0 0 24 24"
//           >
//             <path
//               strokeLinecap="round"
//               strokeLinejoin="round"
//               strokeWidth="2"
//               d="M6 18L18 6M6 6l12 12"
//             />
//           </svg>
//         </button>
//       </div>

//       {/* Form Section */}
//       <div className="flex-grow p-4 overflow-y-auto">
//         {/* Progress */}
//         <div className="text-sm text-gray-500 mt-[5%] flex items-center">
//           <span className="w-5 h-5 flex items-center justify-center mr-2 text-xs">
//             <img src="/two.svg" alt="icon" width={20} height={20} />
//           </span>
//           <span className="text-black">
//             2/6 - <span className="font-bold">PARTIES INVOLVED</span>
//           </span>
//         </div>
//         <hr className="border-t border-gray-100 my-3" />

//         {/* Error Message */}
//         {error && <div className="text-red-500 text-sm mb-4">{error}</div>}

//         <form className="space-y-5">
//           {/* Name or Groups Involved */}
//           <div>
//             <label className="block text-sm text-gray-700 mb-1">
//               Name or Groups Involved
//             </label>
//             <input
//               type="text"
//               name="peopleInvolved"
//               value={getDisplayValue()}
//               onChange={handleInputChange}
//               className="block w-[400px] h-[43px] border border-gray-300 rounded-[3px] px-2 py-1 focus:outline-none focus:ring-1 focus:ring-blue-500"
//               placeholder="Type names or groups, separated by commas or spaces"
//               required
//             />
//           </div>

//           {/* Stakeholder Role */}
//           <div>
//             <label className="block text-sm text-gray-700 mb-1">
//               Stakeholder Role
//             </label>
//             <div className="relative">
//               <select
//                 name="stakeholderRole"
//                 value={formData.stakeholderRole || ""}
//                 onChange={handleInputChange}
//                 className="block w-[400px] h-[43px] border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
//                 required
//               >
//                 <option value="" disabled>
//                   Select
//                 </option>
//                 {stakeholderRoles.map((role, idx) => (
//                   <option key={idx} value={role}>
//                     {role}
//                   </option>
//                 ))}
//               </select>
//               <span className="absolute inset-y-0 right-0 flex items-center pr-6 pointer-events-none">
//                 <svg
//                   className="w-5 h-5 text-gray-400"
//                   fill="none"
//                   stroke="currentColor"
//                   viewBox="0 0 24 24"
//                 >
//                   <path
//                     strokeLinecap="round"
//                     strokeLinejoin="round"
//                     strokeWidth="2"
//                     d="M19 9l-7 7-7-7"
//                   />
//                 </svg>
//               </span>
//             </div>
//           </div>

//           {/* Number of People Involved */}
//           <div>
//             <label className="block text-sm text-gray-700 mb-1">
//               Number of People Involved
//             </label>
//             <input
//               type="number"
//               name="numberOfPeopleInvolved"
//               value={formData.numberOfPeopleInvolved || ""}
//               onChange={handleInputChange}
//               className="block w-[400px] h-[43px] border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
//               placeholder="Enter number"
//               min="0"
//               required
//             />
//           </div>
//         </form>
//       </div>

//       {/* Footer Buttons */}
//       <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
//         <button
//           type="button"
//           onClick={onBack}
//           className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
//         >
//           Prev
//         </button>
//         <button
//           type="button"
//           onClick={handleNextClick}
//           className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
//         >
//           Next
//         </button>
//       </div>
//     </div>
//   );
// }

// export default Step2Details;







import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";

function Step2Details({ formData, onChange, onNext, onBack, onClose }) {
  const token = localStorage.getItem("userAccess");
  const [stakeholderRoles, setStakeholderRoles] = useState([
    "Witness",
    "Victim",
    "Authority",
  ]);
  const [error, setError] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null); // New state for file
  const [previewFile, setPreviewFile] = useState(null); // New state for file preview
  const fileInputRef = useRef(null); // Ref for file input

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const res = await axios.get(
          "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/get_default_options", // Corrected endpoint
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (
          res.data &&
          Array.isArray(res.data.stakeholder_roles) &&
          res.data.stakeholder_roles.length > 0
        ) {
          setStakeholderRoles(res.data.stakeholder_roles);
        }
      } catch (error) {
        console.warn("Could not fetch stakeholder roles. Using fallback:", error);
        setError("Failed to load stakeholder roles. Using default options.");
        toast.error("Failed to load stakeholder roles.");
      }
    };

    if (token) {
      fetchOptions();
    } else {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
    }
  }, [token]);

  // Handle input changes and transform peopleInvolved into an array
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "peopleInvolved") {
      const peopleArray = value
        .split(/[, ]+/)
        .map((item) => item.trim())
        .filter((item) => item);
      console.log("PeopleInvolved input:", {
        rawInput: value,
        parsed: peopleArray,
      });
      onChange({
        target: {
          name,
          value: peopleArray.length > 0 ? peopleArray : [""],
        },
      });
    } else {
      onChange({ target: { name, value } });
    }
  };

  // Handle input display value for peopleInvolved
  const getDisplayValue = () => {
    if (Array.isArray(formData.peopleInvolved)) {
      return formData.peopleInvolved.join(", ");
    }
    return formData.peopleInvolved || "";
  };

  // Handle file input
  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      setPreviewFile(URL.createObjectURL(file));
    }
  };

  // Validate and submit form data using FormData
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      setError("Authentication token is missing. Please log in.");
      toast.error("Authentication token is missing. Please log in.");
      return;
    }

    // Validate form fields
    if (
      !formData.peopleInvolved ||
      formData.peopleInvolved.length === 0 ||
      formData.peopleInvolved[0] === ""
    ) {
      setError("Please enter at least one name or group involved.");
      toast.error("Please enter at least one name or group involved.");
      return;
    }
    if (
      formData.peopleInvolved.some(
        (name) => !/^[a-zA-Z\s-]+$/.test(name) || name.length < 2
      )
    ) {
      setError(
        "Names must contain only letters, spaces, or hyphens, and be at least 2 characters."
      );
      toast.error(
        "Names must contain only letters, spaces, or hyphens, and be at least 2 characters."
      );
      return;
    }
    if (!formData.stakeholderRole) {
      setError("Please select a stakeholder role.");
      toast.error("Please select a stakeholder role.");
      return;
    }
    if (
      !formData.numberOfPeopleInvolved ||
      formData.numberOfPeopleInvolved < 0
    ) {
      setError("Please enter a valid number of people involved.");
      toast.error("Please enter a valid number of people involved.");
      return;
    }

    // Create FormData instance
    const formDataPayload = new FormData();
    const payload = {
      people_involved: formData.peopleInvolved || [""],
      stakeholder_role: formData.stakeholderRole || "Unknown",
      number_of_people_involved: parseInt(formData.numberOfPeopleInvolved) || 0,
      // Include fields from Step1Overview or other steps if needed
      type: formData.incidentType ? [formData.incidentType] : ["Unknown"],
      date: formData.dateOfIncident || "2025-07-08",
      time: formData.timeOfIncident || "09:59",
      community_affected: formData.communityAffected || "Unknown",
      clo_response: formData.description || "",
      witnesses: [{ name: "", phone_num: "" }],
      actions_taken: [""],
      additional_notes: "",
      submitted_to: "Safety Department",
      follow_up_actions: [""],
      signature: true,
      report_date: formData.dateOfIncident || "2025-07-08",
    };

    // Append payload as JSON string
    formDataPayload.append("data", JSON.stringify(payload));

    // Append file if selected
    if (selectedFile) {
      formDataPayload.append("document", selectedFile);
    }

    try {
      const response = await axios.post(
        "https://erpturbo-backend.onrender.com/api/oml/incident_reporting/incident/create_incident",
        formDataPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            // Content-Type is automatically set to multipart/form-data
          },
        }
      );
      console.log("Incident created:", response.data);
      toast.success("Incident details submitted successfully!");
      setError(null);
      onClose(); // Close the form on success
    } catch (error) {
      console.error("Error submitting incident details:", error);
      const errorMessage =
        error.response?.data?.message || "Failed to submit incident details. Please try again.";
      setError(errorMessage);
      toast.error(errorMessage);
    }
  };

  // Validate and proceed to the next step
  const handleNextClick = () => {
    if (
      !formData.peopleInvolved ||
      formData.peopleInvolved.length === 0 ||
      formData.peopleInvolved[0] === ""
    ) {
      setError("Please enter at least one name or group involved.");
      toast.error("Please enter at least one name or group involved.");
      return;
    }
    if (
      formData.peopleInvolved.some(
        (name) => !/^[a-zA-Z\s-]+$/.test(name) || name.length < 2
      )
    ) {
      setError(
        "Names must contain only letters, spaces, or hyphens, and be at least 2 characters."
      );
      toast.error(
        "Names must contain only letters, spaces, or hyphens, and be at least 2 characters."
      );
      return;
    }
    if (!formData.stakeholderRole) {
      setError("Please select a stakeholder role.");
      toast.error("Please select a stakeholder role.");
      return;
    }
    if (
      !formData.numberOfPeopleInvolved ||
      formData.numberOfPeopleInvolved < 0
    ) {
      setError("Please enter a valid number of people involved.");
      toast.error("Please enter a valid number of people involved.");
      return;
    }
    setError(null);
    onNext();
  };

  return (
    <div className="h-[575px] flex flex-col">
      {/* Header */}
      <div className="flex justify-between items-center px-4 py-3 rounded-t-md bg-[#1B5FC1]">
        <div className="flex items-center space-x-2">
          <img src="/add.svg" alt="add" width={20} height={20} />
          <h2 className="text-white text-lg font-semibold">Add New</h2>
        </div>
        <button
          onClick={onClose}
          className="text-white hover:text-gray-200"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>

      {/* Form Section */}
      <div className="flex-grow p-4 overflow-y-auto">
        {/* Progress */}
        <div className="text-sm text-gray-500 mt-[5%] flex items-center">
          <span className="w-5 h-5 flex items-center justify-center mr-2 text-xs">
            <img src="/two.svg" alt="icon" width={20} height={20} />
          </span>
          <span className="text-black">
            2/6 - <span className="font-bold">PARTIES INVOLVED</span>
          </span>
        </div>
        <hr className="border-t border-gray-100 my-3" />

        {/* Error Message */}
        {error && <div className="text-red-500 text-sm mb-4">{error}</div>}

        <form className="space-y-5" onSubmit={handleSubmit}>
          {/* Name or Groups Involved */}
          <div>
            <label className="block text-sm text-gray-700 mb-1">
              Name or Groups Involved
            </label>
            <input
              type="text"
              name="peopleInvolved"
              value={getDisplayValue()}
              onChange={handleInputChange}
              className="block w-[400px] h-[43px] border border-gray-300 rounded-[3px] px-2 py-1 focus:outline-none focus:ring-1 focus:ring-blue-500"
              placeholder="Type names or groups, separated by commas or spaces"
              required
            />
          </div>

          {/* Stakeholder Role */}
          <div>
            <label className="block text-sm text-gray-700 mb-1">
              Stakeholder Role
            </label>
            <div className="relative">
              <select
                name="stakeholderRole"
                value={formData.stakeholderRole || ""}
                onChange={handleInputChange}
                className="block w-[400px] h-[43px] border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none"
                required
              >
                <option value="" disabled>
                  Select
                </option>
                {stakeholderRoles.map((role, idx) => (
                  <option key={idx} value={role}>
                    {role}
                  </option>
                ))}
              </select>
              <span className="absolute inset-y-0 right-0 flex items-center pr-6 pointer-events-none">
                <svg
                  className="w-5 h-5 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </span>
            </div>
          </div>

          {/* Number of People Involved */}
          <div>
            <label className="block text-sm text-gray-700 mb-1">
              Number of People Involved
            </label>
            <input
              type="number"
              name="numberOfPeopleInvolved"
              value={formData.numberOfPeopleInvolved || ""}
              onChange={handleInputChange}
              className="block w-[400px] h-[43px] border border-gray-300 rounded-[3px] px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
              placeholder="Enter number"
              min="0"
              required
            />
          </div>

          {/* File Input for Supporting Document */}
          {/* <div>
            <label className="block text-sm text-gray-700 mb-1">
              Supporting Document (Optional)
            </label>
            <div
              className="border border-gray-300 rounded-[3px] p-4 flex items-center justify-center cursor-pointer hover:bg-gray-100"
              onClick={handleFileClick}
            >
              {previewFile ? (
                <img
                  src={previewFile}
                  alt="Document Preview"
                  className="w-32 h-32 object-cover rounded-[3px]"
                />
              ) : (
                <span className="text-gray-500">Click to upload a document or image</span>
              )}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*,.pdf"
                className="hidden"
              />
            </div>
          </div> */}

          {/* Footer Buttons */}
          <div className="mt-auto flex justify-end space-x-4 shadow-[0_-1px_3px_rgba(0,0,0,0.15)] p-4 bg-white w-full">
            <button
              type="button"
              onClick={onBack}
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] w-[100px] hover:bg-gray-300"
            >
              Prev
            </button>
            {/* <button
              type="submit"
              className="border-gray-200 border text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
            >
              Submit
            </button> */}
            <button
              type="button"
              onClick={handleNextClick}
              className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px] hover:bg-[#d0e2fa]"
            >
              Next
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Step2Details;