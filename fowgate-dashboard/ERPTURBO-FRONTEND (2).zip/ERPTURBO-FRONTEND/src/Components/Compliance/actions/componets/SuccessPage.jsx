


import React, { useEffect } from "react";

const SuccessPage = ({  incidentId = '', onClose }) => {
  useEffect(() => {
    const checkmark = document.querySelector(".checkmark");
    if (checkmark) {
      checkmark.classList.add("scale-100");
    }
    return () => {
      if (checkmark) {
        checkmark.classList.remove("scale-100");
      }
    };
  }, []);

  return (
   <div className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white w-full max-w-md p-6 text-center rounded-lg shadow-lg relative">
        {/* Animated Checkmark */}
        <div className="flex justify-center mb-6">
          <div className="checkmark transform scale-0 transition-transform duration-700 ease-out w-20 h-20">
            <svg className="w-full h-full" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="12" fill="#22c55e" />
              <path
                fill="white"
                d="M10.0002 13.172L16.9502 6.222L18.3642 7.636L10.0002 16L5.63623 11.636L7.05023 10.222L10.0002 13.172Z"
              />
            </svg>
          </div>
        </div>

        <h2 className="text-[22px] font-bold text-gray-900 mb-2">Report Updated!</h2>

        <p className="text-gray-600 mb-2 text-sm">
          The incident report
           <span className="font-semibold text-gray-900">({incidentId || "Pending ID"})</span> 
           has been  updated.
        </p>

        <button
          onClick={onClose}
          className="bg-[#1B5FC1] text-white mt-6 w-full py-3 rounded-lg hover:bg-blue-700 transition duration-300"
        >
          Okay
        </button>
      </div>
    </div>
  );
};

export default SuccessPage;

