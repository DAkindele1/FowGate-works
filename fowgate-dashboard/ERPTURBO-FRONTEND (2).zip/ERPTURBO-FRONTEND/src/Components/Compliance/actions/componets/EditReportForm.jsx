


import React, { useState, useEffect, useRef } from 'react';
import { FiClock } from 'react-icons/fi';
import SuccessPage from './SuccessPage';
//import UnsuccessfulPage from './UnsuccessfulPage';
import ConfirmationPage from './ConfirmationPage';

const formatDate = (value) => {
  if (!value || typeof value !== 'string' || !value.includes('-')) return '';
  const [year, month, day] = value.split('-');
  return `${day}/${month}/${year}`;
};

const PickerField = ({ type, name, value, onChange, placeholder, iconType = 'calendar' }) => {
  const inputRef = useRef(null);

  const handleIconClick = () => {
    inputRef.current?.showPicker();
  };

  const isDate = type === 'date';
  const displayValue = value && value.trim() !== ''
    ? isDate
      ? formatDate(value)
      : value
    : '';

  return (
    <div className="relative w-full transition-all duration-300 ease-in-out">
      <input
        ref={inputRef}
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
        pattern={type === 'date' ? '\\d{4}-\\d{2}-\\d{2}' : undefined}
      />

      <div className="flex items-center justify-between w-full border border-gray-300 rounded-[3px] px-3 py-2 min-h-[44px] text-base bg-white relative z-10 pointer-events-none">
        <span className={`truncate ${!displayValue ? 'text-gray-400 italic' : 'text-gray-900'}`}>
          {displayValue || placeholder}
        </span>

        {iconType === 'calendar' ? (
          <img
            src="/calendar.svg"
            alt="calendar"
            width={20}
            height={20}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 cursor-pointer pointer-events-auto hover:scale-110 transition-transform duration-200"
            onClick={handleIconClick}
          />
        ) : (
          <FiClock
            size={20}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer pointer-events-auto hover:scale-110 transition-transform duration-200"
            onClick={handleIconClick}
          />
        )}
      </div>
    </div>
  );
};

const EditReportForm = ({ isOpen, onClose, onSave, incident, defaultOptions }) => {
  const [formData, setFormData] = useState({
    date: '',
    time: '',
    location: '',
    community: '',
    incidentType: '',
    description: '',
  });
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);

  useEffect(() => {
    if (incident) {
      setFormData({
        date: incident.dateOfIncident || '',
        time: incident.timeOfIncident || '',
        location: incident.location || '',
        community: incident.communityAffected || '',
        incidentType: incident.incidentType || incident.type?.[0] || '',
        description: incident.description || incident.additional_notes || '',
      });
    }
  }, [incident]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleConfirmSave = async () => {
    const success = await onSave(formData);
    setShowConfirmation(false);
    if (success) {
      setShowSuccess(true);
    } else {
      setShowError(true);
    }
  };

  if (showSuccess) {
    return (
      <SuccessPage
        incidentId={incident?.id}
        onClose={() => {
          setShowSuccess(false);
          onClose();
        }}
      />
    );
  }

  if (!isOpen || showSuccess) return null;

  return (
    <div className="fixed inset-0 bg-blue bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50">

      <div className="fixed inset-0  rounded-[3px] flex items-center justify-center z-50">
        <div className="bg-white shadow-lg w-full max-w-md h-[90vh] rounded flex flex-col">

          <div className="flex justify-between items-center px-4 py-3 bg-[#1B5FC1]">
            <div className="flex items-center space-x-2">
              <img src="/edit-02.svg" alt="edit" width={20} height={20} />
              <h2 className="text-white text-lg font-semibold">Edit Incident</h2>
            </div>
            <button onClick={onClose} className="text-white hover:text-gray-200">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="overflow-y-auto px-6 py-4 flex-1">
            <div className="text-sm text-gray-500 mb-3 flex items-center">
              <img src="/one.svg" alt="step" width={20} height={20} className="mr-2" />
              <span className="text-black">
                1/6 - <span className="font-bold">INCIDENT OVERVIEW</span>
              </span>
            </div>
            <hr className="border-t border-gray-300 my-4" />

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="w-full min-w-[160px]">
                  <label className="block text-sm text-gray-700 mb-1">Date of Incident</label>
                  <PickerField
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    placeholder="dd/mm/yyyy"
                    iconType="calendar"
                  />
                </div>
                <div className="w-full min-w-[160px]">
                  <label className="block text-sm text-gray-700 mb-1">Time of Incident</label>
                  <PickerField
                    type="time"
                    name="time"
                    value={formData.time}
                    onChange={handleInputChange}
                    placeholder="--:--"
                    iconType="clock"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-700">Location</label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  className="mt-1 p-2 border border-gray-200 rounded w-full"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-700">Community Affected</label>
                <select
                  name="community"
                  value={formData.community}
                  onChange={handleInputChange}
                  className="mt-1 p-2 border border-gray-200 rounded w-full"
                >
                  <option value="" disabled hidden>Select community</option>
                  {defaultOptions.communities.map((community, index) => (
                    <option key={index} value={community}>{community}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-700">Incident Type</label>
                <select
                  name="incidentType"
                  value={formData.incidentType}
                  onChange={handleInputChange}
                  className="mt-1 p-2 border border-gray-200 rounded w-full"
                >
                  <option value="" disabled hidden>Select type</option>
                  {defaultOptions.incidentTypes.map((type, index) => (
                    <option key={index} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-700">Incident Description</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  className="mt-1 p-2 border border-gray-200 rounded w-full h-24"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-gray-200 px-6 py-4 flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="bg-[#E8EFF9] text-[#1B5FC1] w-[100px] px-4 py-2 rounded-[3px]"
            >
              Cancel
            </button>
            <button
              onClick={() => setShowConfirmation(true)}
              className="bg-gray-200 text-sm text-[#292929] px-4 py-2 rounded-[3px] hover:bg-gray-300"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>

      {showConfirmation && (
        <ConfirmationPage
          onClose={() => setShowConfirmation(false)}
          onConfirm={handleConfirmSave}
        />
      )}
    </div>
  );
};

export default EditReportForm;
