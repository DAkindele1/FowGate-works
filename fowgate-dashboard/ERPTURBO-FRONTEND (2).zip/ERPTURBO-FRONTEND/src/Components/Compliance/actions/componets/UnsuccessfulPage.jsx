import React from "react";

const UnsuccessfulPage = ({ incidentId = '', onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex justify-center items-center">
      <div className="bg-white w-full max-w-md p-6 text-center rounded-lg shadow-lg relative">
        {/* Error Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center">
            <svg
              className="w-10 h-10 text-white"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
        </div>

        <h2 className="text-[22px] font-bold text-red-600 mb-2">Update Failed</h2>

        <p className="text-gray-600 mb-2 text-sm">
          The incident report <span className="font-semibold text-gray-900">({incidentId || 'Unknown'})</span> could not be updated due to an error.
        </p>

        <button
          onClick={onClose}
          className="bg-red-600 text-white mt-6 w-full py-3 rounded-lg hover:bg-red-700 transition duration-300"
        >
          Try Again
        </button>
      </div>
    </div>
  );
};

export default UnsuccessfulPage;