const currentUser = {
  name: 'You',
  avatar: 'https://i.pravatar.cc/100?img=9', // your chosen image
};

export default currentUser;
