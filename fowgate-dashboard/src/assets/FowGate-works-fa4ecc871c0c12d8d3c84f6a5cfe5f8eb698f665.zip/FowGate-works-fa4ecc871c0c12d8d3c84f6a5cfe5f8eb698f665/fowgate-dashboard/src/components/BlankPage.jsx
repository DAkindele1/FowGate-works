export default function BlankPage() {
  return (
    <div className="w-full h-screen bg-white flex items-center justify-center">
      <h1 className="text-xl text-gray-600 font-medium">
        Service currently available
      </h1>
    </div>
  );
}